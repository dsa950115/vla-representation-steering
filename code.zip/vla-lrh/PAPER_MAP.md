# Paper → code

Labels as in the LaTeX source. "printed" means the script prints the table rows (LaTeX where noted) at the end of
its output; all files are written to `/content/drive/MyDrive/aclrh/`.

## Q1: probing

| paper | what | script | output |
|---|---|---|---|
| `tab:vla_probe` (main text) | held-out R² of the chunk-induced increment Δψ, OpenVLA-OFT and SmolVLA, linear / additive / bilinear / MLP / unstructured | `probing/q1_probe_extended.py` | printed LaTeX rows, `q1_probe_extended.npz` |
| `tab:smolvla_probe` | SmolVLA columns of the same run | `probing/q1_probe_extended.py` | same |
| `tab:vla_probe_detail` (appendix) | all QoIs, both models | `probing/q1_probe_extended.py` | same |
| `fig:q1_capacity` (main text) | mean held-out R² against parameters per QoI: direct, additive, linear, MLP readout and unstructured MLP at widths 8-256, both models | `probing/q1_capacity_sweep.py` → `probing/q1_capacity_dotplot.py` | `figs/q1_capacity_all_dotplot.(png\|pdf)` |
| `tab:q1_capacity_full` (appendix) | the same for every QoI and width | `probing/q1_capacity_sweep.py` → `probing/q1_capacity_table.py` | `figs/tab_q1_capacity_full.tex` |
| `tab:oft_propagated`, `tab:oft_increment` | OpenVLA-OFT position QoIs: static, increment and propagated probes | `openvla_oft/03_probing_positions.py` (distance QoIs: `05a_probing_task_qoi.py`) | printed, `oft_probe_results*.npz` |

Inputs: `oft_probe.npz` (`openvla_oft/02`), `probe_v2.npz` (`smolvla/s1`). The q1 script re-fits the existing rows with
the same random-number order and checks that their ridge columns are reproduced.

## Corollary 5.4: local steering

| paper | what | script | output |
|---|---|---|---|
| `tab:vla_steer` (main text), `tab:oft_steering` (appendix) | OpenVLA-OFT, one chunk, 20 held-out states per QoI: effect J(8) − J(−8), monotone share, cosine to the simulator gradient; directions: simulator gradient (oracle), Dφᵀλ_ψ (ours), γ_ψ, static, random | heights: `openvla_oft/04_steering_heights.py`; −d(mug,plate), −d(EE,mug₁): `05b_steering_task_qoi.py`; −d(EE,mug₂): `05c_steering_ee_mug2.py` | printed summaries, `oft_steering*.npz` |
| `tab:steer_mlp` (appendix) | the same protocol with directions from nonlinear probes (MLP readout, unstructured MLP) | `openvla_oft/11_steering_mlp_probes.py` | printed `SUMMARY`, `oft_steering_mlp.npz` |
| `fig:oft_curves` | J(α) − J(0) over α for every QoI and direction | `openvla_oft/08_replot_summary_curves.py` (or `06_figures.py`, `RUN_SUMMARY = True`) | `figs/A_summary_curves.png` |
| `fig:vla_closed_loop` (main text) | closed-loop end-effector paths on the camera image + one response curve | `openvla_oft/06_figures.py` (`RUN_B = True`) → `09_plot_main_figure.py` | `figs/main_steering.png` |
| `fig:oft_closed_loop` (appendix) | closed-loop steering towards each mug, two held-out episodes, α ∈ {−16, −8, 0, 8, 16} | `openvla_oft/06_figures.py` (`RUN_B = True`) → `07_replot_trajectories.py` | `figs/B_ep*_*` |
| `tab:smolvla_steer` (main text), `tab:smolvla_steer_all` (appendix) | SmolVLA (stochastic policy): steerable states, effect, monotone share, cosine; all states | `smolvla/s2_steering.py` → `smolvla/s3_steering_analysis.py` (part A) | printed LaTeX rows |
| `tab:smolvla_diag` | variants of the coefficient c at reversed states; probe ranking of the 32 recorded candidate chunks | `smolvla/s3_steering_analysis.py` (part B) | printed, `smolvla_steering_v6_analysis.npz` |
| paragraph after `tab:smolvla_diag` | bimodal outcomes at the reversed / weakly aligned states (11 of 32, cosine 0.34 vs 0.98, 3 of 4 reversals) | `smolvla/s4_bimodality.py` | printed |
| SmolVLA failure analysis (paragraph and figure) | gradient vs. finite differences vs. oracle, probe calibration and best-of-8 selection at bimodal states (s5); separability of the outcome modes (s6); the outcome along a line between chunks (s7); contact events behind the jumps (s8) | `smolvla/s5_diagnose_bimodal.py` → `s6_bimodal_mechanism.py`, `s7_discontinuity.py`, `s8_discontinuity_cause.py` | printed, `figs/smolvla_discontinuity_*` |

## Use case: changing the intent (Figure 2 and project page)

| paper | what | script | output |
|---|---|---|---|
| `fig:usecase` (a) | key frames, new instruction vs. steering, on one held-out start | `use_case/18_intent_confirm.py` → `use_case/17_usecase_figure.py` | `intent_change_confirm/fig_usecase.(png\|pdf)` |
| `fig:usecase` (b) | outcome by steering strength α | `use_case/16_intent_change.py` (sweep on its 13 test starts; or step 18's sweep if it was run) → `17` | same |
| text and caption | changing the instruction: 0 of 50 runs; steering with α = 56 fixed in advance: 19 of 25 new held-out starts | `use_case/18_intent_confirm.py` | printed `SUMMARY`, `intent_change_confirm/results.json` |
| strength sweep | α = 16 / 24 / 40 / 56 on 13 held-out starts (0 / 2 / 4 / 13 successes) | `use_case/16_intent_change.py` | printed, `intent_change/results.json` |
| project page | the use case, method, scope | `site/19_figure_and_site.py` (= 17 + 12) | `site_v1/`, `site_v1.zip` |
| project page, "Against fixed steering vectors" (not in the paper) | CAA (outcome / behaviour contrast) and a probe-weight direction at every strength vs. ours at the fixed one, same starts | `use_case/18b_intent_baselines.py` → `site/20_site_add_baselines.py` (or rebuild with `19`) | `intent_change_confirm/baselines.json` |

## Not generated by code

- `fig:Libero_figure` (task frames).
