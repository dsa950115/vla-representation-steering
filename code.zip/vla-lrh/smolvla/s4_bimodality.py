# ======================================================================
# SmolVLA — bimodality of the policy's outcomes at the steered states  (ONE Colab cell, CPU runtime, ~1 min)
#   Paragraph after tab:smolvla_diag: for the two end-effector QoIs, which steerable (QoI, state) pairs have bimodal
#   outcomes over the K_POL = 16 policy samples, and how the cosine to the oracle and the sign reversals of our
#   direction split between bimodal and unimodal pairs.
#   bimodal: after sorting the 16 increments, the largest gap between consecutive values exceeds BIMODAL_GAP times the
#            larger within-group standard deviation, and the smaller group has at least BIMODAL_MIN samples.
#   The criterion was chosen after inspecting the outcomes (reported as a pattern, not a test).
# Needs on Drive (aclrh/): probe_v2.npz (smolvla/s1), smolvla_steering_v6_partial.pkl (smolvla/s2).
# ======================================================================
import os, pickle
import numpy as np

try:
    from google.colab import drive
    if not os.path.exists("/content/drive/MyDrive"):
        drive.mount("/content/drive")
except ImportError:
    pass
ROOT = os.environ.get("ACLRH_ROOT", "/content/drive/MyDrive/aclrh")
DATA, CKPT = f"{ROOT}/probe_v2.npz", f"{ROOT}/smolvla_steering_v6_partial.pkl"

# ---- constants of smolvla/s2 and s3 (must match) ----
QOI_ALL = ["EE z (control)", "mug1 z", "mug2 z", "-d(mug1,plate) xy", "-d(mug2,plate) xy", "-d(EE,mug1)", "-d(EE,mug2)"]
EE_QOIS = ["EE z (control)", "-d(EE,mug1)"]           # the two end-effector QoIs that were steered
TAUS, K_ST, K_POL, RHO_MIN = [-3.0, -1.5, 0.0, 1.5, 3.0], 16, 16, 0.8
OURS = "Dphi^T lambda_psi"
BIMODAL_GAP, BIMODAL_MIN = 3.0, 3
i0 = TAUS.index(0.0)


def target_plates(Q0r, EP, success):
    out = []
    for m in (3, 6):
        votes = []
        for e in np.where(success)[0]:
            idx = np.where(EP == e)[0]
            if len(idx):
                p = Q0r[idx[-1]]
                votes.append(9 if np.linalg.norm(p[m:m + 2] - p[9:11]) < np.linalg.norm(p[m:m + 2] - p[12:14]) else 12)
        out.append(max(set(votes), key=votes.count) if votes else (9 if m == 3 else 12))
    return out


def make_qoi(tp1, tp2):
    def f(P):
        P = np.asarray(P, dtype=np.float64)
        return np.stack([P[..., 2], P[..., 5], P[..., 8],
                         -np.linalg.norm(P[..., 3:5] - P[..., tp1:tp1 + 2], axis=-1),
                         -np.linalg.norm(P[..., 6:8] - P[..., tp2:tp2 + 2], axis=-1),
                         -np.linalg.norm(P[..., 0:3] - P[..., 3:6], axis=-1),
                         -np.linalg.norm(P[..., 0:3] - P[..., 6:9], axis=-1)], axis=-1)
    return f


def steerable(r):                                       # as in smolvla/s3, part A
    o = r["sim-gradient"]
    return (o["rho"] >= RHO_MIN) and (o["eff"] > 2 * o["SD"][i0] * np.sqrt(2 / K_ST))


reversed_ = lambda d: (d["rho"] <= -RHO_MIN) and (d["eff"] < 0)


def bimodal(v):
    v = np.sort(np.asarray(v, float))
    k = int(np.argmax(np.diff(v)))                      # split at the largest gap
    lo, hi = v[:k + 1], v[k + 1:]
    if min(len(lo), len(hi)) < BIMODAL_MIN:
        return False
    return (v[k + 1] - v[k]) > BIMODAL_GAP * max(lo.std(), hi.std())


d = np.load(DATA)
EP, CS, Q0r, QFr = d["EP"], d["C_STATE"], d["Q0"], d["QF"]
qoi = make_qoi(*target_plates(Q0r, EP, d["success"]))
Q0, QF = qoi(Q0r), qoi(QFr)                              # (NS, 7), (NC, K, 7)
QI = {n: i for i, n in enumerate(QOI_ALL)}
g2j = {int(g): j for j, g in enumerate(CS)}
done = pickle.load(open(CKPT, "rb"))
rows = [v for k, v in done.items() if k[0] == "row" and k[2] in EE_QOIS]
qn_of = {id(v): k[2] for k, v in done.items() if k[0] == "row"}

pairs = []
for r in rows:
    if not steerable(r):
        continue
    qn, g = qn_of[id(r)], int(r["state"])
    inc = QF[g2j[g], :K_POL, QI[qn]] - Q0[g, QI[qn]]   # outcomes of the 16 policy samples at this state
    pairs.append(dict(qoi=qn, state=g, bimodal=bool(bimodal(inc)), cos=float(r["cos_sim"][OURS]),
                      rev=bool(reversed_(r[OURS])), inc_mm=np.round(1e3 * np.sort(inc), 1)))

B = [p for p in pairs if p["bimodal"]]; U = [p for p in pairs if not p["bimodal"]]
med = lambda P: float(np.median([p["cos"] for p in P])) if P else float("nan")
print(f"steerable (QoI, state) pairs for {EE_QOIS}: {len(pairs)}")
print(f"  bimodal  {len(B):2d} | median cos to the oracle {med(B):+.2f} | "
      f"reversals {sum(p['rev'] for p in B)}")
print(f"  unimodal {len(U):2d} | median cos to the oracle {med(U):+.2f} | "
      f"reversals {sum(p['rev'] for p in U)}")
print("\nreversed pairs (sorted increments, mm):")
for p in pairs:
    if p["rev"]:
        print(f"  state {p['state']:5d} {p['qoi']:16s} bimodal {p['bimodal']!s:5s} {p['inc_mm'].tolist()}")
print("\npaper (appendix, after tab:smolvla_diag): 11 of 32 bimodal, median cos 0.34 vs 0.98, 3 of the 4 reversals bimodal")
