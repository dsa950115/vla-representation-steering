# ======================================================================
# SmolVLA — DIAGNOSIS of the steering failures at bimodal states  (ONE Colab cell, GPU runtime, A100)
#
# Question: at the steered states where the policy's outcomes are bimodal (smolvla/s4), is the poor alignment with
# the oracle an estimation error (finite differences with few samples) or a real effect?
# For every steerable (QoI, state) pair of the two end-effector QoIs in the s2 run (same folds, PCA, probes):
#   ours, autodiff  pathwise gradient of c . E_eps[S(u)] through the flow-matching sampler, 128 samples
#   ours, FD        mean-signature Jacobian by central differences, 64 samples, steps 0.1 and 0.25
#   oracle          simulated expected QoI by central differences, 64 samples (s2: 8), steps 0.1 and 0.25
#   reliability     cosine between the two halves of the samples of each estimate
#   evaluation      64 fresh samples per strength (s2: 16), tau in {+-0.5, +-1.5, +-3}
# Needs on Drive (aclrh/): probe_v2.npz (s1), smolvla_steering_v6_partial.pkl (s2).
# Writes aclrh/smolvla_diagnose_s5.npz; per-pair checkpoint aclrh/smolvla_diagnose_s5_partial.pkl (re-run to resume).
# ======================================================================

import sys
import subprocess

AUTO_SHUTDOWN = True         # disconnect and delete the runtime when the run ends (finished or crashed), after syncing Drive

PY = sys.executable

# ---------------------------------------------------------------- Google Drive (data, checkpoint and results live there)
import os as _os0
if not _os0.path.isdir("/content/drive/MyDrive"):
    from google.colab import drive
    drive.mount("/content/drive")
assert _os0.path.exists("/content/drive/MyDrive/aclrh/smolvla_steering_v6_partial.pkl"), \
    "smolvla_steering_v6_partial.pkl not found in /content/drive/MyDrive/aclrh/ (run smolvla/s2 first)"
assert _os0.path.exists("/content/drive/MyDrive/aclrh/probe_v2.npz"), \
    "probe_v2.npz not found in /content/drive/MyDrive/aclrh/ (the SmolVLA probing data)"

print("=" * 100)
print("0. FRESH COLAB ENVIRONMENT SETUP")
print("=" * 100)
print("Python:", sys.version)

subprocess.run([PY, "-m", "pip", "install", "-q", "--upgrade", "pip>=25,<26"], check=True)

torch_check = subprocess.run(
    [PY, "-c", r"""
import torch
from packaging.version import Version
v = Version(torch.__version__.split("+")[0])
print(torch.__version__)
assert Version("2.7") <= v < Version("2.12")
"""],
    stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
)
print("Torch check:", torch_check.stdout.strip())

# GPU present but a CPU-only torch build installed -> reinstall the CUDA build
import shutil as _sh
_has_gpu = (_sh.which("nvidia-smi") is not None and
            subprocess.run(["nvidia-smi"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode == 0)
if _has_gpu and "+cpu" in torch_check.stdout:
    print("GPU detected but torch is a CPU build -> installing torch 2.11.0 (CUDA 12.8) ...")
    subprocess.run([PY, "-m", "pip", "install", "-q", "--force-reinstall",
                    "torch==2.11.0", "torchvision==0.26.0",
                    "--index-url", "https://download.pytorch.org/whl/cu128"], check=True)
elif not _has_gpu:
    raise RuntimeError("No GPU on this machine (nvidia-smi not available). Back up /content, then "
                       "Runtime -> Disconnect and delete runtime, reconnect with a GPU runtime.")
if torch_check.returncode != 0:
    subprocess.run([PY, "-m", "pip", "install", "-q", "--upgrade",
                    "torch==2.11.0", "torchvision==0.26.0"], check=True)

import os as _os
_os.environ["CMAKE_POLICY_VERSION_MINIMUM"] = "3.5"   # harmless; guards old CMake projects


def pip(*args, label=""):
    """pip with the error actually shown (Colab hides child-process stderr otherwise)."""
    r = subprocess.run([PY, "-m", "pip", "install", "-q", *args],
                       stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    if r.returncode != 0:
        print(f"\n----- pip failed ({label}) -----")
        print("\n".join(r.stdout.strip().splitlines()[-60:]))
        raise RuntimeError(f"pip install failed: {label}")
    print(f"  ok: {label}")


print("Installing ...")
pip("--upgrade", "--upgrade-strategy", "only-if-needed",
    "numpy==2.2.6",
    "lerobot[smolvla]==0.6.1",
    "transformers==5.5.4",
    "av==15.1.0",
    "datasets>=4.8.0,<5.0.0",
    "pandas>=2.0.0,<3.0.0",
    "pyarrow>=21.0.0,<30.0.0",
    "jsonlines>=4.0.0,<5.0.0",
    "scikit-learn==1.9.1",
    label="lerobot + smolvla")

# LIBERO sim WITHOUT robomimic: hf-libero pins robomimic==0.2.0 -> egl_probe, whose CMake
# project (cmake_minimum_required 2.8.12) does not build with CMake 4. The simulator path
# (libero.libero.envs / benchmark / asset download) never imports robomimic, so install
# the three sim packages with --no-deps and their real runtime deps explicitly.
pip("--no-deps", "hf-libero>=0.1.4,<0.2.0", "robosuite==1.4.0", "bddl==1.0.1",
    label="hf-libero / robosuite / bddl (no-deps)")
pip("--upgrade-strategy", "only-if-needed",
    "mujoco>=3.0.0,<3.9.0", "numba>=0.61", "scipy", "Pillow", "opencv-python-headless",
    "easydict", "gymnasium>=0.29.0", "h5py", "imageio", "matplotlib", "termcolor", "tqdm",
    "cloudpickle", "pyyaml", "networkx", "huggingface_hub", "PyOpenGL",
    label="sim runtime deps")

# Colab ships a torchao that is older than what the preinstalled diffusers expects (FqnToConfig);
# lerobot imports diffusers through the GR00T policy. Quantization is not used here -> remove torchao,
# diffusers then skips its torchao quantizer.
r_ = subprocess.run([PY, "-m", "pip", "uninstall", "-y", "-q", "torchao"], stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT, text=True)
print("  ok: torchao removed" if r_.returncode == 0 else "  (torchao not installed)")

VERIFY = r'''
import os, importlib.util
os.environ.setdefault("MUJOCO_GL", "egl")
os.environ.setdefault("PYOPENGL_PLATFORM", "egl")
import importlib.metadata as im
for p in ["torch", "lerobot", "transformers", "numpy", "hf-libero", "robosuite", "mujoco"]:
    try:
        print(f"{p:14s}: {im.version(p)}")
    except Exception as e:
        print(f"{p:14s}: MISSING ({e})")
import torch
assert torch.cuda.is_available(), "Colab GPU runtime is required."
assert importlib.util.find_spec("libero") is not None, "libero not importable"
import yaml
_cfg = os.path.expanduser("~/.libero"); os.makedirs(_cfg, exist_ok=True)
_f = os.path.join(_cfg, "config.yaml")
if not os.path.exists(_f):
    _root = os.path.join(list(importlib.util.find_spec("libero").submodule_search_locations)[0], "libero")
    yaml.dump({"benchmark_root": _root, "bddl_files": _root + "/bddl_files",
               "init_states": _root + "/init_files", "datasets": _root + "/../datasets",
               "assets": _root + "/assets"}, open(_f, "w"))
import mujoco, robosuite
from libero.libero import benchmark
from libero.libero.envs import OffScreenRenderEnv
print("libero suites:", sorted(benchmark.get_benchmark_dict().keys())[:6])
from lerobot.policies.smolvla.modeling_smolvla import SmolVLAPolicy
print("GPU:", torch.cuda.get_device_name(0))
print("ENVIRONMENT SUCCESS")
'''
verify = subprocess.run([PY, "-c", VERIFY], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
print(verify.stdout)
if verify.returncode != 0:
    raise RuntimeError("Environment setup failed. The experiment has NOT started.")


# ======================================================================
# EXPERIMENT SCRIPT
# ======================================================================

SCRIPT = r'''
import os
os.environ.setdefault("MUJOCO_GL", "egl")
os.environ.setdefault("PYOPENGL_PLATFORM", "egl")
os.environ["TOKENIZERS_PARALLELISM"] = "false"
os.environ["HF_HUB_DISABLE_TELEMETRY"] = "1"

import warnings
warnings.filterwarnings("ignore")

import importlib.util
import math
import time

import numpy as np
import torch
import yaml

# ----------------------------------------------------------------------
# LIBERO asks for a config path interactively on first import -> pre-create it
# ----------------------------------------------------------------------
_cfg_dir = os.environ.setdefault("LIBERO_CONFIG_PATH", os.path.expanduser("~/.libero"))
os.makedirs(_cfg_dir, exist_ok=True)
_cfg_file = os.path.join(_cfg_dir, "config.yaml")
if not os.path.exists(_cfg_file):
    _root = os.path.join(list(importlib.util.find_spec("libero").submodule_search_locations)[0], "libero")
    with open(_cfg_file, "w") as f:
        yaml.dump({
            "benchmark_root": _root,
            "bddl_files": os.path.join(_root, "bddl_files"),
            "init_states": os.path.join(_root, "init_files"),
            "datasets": os.path.join(_root, "..", "datasets"),
            "assets": os.path.join(_root, "assets"),
        }, f)

import mujoco
from libero.libero import benchmark, get_libero_path
from libero.libero.envs import OffScreenRenderEnv

from sklearn.linear_model import RidgeCV
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.model_selection import GroupKFold

from lerobot.policies.factory import make_pre_post_processors
from lerobot.policies.smolvla.modeling_smolvla import SmolVLAPolicy
from lerobot.policies.common.vla_utils import make_att_2d_masks
from lerobot.policies.common.flow_matching import euler_integrate


# ======================================================================
# 1. SETTINGS
# ======================================================================

SEED = 0
MODEL_ID = "lerobot/smolvla_libero"
SUITE = "libero_10"
TASK_LANG = "put the white mug on the left plate and put the yellow and white mug on the right plate"

N_EPISODES = 50              # all LIBERO initial layouts of the task
MAX_STEPS = 520              # libero_10 limit used by lerobot-eval
NUM_STEPS_WAIT = 10          # settle steps after reset (same as lerobot)
SNAP_STRIDE = 16             # snapshot every k env steps
MAX_SNAPS_PER_EP = 30

H = 20                       # candidate chunk horizon (env steps, 1 s at 20 Hz)
K_POL = 16                   # policy-sampled candidates per candidate state
K_PERT = 16                  # smooth perturbations of policy candidates
CAND_EVERY = 2               # candidate chunks at every 2nd snapshot (static data at all)
PERT_SCALE = 0.3             # std of perturbation (normalized action units) on dims 0..5
PERT_KNOTS = 5

PCA_K = 32                   # representation dims after PCA (fit on train states only)
MOVE_TOL = 1e-3              # "QoI moves at this state" threshold (m)

CACHE = "/content/probe_v2.npz"
PARTIAL = "/content/probe_v2_partial.npz"     # per-episode checkpoint; rerun resumes from it
REUSE_CACHE = True           # skip simulation if the final cache exists
N_WORKERS = max(1, min((os.cpu_count() or 2) - 1, 16))
JOB_SPLIT = 4                # candidate blocks per snapshot (load balancing)

rng = np.random.default_rng(SEED)
torch.manual_seed(SEED)
assert torch.cuda.is_available()
DEVICE = torch.device("cuda")
T0 = time.time()


def stamp(msg):
    print(f"[{time.time() - T0:7.1f}s] {msg}", flush=True)


def header(title):
    print("\n" + "=" * 100)
    print(title)
    print("=" * 100, flush=True)


QOI_NAMES = ["ee_x", "ee_y", "ee_z", "mug1_x", "mug1_y", "mug1_z", "mug2_x", "mug2_y", "mug2_z",
             "plate1_x", "plate1_y", "plate1_z", "plate2_x", "plate2_y", "plate2_z"]


# ======================================================================
# 2. POLICY (same verified intervention path as before)
# ======================================================================

policy = None
preprocessor = postprocessor = None
PREFIX_DTYPE = None


def load_policy():
    global policy, preprocessor, postprocessor, CH, MAD, N_EXEC
    policy = SmolVLAPolicy.from_pretrained(MODEL_ID).to(torch.float32).to(DEVICE).eval()
    preprocessor, postprocessor = make_pre_post_processors(policy.config, pretrained_path=MODEL_ID)
    CH = policy.config.chunk_size
    MAD = policy.config.max_action_dim
    N_EXEC = policy.config.n_action_steps
    print("chunk_size:", CH, "| n_action_steps:", N_EXEC, "| num_steps:", policy.config.num_steps)


def quat2axisangle(q):
    """(x, y, z, w) -> axis-angle; identical to lerobot LiberoProcessorStep."""
    q = np.asarray(q, dtype=np.float64)
    w = float(np.clip(q[3], -1.0, 1.0))
    den = math.sqrt(max(1.0 - w * w, 0.0))
    if den < 1e-10:
        return np.zeros(3)
    return q[:3] / den * (2.0 * math.acos(w))


def obs_to_arrays(raw):
    """LIBERO raw obs -> (agentview, wrist, state8) in the HuggingFaceVLA/libero convention
    (images rotated 180 deg; state = eef pos, axis-angle, gripper qpos)."""
    img1 = np.ascontiguousarray(raw["agentview_image"][::-1, ::-1])
    img2 = np.ascontiguousarray(raw["robot0_eye_in_hand_image"][::-1, ::-1])
    state = np.concatenate([raw["robot0_eef_pos"], quat2axisangle(raw["robot0_eef_quat"]),
                            raw["robot0_gripper_qpos"]]).astype(np.float32)
    return img1, img2, state


def policy_batch(img1, img2, state):
    to_t = lambda im: torch.from_numpy(im).permute(2, 0, 1).float() / 255.0
    return preprocessor({
        "observation.images.image": to_t(img1),
        "observation.images.image2": to_t(img2),
        "observation.state": torch.from_numpy(state),
        "task": TASK_LANG,
    })


@torch.no_grad()
def prefix_of(batch):
    global PREFIX_DTYPE
    b = policy._prepare_batch(batch)
    images, img_masks = policy.prepare_images(b)
    state = policy.prepare_state(b)
    prefix, pad, att = policy.model.embed_prefix(
        images, img_masks, b["observation.language.tokens"],
        b["observation.language.attention_mask"], state=state,
    )
    PREFIX_DTYPE = prefix.dtype
    return prefix.float().cpu(), pad.cpu(), att.cpu()


@torch.inference_mode()
def build_kv(P, pm, am, B):
    P = P.to(DEVICE, PREFIX_DTYPE).expand(B, -1, -1).contiguous()
    pad = pm.to(DEVICE).expand(B, -1).contiguous()
    att = am.to(DEVICE).expand(B, -1).contiguous()
    _, kv = policy.model.vlm_with_expert.forward(
        attention_mask=make_att_2d_masks(pad, att), position_ids=torch.cumsum(pad, 1) - 1,
        past_key_values=None, inputs_embeds=[P, None], use_cache=policy.config.use_cache,
    )
    return pad, kv


@torch.inference_mode()
def denoise(pad, kv, noise):
    x = euler_integrate(
        lambda x_t, t: policy.model.denoise_step(
            x_t=x_t, prefix_pad_masks=pad, past_key_values=kv, timestep=t),
        noise, policy.config.num_steps)
    return x[:, :, :7]


@torch.inference_mode()
def sample_chunks(P, pm, am, K, seed):
    pad, kv = build_kv(P, pm, am, K)
    torch.manual_seed(seed)
    noise = policy.model.sample_noise((K, CH, MAD), DEVICE)
    a = postprocessor(denoise(pad, kv, noise))
    return torch.as_tensor(a).float().cpu().numpy()          # (K, CH, 7)


# ======================================================================
# 3. SIMULATOR
#
# main process : one camera env (closed-loop policy rollouts need images)
# workers      : camera-FREE envs (no renderer at all) that replay candidate chunks
#                from saved MuJoCo states, one per CPU core
# ======================================================================

env = None
BDDL = None
DUMMY = np.array([0, 0, 0, 0, 0, 0, -1], dtype=np.float64)
_SPEC = mujoco.mjtState.mjSTATE_INTEGRATION


def find_task():
    suite = benchmark.get_benchmark_dict()[SUITE]()
    ids = [i for i, t in enumerate(suite.tasks) if t.language == TASK_LANG]
    assert ids, f"task not found in {SUITE}"
    task = suite.get_task(ids[0])
    bddl = os.path.join(get_libero_path("bddl_files"), task.problem_folder, task.bddl_file)
    init_path = os.path.join(get_libero_path("init_states"), task.problem_folder,
                             os.path.basename(task.init_states_file))
    return ids[0], bddl, torch.load(init_path, weights_only=False)


def make_env():
    global env, INIT_STATES, BDDL
    tid, BDDL, INIT_STATES = find_task()
    env = OffScreenRenderEnv(bddl_file_name=BDDL, camera_heights=256, camera_widths=256,
                             control_freq=20)
    env.seed(SEED)
    env.reset()
    print("task id:", tid, "| init states:", len(INIT_STATES))


def set_cameras(e, on):
    """robosuite: `enabled` controls whether the sensor (renderer) runs at all;
    `active` only controls whether the value is returned. Toggle both."""
    for name in ("agentview_image", "robot0_eye_in_hand_image"):
        for attr in ("enabled", "active"):
            try:
                e.env.modify_observable(observable_name=name, attribute=attr, modifier=on)
            except Exception as ex:
                print(f"  [warn] could not set {attr}={on} on {name}: {ex}")


def reset_episode(ep):
    env.reset()
    env.env.ignore_done = True
    set_cameras(env, True)
    raw = env.set_init_state(INIT_STATES[ep % len(INIT_STATES)])
    for _ in range(NUM_STEPS_WAIT):
        raw, _, _, _ = env.step(DUMMY)
    for r in env.robots:
        r.controller.use_delta = True
    return raw


def save_sim(e):
    """Full integration state + the Panda gripper's internal `current_action`
    (not part of the MuJoCo state)."""
    M, D = e.sim.model._model, e.sim.data._data
    s = np.empty(mujoco.mj_stateSize(M, _SPEC))
    mujoco.mj_getState(M, D, s, _SPEC)
    g = getattr(e.robots[0].gripper, "current_action", None)
    return s, (None if g is None else np.array(g, copy=True))


def load_sim(e, snap):
    s, g = snap
    M, D = e.sim.model._model, e.sim.data._data
    mujoco.mj_setState(M, D, s, _SPEC)
    mujoco.mj_forward(M, D)
    if g is not None:
        e.robots[0].gripper.current_action = np.array(g, copy=True)
    e.robots[0].controller.update(force=True)


def qoi_now(e):
    """raw positions: EE, white mug, yellow-white mug, left plate, right plate (15 numbers)."""
    d = e.sim.data
    bid = e.env.obj_body_id
    return np.concatenate([np.array(d.site_xpos[e.robots[0].eef_site_id]),
                           np.array(d.body_xpos[bid["porcelain_mug_1"]]),
                           np.array(d.body_xpos[bid["white_yellow_mug_1"]]),
                           np.array(d.body_xpos[bid["plate_1"]]),
                           np.array(d.body_xpos[bid["plate_2"]])])


def true_state(e):
    d = e.sim.data
    bid = e.env.obj_body_id
    r = e.robots[0]
    parts = [np.array(d.site_xpos[r.eef_site_id]), np.array(d.site_xmat[r.eef_site_id]).ravel()]
    try:
        parts.append(np.array(d.qpos[r._ref_gripper_joint_pos_indexes]))
    except Exception:
        pass
    for name in ("porcelain_mug_1", "white_yellow_mug_1"):
        parts += [np.array(d.body_xpos[bid[name]]), np.array(d.body_xquat[bid[name]])]
    for name in ("plate_1", "plate_2"):
        parts.append(np.array(d.body_xpos[bid[name]]))
    return np.concatenate(parts)


def run_candidate(e, snap, actions):
    load_sim(e, snap)
    for a in actions:
        e.step(np.asarray(a, dtype=np.float64))
    return qoi_now(e)


def perturb(chunks, n):
    """Smooth random perturbation of randomly chosen policy chunks (dims 0..5; gripper kept)."""
    base = chunks[rng.integers(len(chunks), size=n)].copy()
    knots = rng.normal(0.0, PERT_SCALE, size=(n, PERT_KNOTS, 6))
    grid = np.linspace(0, 1, H)
    kx = np.linspace(0, 1, PERT_KNOTS)
    W = np.stack([np.interp(grid, kx, np.eye(PERT_KNOTS)[j]) for j in range(PERT_KNOTS)], axis=1)
    base[:, :, :6] += np.einsum("hk,nkd->nhd", W, knots)
    return np.clip(base, -1.0, 1.0)


# ---------------- workers (spawned; each builds a renderer-free env) ----------------
_WENV = None


def _worker_init(bddl):
    global _WENV
    torch.set_num_threads(1)
    from libero.libero.envs.env_wrapper import ControlEnv
    _WENV = ControlEnv(bddl_file_name=bddl, use_camera_obs=False, has_renderer=False,
                       has_offscreen_renderer=False, control_freq=20, ignore_done=True)
    _WENV.reset()
    for r in _WENV.robots:
        r.controller.use_delta = True


def _worker_job(args):
    sim, grip, cands = args
    return np.stack([run_candidate(_WENV, (sim, grip), c) for c in cands])



# ======================================================================
# 4. STEERING v6 — Corollary 5.4 on a stochastic (flow-matching) policy, OpenVLA-OFT protocol
#
#   representation   prefix (VLM input embeddings), z = 32 leading PCA coordinates fitted on the
#                    fitting fold only, standardized
#   Phi(z')          = E_eps[S(u(z', eps))], mean chunk signature (flow matching: u = T(prefix, eps))
#   lambda_psi(x)    = D Phi(z(x))^T c(x),  c(x) = non-empty-word part of L_psi^* z(x)
#                    D Phi by central differences along the 32 axes with common gradient noise
#   oracle           grad_z E_eps[psi(F_u x)]: the same displacements, executed in the simulator
#   gamma_psi(u0)    a + W E_eps[S(u)]: the increment probe differentiated in its state argument,
#                    chunk signature held at the policy mean (no head information)
#   static           static probe direction;  global: mean of the normalized lambda_psi of
#                    fitting-fold states, applied unchanged to every held-out state
#   evaluation       fresh noise, shared across strengths and directions; 2 folds of episodes
# ======================================================================

import pickle
from scipy.stats import spearmanr
from sklearn.linear_model import RidgeCV


def sig2(U):
    """time-augmented signature up to level 2, dX = (dt, u dt)."""
    U = np.asarray(U, dtype=np.float64)
    N, Hh, A = U.shape
    dt = 1.0 / Hh
    dx = np.concatenate([np.full((N, Hh, 1), dt), U * dt], axis=2)
    prev = np.cumsum(dx, axis=1) - dx
    S2 = np.einsum("nti,ntj->nij", prev, dx) + 0.5 * np.einsum("nti,ntj->nij", dx, dx)
    return np.concatenate([dx.sum(axis=1), S2.reshape(N, -1)], axis=1)


DATA = "/content/drive/MyDrive/aclrh/probe_v2.npz"
OUT_ST = "/content/drive/MyDrive/aclrh/smolvla_steering_v6.npz"
CKPT = "/content/drive/MyDrive/aclrh/smolvla_steering_v6_partial.pkl"     # per-state checkpoint (resume)
QOI_ALL = ["EE z (control)", "mug1 z", "mug2 z", "-d(mug1,plate) xy", "-d(mug2,plate) xy",
           "-d(EE,mug1)", "-d(EE,mug2)"]
QOI_RUN = ["mug1 z", "mug2 z", "-d(mug1,plate) xy", "-d(EE,mug1)", "EE z (control)"]   # add the other two later
MOVE_FILTER = {"mug1 z", "mug2 z", "-d(mug1,plate) xy", "-d(mug2,plate) xy"}            # the mug must respond
N_PER_FOLD = 10              # steered states per QoI and fold (2 folds -> 20 per QoI)
PCA_K = 32
MOVE_MM, MIN_FRAC = 2e-3, 0.5
H_Z = 0.25                   # finite-difference step, standardized PCA units
K_J = 32                     # chunks per Jacobian evaluation (common gradient noise)
K_G = 8                      # of those, simulated for the oracle (0 = no oracle)
K_ST = 16                    # chunks per steering level (fresh noise, shared across levels and directions)
TAUS = [-3.0, -1.5, 0.0, 1.5, 3.0]
STEP_REL = 0.003             # ||delta prefix|| / ||prefix|| per unit tau, identical for every direction
N_RANDOM = 3
N_GLOBAL = 8                 # fitting-fold states averaged into the global direction (0 = skip)
RIDGE = np.logspace(-2, 5, 15)
DIRS = ["sim-gradient", "Dphi^T lambda_psi", "gamma_psi", "static", "global"]


def target_plates(Q0r, EP, success):
    """target plate of each mug = the plate it is nearest to at the last snapshot of successful episodes"""
    out = []
    for m in (3, 6):
        votes = []
        for e in np.where(success)[0]:
            idx = np.where(EP == e)[0]
            if len(idx):
                p = Q0r[idx[-1]]
                votes.append(9 if np.linalg.norm(p[m:m + 2] - p[9:11]) < np.linalg.norm(p[m:m + 2] - p[12:14]) else 12)
        out.append(max(set(votes), key=votes.count) if votes else (9 if m == 3 else 12))
        print(f"  mug at {m}: target plate index {out[-1]} ({votes.count(out[-1])}/{len(votes)} successful episodes)")
    return out


def make_qoi(tp1, tp2):
    def f(P):
        P = np.asarray(P, dtype=np.float64)
        return np.stack([P[..., 2], P[..., 5], P[..., 8],
                         -np.linalg.norm(P[..., 3:5] - P[..., tp1:tp1 + 2], axis=-1),
                         -np.linalg.norm(P[..., 6:8] - P[..., tp2:tp2 + 2], axis=-1),
                         -np.linalg.norm(P[..., 0:3] - P[..., 3:6], axis=-1),
                         -np.linalg.norm(P[..., 0:3] - P[..., 6:9], axis=-1)], axis=-1)
    return f


# ======================================================================
# DIAGNOSIS (s5): is the failure at bimodal states an estimation error or a real effect?
#   same states, same folds, same PCA and probes as s2 (refit identically and checked against s2's directions)
#   ours, autodiff   d/dz of c . E_eps[S(u(z, eps))], pathwise through the flow (noise fixed), K_AD samples
#   ours, FD         central differences of the mean signature, K_O samples, steps H_O_LIST
#   oracle           central differences of the simulated expected QoI, K_O samples, steps H_O_LIST
#   reliability      cosine between the two halves of the samples of each estimate
#   evaluation       K_EV fresh samples shared across strengths and directions, small and large tau
# ======================================================================
CKPT_S2 = CKPT                                                     # s2 checkpoint: states, folds, old directions
OUT_D = "/content/drive/MyDrive/aclrh/smolvla_diagnose_s5.npz"
CKPT_D = "/content/drive/MyDrive/aclrh/smolvla_diagnose_s5_partial_v2.pkl"   # v2: with probe calibration and selection
SEL_K = 8                    # best-of-K selection by the probe, evaluated on the K_EV evaluation samples
QOI_DIAG = ["EE z (control)", "-d(EE,mug1)"]   # the QoIs of the bimodality paragraph (add others from QOI_RUN if wanted)
K_AD = 128                   # samples for the autodiff gradient (in batches of B_AD)
B_AD = 16
K_O = 32                     # samples per displacement for the oracle and the FD signature Jacobian (64: reliability +0.98)
H_O_LIST = [0.1]             # FD steps (standardized PCA units); add 0.25 (= s2) to compare steps, doubles the oracle cost
N_UNIMODAL = 8               # unimodal pairs kept as the control group (None: all); every bimodal pair is run
H_REF = 0.1                  # oracle step used as the reference
K_EV = 64                    # evaluation samples per strength
TAUS_EV = [-3.0, -1.5, -0.5, 0.0, 0.5, 1.5, 3.0]
BIMODAL_GAP, BIMODAL_MIN = 3.0, 3                                  # as in smolvla/s4
EVAL_DIRS = ["oracle", "ours AD", f"ours FD h={H_REF}", "ours s2"]


def steerable_s2(r):
    o = r["sim-gradient"]
    return (o["rho"] >= 0.8) and (o["eff"] > 2 * o["SD"][TAUS.index(0.0)] * np.sqrt(2 / K_ST))


def bimodal(v):
    v = np.sort(np.asarray(v, float)); k = int(np.argmax(np.diff(v)))
    lo, hi = v[:k + 1], v[k + 1:]
    return min(len(lo), len(hi)) >= BIMODAL_MIN and (v[k + 1] - v[k]) > BIMODAL_GAP * max(lo.std(), hi.std())


INTEGRATOR = {"manual": False}


def sig2_t(U):
    """torch version of sig2 (same formula)"""
    N, Hh, A = U.shape
    dt = 1.0 / Hh
    dx = torch.cat([torch.full((N, Hh, 1), dt, device=U.device, dtype=U.dtype), U * dt], dim=2)
    prev = torch.cumsum(dx, 1) - dx
    S2 = torch.einsum("nti,ntj->nij", prev, dx) + 0.5 * torch.einsum("nti,ntj->nij", dx, dx)
    return torch.cat([dx.sum(1), S2.reshape(N, -1)], dim=1)


def main_diagnose():
    header("DIAGNOSIS s5 — estimation error vs. real effect at the steered SmolVLA states")
    load_policy()
    policy.requires_grad_(False)
    global BDDL
    _, BDDL, _ = find_task()
    assert os.path.exists(CKPT_S2), f"{CKPT_S2} not found (run smolvla/s2 first)"
    d = np.load(DATA)
    LAM = d["LAM"]
    EP, CS, Q0r, U, QFr = d["EP"], d["C_STATE"], d["Q0"], d["U"], d["QF"]
    IMG1, IMG2, ST8, SIM, GRIP = d["IMG1"], d["IMG2"], d["STATE8"], d["SIM"], d["GRIP"]
    NS, (NC, K) = len(EP), U.shape[:2]
    qoi = make_qoi(*target_plates(Q0r, EP, d["success"]))
    Q0, QF = qoi(Q0r), qoi(QFr)
    QI = {n: i for i, n in enumerate(QOI_ALL)}
    qidx = [QI[q] for q in QOI_RUN]
    g2j = {int(g): j for j, g in enumerate(CS)}

    S_all = sig2(U.reshape(NC * K, H, 7))
    s_mu, s_sd = S_all.mean(0), S_all.std(0)
    keep = s_sd > 1e-8 * s_sd.max()
    st = lambda UU: (sig2(UU)[:, keep] - s_mu[keep]) / s_sd[keep]
    S_all = (S_all[:, keep] - s_mu[keep]) / s_sd[keep]
    ps = S_all.shape[1]
    keep_t = torch.from_numpy(np.where(keep)[0]).to(DEVICE)
    mu_t = torch.from_numpy(s_mu[keep]).float().to(DEVICE); sd_t = torch.from_numpy(s_sd[keep]).float().to(DEVICE)

    s2 = pickle.load(open(CKPT_S2, "rb"))
    todo = []
    for k_, r in s2.items():
        if k_[0] == "row" and k_[2] in QOI_DIAG and steerable_s2(r):
            fi, qn, g = k_[1], k_[2], int(k_[3])
            inc = QF[g2j[g], :K_POL, QI[qn]] - Q0[g, QI[qn]]
            todo.append((fi, qn, g, bool(bimodal(inc))))
    print(f"steerable pairs for {QOI_DIAG}: {len(todo)} ({sum(t[3] for t in todo)} bimodal)")
    if N_UNIMODAL is not None:                                       # deterministic control subset, spread over both folds
        uni = sorted([t for t in todo if not t[3]], key=lambda t: (t[2] * 7919) % 1009)[:N_UNIMODAL]
        todo = [t for t in todo if t[3]] + uni
        print(f"running {len(todo)} pairs: all bimodal + {len(uni)} unimodal controls")

    done = pickle.load(open(CKPT_D, "rb")) if os.path.exists(CKPT_D) else {}
    save_ck = lambda: pickle.dump(done, open(CKPT_D, "wb"))
    stamp("preparing LIBERO assets in the main process ...")
    _worker_init(BDDL)
    import concurrent.futures as cf
    import multiprocessing as mp
    pool = cf.ProcessPoolExecutor(max_workers=N_WORKERS, mp_context=mp.get_context("spawn"),
                                  initializer=_worker_init, initargs=(BDDL,))

    def simulate(g, chunk_list):
        kk = len(chunk_list[0])
        jobs = [(SIM[g], GRIP[g], c_[blk].astype(np.float64)) for c_ in chunk_list
                for blk in np.array_split(np.arange(len(c_)), JOB_SPLIT)]
        return np.concatenate(list(pool.map(_worker_job, jobs))).reshape(len(chunk_list), kk, -1)

    # ---- the postprocessor (unnormalization) as an affine map, so that the chunk is differentiable ----
    with torch.no_grad():
        x0 = torch.zeros(1, CH, 7, device=DEVICE)
        a0 = torch.as_tensor(postprocessor(x0.clone())).float().to(DEVICE)
        a1 = torch.as_tensor(postprocessor(torch.ones(1, CH, 7, device=DEVICE))).float().to(DEVICE)
        scale = a1 - a0
        xr = torch.randn(4, CH, 7, device=DEVICE) * 0.5
        err = (torch.as_tensor(postprocessor(xr.clone())).float().to(DEVICE) - (a0 + scale * xr)).abs().max().item()
    print(f"postprocessor as affine map: max error {err:.2e}")
    assert err < 1e-4, "postprocessor is not affine on these inputs (clipping?); autodiff path would be wrong"

    def chunks_grad(P, pm, am, noise):
        """differentiable chunks (B, CH, 7) for prefix P (1, L, D) with grad, fixed noise"""
        B = noise.shape[0]
        Pb = P.to(PREFIX_DTYPE).expand(B, -1, -1)
        pad = pm.to(DEVICE).expand(B, -1).contiguous(); att = am.to(DEVICE).expand(B, -1).contiguous()
        _, kv = policy.model.vlm_with_expert.forward(
            attention_mask=make_att_2d_masks(pad, att), position_ids=torch.cumsum(pad, 1) - 1,
            past_key_values=None, inputs_embeds=[Pb, None], use_cache=policy.config.use_cache)
        fn = lambda x_t, t: policy.model.denoise_step(x_t=x_t, prefix_pad_masks=pad, past_key_values=kv, timestep=t)
        if INTEGRATOR["manual"]:
            x, n, t = noise, policy.config.num_steps, torch.tensor(1.0, device=DEVICE)
            for _ in range(n):                                  # x_1 = noise -> x_0, dt = -1/n
                x = x + (-1.0 / n) * fn(x, t.expand(B)); t = t - 1.0 / n
        else:
            x = euler_integrate(fn, noise, policy.config.num_steps)
        return a0 + scale * x[:, :, :7]

    # ---- check: the differentiable path reproduces sample_chunks and carries a gradient ----
    j0 = g2j[todo[0][2]] if todo else 0
    P0, PM0, AM0 = prefix_of(policy_batch(IMG1[j0], IMG2[j0], ST8[int(CS[j0])]))
    ref = sample_chunks(P0, PM0, AM0, 4, seed=123)
    torch.manual_seed(123); nz = policy.model.sample_noise((4, CH, MAD), DEVICE)
    Pg = P0.to(DEVICE).clone().requires_grad_(True)
    with torch.enable_grad():
        out = chunks_grad(Pg, PM0, AM0, nz)
        if not out.requires_grad:                               # lerobot's integrator runs without grad
            INTEGRATOR["manual"] = True
            print("euler_integrate carries no gradient -> own Euler loop (checked against the policy below)")
            out = chunks_grad(Pg, PM0, AM0, nz)
        assert out.requires_grad, "no gradient through the flow"
        out.sum().backward()
    dev = np.abs(out.detach().cpu().numpy() - ref).max()
    print(f"differentiable path vs. sample_chunks: max |diff| {dev:.2e} | grad norm {Pg.grad.norm().item():.3e}")
    assert dev < 1e-3, "differentiable path does not reproduce the policy's chunks"

    eps_all = np.unique(EP)
    folds = [(eps_all[::2], eps_all[1::2]), (eps_all[1::2], eps_all[::2])]
    T_START, n_new = time.time(), 0
    for fi, (A_eps, B_eps) in enumerate(folds):
        mine = [t for t in todo if t[0] == fi]
        if not mine:
            continue
        header(f"FOLD {fi + 1}/2: {len(mine)} pairs")
        # ---- PCA and probes exactly as in s2 ----
        inA = np.isin(EP, A_eps)
        X = LAM[inA].astype(np.float32)
        mu = X.mean(0); X -= mu
        ev, V = np.linalg.eigh((X @ X.T).astype(np.float64)); ix = np.argsort(ev)[::-1][:PCA_K]
        comps = ((X.T.astype(np.float64) @ V[:, ix]) / np.sqrt(ev[ix])).astype(np.float32)
        del X
        Zall = np.concatenate([(LAM[i:i + 64].astype(np.float32) - mu) @ comps for i in range(0, NS, 64)])
        zm, zs = Zall[inA].mean(0), Zall[inA].std(0) + 1e-12
        Zall = (Zall - zm) / zs
        z_of = lambda P: (((P.reshape(1, -1).numpy() - mu) @ comps) - zm) / zs
        to_prefix = lambda dz, shp: torch.from_numpy((comps @ (zs * dz)).astype(np.float32).reshape(shp))[None]
        disp = lambda dz: float(np.linalg.norm(zs * dz))
        comps_t = torch.from_numpy(comps).to(DEVICE)
        cA = np.where(inA[CS])[0]
        Z = np.repeat(Zall[CS[cA]], K, 0)
        S = S_all[(cA[:, None] * K + np.arange(K)).ravel()]
        Y = (QF[cA][:, :, qidx] - Q0[CS[cA]][:, None, qidx]).reshape(-1, len(qidx))
        inc = RidgeCV(alphas=RIDGE, alpha_per_target=True).fit(
            np.c_[Z, S, (Z[:, :, None] * S[:, None, :]).reshape(len(Z), -1)], Y)
        coef = np.atleast_2d(inc.coef_)
        b_inc = coef[:, PCA_K:PCA_K + ps]
        W_inc = coef[:, PCA_K + ps:].reshape(len(qidx), PCA_K, ps)
        del Z, S
        stamp("PCA and probes refit")

        for (_, qn, g, bim) in mine:
            key = (fi, qn, g)
            if key in done:
                continue
            t0 = time.time()
            q, qi, j = QOI_RUN.index(qn), QI[qn], g2j[g]
            old, cache = s2[("row", fi, qn, g)], s2[("cache", fi, g)]
            z0 = cache["z0"]; c = b_inc[q] + W_inc[q].T @ z0
            chk = float(np.dot(cache["J"].T @ c, old["lam_dir"]) /
                        (np.linalg.norm(cache["J"].T @ c) * np.linalg.norm(old["lam_dir"]) + 1e-300))
            P, PM, AM = prefix_of(policy_batch(IMG1[j], IMG2[j], ST8[g]))
            shp, pn = P.shape[1:], float(P.norm())
            dirs, extra = {}, {}
            # ---- old directions (s2) ----
            dirs["ours s2"] = old["lam_dir"].copy()
            dirs["oracle s2"] = (qoi(cache["pos_p"])[..., qi].mean(1) - qoi(cache["pos_m"])[..., qi].mean(1)) / (2 * H_Z)
            # ---- ours, autodiff (pathwise) ----
            c_t = torch.from_numpy(c).float().to(DEVICE)
            grads = []
            torch.manual_seed(9_300_000 + 10_000 * fi + g)
            noise_all = policy.model.sample_noise((K_AD, CH, MAD), DEVICE)
            for b0 in range(0, K_AD, B_AD):
                Pg = P.to(DEVICE).clone().requires_grad_(True)
                with torch.enable_grad():
                    u = chunks_grad(Pg, PM, AM, noise_all[b0:b0 + B_AD])[:, :H].double()
                    s_ = (sig2_t(u)[:, keep_t] - mu_t.double()) / sd_t.double()
                    (s_ @ c_t.double()).sum().backward()
                gz = zs * (comps_t.T @ Pg.grad.reshape(-1)).double().cpu().numpy()
                grads.append(gz / len(noise_all[b0:b0 + B_AD]))
                del Pg
            G = np.stack(grads)                                          # (K_AD / B_AD, 32), batch means
            dirs["ours AD"] = G.mean(0)
            extra["AD halves"] = (G[:len(G) // 2].mean(0), G[len(G) // 2:].mean(0))
            # ---- oracle and FD signature Jacobian, K_O samples, common noise ----
            so = 9_400_000 + 10_000 * fi + g
            chunks, tags = [], []
            for h in H_O_LIST:
                for kx in range(PCA_K):
                    e = np.zeros(PCA_K); e[kx] = h
                    chunks.append(sample_chunks(P + to_prefix(e, shp), PM, AM, K_O, seed=so)[:, :H]); tags.append((h, kx, +1))
                    chunks.append(sample_chunks(P - to_prefix(e, shp), PM, AM, K_O, seed=so)[:, :H]); tags.append((h, kx, -1))
            t_sim = time.time()
            vals = qoi(simulate(g, chunks))[..., qi]                     # (n, K_O)
            t_sim = time.time() - t_sim
            sig_m = np.stack([st(c_.reshape(-1, H, 7)) for c_ in chunks])   # (n, K_O, ps)
            for h in H_O_LIST:
                ip = [i for i, t in enumerate(tags) if t[0] == h and t[2] > 0]
                im_ = [i for i, t in enumerate(tags) if t[0] == h and t[2] < 0]
                D = (vals[ip] - vals[im_]) / (2 * h)                     # (32, K_O)
                dirs[f"oracle h={h}"] = D.mean(1)
                extra[f"oracle h={h} halves"] = (D[:, :K_O // 2].mean(1), D[:, K_O // 2:].mean(1))
                JS = (sig_m[ip] - sig_m[im_]) / (2 * h)                  # (32, K_O, ps)
                dirs[f"ours FD h={h}"] = JS.mean(1) @ c
                extra[f"ours FD h={h} halves"] = (JS[:, :K_O // 2].mean(1) @ c, JS[:, K_O // 2:].mean(1) @ c)
            dirs["oracle"] = dirs[f"oracle h={H_REF}"]
            # ---- cosines ----
            cosv = lambda a, b: float(a @ b / (np.linalg.norm(a) * np.linalg.norm(b) + 1e-300))
            cos = {k_: cosv(v, dirs["oracle"]) for k_, v in dirs.items()}
            rel = {k_: cosv(*v) for k_, v in extra.items()}
            # ---- evaluation: fresh noise shared across strengths and directions ----
            se = 8_800_000 + 10_000 * fi + g
            ev_dirs = {k_: dirs[k_] / (disp(dirs[k_]) + 1e-300) * STEP_REL * pn for k_ in EVAL_DIRS}
            keys, ch = [("base", 0.0)], [sample_chunks(P, PM, AM, K_EV, seed=se)[:, :H]]
            for k_, v in ev_dirs.items():
                for t in TAUS_EV:
                    if t != 0.0:
                        ch.append(sample_chunks(P + to_prefix(t * v, shp), PM, AM, K_EV, seed=se)[:, :H]); keys.append((k_, t))
            ev = qoi(simulate(g, ch))[..., qi] - Q0[g, qi]               # (n, K_EV)
            mean = {kt: ev[i].mean() for i, kt in enumerate(keys)}
            sem = {kt: ev[i].std() / np.sqrt(K_EV) for i, kt in enumerate(keys)}
            evals = {}
            for k_ in EVAL_DIRS:
                J_ = np.array([mean[("base", 0.0)] if t == 0.0 else mean[(k_, t)] for t in TAUS_EV])
                E_ = np.array([sem[("base", 0.0)] if t == 0.0 else sem[(k_, t)] for t in TAUS_EV])
                rho = float(spearmanr(TAUS_EV, J_).correlation)
                small = J_[TAUS_EV.index(0.5)] - J_[TAUS_EV.index(-0.5)]
                evals[k_] = dict(J=J_, SEM=E_, rho=rho, eff=float(J_[-1] - J_[0]), small=float(small))
            # ---- probe calibration at this state: predicted vs simulated increment of the same chunks ----
            # increment probe at z0: const + c . S(u); the constant cancels in every comparison below
            pred_fd = (sig_m @ c).ravel(); true_fd = (vals - Q0[g, qi]).ravel()
            sig_e = np.stack([st(c_) for c_ in ch]); pred_e = sig_e @ c              # (n, K_EV)
            calib = dict(rho_chunks=float(spearmanr(pred_fd, true_fd).correlation),
                         slope=float(np.polyfit(pred_fd, true_fd, 1)[0]))
            b0 = ev[0]; srt = np.argsort(b0); kk = int(np.argmax(np.diff(b0[srt])))
            lo, hi = srt[:kk + 1], srt[kk + 1:]
            calib["base_bimodal"] = bool(bimodal(b0))
            calib["gap_true"] = float(b0[hi].mean() - b0[lo].mean())                # > 0 by construction
            calib["gap_pred"] = float(pred_e[0][hi].mean() - pred_e[0][lo].mean())   # same sign = probe orders the modes
            # predicted vs measured response along each evaluated direction (mean over the samples at each tau)
            pmean = {kt: pred_e[i].mean() for i, kt in enumerate(keys)}
            for k_ in EVAL_DIRS:
                Jp = np.array([pmean[("base", 0.0)] if t == 0.0 else pmean[(k_, t)] for t in TAUS_EV])
                evals[k_]["Jpred"] = Jp - Jp[TAUS_EV.index(0.0)]
            # ---- selection by the probe: best of SEL_K samples (no simulator), with and without steering ----
            def best_of(i):
                tv, pv = ev[i].reshape(-1, SEL_K), pred_e[i].reshape(-1, SEL_K)
                pick = tv[np.arange(len(tv)), pv.argmax(1)]
                return dict(mean=float(tv.mean()), probe=float(pick.mean()), best=float(tv.max(1).mean()))
            sel = {"no steering": best_of(0)}
            for k_ in ["ours AD", "oracle"]:
                sel[f"{k_} tau=1.5"] = best_of(keys.index((k_, 1.5)))
            done[key] = dict(fold=fi, qoi=qn, state=g, bimodal=bim, check_s2=chk, cos=cos, rel=rel, ev=evals,
                             calib=calib, sel=sel, dirs={k_: v for k_, v in dirs.items()})
            save_ck(); n_new += 1
            left = len(todo) - len(done)
            el = time.time() - T_START
            print(f"  {qn:16s} state {g:5d} {'BIMODAL ' if bim else 'unimodal'} | s2 refit check {chk:+.3f} | "
                  f"cos to oracle: s2 {cos['ours s2']:+.2f}  FD {cos[f'ours FD h={H_REF}']:+.2f}  AD {cos['ours AD']:+.2f} | "
                  f"oracle s2 vs new {cos['oracle s2']:+.2f} | reliability oracle {rel[f'oracle h={H_REF} halves']:+.2f} "
                  f"AD {rel['AD halves']:+.2f} | rho AD {evals['ours AD']['rho']:+.2f} s2 {evals['ours s2']['rho']:+.2f} | "
                  f"{time.time() - t0:.0f} s (sim {t_sim:.0f} s) | ~{el / n_new * left / 60:.0f} min left", flush=True)
    pool.shutdown()

    # ---------------- summary ----------------
    header("SUMMARY: bimodal vs unimodal pairs")
    R = list(done.values())
    med = lambda xs: float(np.nanmedian(xs)) if len(xs) else float("nan")
    save = {}
    for grp, sel in [("bimodal", [r for r in R if r["bimodal"]]), ("unimodal", [r for r in R if not r["bimodal"]])]:
        if not sel:
            continue
        print(f"\n{grp}: {len(sel)} pairs")
        print(f"  reliability (cos between sample halves): oracle h={H_REF} {med([r['rel'][f'oracle h={H_REF} halves'] for r in sel]):+.2f}"
              + "".join(f" | oracle h={h} {med([r['rel'][f'oracle h={h} halves'] for r in sel]):+.2f}" for h in H_O_LIST if h != H_REF)
              + f" | ours AD {med([r['rel']['AD halves'] for r in sel]):+.2f}"
              + "".join(f" | ours FD h={h} {med([r['rel'][f'ours FD h={h} halves'] for r in sel]):+.2f}" for h in H_O_LIST))
        print(f"  old oracle (s2, 8 samples, h={H_Z}) vs new oracle: median cos {med([r['cos']['oracle s2'] for r in sel]):+.2f}")
        names = ["ours s2"] + [f"ours FD h={h}" for h in H_O_LIST] + ["ours AD"] + [f"oracle h={h}" for h in H_O_LIST if h != H_REF]
        print("  median cos to the new oracle: " + " | ".join(f"{n} {med([r['cos'][n] for r in sel]):+.2f}" for n in names))
        print(f"  {'evaluation (K_EV=%d)' % K_EV:22s} | monotone rho>0.8 | reversed | small-tau slope > 2 SEM | median effect (mm)")
        for n in EVAL_DIRS:
            rh = np.array([r["ev"][n]["rho"] for r in sel]); ef = np.array([r["ev"][n]["eff"] for r in sel])
            sm = np.array([r["ev"][n]["small"] > 2 * np.hypot(r["ev"][n]["SEM"][TAUS_EV.index(0.5)], r["ev"][n]["SEM"][TAUS_EV.index(-0.5)]) for r in sel])
            rv = np.array([(r["ev"][n]["rho"] <= -0.8) and (r["ev"][n]["eff"] < 0) for r in sel])
            print(f"  {n:22s} |      {np.mean(rh > 0.8):4.0%}       |  {rv.sum():3d}     |        {np.mean(sm):4.0%}           |   {1e3 * np.median(ef):+6.1f}")
            save[f"{grp}|{n}|J"] = np.stack([r["ev"][n]["J"] for r in sel])
        for n in names + ["oracle"]:
            save[f"{grp}|{n}|cos"] = np.array([r["cos"][n] for r in sel])
        save[f"{grp}|state"] = np.array([r["state"] for r in sel]); save[f"{grp}|qoi"] = np.array([r["qoi"] for r in sel])
    for grp, sel_ in [("bimodal", [r for r in R if r["bimodal"]]), ("unimodal", [r for r in R if not r["bimodal"]])]:
        if not sel_:
            continue
        print(f"\n{grp}: probe at the state ({len(sel_)} pairs)")
        print(f"  chunk-level rank correlation predicted vs simulated increment: median {med([r['calib']['rho_chunks'] for r in sel_]):+.2f}"
              f" | calibration slope (1 = right scale): median {med([r['calib']['slope'] for r in sel_]):+.2f}")
        gb = [r for r in sel_ if r["calib"]["base_bimodal"]]
        if gb:
            print(f"  modes ordered correctly by the probe (gap_pred > 0): {sum(r['calib']['gap_pred'] > 0 for r in gb)}/{len(gb)} pairs with bimodal evaluation samples")
        for n in ["ours AD", "oracle"]:
            ok = [np.sign(r["ev"][n]["Jpred"][TAUS_EV.index(1.5)] - r["ev"][n]["Jpred"][TAUS_EV.index(-1.5)]) ==
                  np.sign(r["ev"][n]["J"][TAUS_EV.index(1.5)] - r["ev"][n]["J"][TAUS_EV.index(-1.5)]) for r in sel_]
            print(f"  along {n:8s}: probe predicts the sign of the measured response (tau +-1.5) in {sum(ok)}/{len(ok)}")
        print(f"  selection, best of {SEL_K} by the probe (mm, mean over evaluation samples): ")
        for sk in ["no steering", "ours AD tau=1.5", "oracle tau=1.5"]:
            m_ = med([1e3 * r["sel"][sk]["mean"] for r in sel_]); pr = med([1e3 * r["sel"][sk]["probe"] for r in sel_])
            be = med([1e3 * r["sel"][sk]["best"] for r in sel_])
            cap = med([(r["sel"][sk]["probe"] - r["sel"][sk]["mean"]) / (r["sel"][sk]["best"] - r["sel"][sk]["mean"] + 1e-12) for r in sel_])
            print(f"    {sk:16s} random sample {m_:+6.1f} | probe pick {pr:+6.1f} | best possible {be:+6.1f} | share of the possible gain captured {cap:+.2f}")
    print(f"\ns2 refit check (cos of the refit direction with s2's, should be 1): min {min(r['check_s2'] for r in R):+.4f}")
    save["taus"] = np.array(TAUS_EV)
    np.savez(OUT_D, **save)
    print(r"""
READING
=======
reliability low (oracle halves disagree)  -> the old cosine to the oracle was measured against noise
AD / FD with more samples close to the new oracle at bimodal pairs, while s2 was not -> estimation error
monotone only at small tau, broken at tau = +-3 with good cosines -> real curvature (linear range is small)
all estimates agree with each other but not with the oracle -> the probe's prediction between the modes
probe at the state: low chunk-level rank correlation or wrong mode order -> the probe itself is wrong there;
  good ranking but wrong predicted sign along the direction -> the probe is right on samples but not on the mean shift
selection: share captured near 1 -> the probe picks good chunks even where steering fails
""")
    stamp(f"saved {OUT_D}")


if __name__ == "__main__":
    main_diagnose()
'''

FILE = "/content/run_smolvla_diagnose_s5.py"
with open(FILE, "w") as f:
    f.write(SCRIPT)

print("\n" + "=" * 100)
print("START EXPERIMENT")
print("=" * 100)
LOG = "/content/drive/MyDrive/aclrh/smolvla_diagnose_s5_log.txt"      # full output, also after the runtime is gone
rc = -1
try:
    with open(LOG, "a") as logf:
        p = subprocess.Popen([PY, FILE], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
        for line in p.stdout:
            print(line, end="")
            logf.write(line); logf.flush()
        rc = p.wait()
        msg = "\nReturn code: %d\n%s\n" % (rc, "COMPLETE" if rc == 0 else "Stopped. Traceback above is enough to diagnose it.")
        print(msg); logf.write(msg)
finally:
    if AUTO_SHUTDOWN:
        print(f"log: {LOG}\nshutting the runtime down (AUTO_SHUTDOWN) ...", flush=True)
        try:
            from google.colab import drive as _d
            _d.flush_and_unmount()                       # make sure the results and the log reach Drive
        except Exception as ex:
            print("  (flush:", ex, ")")
        from google.colab import runtime
        runtime.unassign()
