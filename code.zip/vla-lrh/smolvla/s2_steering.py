# ======================================================================
# SmolVLA STEERING v6 — Corollary 5.4 on a stochastic (flow-matching) policy  (ONE Colab cell, GPU runtime, A100)
#
# Same protocol as the OpenVLA-OFT steering (04/05b/05c): 2 folds of episodes (PCA, probes and the global
# direction from one half, steering on the other), 10 states per QoI and fold, equal displacement per unit tau.
#   ours      lambda_psi = D Phi(z)^T L_psi^* z(x), Phi = E_eps[S(u)]  (finite differences, common gradient noise)
#   oracle    gradient of the simulated expected QoI along the same axes
#   baselines gamma_psi(u0), static probe, global (one direction per QoI), 3 random
#   evaluation with fresh noise shared across strengths and directions; spread of psi is recorded too
# Needs /content/drive/MyDrive/aclrh/probe_v2.npz. Per-state checkpoint on Drive: re-run the cell to resume.
# Writes /content/drive/MyDrive/aclrh/smolvla_steering_v6.npz (same keys as the OFT steering files).
# ======================================================================

import sys
import subprocess

PY = sys.executable

# ---------------------------------------------------------------- Google Drive (data, checkpoint and results live there)
import os as _os0
if not _os0.path.isdir("/content/drive/MyDrive"):
    from google.colab import drive
    drive.mount("/content/drive")
assert _os0.path.exists("/content/drive/MyDrive/aclrh/probe_v2.npz"), \
    "probe_v2.npz not found in /content/drive/MyDrive/aclrh/ (the SmolVLA probing data)"

print("=" * 100)
print("0. FRESH COLAB ENVIRONMENT SETUP")
print("=" * 100)
print("Python:", sys.version)

subprocess.run([PY, "-m", "pip", "install", "-q", "--upgrade", "pip>=25,<26"], check=True)

torch_check = subprocess.run(
    [PY, "-c", r"""
import torch
from packaging.version import Version
v = Version(torch.__version__.split("+")[0])
print(torch.__version__)
assert Version("2.7") <= v < Version("2.12")
"""],
    stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
)
print("Torch check:", torch_check.stdout.strip())

# GPU present but a CPU-only torch build installed -> reinstall the CUDA build
import shutil as _sh
_has_gpu = (_sh.which("nvidia-smi") is not None and
            subprocess.run(["nvidia-smi"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode == 0)
if _has_gpu and "+cpu" in torch_check.stdout:
    print("GPU detected but torch is a CPU build -> installing torch 2.11.0 (CUDA 12.8) ...")
    subprocess.run([PY, "-m", "pip", "install", "-q", "--force-reinstall",
                    "torch==2.11.0", "torchvision==0.26.0",
                    "--index-url", "https://download.pytorch.org/whl/cu128"], check=True)
elif not _has_gpu:
    raise RuntimeError("No GPU on this machine (nvidia-smi not available). Back up /content, then "
                       "Runtime -> Disconnect and delete runtime, reconnect with a GPU runtime.")
if torch_check.returncode != 0:
    subprocess.run([PY, "-m", "pip", "install", "-q", "--upgrade",
                    "torch==2.11.0", "torchvision==0.26.0"], check=True)

import os as _os
_os.environ["CMAKE_POLICY_VERSION_MINIMUM"] = "3.5"   # harmless; guards old CMake projects


def pip(*args, label=""):
    """pip with the error actually shown (Colab hides child-process stderr otherwise)."""
    r = subprocess.run([PY, "-m", "pip", "install", "-q", *args],
                       stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    if r.returncode != 0:
        print(f"\n----- pip failed ({label}) -----")
        print("\n".join(r.stdout.strip().splitlines()[-60:]))
        raise RuntimeError(f"pip install failed: {label}")
    print(f"  ok: {label}")


print("Installing ...")
pip("--upgrade", "--upgrade-strategy", "only-if-needed",
    "numpy==2.2.6",
    "lerobot[smolvla]==0.6.1",
    "transformers==5.5.4",
    "av==15.1.0",
    "datasets>=4.8.0,<5.0.0",
    "pandas>=2.0.0,<3.0.0",
    "pyarrow>=21.0.0,<30.0.0",
    "jsonlines>=4.0.0,<5.0.0",
    "scikit-learn==1.9.1",
    label="lerobot + smolvla")

# LIBERO sim WITHOUT robomimic: hf-libero pins robomimic==0.2.0 -> egl_probe, whose CMake
# project (cmake_minimum_required 2.8.12) does not build with CMake 4. The simulator path
# (libero.libero.envs / benchmark / asset download) never imports robomimic, so install
# the three sim packages with --no-deps and their real runtime deps explicitly.
pip("--no-deps", "hf-libero>=0.1.4,<0.2.0", "robosuite==1.4.0", "bddl==1.0.1",
    label="hf-libero / robosuite / bddl (no-deps)")
pip("--upgrade-strategy", "only-if-needed",
    "mujoco>=3.0.0,<3.9.0", "numba>=0.61", "scipy", "Pillow", "opencv-python-headless",
    "easydict", "gymnasium>=0.29.0", "h5py", "imageio", "matplotlib", "termcolor", "tqdm",
    "cloudpickle", "pyyaml", "networkx", "huggingface_hub", "PyOpenGL",
    label="sim runtime deps")

# Colab ships a torchao that is older than what the preinstalled diffusers expects (FqnToConfig);
# lerobot imports diffusers through the GR00T policy. Quantization is not used here -> remove torchao,
# diffusers then skips its torchao quantizer.
r_ = subprocess.run([PY, "-m", "pip", "uninstall", "-y", "-q", "torchao"], stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT, text=True)
print("  ok: torchao removed" if r_.returncode == 0 else "  (torchao not installed)")

VERIFY = r'''
import os, importlib.util
os.environ.setdefault("MUJOCO_GL", "egl")
os.environ.setdefault("PYOPENGL_PLATFORM", "egl")
import importlib.metadata as im
for p in ["torch", "lerobot", "transformers", "numpy", "hf-libero", "robosuite", "mujoco"]:
    try:
        print(f"{p:14s}: {im.version(p)}")
    except Exception as e:
        print(f"{p:14s}: MISSING ({e})")
import torch
assert torch.cuda.is_available(), "Colab GPU runtime is required."
assert importlib.util.find_spec("libero") is not None, "libero not importable"
import yaml
_cfg = os.path.expanduser("~/.libero"); os.makedirs(_cfg, exist_ok=True)
_f = os.path.join(_cfg, "config.yaml")
if not os.path.exists(_f):
    _root = os.path.join(list(importlib.util.find_spec("libero").submodule_search_locations)[0], "libero")
    yaml.dump({"benchmark_root": _root, "bddl_files": _root + "/bddl_files",
               "init_states": _root + "/init_files", "datasets": _root + "/../datasets",
               "assets": _root + "/assets"}, open(_f, "w"))
import mujoco, robosuite
from libero.libero import benchmark
from libero.libero.envs import OffScreenRenderEnv
print("libero suites:", sorted(benchmark.get_benchmark_dict().keys())[:6])
from lerobot.policies.smolvla.modeling_smolvla import SmolVLAPolicy
print("GPU:", torch.cuda.get_device_name(0))
print("ENVIRONMENT SUCCESS")
'''
verify = subprocess.run([PY, "-c", VERIFY], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
print(verify.stdout)
if verify.returncode != 0:
    raise RuntimeError("Environment setup failed. The experiment has NOT started.")


# ======================================================================
# EXPERIMENT SCRIPT
# ======================================================================

SCRIPT = r'''
import os
os.environ.setdefault("MUJOCO_GL", "egl")
os.environ.setdefault("PYOPENGL_PLATFORM", "egl")
os.environ["TOKENIZERS_PARALLELISM"] = "false"
os.environ["HF_HUB_DISABLE_TELEMETRY"] = "1"

import warnings
warnings.filterwarnings("ignore")

import importlib.util
import math
import time

import numpy as np
import torch
import yaml

# ----------------------------------------------------------------------
# LIBERO asks for a config path interactively on first import -> pre-create it
# ----------------------------------------------------------------------
_cfg_dir = os.environ.setdefault("LIBERO_CONFIG_PATH", os.path.expanduser("~/.libero"))
os.makedirs(_cfg_dir, exist_ok=True)
_cfg_file = os.path.join(_cfg_dir, "config.yaml")
if not os.path.exists(_cfg_file):
    _root = os.path.join(list(importlib.util.find_spec("libero").submodule_search_locations)[0], "libero")
    with open(_cfg_file, "w") as f:
        yaml.dump({
            "benchmark_root": _root,
            "bddl_files": os.path.join(_root, "bddl_files"),
            "init_states": os.path.join(_root, "init_files"),
            "datasets": os.path.join(_root, "..", "datasets"),
            "assets": os.path.join(_root, "assets"),
        }, f)

import mujoco
from libero.libero import benchmark, get_libero_path
from libero.libero.envs import OffScreenRenderEnv

from sklearn.linear_model import RidgeCV
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.model_selection import GroupKFold

from lerobot.policies.factory import make_pre_post_processors
from lerobot.policies.smolvla.modeling_smolvla import SmolVLAPolicy
from lerobot.policies.common.vla_utils import make_att_2d_masks
from lerobot.policies.common.flow_matching import euler_integrate


# ======================================================================
# 1. SETTINGS
# ======================================================================

SEED = 0
MODEL_ID = "lerobot/smolvla_libero"
SUITE = "libero_10"
TASK_LANG = "put the white mug on the left plate and put the yellow and white mug on the right plate"

N_EPISODES = 50              # all LIBERO initial layouts of the task
MAX_STEPS = 520              # libero_10 limit used by lerobot-eval
NUM_STEPS_WAIT = 10          # settle steps after reset (same as lerobot)
SNAP_STRIDE = 16             # snapshot every k env steps
MAX_SNAPS_PER_EP = 30

H = 20                       # candidate chunk horizon (env steps, 1 s at 20 Hz)
K_POL = 16                   # policy-sampled candidates per candidate state
K_PERT = 16                  # smooth perturbations of policy candidates
CAND_EVERY = 2               # candidate chunks at every 2nd snapshot (static data at all)
PERT_SCALE = 0.3             # std of perturbation (normalized action units) on dims 0..5
PERT_KNOTS = 5

PCA_K = 32                   # representation dims after PCA (fit on train states only)
MOVE_TOL = 1e-3              # "QoI moves at this state" threshold (m)

CACHE = "/content/probe_v2.npz"
PARTIAL = "/content/probe_v2_partial.npz"     # per-episode checkpoint; rerun resumes from it
REUSE_CACHE = True           # skip simulation if the final cache exists
N_WORKERS = max(1, min((os.cpu_count() or 2) - 1, 16))
JOB_SPLIT = 4                # candidate blocks per snapshot (load balancing)

rng = np.random.default_rng(SEED)
torch.manual_seed(SEED)
assert torch.cuda.is_available()
DEVICE = torch.device("cuda")
T0 = time.time()


def stamp(msg):
    print(f"[{time.time() - T0:7.1f}s] {msg}", flush=True)


def header(title):
    print("\n" + "=" * 100)
    print(title)
    print("=" * 100, flush=True)


QOI_NAMES = ["ee_x", "ee_y", "ee_z", "mug1_x", "mug1_y", "mug1_z", "mug2_x", "mug2_y", "mug2_z",
             "plate1_x", "plate1_y", "plate1_z", "plate2_x", "plate2_y", "plate2_z"]


# ======================================================================
# 2. POLICY (same verified intervention path as before)
# ======================================================================

policy = None
preprocessor = postprocessor = None
PREFIX_DTYPE = None


def load_policy():
    global policy, preprocessor, postprocessor, CH, MAD, N_EXEC
    policy = SmolVLAPolicy.from_pretrained(MODEL_ID).to(torch.float32).to(DEVICE).eval()
    preprocessor, postprocessor = make_pre_post_processors(policy.config, pretrained_path=MODEL_ID)
    CH = policy.config.chunk_size
    MAD = policy.config.max_action_dim
    N_EXEC = policy.config.n_action_steps
    print("chunk_size:", CH, "| n_action_steps:", N_EXEC, "| num_steps:", policy.config.num_steps)


def quat2axisangle(q):
    """(x, y, z, w) -> axis-angle; identical to lerobot LiberoProcessorStep."""
    q = np.asarray(q, dtype=np.float64)
    w = float(np.clip(q[3], -1.0, 1.0))
    den = math.sqrt(max(1.0 - w * w, 0.0))
    if den < 1e-10:
        return np.zeros(3)
    return q[:3] / den * (2.0 * math.acos(w))


def obs_to_arrays(raw):
    """LIBERO raw obs -> (agentview, wrist, state8) in the HuggingFaceVLA/libero convention
    (images rotated 180 deg; state = eef pos, axis-angle, gripper qpos)."""
    img1 = np.ascontiguousarray(raw["agentview_image"][::-1, ::-1])
    img2 = np.ascontiguousarray(raw["robot0_eye_in_hand_image"][::-1, ::-1])
    state = np.concatenate([raw["robot0_eef_pos"], quat2axisangle(raw["robot0_eef_quat"]),
                            raw["robot0_gripper_qpos"]]).astype(np.float32)
    return img1, img2, state


def policy_batch(img1, img2, state):
    to_t = lambda im: torch.from_numpy(im).permute(2, 0, 1).float() / 255.0
    return preprocessor({
        "observation.images.image": to_t(img1),
        "observation.images.image2": to_t(img2),
        "observation.state": torch.from_numpy(state),
        "task": TASK_LANG,
    })


@torch.no_grad()
def prefix_of(batch):
    global PREFIX_DTYPE
    b = policy._prepare_batch(batch)
    images, img_masks = policy.prepare_images(b)
    state = policy.prepare_state(b)
    prefix, pad, att = policy.model.embed_prefix(
        images, img_masks, b["observation.language.tokens"],
        b["observation.language.attention_mask"], state=state,
    )
    PREFIX_DTYPE = prefix.dtype
    return prefix.float().cpu(), pad.cpu(), att.cpu()


@torch.inference_mode()
def build_kv(P, pm, am, B):
    P = P.to(DEVICE, PREFIX_DTYPE).expand(B, -1, -1).contiguous()
    pad = pm.to(DEVICE).expand(B, -1).contiguous()
    att = am.to(DEVICE).expand(B, -1).contiguous()
    _, kv = policy.model.vlm_with_expert.forward(
        attention_mask=make_att_2d_masks(pad, att), position_ids=torch.cumsum(pad, 1) - 1,
        past_key_values=None, inputs_embeds=[P, None], use_cache=policy.config.use_cache,
    )
    return pad, kv


@torch.inference_mode()
def denoise(pad, kv, noise):
    x = euler_integrate(
        lambda x_t, t: policy.model.denoise_step(
            x_t=x_t, prefix_pad_masks=pad, past_key_values=kv, timestep=t),
        noise, policy.config.num_steps)
    return x[:, :, :7]


@torch.inference_mode()
def sample_chunks(P, pm, am, K, seed):
    pad, kv = build_kv(P, pm, am, K)
    torch.manual_seed(seed)
    noise = policy.model.sample_noise((K, CH, MAD), DEVICE)
    a = postprocessor(denoise(pad, kv, noise))
    return torch.as_tensor(a).float().cpu().numpy()          # (K, CH, 7)


# ======================================================================
# 3. SIMULATOR
#
# main process : one camera env (closed-loop policy rollouts need images)
# workers      : camera-FREE envs (no renderer at all) that replay candidate chunks
#                from saved MuJoCo states, one per CPU core
# ======================================================================

env = None
BDDL = None
DUMMY = np.array([0, 0, 0, 0, 0, 0, -1], dtype=np.float64)
_SPEC = mujoco.mjtState.mjSTATE_INTEGRATION


def find_task():
    suite = benchmark.get_benchmark_dict()[SUITE]()
    ids = [i for i, t in enumerate(suite.tasks) if t.language == TASK_LANG]
    assert ids, f"task not found in {SUITE}"
    task = suite.get_task(ids[0])
    bddl = os.path.join(get_libero_path("bddl_files"), task.problem_folder, task.bddl_file)
    init_path = os.path.join(get_libero_path("init_states"), task.problem_folder,
                             os.path.basename(task.init_states_file))
    return ids[0], bddl, torch.load(init_path, weights_only=False)


def make_env():
    global env, INIT_STATES, BDDL
    tid, BDDL, INIT_STATES = find_task()
    env = OffScreenRenderEnv(bddl_file_name=BDDL, camera_heights=256, camera_widths=256,
                             control_freq=20)
    env.seed(SEED)
    env.reset()
    print("task id:", tid, "| init states:", len(INIT_STATES))


def set_cameras(e, on):
    """robosuite: `enabled` controls whether the sensor (renderer) runs at all;
    `active` only controls whether the value is returned. Toggle both."""
    for name in ("agentview_image", "robot0_eye_in_hand_image"):
        for attr in ("enabled", "active"):
            try:
                e.env.modify_observable(observable_name=name, attribute=attr, modifier=on)
            except Exception as ex:
                print(f"  [warn] could not set {attr}={on} on {name}: {ex}")


def reset_episode(ep):
    env.reset()
    env.env.ignore_done = True
    set_cameras(env, True)
    raw = env.set_init_state(INIT_STATES[ep % len(INIT_STATES)])
    for _ in range(NUM_STEPS_WAIT):
        raw, _, _, _ = env.step(DUMMY)
    for r in env.robots:
        r.controller.use_delta = True
    return raw


def save_sim(e):
    """Full integration state + the Panda gripper's internal `current_action`
    (not part of the MuJoCo state)."""
    M, D = e.sim.model._model, e.sim.data._data
    s = np.empty(mujoco.mj_stateSize(M, _SPEC))
    mujoco.mj_getState(M, D, s, _SPEC)
    g = getattr(e.robots[0].gripper, "current_action", None)
    return s, (None if g is None else np.array(g, copy=True))


def load_sim(e, snap):
    s, g = snap
    M, D = e.sim.model._model, e.sim.data._data
    mujoco.mj_setState(M, D, s, _SPEC)
    mujoco.mj_forward(M, D)
    if g is not None:
        e.robots[0].gripper.current_action = np.array(g, copy=True)
    e.robots[0].controller.update(force=True)


def qoi_now(e):
    """raw positions: EE, white mug, yellow-white mug, left plate, right plate (15 numbers)."""
    d = e.sim.data
    bid = e.env.obj_body_id
    return np.concatenate([np.array(d.site_xpos[e.robots[0].eef_site_id]),
                           np.array(d.body_xpos[bid["porcelain_mug_1"]]),
                           np.array(d.body_xpos[bid["white_yellow_mug_1"]]),
                           np.array(d.body_xpos[bid["plate_1"]]),
                           np.array(d.body_xpos[bid["plate_2"]])])


def true_state(e):
    d = e.sim.data
    bid = e.env.obj_body_id
    r = e.robots[0]
    parts = [np.array(d.site_xpos[r.eef_site_id]), np.array(d.site_xmat[r.eef_site_id]).ravel()]
    try:
        parts.append(np.array(d.qpos[r._ref_gripper_joint_pos_indexes]))
    except Exception:
        pass
    for name in ("porcelain_mug_1", "white_yellow_mug_1"):
        parts += [np.array(d.body_xpos[bid[name]]), np.array(d.body_xquat[bid[name]])]
    for name in ("plate_1", "plate_2"):
        parts.append(np.array(d.body_xpos[bid[name]]))
    return np.concatenate(parts)


def run_candidate(e, snap, actions):
    load_sim(e, snap)
    for a in actions:
        e.step(np.asarray(a, dtype=np.float64))
    return qoi_now(e)


def perturb(chunks, n):
    """Smooth random perturbation of randomly chosen policy chunks (dims 0..5; gripper kept)."""
    base = chunks[rng.integers(len(chunks), size=n)].copy()
    knots = rng.normal(0.0, PERT_SCALE, size=(n, PERT_KNOTS, 6))
    grid = np.linspace(0, 1, H)
    kx = np.linspace(0, 1, PERT_KNOTS)
    W = np.stack([np.interp(grid, kx, np.eye(PERT_KNOTS)[j]) for j in range(PERT_KNOTS)], axis=1)
    base[:, :, :6] += np.einsum("hk,nkd->nhd", W, knots)
    return np.clip(base, -1.0, 1.0)


# ---------------- workers (spawned; each builds a renderer-free env) ----------------
_WENV = None


def _worker_init(bddl):
    global _WENV
    torch.set_num_threads(1)
    from libero.libero.envs.env_wrapper import ControlEnv
    _WENV = ControlEnv(bddl_file_name=bddl, use_camera_obs=False, has_renderer=False,
                       has_offscreen_renderer=False, control_freq=20, ignore_done=True)
    _WENV.reset()
    for r in _WENV.robots:
        r.controller.use_delta = True


def _worker_job(args):
    sim, grip, cands = args
    return np.stack([run_candidate(_WENV, (sim, grip), c) for c in cands])



# ======================================================================
# 4. STEERING v6 — Corollary 5.4 on a stochastic (flow-matching) policy, OpenVLA-OFT protocol
#
#   representation   prefix (VLM input embeddings), z = 32 leading PCA coordinates fitted on the
#                    fitting fold only, standardized
#   Phi(z')          = E_eps[S(u(z', eps))], mean chunk signature (flow matching: u = T(prefix, eps))
#   lambda_psi(x)    = D Phi(z(x))^T c(x),  c(x) = non-empty-word part of L_psi^* z(x)
#                    D Phi by central differences along the 32 axes with common gradient noise
#   oracle           grad_z E_eps[psi(F_u x)]: the same displacements, executed in the simulator
#   gamma_psi(u0)    a + W E_eps[S(u)]: the increment probe differentiated in its state argument,
#                    chunk signature held at the policy mean (no head information)
#   static           static probe direction;  global: mean of the normalized lambda_psi of
#                    fitting-fold states, applied unchanged to every held-out state
#   evaluation       fresh noise, shared across strengths and directions; 2 folds of episodes
# ======================================================================

import pickle
from scipy.stats import spearmanr
from sklearn.linear_model import RidgeCV


def sig2(U):
    """time-augmented signature up to level 2, dX = (dt, u dt)."""
    U = np.asarray(U, dtype=np.float64)
    N, Hh, A = U.shape
    dt = 1.0 / Hh
    dx = np.concatenate([np.full((N, Hh, 1), dt), U * dt], axis=2)
    prev = np.cumsum(dx, axis=1) - dx
    S2 = np.einsum("nti,ntj->nij", prev, dx) + 0.5 * np.einsum("nti,ntj->nij", dx, dx)
    return np.concatenate([dx.sum(axis=1), S2.reshape(N, -1)], axis=1)


DATA = "/content/drive/MyDrive/aclrh/probe_v2.npz"
OUT_ST = "/content/drive/MyDrive/aclrh/smolvla_steering_v6.npz"
CKPT = "/content/drive/MyDrive/aclrh/smolvla_steering_v6_partial.pkl"     # per-state checkpoint (resume)
QOI_ALL = ["EE z (control)", "mug1 z", "mug2 z", "-d(mug1,plate) xy", "-d(mug2,plate) xy",
           "-d(EE,mug1)", "-d(EE,mug2)"]
QOI_RUN = ["mug1 z", "mug2 z", "-d(mug1,plate) xy", "-d(EE,mug1)", "EE z (control)"]   # add the other two later
MOVE_FILTER = {"mug1 z", "mug2 z", "-d(mug1,plate) xy", "-d(mug2,plate) xy"}            # the mug must respond
N_PER_FOLD = 10              # steered states per QoI and fold (2 folds -> 20 per QoI)
PCA_K = 32
MOVE_MM, MIN_FRAC = 2e-3, 0.5
H_Z = 0.25                   # finite-difference step, standardized PCA units
K_J = 32                     # chunks per Jacobian evaluation (common gradient noise)
K_G = 8                      # of those, simulated for the oracle (0 = no oracle)
K_ST = 16                    # chunks per steering level (fresh noise, shared across levels and directions)
TAUS = [-3.0, -1.5, 0.0, 1.5, 3.0]
STEP_REL = 0.003             # ||delta prefix|| / ||prefix|| per unit tau, identical for every direction
N_RANDOM = 3
N_GLOBAL = 8                 # fitting-fold states averaged into the global direction (0 = skip)
RIDGE = np.logspace(-2, 5, 15)
DIRS = ["sim-gradient", "Dphi^T lambda_psi", "gamma_psi", "static", "global"]


def target_plates(Q0r, EP, success):
    """target plate of each mug = the plate it is nearest to at the last snapshot of successful episodes"""
    out = []
    for m in (3, 6):
        votes = []
        for e in np.where(success)[0]:
            idx = np.where(EP == e)[0]
            if len(idx):
                p = Q0r[idx[-1]]
                votes.append(9 if np.linalg.norm(p[m:m + 2] - p[9:11]) < np.linalg.norm(p[m:m + 2] - p[12:14]) else 12)
        out.append(max(set(votes), key=votes.count) if votes else (9 if m == 3 else 12))
        print(f"  mug at {m}: target plate index {out[-1]} ({votes.count(out[-1])}/{len(votes)} successful episodes)")
    return out


def make_qoi(tp1, tp2):
    def f(P):
        P = np.asarray(P, dtype=np.float64)
        return np.stack([P[..., 2], P[..., 5], P[..., 8],
                         -np.linalg.norm(P[..., 3:5] - P[..., tp1:tp1 + 2], axis=-1),
                         -np.linalg.norm(P[..., 6:8] - P[..., tp2:tp2 + 2], axis=-1),
                         -np.linalg.norm(P[..., 0:3] - P[..., 3:6], axis=-1),
                         -np.linalg.norm(P[..., 0:3] - P[..., 6:9], axis=-1)], axis=-1)
    return f


def main_steer():
    header("STEERING v6 — Corollary 5.4 on SmolVLA (flow matching), held-out episodes")
    load_policy()
    global BDDL
    _, BDDL, _ = find_task()
    assert os.path.exists(DATA), (f"{DATA} not found: mount Drive first "
                                  "(from google.colab import drive; drive.mount('/content/drive'))")
    d = np.load(DATA)
    LAM = d["LAM"]                                         # float16 (NS, D); converted block by block
    EP, CS, Q0r, U, QFr = d["EP"], d["C_STATE"], d["Q0"], d["U"], d["QF"]
    IMG1, IMG2, ST8, SIM, GRIP = d["IMG1"], d["IMG2"], d["STATE8"], d["SIM"], d["GRIP"]
    NS, (NC, K) = len(EP), U.shape[:2]
    print("target plates:")
    qoi = make_qoi(*target_plates(Q0r, EP, d["success"]))
    Q0, QF = qoi(Q0r), qoi(QFr)                            # (NS, 7), (NC, K, 7)
    QI = {n: i for i, n in enumerate(QOI_ALL)}
    qidx = [QI[q] for q in QOI_RUN]

    S_all = sig2(U.reshape(NC * K, H, 7))
    s_mu, s_sd = S_all.mean(0), S_all.std(0)
    keep = s_sd > 1e-8 * s_sd.max()
    st = lambda UU: (sig2(UU)[:, keep] - s_mu[keep]) / s_sd[keep]
    S_all = (S_all[:, keep] - s_mu[keep]) / s_sd[keep]
    ps = S_all.shape[1]
    print(f"signature coordinates kept: {ps}")

    done = pickle.load(open(CKPT, "rb")) if os.path.exists(CKPT) else {}
    if done:
        print(f"resuming: {sum(1 for k in done if k[0] == 'row')} steered states already done")
    save_ck = lambda: pickle.dump(done, open(CKPT, "wb"))

    stamp("preparing LIBERO assets in the main process ...")
    _worker_init(BDDL)
    import concurrent.futures as cf
    import multiprocessing as mp
    pool = cf.ProcessPoolExecutor(max_workers=N_WORKERS, mp_context=mp.get_context("spawn"),
                                  initializer=_worker_init, initargs=(BDDL,))

    TIMES = {"sim": 0.0}
    print(f"CPU workers for the simulator: {N_WORKERS} | GPU: {torch.cuda.get_device_name(0)}", flush=True)

    def simulate(g, chunk_list):
        """positions (len(chunk_list), K, 15) after executing every chunk from state g"""
        t_ = time.time()
        out = _simulate(g, chunk_list)
        TIMES["sim"] += time.time() - t_
        return out

    def _simulate(g, chunk_list):
        kk = len(chunk_list[0])
        jobs = [(SIM[g], GRIP[g], c_[blk].astype(np.float64)) for c_ in chunk_list
                for blk in np.array_split(np.arange(len(c_)), JOB_SPLIT)]
        return np.concatenate(list(pool.map(_worker_job, jobs))).reshape(len(chunk_list), kk, -1)

    eps_all = np.unique(EP)
    folds = [(eps_all[::2], eps_all[1::2]), (eps_all[1::2], eps_all[::2])]
    T_START, n_done_now = time.time(), 0
    n_total = len(QOI_RUN) * N_PER_FOLD * 2

    for fi, (A_eps, B_eps) in enumerate(folds):
        header(f"FOLD {fi + 1}/2: fit on {len(A_eps)} episodes, steer in {len(B_eps)} held-out episodes")
        inA = np.isin(EP, A_eps)
        X = LAM[inA].astype(np.float32)
        mu = X.mean(0); X -= mu
        ev, V = np.linalg.eigh((X @ X.T).astype(np.float64)); ix = np.argsort(ev)[::-1][:PCA_K]
        comps = ((X.T.astype(np.float64) @ V[:, ix]) / np.sqrt(ev[ix])).astype(np.float32)   # orthonormal
        del X
        Zall = np.concatenate([(LAM[i:i + 64].astype(np.float32) - mu) @ comps for i in range(0, NS, 64)])
        zm, zs = Zall[inA].mean(0), Zall[inA].std(0) + 1e-12
        Zall = (Zall - zm) / zs
        z_of = lambda P: (((P.reshape(1, -1).numpy() - mu) @ comps) - zm) / zs
        to_prefix = lambda dz, shp: torch.from_numpy((comps @ (zs * dz)).astype(np.float32).reshape(shp))[None]
        disp = lambda dz: float(np.linalg.norm(zs * dz))          # ||delta prefix|| (orthonormal comps)

        # ---- probes on the fitting fold ----
        cA = np.where(inA[CS])[0]
        Z = np.repeat(Zall[CS[cA]], K, 0)
        S = S_all[(cA[:, None] * K + np.arange(K)).ravel()]
        Y = (QF[cA][:, :, qidx] - Q0[CS[cA]][:, None, qidx]).reshape(-1, len(qidx))
        inc = RidgeCV(alphas=RIDGE, alpha_per_target=True).fit(
            np.c_[Z, S, (Z[:, :, None] * S[:, None, :]).reshape(len(Z), -1)], Y)
        coef = np.atleast_2d(inc.coef_)
        a_inc, b_inc = coef[:, :PCA_K], coef[:, PCA_K:PCA_K + ps]
        W_inc = coef[:, PCA_K + ps:].reshape(len(qidx), PCA_K, ps)
        del Z, S
        sA = np.where(inA)[0]
        a_sta = np.atleast_2d(RidgeCV(alphas=RIDGE, alpha_per_target=True).fit(Zall[sA], Q0[sA][:, qidx]).coef_)
        stamp("probes fitted on the fitting fold")

        def state_cache(j, with_oracle):
            """Jacobian of the mean chunk signature, mean signature, oracle positions (cached per state)"""
            g = int(CS[j]); key = ("cache", fi, g)
            if key in done and (done[key]["pos_p"] is not None or not with_oracle):
                return done[key]
            P, PM, AM = prefix_of(policy_batch(IMG1[j], IMG2[j], ST8[g]))
            shp, sg = P.shape[1:], 9_100_000 + 10_000 * fi + g            # gradient noise
            Jm, Cps, Cms = np.zeros((ps, PCA_K)), [], []
            for kx in range(PCA_K):
                e = np.zeros(PCA_K); e[kx] = H_Z
                Cp = sample_chunks(P + to_prefix(e, shp), PM, AM, K_J, seed=sg)[:, :H]
                Cm = sample_chunks(P - to_prefix(e, shp), PM, AM, K_J, seed=sg)[:, :H]
                Jm[:, kx] = (st(Cp).mean(0) - st(Cm).mean(0)) / (2 * H_Z)
                Cps.append(Cp[:K_G]); Cms.append(Cm[:K_G])
            Sbar = st(sample_chunks(P, PM, AM, K_J, seed=sg)[:, :H]).mean(0)
            pos_p = pos_m = None
            if with_oracle and K_G > 0:
                pos = simulate(g, Cps + Cms)
                pos_p, pos_m = pos[:PCA_K], pos[PCA_K:]
            done[key] = dict(J=Jm, Sbar=Sbar, z0=z_of(P)[0], pn=float(P.norm()), pos_p=pos_p, pos_m=pos_m)
            save_ck()
            return done[key]

        # ---- global direction: mean normalized lambda_psi over fitting-fold states ----
        GLOBAL = None
        if N_GLOBAL > 0:
            gsel = np.random.default_rng(SEED + fi).choice(cA, size=min(N_GLOBAL, len(cA)), replace=False)
            acc = np.zeros((len(qidx), PCA_K))
            for n, j in enumerate(gsel):
                c_ = state_cache(j, with_oracle=False)
                for q in range(len(qidx)):
                    v = c_["J"].T @ (b_inc[q] + W_inc[q].T @ c_["z0"])
                    acc[q] += v / (disp(v) + 1e-300)
                stamp(f"  global direction: fitting-fold state {n + 1}/{len(gsel)}")
            GLOBAL = acc / len(gsel)

        # ---- steering at held-out states ----
        rng_ = np.random.default_rng(SEED + 100 + fi)
        for q, qn in enumerate(QOI_RUN):
            qi = QI[qn]
            cB = np.where(~inA[CS])[0]
            dq = QF[cB][:, :K_POL, qi] - Q0[CS[cB], qi][:, None]          # policy samples only
            frac, sd = (np.abs(dq) > MOVE_MM).mean(1), dq.std(1)
            ok = (frac >= (MIN_FRAC if qn in MOVE_FILTER else 0.0)) & (sd > MOVE_MM)
            sel = cB[ok][np.argsort(-sd[ok])][:N_PER_FOLD]
            print(f"\n[{qn}] fold {fi + 1}: eligible {ok.sum()} -> steering {len(sel)}", flush=True)
            for j in sel:
                g = int(CS[j]); key = ("row", fi, qn, g)
                if key in done:
                    continue
                t_state, sim0 = time.time(), TIMES["sim"]
                c_ = state_cache(j, with_oracle=True)
                Jm, z0, pn = c_["J"], c_["z0"], c_["pn"]
                c = b_inc[q] + W_inc[q].T @ z0
                dirs = {"Dphi^T lambda_psi": Jm.T @ c,
                        "gamma_psi": a_inc[q] + W_inc[q] @ c_["Sbar"],
                        "static": a_sta[q].copy()}
                if c_["pos_p"] is not None:
                    pp, pm_ = qoi(c_["pos_p"])[..., qi].mean(1), qoi(c_["pos_m"])[..., qi].mean(1)
                    dirs["sim-gradient"] = (pp - pm_) / (2 * H_Z)
                if GLOBAL is not None:
                    dirs["global"] = GLOBAL[q].copy()
                for i in range(N_RANDOM):
                    dirs[f"random{i}"] = rng_.normal(size=PCA_K)
                ref = dirs.get("sim-gradient")
                cosv = lambda a, b: float(a @ b / (np.linalg.norm(a) * np.linalg.norm(b) + 1e-300))
                cos_sim = {k_: (cosv(v, ref) if ref is not None else np.nan) for k_, v in dirs.items()}
                cos_glob = cosv(dirs["Dphi^T lambda_psi"], dirs["global"]) if "global" in dirs else np.nan
                lam_dir = dirs["Dphi^T lambda_psi"].copy()
                for k_ in dirs:
                    dirs[k_] = dirs[k_] / (disp(dirs[k_]) + 1e-300) * STEP_REL * pn
                pred = float(c @ Jm @ dirs["Dphi^T lambda_psi"])            # probe-predicted slope per unit tau
                # ---- evaluation: fresh noise, shared across strengths and directions ----
                P, PM, AM = prefix_of(policy_batch(IMG1[j], IMG2[j], ST8[g]))
                shp, se = P.shape[1:], 8_700_000 + 10_000 * fi + g
                keys, chunks = [("base", 0.0)], [sample_chunks(P, PM, AM, K_ST, seed=se)[:, :H]]
                for k_, v in dirs.items():
                    for t in TAUS:
                        if t != 0.0:
                            chunks.append(sample_chunks(P + to_prefix(t * v, shp), PM, AM, K_ST, seed=se)[:, :H])
                            keys.append((k_, t))
                vals = qoi(simulate(g, chunks))[..., qi] - Q0[g, qi]          # (n, K_ST)
                mean = {kt: vals[i].mean() for i, kt in enumerate(keys)}
                sdv = {kt: vals[i].std() for i, kt in enumerate(keys)}
                row = dict(state=g, fold=fi, cos_sim=cos_sim, cos_global=cos_glob, pred=pred, lam_dir=lam_dir)
                for k_ in dirs:
                    J_ = np.array([mean[("base", 0.0)] if t == 0.0 else mean[(k_, t)] for t in TAUS])
                    SD_ = np.array([sdv[("base", 0.0)] if t == 0.0 else sdv[(k_, t)] for t in TAUS])
                    row[k_] = dict(J=J_, SD=SD_, rho=float(spearmanr(TAUS, J_).correlation), eff=float(J_[-1] - J_[0]))
                i1, i0 = TAUS.index(1.5), TAUS.index(-1.5)
                row["meas"] = float((row["Dphi^T lambda_psi"]["J"][i1] - row["Dphi^T lambda_psi"]["J"][i0]) / (TAUS[i1] - TAUS[i0]))
                done[key] = row; save_ck()
                n_done_now += 1
                el = time.time() - T_START
                left = n_total - sum(1 for k in done if k[0] == "row")
                print(f"  state {g:5d} | " + " | ".join(
                    f"{nm} {1e3 * row[k_]['eff']:+5.1f}mm ρ{row[k_]['rho']:+.2f}"
                    for k_, nm in [("sim-gradient", "oracle"), ("Dphi^T lambda_psi", "ours"), ("gamma_psi", "γ"),
                                   ("static", "static"), ("global", "global")] if k_ in row)
                      + f" | cos(ours, oracle) {cos_sim['Dphi^T lambda_psi']:+.2f}"
                      + f" | ~{el / max(n_done_now, 1) * left / 60:.0f} min left", flush=True)
                t_all, t_sim = time.time() - t_state, TIMES["sim"] - sim0
                print(f"           time {t_all:5.1f} s = GPU {t_all - t_sim:5.1f} s + simulator {t_sim:5.1f} s", flush=True)

    pool.shutdown()

    # ---------------- summary ----------------
    header("SUMMARY (held-out episodes, 2 folds; equal prefix displacement per tau; fresh evaluation noise)")
    rows_by = {qn: [v for k, v in done.items() if k[0] == "row" and k[2] == qn] for qn in QOI_RUN}
    save = {"taus": np.array(TAUS), "step_rel": STEP_REL, "k_st": K_ST, "k_g": K_G}
    for qn, rows in rows_by.items():
        if not rows:
            continue
        print(f"\n{qn} ({len(rows)} states)")
        print(f"  {'direction':18s} | monotone (rho>0.8) | effect (mm) | beats all randoms | cos to oracle | spread at +max / at 0")
        for nm in DIRS:
            rs = [r for r in rows if nm in r]
            if not rs:
                continue
            rh = np.array([r[nm]["rho"] for r in rs]); ef = np.array([r[nm]["eff"] for r in rs])
            beat = np.array([r[nm]["eff"] > max(r[f"random{i}"]["eff"] for i in range(N_RANDOM)) for r in rs])
            cs = np.array([r["cos_sim"][nm] for r in rs]); spr = np.array([r[nm]["SD"][-1] / (r[nm]["SD"][TAUS.index(0.0)] + 1e-12) for r in rs])
            print(f"  {nm:18s} |       {np.mean(rh > 0.8):4.0%}         |   {1e3 * np.median(ef):+6.1f}    |"
                  f"      {np.mean(beat):4.0%}        |    {np.nanmedian(cs):+.2f}      |     {np.median(spr):.2f}")
            save[f"{qn}|{nm}|J"] = np.stack([r[nm]["J"] for r in rs])
            save[f"{qn}|{nm}|SD"] = np.stack([r[nm]["SD"] for r in rs])
            save[f"{qn}|{nm}|cos"] = cs
        rh = np.array([r[f"random{i}"]["rho"] for r in rows for i in range(N_RANDOM)])
        ef = np.array([r[f"random{i}"]["eff"] for r in rows for i in range(N_RANDOM)])
        print(f"  {'random':18s} |       {np.mean(rh > 0.8):4.0%}         |   {1e3 * np.median(ef):+6.1f}    |        -         |       -       |")
        for i in range(N_RANDOM):
            save[f"{qn}|random{i}|J"] = np.stack([r[f"random{i}"]["J"] for r in rows])
        ratio = np.array([r["meas"] / (r["pred"] + 1e-12) for r in rows])
        L = np.stack([r["lam_dir"] / (np.linalg.norm(r["lam_dir"]) + 1e-300) for r in rows])
        pc = (L @ L.T)[np.triu_indices(len(L), 1)]
        print(f"  lambda_psi: measured / probe-predicted slope (median) {np.median(ratio):.2f} | "
              f"cos with the global direction (median) {np.nanmedian([r['cos_global'] for r in rows]):+.2f} | "
              f"pairwise cos between states (median) {np.median(pc):+.2f}")
        save[f"{qn}|state"] = np.array([r["state"] for r in rows]); save[f"{qn}|fold"] = np.array([r["fold"] for r in rows])
        save[f"{qn}|ratio"] = ratio; save[f"{qn}|pairwise_cos"] = pc
    np.savez(OUT_ST, **save)
    print(r"""
READING (paper notation; Corollary 5.4 with z in place of lambda)
=======
ours (Dphi^T lambda_psi)  lambda_psi(x) = D Phi(z)^T L_psi^* z(x), Phi = mean chunk signature of the stochastic policy
oracle (sim-gradient)     gradient of the simulated expected QoI along the same 32 axes
gamma_psi                 probe differentiated in its state argument (chunk signature at the policy mean)
global                    one direction per QoI, averaged over fitting-fold states, applied to every held-out state
spread                    std of psi over the evaluation samples at tau = +max relative to tau = 0
""")
    stamp(f"saved {OUT_ST}")


if __name__ == "__main__":
    main_steer()
'''

FILE = "/content/run_smolvla_steering_v6.py"
with open(FILE, "w") as f:
    f.write(SCRIPT)

print("\n" + "=" * 100)
print("START EXPERIMENT")
print("=" * 100)
p = subprocess.Popen([PY, FILE], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
for line in p.stdout:
    print(line, end="")
rc = p.wait()
print("\nReturn code:", rc)
print("✅ COMPLETE" if rc == 0 else "❌ Stopped. Traceback above is enough to diagnose it.")
