# ======================================================================
# SmolVLA — what causes the jumps found by s7  (ONE Colab cell, CPU runtime, ~5 min; or L4 if EGL is missing)
#   1. figures   the s7 lines again, cleaned: main panel (4 representative pairs) and appendix panel (all pairs)
#   2. cause     for every pair, the two chunks on either side of the finest jump (|du| ~ 1e-8 apart) are executed
#                step by step; recorded per step: end effector, both mugs (position, tilt), finger opening, every
#                robot-mug contact (which robot geom, which mug, normal force). Reported: the step at which the two
#                runs separate, the contacts present in only one of them, and what differs at the end of the chunk.
#   3. figure    the two runs over time for one representative state
# No policy, no GPU. Needs on Drive (aclrh/): probe_v2.npz, smolvla_diagnose_s5_partial_v2.pkl, smolvla_discontinuity_s7.npz
# Writes aclrh/figs/smolvla_discontinuity_{main,all,cause}.(png|pdf), aclrh/smolvla_discontinuity_cause_s8.npz
# ======================================================================
import os, sys, subprocess, importlib.util

PY = sys.executable


def pip(*args, label=""):
    r = subprocess.run([PY, "-m", "pip", "install", "-q", *args], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    if r.returncode != 0:
        print("\n".join(r.stdout.strip().splitlines()[-40:]))
        raise RuntimeError(f"pip install failed: {label}")
    print(f"  ok: {label}")


if importlib.util.find_spec("libero") is None:
    print("Installing the LIBERO simulator (CPU) ...")
    pip("--no-deps", "hf-libero>=0.1.4,<0.2.0", "robosuite==1.4.0", "bddl==1.0.1", label="hf-libero / robosuite / bddl")
    pip("mujoco>=3.0.0,<3.9.0", "numba>=0.61", "scipy", "Pillow", "opencv-python-headless", "easydict",
        "gymnasium>=0.29.0", "h5py", "imageio", "matplotlib", "termcolor", "tqdm", "cloudpickle", "pyyaml",
        "networkx", "huggingface_hub", "PyOpenGL", label="simulator dependencies")

os.environ.setdefault("MUJOCO_GL", "egl")
os.environ.setdefault("PYOPENGL_PLATFORM", "egl")
import pickle, time, warnings
import numpy as np
import yaml
warnings.filterwarnings("ignore")

_cfg_dir = os.environ.setdefault("LIBERO_CONFIG_PATH", os.path.expanduser("~/.libero"))
os.makedirs(_cfg_dir, exist_ok=True)
if not os.path.exists(os.path.join(_cfg_dir, "config.yaml")):
    _root = os.path.join(list(importlib.util.find_spec("libero").submodule_search_locations)[0], "libero")
    yaml.dump({"benchmark_root": _root, "bddl_files": _root + "/bddl_files", "init_states": _root + "/init_files",
               "datasets": _root + "/../datasets", "assets": _root + "/assets"},
              open(os.path.join(_cfg_dir, "config.yaml"), "w"))

import mujoco
from libero.libero import benchmark, get_libero_path
from libero.libero.envs.env_wrapper import ControlEnv
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

try:
    from google.colab import drive
    if not os.path.isdir("/content/drive/MyDrive"):
        drive.mount("/content/drive")
except ImportError:
    pass
ROOT = os.environ.get("ACLRH_ROOT", "/content/drive/MyDrive/aclrh")
DATA, CKPT_S5 = f"{ROOT}/probe_v2.npz", f"{ROOT}/smolvla_diagnose_s5_partial_v2.pkl"
OUT, FIG = f"{ROOT}/smolvla_discontinuity_s7.npz", f"{ROOT}/figs/smolvla_discontinuity"
os.makedirs(f"{ROOT}/figs", exist_ok=True)

SUITE = "libero_10"
TASK_LANG = "put the white mug on the left plate and put the yellow and white mug on the right plate"
QOI_ALL = ["EE z (control)", "mug1 z", "mug2 z", "-d(mug1,plate) xy", "-d(mug2,plate) xy", "-d(EE,mug1)", "-d(EE,mug2)"]
H, K_POL = 20, 16
N_LINE, N_ZOOM, ZOOMS = 61, 41, 3     # points on the line; points per zoom level; zoom levels
N_CONTROLS = 3
_SPEC = mujoco.mjtState.mjSTATE_INTEGRATION


# ---------------------------------------------------------------- data, QoIs, pairs (as in s2, s5, s6)
def target_plates(Q0r, EP, success):
    out = []
    for m in (3, 6):
        votes = []
        for e in np.where(success)[0]:
            idx = np.where(EP == e)[0]
            if len(idx):
                p = Q0r[idx[-1]]
                votes.append(9 if np.linalg.norm(p[m:m + 2] - p[9:11]) < np.linalg.norm(p[m:m + 2] - p[12:14]) else 12)
        out.append(max(set(votes), key=votes.count) if votes else (9 if m == 3 else 12))
    return out


def make_qoi(tp1, tp2):
    def f(P):
        P = np.asarray(P, dtype=np.float64)
        return np.stack([P[..., 2], P[..., 5], P[..., 8],
                         -np.linalg.norm(P[..., 3:5] - P[..., tp1:tp1 + 2], axis=-1),
                         -np.linalg.norm(P[..., 6:8] - P[..., tp2:tp2 + 2], axis=-1),
                         -np.linalg.norm(P[..., 0:3] - P[..., 3:6], axis=-1),
                         -np.linalg.norm(P[..., 0:3] - P[..., 6:9], axis=-1)], axis=-1)
    return f


def split_modes(v, bim):
    o = np.argsort(v)
    k = int(np.argmax(np.diff(v[o]))) + 1 if bim else len(v) // 2
    return o[:k], o[k:]


d = np.load(DATA)
EP, CS, Q0r, U, QFr, SIM, GRIP = d["EP"], d["C_STATE"], d["Q0"], d["U"], d["QF"], d["SIM"], d["GRIP"]
qoi = make_qoi(*target_plates(Q0r, EP, d["success"]))
Q0, QF = qoi(Q0r), qoi(QFr)
QI = {n: i for i, n in enumerate(QOI_ALL)}
g2j = {int(g): j for j, g in enumerate(CS)}
s5 = pickle.load(open(CKPT_S5, "rb"))
bim_pairs = sorted([(r["qoi"], r["state"]) for r in s5.values() if r["bimodal"]])
uni_pairs = sorted([(r["qoi"], r["state"]) for r in s5.values() if not r["bimodal"]])[:N_CONTROLS]
print(f"{len(bim_pairs)} bimodal pairs + {len(uni_pairs)} unimodal controls")

# ---------------------------------------------------------------- simulator (renderer-free, as the s2 workers)
suite = benchmark.get_benchmark_dict()[SUITE]()
task = suite.get_task([i for i, t in enumerate(suite.tasks) if t.language == TASK_LANG][0])
BDDL = os.path.join(get_libero_path("bddl_files"), task.problem_folder, task.bddl_file)
env = ControlEnv(bddl_file_name=BDDL, use_camera_obs=False, has_renderer=False, has_offscreen_renderer=False,
                 control_freq=20, ignore_done=True)
env.reset()
for r_ in env.robots:
    r_.controller.use_delta = True
M = env.sim.model._model
name = lambda b: mujoco.mj_id2name(M, mujoco.mjtObj.mjOBJ_BODY, int(b)) or ""
GEOM_KIND = {}
for gid in range(M.ngeom):
    b = name(M.geom_bodyid[gid])
    GEOM_KIND[gid] = ("robot" if b.startswith(("robot0", "gripper0")) else
                      "mug1" if "porcelain_mug" in b else "mug2" if "white_yellow_mug" in b else "other")
print("geoms:", {k: sum(v == k for v in GEOM_KIND.values()) for k in ("robot", "mug1", "mug2", "other")})


def load_sim(snap_s, snap_g):
    D = env.sim.data._data
    mujoco.mj_setState(M, D, snap_s, _SPEC)
    mujoco.mj_forward(M, D)
    if snap_g is not None:
        env.robots[0].gripper.current_action = np.array(snap_g, copy=True)
    env.robots[0].controller.update(force=True)


def qoi_now():
    dd, bid = env.sim.data, env.env.obj_body_id
    return np.concatenate([np.array(dd.site_xpos[env.robots[0].eef_site_id]),
                           np.array(dd.body_xpos[bid["porcelain_mug_1"]]), np.array(dd.body_xpos[bid["white_yellow_mug_1"]]),
                           np.array(dd.body_xpos[bid["plate_1"]]), np.array(dd.body_xpos[bid["plate_2"]])])


def run(g, actions):
    """positions after the chunk, and the steps with a robot-mug contact (per mug)"""
    load_sim(SIM[g], GRIP[g])
    touch = {"mug1": 0, "mug2": 0}
    for a in actions:
        env.step(np.asarray(a, dtype=np.float64))
        D = env.sim.data._data
        seen = set()
        for g1, g2 in zip(np.asarray(D.contact.geom1)[:D.ncon], np.asarray(D.contact.geom2)[:D.ncon]):
            k1, k2 = GEOM_KIND[int(g1)], GEOM_KIND[int(g2)]
            for m in ("mug1", "mug2"):
                if {k1, k2} == {"robot", m}:
                    seen.add(m)
        for m in seen:
            touch[m] += 1
    return qoi_now(), touch


# ---------------------------------------------------------------- sanity check: the recorded outcomes are reproduced
_, g0 = (bim_pairs + uni_pairs)[0]
j0 = g2j[g0]
pos, _ = run(g0, U[j0, 0].astype(np.float64))
err = np.abs(pos - QFr[j0, 0]).max()
print(f"replaying a recorded chunk: max position difference {1e3 * err:.3f} mm")
assert err < 1e-3, "the simulator does not reproduce the recorded outcome (different simulator version?)"

# ---------------------------------------------------------------- the jumps found by s7
S7 = np.load(f"{ROOT}/smolvla_discontinuity_s7.npz", allow_pickle=True)["res"]
print(f"{len(S7)} pairs from s7")
GEOM_NAME = {gid: (mujoco.mj_id2name(M, mujoco.mjtObj.mjOBJ_GEOM, gid) or f"{name(M.geom_bodyid[gid])}#{gid}")
             for gid in range(M.ngeom)}
try:
    FING = list(env.robots[0]._ref_gripper_joint_pos_indexes)
except Exception:
    FING = []


def chunks_of(r):
    """the two chunks of s7 (closest across the modes) and the two chunks on either side of the finest jump"""
    g, qi = int(r["state"]), QI[r["qoi"]]
    j = g2j[g]
    Uj = U[j, :K_POL].astype(np.float64)
    v = QF[j, :K_POL, qi] - Q0[g, qi]
    lo, hi = split_modes(v, r["bimodal"])
    D_ = np.linalg.norm((Uj[lo][:, None] - Uj[hi][None]).reshape(len(lo), len(hi), -1), axis=2)
    a, b = np.unravel_index(np.argmin(D_), D_.shape)
    ua, ub = Uj[lo[a]], Uj[hi[b]]
    lz = r["levels"][-1]
    k = int(np.argmax(np.abs(np.diff(lz["psi"]))))
    la, lb = float(lz["l"][k]), float(lz["l"][k + 1])
    return (1 - la) * ua + la * ub, (1 - lb) * ua + lb * ub, la, lb


def tilt(dd, b):
    R = np.array(dd.body_xmat[b]).reshape(3, 3)
    return float(np.degrees(np.arccos(np.clip(R[2, 2], -1, 1))))


def run_log(g, actions):
    """per step: EE, mug positions and tilts, finger opening, robot-mug contacts (geom names, normal force in N)"""
    load_sim(SIM[g], GRIP[g])
    dd, bid = env.sim.data, env.env.obj_body_id
    b1, b2 = bid["porcelain_mug_1"], bid["white_yellow_mug_1"]
    log = []
    for a in actions:
        env.step(np.asarray(a, dtype=np.float64))
        D = env.sim.data._data
        cons = []
        for i in range(D.ncon):
            g1, g2 = int(np.asarray(D.contact.geom1)[i]), int(np.asarray(D.contact.geom2)[i])
            k1, k2 = GEOM_KIND[g1], GEOM_KIND[g2]
            if "robot" in (k1, k2) and ({k1, k2} & {"mug1", "mug2"}):
                f = np.zeros(6); mujoco.mj_contactForce(M, D, i, f)
                rg, mg = (g1, g2) if k1 == "robot" else (g2, g1)
                cons.append((GEOM_NAME[rg], GEOM_KIND[mg], float(abs(f[0]))))
        log.append(dict(ee=np.array(dd.site_xpos[env.robots[0].eef_site_id]), m1=np.array(dd.body_xpos[b1]),
                        m2=np.array(dd.body_xpos[b2]), t1=tilt(dd, b1), t2=tilt(dd, b2),
                        fing=float(np.sum(np.abs(np.array(dd.qpos)[FING]))) if FING else np.nan, cons=cons))
    return log


def summarize_contacts(log, t0, t1):
    out = {}
    for s in log[t0:t1]:
        for rg, m, f in s["cons"]:
            out[(rg, m)] = max(out.get((rg, m), 0.0), f)
    return out


DT = 0.05
causes, logs = [], {}
print("\n" + "=" * 100 + "\nCAUSE: the two chunks on either side of each jump, executed step by step\n" + "=" * 100)
for r in S7:
    g, qn = int(r["state"]), r["qoi"]
    jump = r["jumps"][-1] / (r["range"] + 1e-12)
    ca, cb, la, lb = chunks_of(r)
    A, B = run_log(g, ca), run_log(g, cb)
    logs[(qn, g)] = (A, B)
    T = len(A)
    gap = np.array([max(np.linalg.norm(A[t]["ee"] - B[t]["ee"]), np.linalg.norm(A[t]["m1"] - B[t]["m1"]),
                        np.linalg.norm(A[t]["m2"] - B[t]["m2"])) for t in range(T)])
    div = int(np.argmax(gap > 1e-3)) if (gap > 1e-3).any() else None
    p0 = {"ee": Q0r[g, 0:3], "m1": Q0r[g, 3:6], "m2": Q0r[g, 6:9]}
    info = dict(qoi=qn, state=g, bimodal=bool(r["bimodal"]), discontinuous=bool(jump >= 0.5), du_step=float(
        np.linalg.norm(cb - ca)), div=div, final_gap_mm=1e3 * float(gap[-1]))
    for X, nm in ((A, "A"), (B, "B")):
        info[f"{nm} ee move"] = 1e3 * float(np.linalg.norm(X[-1]["ee"] - p0["ee"]))
        info[f"{nm} mug1 move"] = 1e3 * float(np.linalg.norm(X[-1]["m1"] - p0["m1"]))
        info[f"{nm} mug2 move"] = 1e3 * float(np.linalg.norm(X[-1]["m2"] - p0["m2"]))
        info[f"{nm} mug1 tilt"] = X[-1]["t1"]; info[f"{nm} mug2 tilt"] = X[-1]["t2"]
        info[f"{nm} fingers"] = X[-1]["fing"]
        info[f"{nm} contact steps"] = sum(1 for s in X if s["cons"])
    labels = []
    if div is not None:
        w0, w1 = max(0, div - 2), min(T, div + 3)
        cA, cB = summarize_contacts(A, w0, w1), summarize_contacts(B, w0, w1)
        info["contacts only A"] = sorted([(k, v) for k, v in cA.items() if k not in cB], key=lambda t: -t[1])[:3]
        info["contacts only B"] = sorted([(k, v) for k, v in cB.items() if k not in cA], key=lambda t: -t[1])[:3]
        info["force A/B at divergence"] = (max(cA.values(), default=0.0), max(cB.values(), default=0.0))
        for m in ("mug1", "mug2"):
            dm = abs(info[f"A {m} move"] - info[f"B {m} move"])
            dt_ = abs(info[f"A {m} tilt"] - info[f"B {m} tilt"])
            if dt_ > 10:
                labels.append(f"{m} tipped in one run ({info[f'A {m} tilt']:.0f}° vs {info[f'B {m} tilt']:.0f}°)")
            elif dm > 5:
                labels.append(f"{m} pushed/dragged in one run ({info[f'A {m} move']:.0f} vs {info[f'B {m} move']:.0f} mm)")
        de = abs(info["A ee move"] - info["B ee move"])
        if de > 5:
            labels.append(f"end effector stopped in one run (moves {info['A ee move']:.0f} vs {info['B ee move']:.0f} mm)")
        if np.isfinite(info["A fingers"]) and abs(info["A fingers"] - info["B fingers"]) > 5e-3:
            labels.append(f"fingers close differently ({info['A fingers']:.3f} vs {info['B fingers']:.3f}): grasp vs no grasp")
        if info["contacts only A"] or info["contacts only B"]:
            labels.append("a contact exists in one run only")
    info["labels"] = labels or ["no difference above the thresholds"]
    causes.append(info)
    print(f"\n{'BIMODAL ' if r['bimodal'] else 'unimodal'} {qn:16s} state {g:5d} | jump survives zooming: "
          f"{'YES' if info['discontinuous'] else 'no '} | the two chunks differ by |du| {info['du_step']:.1e}")
    if div is None:
        print("   the two runs never differ by more than 1 mm")
        continue
    print(f"   identical until step {div} ({div * DT:.2f} s of {T * DT:.2f} s); final difference {info['final_gap_mm']:.1f} mm")
    print(f"   at the divergence: max robot-mug normal force A {info['force A/B at divergence'][0]:.1f} N | "
          f"B {info['force A/B at divergence'][1]:.1f} N")
    print(f"   contacts only in A: {[(k[0], k[1], round(v, 1)) for k, v in info['contacts only A']]}")
    print(f"   contacts only in B: {[(k[0], k[1], round(v, 1)) for k, v in info['contacts only B']]}")
    print(f"   end of chunk  A: EE moved {info['A ee move']:.0f} mm, mug1 {info['A mug1 move']:.0f} mm / tilt {info['A mug1 tilt']:.0f}°, "
          f"mug2 {info['A mug2 move']:.0f} mm, fingers {info['A fingers']:.3f}, contact in {info['A contact steps']}/{T} steps")
    print(f"                 B: EE moved {info['B ee move']:.0f} mm, mug1 {info['B mug1 move']:.0f} mm / tilt {info['B mug1 tilt']:.0f}°, "
          f"mug2 {info['B mug2 move']:.0f} mm, fingers {info['B fingers']:.3f}, contact in {info['B contact steps']}/{T} steps")
    print("   -> " + "; ".join(info["labels"]))

print("\n" + "=" * 100 + "\nSUMMARY OF CAUSES (pairs whose jump survives zooming)\n" + "=" * 100)
disc = [c for c in causes if c["discontinuous"]]
from collections import Counter
cnt = Counter()
for c in disc:
    for l_ in c["labels"]:
        cnt[l_.split(" (")[0]] += 1
for k_, v_ in cnt.most_common():
    print(f"  {v_:2d}/{len(disc)}  {k_}")
print(f"  divergence step (median): {np.median([c['div'] for c in disc if c['div'] is not None]):.0f} of {H}")

# ---------------------------------------------------------------- figures
INK, INK2, GRIDC = "#0b0b0b", "#52514e", "#e1e0d9"
plt.rcParams.update({"font.size": 8, "axes.edgecolor": "#c3c2b7", "axes.labelcolor": INK2, "xtick.color": INK2, "ytick.color": INK2})


def line_panel(ax, r, inset=True):
    lv = r["levels"][0]
    col = "#2a78d6" if r["bimodal"] else "#898781"
    ax.plot(lv["l"], 1e3 * lv["psi"], color=col, lw=1.5, marker="o", ms=1.8)
    ax.set_title(f"{'bimodal' if r['bimodal'] else 'unimodal'} · {r['qoi']} · state {r['state']}", fontsize=7.5, color=INK)
    ax.set_xlabel("interpolation l (low → high mode)", fontsize=7); ax.set_ylabel("Δψ (mm)", fontsize=7)
    ax.tick_params(labelsize=6.5); ax.spines[["top", "right"]].set_visible(False)
    ax.yaxis.grid(True, color=GRIDC, lw=0.5); ax.set_axisbelow(True)
    if inset:
        lz = r["levels"][-1]
        x = (lz["l"] - lz["l"][0]) / (np.ptp(lz["l"]) + 1e-300)
        up, right = lz["psi"][-1] > lz["psi"][0], r["at"] > 0.55   # put the inset in a corner the curve leaves empty
        pos = {(True, True): [0.06, 0.58, 0.34, 0.30], (True, False): [0.62, 0.10, 0.34, 0.30],
               (False, True): [0.06, 0.10, 0.34, 0.30], (False, False): [0.62, 0.58, 0.34, 0.30]}[(bool(up), bool(right))]
        ins = ax.inset_axes(pos)
        ins.plot(x, 1e3 * (lz["psi"] - lz["psi"][0]), color="#0d366b", lw=1.1)
        ins.set_xticks([]); ins.tick_params(labelsize=5.5)
        ins.ticklabel_format(axis="y", useOffset=False, style="plain")
        ins.set_title(f"interval ×1/{(N_LINE - 1) * (N_ZOOM - 1) ** ZOOMS:.0e}", fontsize=5.5, pad=1)
        ins.set_ylabel("mm", fontsize=5.5, labelpad=1)


byk = {(r["qoi"], int(r["state"])): r for r in S7}
REP = [k for k in [("-d(EE,mug1)", 618), ("EE z (control)", 979), ("EE z (control)", 215), ("-d(EE,mug1)", 283)] if k in byk]
REP = REP or list(byk)[:4]
fig, axes = plt.subplots(1, len(REP), figsize=(3.0 * len(REP), 2.3), squeeze=False)
for ax, k in zip(axes[0], REP):
    line_panel(ax, byk[k])
fig.tight_layout()
for ext in ("png", "pdf"):
    fig.savefig(f"{FIG}_main.{ext}", dpi=250, bbox_inches="tight")
n = len(S7); nc = 4; nr = int(np.ceil(n / nc))
fig, axes = plt.subplots(nr, nc, figsize=(3.0 * nc, 2.3 * nr), squeeze=False)
for ax, r in zip(axes.ravel(), S7):
    line_panel(ax, r)
for ax in axes.ravel()[n:]:
    ax.axis("off")
fig.tight_layout()
for ext in ("png", "pdf"):
    fig.savefig(f"{FIG}_all.{ext}", dpi=200, bbox_inches="tight")

# cause figure: the two runs either side of the jump, one representative pair
kc = next((k for k in [("-d(EE,mug1)", 618), ("EE z (control)", 618)] if k in logs),
          next(((c["qoi"], c["state"]) for c in disc), None))
if kc is not None:
    A, B = logs[kc]; T = len(A); t = np.arange(1, T + 1) * DT
    fig, axs = plt.subplots(1, 4, figsize=(11.5, 2.3))
    for X, col, lab in ((A, "#2a78d6", "just below the jump"), (B, "#eb6834", "just above")):
        axs[0].plot(t, [1e3 * (s["ee"][2] - Q0r[kc[1], 2]) for s in X], color=col, lw=1.4, label=lab)
        axs[1].plot(t, [1e3 * np.linalg.norm(s["m1"] - Q0r[kc[1], 3:6]) for s in X], color=col, lw=1.4)
        axs[2].plot(t, [max([f for _, m, f in s["cons"] if m == "mug1"], default=0.0) for s in X], color=col, lw=1.4)
        axs[3].plot(t, [s["fing"] for s in X], color=col, lw=1.4)
    for ax, yl in zip(axs, ["EE height change (mm)", "white mug displacement (mm)", "robot–white mug force (N)", "finger opening (rad)"]):
        ax.set_xlabel("time in the chunk (s)", fontsize=7); ax.set_ylabel(yl, fontsize=7)
        ax.tick_params(labelsize=6.5); ax.spines[["top", "right"]].set_visible(False)
    c0 = next(c for c in causes if (c["qoi"], c["state"]) == kc)
    if c0["div"] is not None:
        for ax in axs:
            ax.axvline((c0["div"] + 1) * DT, color="#c3c2b7", lw=0.8, ls="--")
    axs[0].legend(frameon=False, fontsize=6.5)
    fig.suptitle(f"state {kc[1]}: two chunks {c0['du_step']:.0e} apart, executed", fontsize=8, color=INK)
    fig.tight_layout()
    for ext in ("png", "pdf"):
        fig.savefig(f"{FIG}_cause.{ext}", dpi=250, bbox_inches="tight")
np.savez(f"{ROOT}/smolvla_discontinuity_cause_s8.npz", causes=np.array(causes, dtype=object))
print(f"\nsaved {FIG}_main / _all / _cause (.png, .pdf) and {ROOT}/smolvla_discontinuity_cause_s8.npz")
