# ======================================================================
# SmolVLA — is the outcome discontinuous in the chunk at the bimodal states?  (ONE Colab cell, CPU runtime, ~10-20 min)
#   For every bimodal pair of smolvla/s5 (and 3 unimodal controls), take the two recorded policy samples, one from
#   each outcome mode, whose chunks are closest, and execute the straight line between them,
#       u(l) = (1 - l) u_low + l u_high,  l in [0, 1]
#   from the saved simulator state. A jump of psi along l that stays as large when the interval around it is
#   zoomed in three times (each time 40x finer) is a discontinuity at the simulator's resolution; a smooth ramp is not.
#   Also recorded along l: robot-mug contacts during the chunk, and how far each mug moves.
# No policy, no GPU: only the simulator and the recorded chunks.
# Needs on Drive (aclrh/): probe_v2.npz (s1), smolvla_diagnose_s5_partial_v2.pkl (s5).
# Writes aclrh/smolvla_discontinuity_s7.npz and aclrh/figs/smolvla_discontinuity.(png|pdf)
# ======================================================================
import os, sys, subprocess, importlib.util

PY = sys.executable


def pip(*args, label=""):
    r = subprocess.run([PY, "-m", "pip", "install", "-q", *args], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    if r.returncode != 0:
        print("\n".join(r.stdout.strip().splitlines()[-40:]))
        raise RuntimeError(f"pip install failed: {label}")
    print(f"  ok: {label}")


if importlib.util.find_spec("libero") is None:
    print("Installing the LIBERO simulator (CPU) ...")
    pip("--no-deps", "hf-libero>=0.1.4,<0.2.0", "robosuite==1.4.0", "bddl==1.0.1", label="hf-libero / robosuite / bddl")
    pip("mujoco>=3.0.0,<3.9.0", "numba>=0.61", "scipy", "Pillow", "opencv-python-headless", "easydict",
        "gymnasium>=0.29.0", "h5py", "imageio", "matplotlib", "termcolor", "tqdm", "cloudpickle", "pyyaml",
        "networkx", "huggingface_hub", "PyOpenGL", label="simulator dependencies")

os.environ.setdefault("MUJOCO_GL", "egl")
os.environ.setdefault("PYOPENGL_PLATFORM", "egl")
import pickle, time, warnings
import numpy as np
import yaml
warnings.filterwarnings("ignore")

_cfg_dir = os.environ.setdefault("LIBERO_CONFIG_PATH", os.path.expanduser("~/.libero"))
os.makedirs(_cfg_dir, exist_ok=True)
if not os.path.exists(os.path.join(_cfg_dir, "config.yaml")):
    _root = os.path.join(list(importlib.util.find_spec("libero").submodule_search_locations)[0], "libero")
    yaml.dump({"benchmark_root": _root, "bddl_files": _root + "/bddl_files", "init_states": _root + "/init_files",
               "datasets": _root + "/../datasets", "assets": _root + "/assets"},
              open(os.path.join(_cfg_dir, "config.yaml"), "w"))

import mujoco
from libero.libero import benchmark, get_libero_path
from libero.libero.envs.env_wrapper import ControlEnv
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

try:
    from google.colab import drive
    if not os.path.isdir("/content/drive/MyDrive"):
        drive.mount("/content/drive")
except ImportError:
    pass
ROOT = os.environ.get("ACLRH_ROOT", "/content/drive/MyDrive/aclrh")
DATA, CKPT_S5 = f"{ROOT}/probe_v2.npz", f"{ROOT}/smolvla_diagnose_s5_partial_v2.pkl"
OUT, FIG = f"{ROOT}/smolvla_discontinuity_s7.npz", f"{ROOT}/figs/smolvla_discontinuity"
os.makedirs(f"{ROOT}/figs", exist_ok=True)

SUITE = "libero_10"
TASK_LANG = "put the white mug on the left plate and put the yellow and white mug on the right plate"
QOI_ALL = ["EE z (control)", "mug1 z", "mug2 z", "-d(mug1,plate) xy", "-d(mug2,plate) xy", "-d(EE,mug1)", "-d(EE,mug2)"]
H, K_POL = 20, 16
N_LINE, N_ZOOM, ZOOMS = 61, 41, 3     # points on the line; points per zoom level; zoom levels
N_CONTROLS = 3
_SPEC = mujoco.mjtState.mjSTATE_INTEGRATION


# ---------------------------------------------------------------- data, QoIs, pairs (as in s2, s5, s6)
def target_plates(Q0r, EP, success):
    out = []
    for m in (3, 6):
        votes = []
        for e in np.where(success)[0]:
            idx = np.where(EP == e)[0]
            if len(idx):
                p = Q0r[idx[-1]]
                votes.append(9 if np.linalg.norm(p[m:m + 2] - p[9:11]) < np.linalg.norm(p[m:m + 2] - p[12:14]) else 12)
        out.append(max(set(votes), key=votes.count) if votes else (9 if m == 3 else 12))
    return out


def make_qoi(tp1, tp2):
    def f(P):
        P = np.asarray(P, dtype=np.float64)
        return np.stack([P[..., 2], P[..., 5], P[..., 8],
                         -np.linalg.norm(P[..., 3:5] - P[..., tp1:tp1 + 2], axis=-1),
                         -np.linalg.norm(P[..., 6:8] - P[..., tp2:tp2 + 2], axis=-1),
                         -np.linalg.norm(P[..., 0:3] - P[..., 3:6], axis=-1),
                         -np.linalg.norm(P[..., 0:3] - P[..., 6:9], axis=-1)], axis=-1)
    return f


def split_modes(v, bim):
    o = np.argsort(v)
    k = int(np.argmax(np.diff(v[o]))) + 1 if bim else len(v) // 2
    return o[:k], o[k:]


d = np.load(DATA)
EP, CS, Q0r, U, QFr, SIM, GRIP = d["EP"], d["C_STATE"], d["Q0"], d["U"], d["QF"], d["SIM"], d["GRIP"]
qoi = make_qoi(*target_plates(Q0r, EP, d["success"]))
Q0, QF = qoi(Q0r), qoi(QFr)
QI = {n: i for i, n in enumerate(QOI_ALL)}
g2j = {int(g): j for j, g in enumerate(CS)}
s5 = pickle.load(open(CKPT_S5, "rb"))
bim_pairs = sorted([(r["qoi"], r["state"]) for r in s5.values() if r["bimodal"]])
uni_pairs = sorted([(r["qoi"], r["state"]) for r in s5.values() if not r["bimodal"]])[:N_CONTROLS]
print(f"{len(bim_pairs)} bimodal pairs + {len(uni_pairs)} unimodal controls")

# ---------------------------------------------------------------- simulator (renderer-free, as the s2 workers)
suite = benchmark.get_benchmark_dict()[SUITE]()
task = suite.get_task([i for i, t in enumerate(suite.tasks) if t.language == TASK_LANG][0])
BDDL = os.path.join(get_libero_path("bddl_files"), task.problem_folder, task.bddl_file)
env = ControlEnv(bddl_file_name=BDDL, use_camera_obs=False, has_renderer=False, has_offscreen_renderer=False,
                 control_freq=20, ignore_done=True)
env.reset()
for r_ in env.robots:
    r_.controller.use_delta = True
M = env.sim.model._model
name = lambda b: mujoco.mj_id2name(M, mujoco.mjtObj.mjOBJ_BODY, int(b)) or ""
GEOM_KIND = {}
for gid in range(M.ngeom):
    b = name(M.geom_bodyid[gid])
    GEOM_KIND[gid] = ("robot" if b.startswith(("robot0", "gripper0")) else
                      "mug1" if "porcelain_mug" in b else "mug2" if "white_yellow_mug" in b else "other")
print("geoms:", {k: sum(v == k for v in GEOM_KIND.values()) for k in ("robot", "mug1", "mug2", "other")})


def load_sim(snap_s, snap_g):
    D = env.sim.data._data
    mujoco.mj_setState(M, D, snap_s, _SPEC)
    mujoco.mj_forward(M, D)
    if snap_g is not None:
        env.robots[0].gripper.current_action = np.array(snap_g, copy=True)
    env.robots[0].controller.update(force=True)


def qoi_now():
    dd, bid = env.sim.data, env.env.obj_body_id
    return np.concatenate([np.array(dd.site_xpos[env.robots[0].eef_site_id]),
                           np.array(dd.body_xpos[bid["porcelain_mug_1"]]), np.array(dd.body_xpos[bid["white_yellow_mug_1"]]),
                           np.array(dd.body_xpos[bid["plate_1"]]), np.array(dd.body_xpos[bid["plate_2"]])])


def run(g, actions):
    """positions after the chunk, and the steps with a robot-mug contact (per mug)"""
    load_sim(SIM[g], GRIP[g])
    touch = {"mug1": 0, "mug2": 0}
    for a in actions:
        env.step(np.asarray(a, dtype=np.float64))
        D = env.sim.data._data
        seen = set()
        for g1, g2 in zip(np.asarray(D.contact.geom1)[:D.ncon], np.asarray(D.contact.geom2)[:D.ncon]):
            k1, k2 = GEOM_KIND[int(g1)], GEOM_KIND[int(g2)]
            for m in ("mug1", "mug2"):
                if {k1, k2} == {"robot", m}:
                    seen.add(m)
        for m in seen:
            touch[m] += 1
    return qoi_now(), touch


# ---------------------------------------------------------------- sanity check: the recorded outcomes are reproduced
_, g0 = (bim_pairs + uni_pairs)[0]
j0 = g2j[g0]
pos, _ = run(g0, U[j0, 0].astype(np.float64))
err = np.abs(pos - QFr[j0, 0]).max()
print(f"replaying a recorded chunk: max position difference {1e3 * err:.3f} mm")
assert err < 1e-3, "the simulator does not reproduce the recorded outcome (different simulator version?)"

# ---------------------------------------------------------------- lines between the closest chunks of the two modes
res = []
T0 = time.time()
for bim, (qn, g) in [(True, p) for p in bim_pairs] + [(False, p) for p in uni_pairs]:
    j, qi = g2j[g], QI[qn]
    Uj = U[j, :K_POL].astype(np.float64)
    v = QF[j, :K_POL, qi] - Q0[g, qi]
    lo, hi = split_modes(v, bim)
    D_ = np.linalg.norm((Uj[lo][:, None] - Uj[hi][None]).reshape(len(lo), len(hi), -1), axis=2)
    a, b = np.unravel_index(np.argmin(D_), D_.shape)
    ua, ub = Uj[lo[a]], Uj[hi[b]]
    du = float(np.linalg.norm(ub - ua))

    def line(ls):
        out = [run(g, (1 - l) * ua + l * ub) for l in ls]
        return (np.array([qoi(p)[qi] - Q0[g, qi] for p, _ in out]),
                np.array([[t["mug1"], t["mug2"]] for _, t in out]),
                np.array([[np.linalg.norm(p[3:6] - Q0r[g, 3:6]), np.linalg.norm(p[6:9] - Q0r[g, 6:9])] for p, _ in out]))

    L = np.linspace(0, 1, N_LINE)
    psi, touch, moved = line(L)
    levels = [dict(l=L, psi=psi, touch=touch, moved=moved)]
    lo_l, hi_l = L[np.argmax(np.abs(np.diff(psi)))], L[np.argmax(np.abs(np.diff(psi))) + 1]
    for z in range(ZOOMS):
        Lz = np.linspace(lo_l, hi_l, N_ZOOM)
        pz, tz, mz = line(Lz)
        levels.append(dict(l=Lz, psi=pz, touch=tz, moved=mz))
        k = int(np.argmax(np.abs(np.diff(pz))))
        lo_l, hi_l = Lz[k], Lz[k + 1]
    rng_ = float(np.ptp(psi))
    jumps = [float(np.abs(np.diff(lv["psi"])).max()) for lv in levels]
    widths = [float(np.ptp(lv["l"]) / (len(lv["l"]) - 1)) for lv in levels]       # step in l at each level
    row = dict(bimodal=bim, qoi=qn, state=g, du=du, gap=float(v[hi].mean() - v[lo].mean()), range=rng_,
               jumps=jumps, widths=widths, at=float(0.5 * (lo_l + hi_l)), levels=levels,
               ends=(float(v[lo[a]]), float(v[hi[b]])))
    res.append(row)
    keepfrac = jumps[-1] / (rng_ + 1e-12)
    tc = levels[0]["touch"].sum(1) > 0
    print(f"{'BIMODAL ' if bim else 'unimodal'} {qn:16s} state {g:5d} | closest chunks across the modes: |du| {du:.3f} "
          f"(outcomes {1e3 * row['ends'][0]:+.1f} / {1e3 * row['ends'][1]:+.1f} mm) | along the line: range {1e3 * rng_:.1f} mm, "
          f"largest step {1e3 * jumps[0]:.1f} mm -> after {ZOOMS} zooms ({widths[-1] * du:.1e} in |du|) still {1e3 * jumps[-1]:.1f} mm "
          f"= {keepfrac:.0%} of the range | contact with a mug along the line: {tc.mean():.0%} of the points "
          f"| {time.time() - T0:.0f} s", flush=True)

# ---------------------------------------------------------------- summary
print("\n" + "=" * 100 + "\nSUMMARY\n" + "=" * 100)
for grp in (True, False):
    R = [r for r in res if r["bimodal"] == grp]
    if not R:
        continue
    kf = np.array([r["jumps"][-1] / (r["range"] + 1e-12) for r in R])
    print(f"{'bimodal' if grp else 'unimodal'}: {len(R)} pairs | the largest step survives {ZOOMS} zooms (still >= 50% of the "
          f"range): {np.sum(kf >= 0.5)}/{len(R)} | median share of the range in one step after zooming {np.median(kf):.0%}")
print(f"""
READING
=======
a step that keeps (most of) its size while the interval shrinks {N_LINE - 1} x {N_ZOOM - 1}^{ZOOMS} times
    -> discontinuous in the chunk at the simulator's resolution: no smooth readout (signature or otherwise) can follow it
a step that shrinks with every zoom -> steep but continuous: a smooth readout could follow it given enough samples
contact columns: whether the step coincides with a robot-mug contact appearing or disappearing
""")

# ---------------------------------------------------------------- figure: psi along the line, with the zoomed step
n = len(res); nc = min(4, n); nr = int(np.ceil(n / nc))
fig, axes = plt.subplots(nr, nc, figsize=(3.2 * nc, 2.4 * nr), squeeze=False)
for ax, r in zip(axes.ravel(), res):
    lv = r["levels"][0]
    tc = lv["touch"].sum(1) > 0
    ax.plot(lv["l"], 1e3 * lv["psi"], color="#2a78d6" if r["bimodal"] else "#898781", lw=1.4)
    ax.scatter(lv["l"][tc], 1e3 * lv["psi"][tc], s=9, color="#eb6834", zorder=3, label="robot touches a mug")
    ax.axvline(r["at"], color="#c3c2b7", lw=0.8, ls="--")
    ax.set_title(f"{'bimodal' if r['bimodal'] else 'unimodal'} · {r['qoi']} · state {r['state']}", fontsize=7.5)
    ax.set_xlabel("interpolation l (low mode → high mode)", fontsize=7); ax.set_ylabel("Δψ (mm)", fontsize=7)
    ax.tick_params(labelsize=6.5); ax.spines[["top", "right"]].set_visible(False)
    ins = ax.inset_axes([0.58, 0.12, 0.38, 0.36])
    lz = r["levels"][-1]
    ins.plot((lz["l"] - lz["l"][0]) / (np.ptp(lz["l"]) + 1e-300), 1e3 * lz["psi"], color="#0d366b", lw=1)
    ins.set_xticks([]); ins.tick_params(labelsize=5.5)
    ins.set_title(f"zoom ×{(N_LINE - 1) * (N_ZOOM - 1) ** ZOOMS:.0e}", fontsize=5.5, pad=1)
for ax in axes.ravel()[n:]:
    ax.axis("off")
h_, l_ = axes.ravel()[0].get_legend_handles_labels()
if h_:
    fig.legend(h_[:1], l_[:1], loc="lower right", fontsize=7, frameon=False)
fig.tight_layout()
for ext in ("png", "pdf"):
    fig.savefig(f"{FIG}.{ext}", dpi=200, bbox_inches="tight")
np.savez(OUT, res=np.array(res, dtype=object))
print(f"saved {FIG}.png / .pdf and {OUT}")
