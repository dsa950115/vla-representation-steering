# ======================================================================
# SmolVLA steering v6 — ANALYSIS (CPU runtime, no model, no simulator)
#   Part A  tables for the paper from the per-state checkpoint:
#           steerable states (oracle rho >= 0.8 and effect > 2 sigma_hat sqrt(2/K_ST)), all-state table, LaTeX rows
#   Part B  diagnosis of sign reversals: refit the fold probes exactly as v6, then at every steered state compare
#           variants of the coefficient c in  lambda_psi = J^T c  with the oracle gradient, and check whether the
#           probe ranks the 32 recorded candidate chunks of that state correctly.
# Needs on Drive (aclrh/): probe_v2.npz, smolvla_steering_v6_partial.pkl. ~5-10 min.
# ======================================================================
import os, pickle, time
import numpy as np
from scipy.stats import spearmanr
from sklearn.linear_model import RidgeCV, Ridge
from google.colab import drive

if not os.path.exists("/content/drive/MyDrive"):
    drive.mount("/content/drive")
ROOT = "/content/drive/MyDrive/aclrh"
DATA, CKPT = f"{ROOT}/probe_v2.npz", f"{ROOT}/smolvla_steering_v6_partial.pkl"
OUT = f"{ROOT}/smolvla_steering_v6_analysis.npz"
RUN_B = True

# ---- constants of v6 (must match) ----
QOI_ALL = ["EE z (control)", "mug1 z", "mug2 z", "-d(mug1,plate) xy", "-d(mug2,plate) xy", "-d(EE,mug1)", "-d(EE,mug2)"]
QOI_RUN = ["mug1 z", "mug2 z", "-d(mug1,plate) xy", "-d(EE,mug1)", "EE z (control)"]
TABLE_ORDER = ["EE z (control)", "mug1 z", "mug2 z", "-d(mug1,plate) xy", "-d(EE,mug1)"]
LABEL = {"EE z (control)": r"EE $p_z$ (control)", "mug1 z": r"mug$_1$ $p_z$", "mug2 z": r"mug$_2$ $p_z$",
         "-d(mug1,plate) xy": r"$-d$(mug$_1$, plate)", "-d(EE,mug1)": r"$-d$(EE, mug$_1$)"}
PCA_K, H, K, K_ST, H_Z = 32, 20, 32, 16, 0.25
TAUS = [-3.0, -1.5, 0.0, 1.5, 3.0]
RIDGE = np.logspace(-2, 5, 15)
N_RANDOM = 3
DIRS = ["sim-gradient", "Dphi^T lambda_psi", "gamma_psi", "static", "global"]
RHO_MIN = 0.8
T0 = time.time()
stamp = lambda m: print(f"[{time.time() - T0:7.1f}s] {m}", flush=True)

done = pickle.load(open(CKPT, "rb"))
ROWS = {(k[1], k[2], k[3]): v for k, v in done.items() if k[0] == "row"}
CACHE = {(k[1], k[2]): v for k, v in done.items() if k[0] == "cache"}
print(f"checkpoint: {len(ROWS)} steered states, {len(CACHE)} cached states")
i0 = TAUS.index(0.0)


# ====================================================================== Part A
def steerable(r):
    o = r["sim-gradient"]
    sig = o["SD"][i0]                                     # sd of psi over the K_ST evaluation chunks at tau = 0
    return (o["rho"] >= RHO_MIN) and (o["eff"] > 2 * sig * np.sqrt(2 / K_ST))

mono = lambda d: (d["rho"] >= RHO_MIN) and (d["eff"] > 0)
rev = lambda d: (d["rho"] <= -RHO_MIN) and (d["eff"] < 0)
mm = lambda x: 1e3 * float(np.median(x)) if len(x) else np.nan
sgn = lambda v: "--" if np.isnan(v) else f"${v:+.1f}$"

tabS, tabA, n_st, n_all = {}, {}, 0, 0
print("\n" + "=" * 100 + "\nA. STEERABLE STATES  (oracle rho >= 0.8 and effect > 2 sigma_hat sqrt(2/16))\n" + "=" * 100)
for qn in TABLE_ORDER:
    R = [r for (f, q, g), r in sorted(ROWS.items()) if q == qn]
    S = [r for r in R if steerable(r)]
    n_st += len(S); n_all += len(R)
    eff = {nm: mm([r[nm]["eff"] for r in S]) for nm in DIRS}
    eff["random"] = mm([r[f"random{i}"]["eff"] for r in S for i in range(N_RANDOM)])
    ours = "Dphi^T lambda_psi"
    tabS[qn] = dict(n=len(S), N=len(R), eff=eff,
                    mono=np.mean([mono(r[ours]) for r in S]) if S else np.nan,
                    cos=float(np.median([r["cos_sim"][ours] for r in S])) if S else np.nan,
                    rev=int(sum(rev(r[ours]) for r in S)),
                    ratio=float(np.median([r[ours]["eff"] / r["sim-gradient"]["eff"] for r in S])) if S else np.nan,
                    reversed_states=[(r["fold"] + 1, r["state"]) for r in S if rev(r[ours])])
    tabA[qn] = {nm: (np.mean([mono(r[nm]) for r in R]), mm([r[nm]["eff"] for r in R])) for nm in DIRS}
    t = tabS[qn]
    print(f"{qn:20s} steerable {t['n']:2d}/{t['N']:2d} | effect (mm) " +
          " ".join(f"{nm.split('^')[0][:6]} {eff[nm]:+5.1f}" for nm in DIRS + ["random"]) +
          f" | ours: monotone {t['mono']:4.0%}, cos {t['cos']:+.2f}, effect/oracle {t['ratio']:.2f}, "
          f"reversed {t['rev']} {t['reversed_states']}")
allS = [r for r in ROWS.values() if steerable(r)]
print(f"\nall QoIs: steerable {n_st}/{n_all} | ours monotone {np.mean([mono(r['Dphi^T lambda_psi']) for r in allS]):.0%} "
      f"| cos median {np.median([r['cos_sim']['Dphi^T lambda_psi'] for r in allS]):+.2f} "
      f"| effect/oracle median {np.median([r['Dphi^T lambda_psi']['eff'] / r['sim-gradient']['eff'] for r in allS]):.2f}")

print("\n% ---- tab:smolvla_steer rows: steerable | effect: grad, ours, gamma, static, global, random | monotone, cos")
for qn in TABLE_ORDER:
    t = tabS[qn]; e = t["eff"]
    print(f"{LABEL[qn]:24s} & {t['n']}/{t['N']} & " + " & ".join(sgn(e[nm]) for nm in DIRS + ["random"])
          + f" & {100 * t['mono']:.0f}\\% & {t['cos']:.2f} \\\\")
print("\n% ---- tab:smolvla_steer_all rows: (monotone, effect) for grad, ours, gamma, static, global; all states")
for qn in TABLE_ORDER:
    print(f"{LABEL[qn]:24s} & " + " & ".join(f"{100 * tabA[qn][nm][0]:.0f}\\% & {sgn(tabA[qn][nm][1])}" for nm in DIRS) + r" \\")


# ====================================================================== Part B
def sig2(U):
    U = np.asarray(U, dtype=np.float64)
    N, Hh, A = U.shape
    dx = np.concatenate([np.full((N, Hh, 1), 1.0 / Hh), U / Hh], axis=2)
    prev = np.cumsum(dx, axis=1) - dx
    S2 = np.einsum("nti,ntj->nij", prev, dx) + 0.5 * np.einsum("nti,ntj->nij", dx, dx)
    return np.concatenate([dx.sum(axis=1), S2.reshape(N, -1)], axis=1)


def target_plates(Q0r, EP, success):
    out = []
    for m in (3, 6):
        votes = []
        for e in np.where(success)[0]:
            idx = np.where(EP == e)[0]
            if len(idx):
                p = Q0r[idx[-1]]
                votes.append(9 if np.linalg.norm(p[m:m + 2] - p[9:11]) < np.linalg.norm(p[m:m + 2] - p[12:14]) else 12)
        out.append(max(set(votes), key=votes.count) if votes else (9 if m == 3 else 12))
    return out


def make_qoi(tp1, tp2):
    def f(P):
        P = np.asarray(P, dtype=np.float64)
        return np.stack([P[..., 2], P[..., 5], P[..., 8],
                         -np.linalg.norm(P[..., 3:5] - P[..., tp1:tp1 + 2], axis=-1),
                         -np.linalg.norm(P[..., 6:8] - P[..., tp2:tp2 + 2], axis=-1),
                         -np.linalg.norm(P[..., 0:3] - P[..., 3:6], axis=-1),
                         -np.linalg.norm(P[..., 0:3] - P[..., 6:9], axis=-1)], axis=-1)
    return f


cosv = lambda a, b: float(a @ b / (np.linalg.norm(a) * np.linalg.norm(b) + 1e-300))
DIAG = []
if RUN_B:
    print("\n" + "=" * 100 + "\nB. DIAGNOSIS: which coefficient c makes J^T c agree with the oracle?\n" + "=" * 100)
    d = np.load(DATA)
    LAM, EP, CS, Q0r, U, QFr = d["LAM"], d["EP"], d["C_STATE"], d["Q0"], d["U"], d["QF"]
    qoi = make_qoi(*target_plates(Q0r, EP, d["success"]))
    Q0, QF = qoi(Q0r), qoi(QFr)
    QI = {n: i for i, n in enumerate(QOI_ALL)}
    qidx = [QI[q] for q in QOI_RUN]
    NS, NC = len(EP), len(CS)
    S_all = sig2(U.reshape(NC * K, H, 7))
    s_mu, s_sd = S_all.mean(0), S_all.std(0)
    keep = s_sd > 1e-8 * s_sd.max()
    S_all = (S_all[:, keep] - s_mu[keep]) / s_sd[keep]
    ps = S_all.shape[1]
    lvl1 = np.zeros(ps, bool); lvl1[:int(keep[:8].sum())] = True          # kept level-1 words come first
    print(f"signature coordinates kept: {ps} (level 1: {lvl1.sum()})")
    g2j = {int(g): j for j, g in enumerate(CS)}
    eps_all = np.unique(EP)
    folds = [(eps_all[::2], eps_all[1::2]), (eps_all[1::2], eps_all[::2])]

    for fi, (A_eps, B_eps) in enumerate(folds):
        inA = np.isin(EP, A_eps)
        X = LAM[inA].astype(np.float32); mu = X.mean(0); X -= mu
        ev, V = np.linalg.eigh((X @ X.T).astype(np.float64)); ix = np.argsort(ev)[::-1][:PCA_K]
        comps = ((X.T.astype(np.float64) @ V[:, ix]) / np.sqrt(ev[ix])).astype(np.float32)
        del X
        Zraw = np.concatenate([(LAM[i:i + 64].astype(np.float32) - mu) @ comps for i in range(0, NS, 64)])
        zm, zs = Zraw[inA].mean(0), Zraw[inA].std(0) + 1e-12
        Zall = (Zraw - zm) / zs
        # align component signs with the cached z0 of this fold (eigenvector signs can differ between machines)
        cached = [(g, c_["z0"]) for (f_, g), c_ in CACHE.items() if f_ == fi]
        sign = np.sign(sum(Zall[g] * z0 for g, z0 in cached)); sign[sign == 0] = 1
        Zall = Zall * sign
        print(f"\nfold {fi + 1}: component signs flipped vs. run: {int((sign < 0).sum())} | "
              f"max |z_now - z_cached| {max(np.abs(Zall[g] - z0).max() for g, z0 in cached):.3f}")

        cA = np.where(inA[CS])[0]
        Z = np.repeat(Zall[CS[cA]], K, 0)
        S = S_all[(cA[:, None] * K + np.arange(K)).ravel()]
        Y = (QF[cA][:, :, qidx] - Q0[CS[cA]][:, None, qidx]).reshape(-1, len(qidx))
        Fb = np.c_[Z, S, (Z[:, :, None] * S[:, None, :]).reshape(len(Z), -1)]
        inc = RidgeCV(alphas=RIDGE, alpha_per_target=True).fit(Fb, Y)
        al = np.atleast_1d(inc.alpha_)
        coef = np.atleast_2d(inc.coef_)
        probes = {"bilinear": coef}
        for mult in (10, 100):
            probes[f"bilinear, ridge x{mult}"] = np.atleast_2d(Ridge(alpha=al * mult).fit(Fb, Y).coef_)
        add = np.atleast_2d(RidgeCV(alphas=RIDGE, alpha_per_target=True).fit(np.c_[Z, S], Y).coef_)
        zlo, zhi = np.quantile(Zall[inA], 0.01, axis=0), np.quantile(Zall[inA], 0.99, axis=0)
        rn = np.linalg.norm(Zall[inA], axis=1)
        del Z, S, Fb
        stamp(f"fold {fi + 1}: probes refitted (alphas {np.round(np.log10(al), 1)} log10)")

        for (f_, qn, g), r in sorted(ROWS.items()):
            if f_ != fi:
                continue
            q, qi = QOI_RUN.index(qn), QI[qn]
            c_ = CACHE[(fi, g)]
            Jm, z0 = c_["J"], c_["z0"]
            pp, pm_ = qoi(c_["pos_p"])[..., qi].mean(1), qoi(c_["pos_m"])[..., qi].mean(1)
            orc = (pp - pm_) / (2 * H_Z)
            bc = lambda C, z: C[q, PCA_K:PCA_K + ps] + C[q, PCA_K + ps:].reshape(PCA_K, ps).T @ z
            cs = {nm: bc(C, z0) for nm, C in probes.items()}
            cs["bilinear, z clipped"] = bc(coef, np.clip(z0, zlo, zhi))
            cs["additive (b only)"] = add[q, PCA_K:PCA_K + ps]
            cs["bilinear, level 1"] = np.where(lvl1, cs["bilinear"], 0.0)
            cosd = {nm: cosv(Jm.T @ c, orc) for nm, c in cs.items()}
            # does the probe rank the 32 recorded candidate chunks of this state correctly?
            j = g2j[g]
            Sj = S_all[j * K:(j + 1) * K]
            yj = QF[j, :, qi] - Q0[g, qi]
            pred_b = Sj @ cs["bilinear"]
            pred_a = Sj @ cs["additive (b only)"]
            rows_ = dict(fold=fi + 1, qoi=qn, state=g, steerable=steerable(r),
                         reversed=rev(r["Dphi^T lambda_psi"]), cos_run=r["cos_sim"]["Dphi^T lambda_psi"],
                         z_norm_pct=float(np.mean(rn < np.linalg.norm(z0))),
                         z_out=int(np.sum((z0 < zlo) | (z0 > zhi))),
                         bilin_share=float(np.linalg.norm(cs["bilinear"] - coef[q, PCA_K:PCA_K + ps])
                                           / (np.linalg.norm(coef[q, PCA_K:PCA_K + ps]) + 1e-300)),
                         rank_bilinear=float(spearmanr(pred_b, yj).correlation),
                         rank_additive=float(spearmanr(pred_a, yj).correlation),
                         sd_mm=1e3 * float(yj.std()), **{f"cos|{k}": v for k, v in cosd.items()})
            DIAG.append(rows_)

    # ---- report ----
    variants = list(DIAG[0].keys())[list(DIAG[0].keys()).index("sd_mm") + 1:]
    print(f"\nsanity: |cos(bilinear, refit) - cos(run)| max "
          f"{max(abs(r['cos|bilinear'] - r['cos_run']) for r in DIAG):.3f}  (should be ~0; else the refit differs)")

    def report(sel, title):
        if not sel:
            return
        print(f"\n{title}  (n = {len(sel)})")
        print("  cos(J^T c, oracle), median:  " + " | ".join(f"{v[4:]} {np.median([r[v] for r in sel]):+.2f}" for v in variants))
        print(f"  candidate ranking at the state (Spearman, probe vs simulated, 32 chunks): "
              f"bilinear {np.median([r['rank_bilinear'] for r in sel]):+.2f} | additive {np.median([r['rank_additive'] for r in sel]):+.2f}")
        print(f"  |z0| percentile among fitting states {np.median([r['z_norm_pct'] for r in sel]):.2f} | "
              f"coords outside 1-99% {np.median([r['z_out'] for r in sel]):.0f}/32 | "
              f"||W^T z0|| / ||b|| {np.median([r['bilin_share'] for r in sel]):.2f}")

    ST = [r for r in DIAG if r["steerable"]]
    report([r for r in ST if r["reversed"]], "REVERSED steerable states")
    report([r for r in ST if not r["reversed"]], "other steerable states")
    print("\nper reversed state:")
    for r in [r for r in ST if r["reversed"]]:
        print(f"  fold {r['fold']} {r['qoi']:16s} state {r['state']:5d} | " +
              " ".join(f"{v[4:]} {r[v]:+.2f}" for v in variants) +
              f" | rank bil {r['rank_bilinear']:+.2f} add {r['rank_additive']:+.2f} | |z0| pct {r['z_norm_pct']:.2f} "
              f"out {r['z_out']} | Wz/b {r['bilin_share']:.2f}")
    for qn in TABLE_ORDER:
        sel = [r for r in ST if r["qoi"] == qn]
        if sel:
            print(f"  {qn:20s} steerable n={len(sel):2d} | " + " ".join(f"{v[4:]} {np.median([r[v] for r in sel]):+.2f}" for v in variants))

np.savez(OUT, tabS=np.array(tabS, dtype=object), tabA=np.array(tabA, dtype=object), diag=np.array(DIAG, dtype=object))
stamp(f"saved {OUT}")
