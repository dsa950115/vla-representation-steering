# ======================================================================
# SmolVLA — why the probe fails at bimodal states  (ONE Colab cell, CPU runtime, a few minutes)
#   For the pairs of smolvla/s5 (all bimodal + unimodal controls), on the 16 policy samples recorded at the state:
#   1. separability  can the two outcome modes be told apart from the chunk? leave-one-out balanced accuracy of
#                    a linear and two nonlinear classifiers, on the signature S(u) and on the raw actions
#   2. local readout does a probe fitted at this state alone rank the samples? leave-one-out ridge on S(u) / actions
#                    (the global probe of s2/s5: rank correlation +0.02 at bimodal states, +0.95 at unimodal ones)
#   3. how different  distance between the modes' mean chunks relative to the spread within a mode, and where
#                    (which action dimension, which step) the modes differ most
#   4. contact       do the modes differ in whether a mug was moved by the chunk, or in the gripper command?
#   Unimodal controls are split at the median of psi, so every number has a reference.
# Needs on Drive (aclrh/): probe_v2.npz (s1), smolvla_diagnose_s5_partial_v2.pkl (s5).
# ======================================================================
import os, pickle, warnings
import numpy as np
from scipy.stats import spearmanr
from sklearn.linear_model import LogisticRegression, RidgeCV
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.metrics import balanced_accuracy_score

warnings.filterwarnings("ignore")
try:
    from google.colab import drive
    if not os.path.exists("/content/drive/MyDrive"):
        drive.mount("/content/drive")
except ImportError:
    pass
ROOT = os.environ.get("ACLRH_ROOT", "/content/drive/MyDrive/aclrh")
DATA, CKPT_S5 = f"{ROOT}/probe_v2.npz", f"{ROOT}/smolvla_diagnose_s5_partial_v2.pkl"
OUT = f"{ROOT}/smolvla_bimodal_mechanism_s6.npz"

QOI_ALL = ["EE z (control)", "mug1 z", "mug2 z", "-d(mug1,plate) xy", "-d(mug2,plate) xy", "-d(EE,mug1)", "-d(EE,mug2)"]
H, K_POL = 20, 16
DIMS = ["x", "y", "z", "rx", "ry", "rz", "gripper"]
MUG_MOVE = 5e-3              # a mug counts as moved by the chunk if its position changes by more than 5 mm
BIMODAL_GAP, BIMODAL_MIN = 3.0, 3


def sig2(U):
    U = np.asarray(U, dtype=np.float64)
    N, Hh, A = U.shape
    dt = 1.0 / Hh
    dx = np.concatenate([np.full((N, Hh, 1), dt), U * dt], axis=2)
    prev = np.cumsum(dx, axis=1) - dx
    S2 = np.einsum("nti,ntj->nij", prev, dx) + 0.5 * np.einsum("nti,ntj->nij", dx, dx)
    return np.concatenate([dx.sum(axis=1), S2.reshape(N, -1)], axis=1)


def target_plates(Q0r, EP, success):
    out = []
    for m in (3, 6):
        votes = []
        for e in np.where(success)[0]:
            idx = np.where(EP == e)[0]
            if len(idx):
                p = Q0r[idx[-1]]
                votes.append(9 if np.linalg.norm(p[m:m + 2] - p[9:11]) < np.linalg.norm(p[m:m + 2] - p[12:14]) else 12)
        out.append(max(set(votes), key=votes.count) if votes else (9 if m == 3 else 12))
    return out


def make_qoi(tp1, tp2):
    def f(P):
        P = np.asarray(P, dtype=np.float64)
        return np.stack([P[..., 2], P[..., 5], P[..., 8],
                         -np.linalg.norm(P[..., 3:5] - P[..., tp1:tp1 + 2], axis=-1),
                         -np.linalg.norm(P[..., 6:8] - P[..., tp2:tp2 + 2], axis=-1),
                         -np.linalg.norm(P[..., 0:3] - P[..., 3:6], axis=-1),
                         -np.linalg.norm(P[..., 0:3] - P[..., 6:9], axis=-1)], axis=-1)
    return f


def split_modes(v, bim):
    """indices of the low and the high group: largest gap for bimodal pairs, median split for unimodal ones"""
    o = np.argsort(v)
    k = int(np.argmax(np.diff(v[o]))) + 1 if bim else len(v) // 2
    return o[:k], o[k:]


def loo_class(X, y, make):
    pred = np.empty_like(y)
    for i in range(len(y)):
        tr = np.arange(len(y)) != i
        if len(np.unique(y[tr])) < 2:
            pred[i] = y[tr][0]; continue
        pred[i] = make().fit(X[tr], y[tr]).predict(X[i:i + 1])[0]
    return balanced_accuracy_score(y, pred)


def loo_ridge(X, v):
    pred = np.empty_like(v)
    for i in range(len(v)):
        tr = np.arange(len(v)) != i
        m = make_pipeline(StandardScaler(), RidgeCV(alphas=np.logspace(-3, 4, 15))).fit(X[tr], v[tr])
        pred[i] = m.predict(X[i:i + 1])[0]
    return float(spearmanr(pred, v).correlation)


CLASSIFIERS = {
    "linear": lambda: make_pipeline(StandardScaler(), LogisticRegression(C=1.0, max_iter=2000)),
    "kNN-3": lambda: make_pipeline(StandardScaler(), KNeighborsClassifier(n_neighbors=3)),
    "RBF-SVM": lambda: make_pipeline(StandardScaler(), SVC(C=10.0, gamma="scale")),
}

d = np.load(DATA)
EP, CS, Q0r, U, QFr = d["EP"], d["C_STATE"], d["Q0"], d["U"], d["QF"]
NC, K = U.shape[:2]
qoi = make_qoi(*target_plates(Q0r, EP, d["success"]))
Q0, QF = qoi(Q0r), qoi(QFr)
QI = {n: i for i, n in enumerate(QOI_ALL)}
g2j = {int(g): j for j, g in enumerate(CS)}
S_all = sig2(U.reshape(NC * K, H, 7))
s_mu, s_sd = S_all.mean(0), S_all.std(0)
keep = s_sd > 1e-8 * s_sd.max()
st = lambda UU: (sig2(UU)[:, keep] - s_mu[keep]) / s_sd[keep]

s5 = pickle.load(open(CKPT_S5, "rb"))
pairs = sorted([(r["bimodal"], r["qoi"], r["state"], r) for r in s5.values()], key=lambda t: (not t[0], t[1], t[2]))
print(f"{len(pairs)} pairs from s5 ({sum(p[0] for p in pairs)} bimodal)\n")

rows = []
for bim, qn, g, r5 in pairs:
    j, qi = g2j[g], QI[qn]
    Uj = U[j, :K_POL].astype(np.float64)                              # (16, H, 7) policy samples
    v = QF[j, :K_POL, qi] - Q0[g, qi]                                 # outcome of each sample
    lo, hi = split_modes(v, bim)
    y = np.zeros(K_POL, int); y[hi] = 1
    Xs, Xa = st(Uj), Uj.reshape(K_POL, -1)
    row = dict(bimodal=bim, qoi=qn, state=g, n_lo=len(lo), n_hi=len(hi),
               gap_mm=1e3 * (v[hi].mean() - v[lo].mean()), spread_mm=1e3 * max(v[lo].std(), v[hi].std()))
    for nm, mk in CLASSIFIERS.items():
        row[f"acc S {nm}"] = loo_class(Xs, y, mk)
        row[f"acc a {nm}"] = loo_class(Xa, y, mk)
    row["local rho S"], row["local rho a"] = loo_ridge(Xs, v), loo_ridge(Xa, v)
    row["global rho (s5)"] = r5["calib"]["rho_chunks"]
    # how different are the modes' chunks, and where
    within = np.sqrt(0.5 * (Uj[lo].var(0).mean() + Uj[hi].var(0).mean())) + 1e-12
    diff = Uj[hi].mean(0) - Uj[lo].mean(0)                            # (H, 7)
    row["between/within"] = float(np.linalg.norm(diff) / (within * np.sqrt(diff.size)))
    tstat = np.abs(diff) / (np.sqrt(Uj[lo].var(0) / len(lo) + Uj[hi].var(0) / len(hi)) + 1e-12)
    t_, k_ = np.unravel_index(np.argmax(tstat), tstat.shape)
    row["most different"] = f"{DIMS[k_]} at step {t_}"
    row["dim t-max"] = {DIMS[k]: float(tstat[:, k].max()) for k in range(7)}
    # contact: did the chunk move a mug? gripper command
    mv1 = np.linalg.norm(QFr[j, :K_POL, 3:6] - Q0r[g, 3:6], axis=1) > MUG_MOVE
    mv2 = np.linalg.norm(QFr[j, :K_POL, 6:9] - Q0r[g, 6:9], axis=1) > MUG_MOVE
    row["mug1 moved lo/hi"] = (float(mv1[lo].mean()), float(mv1[hi].mean()))
    row["mug2 moved lo/hi"] = (float(mv2[lo].mean()), float(mv2[hi].mean()))
    row["gripper lo/hi"] = (float(Uj[lo, :, 6].mean()), float(Uj[hi, :, 6].mean()))
    rows.append(row)
    print(f"{'BIMODAL ' if bim else 'unimodal'} {qn:16s} state {g:5d} | modes {len(lo):2d}/{len(hi):2d}, gap {row['gap_mm']:5.1f} mm "
          f"(spread {row['spread_mm']:4.1f}) | separable from S: lin {row['acc S linear']:.2f} kNN {row['acc S kNN-3']:.2f} "
          f"SVM {row['acc S RBF-SVM']:.2f}; from actions: lin {row['acc a linear']:.2f} kNN {row['acc a kNN-3']:.2f} "
          f"SVM {row['acc a RBF-SVM']:.2f} | local rho S {row['local rho S']:+.2f} a {row['local rho a']:+.2f} "
          f"(global {row['global rho (s5)']:+.2f}) | between/within {row['between/within']:.2f}, most different: "
          f"{row['most different']} | mug1 moved {row['mug1 moved lo/hi'][0]:.0%}/{row['mug1 moved lo/hi'][1]:.0%}, "
          f"mug2 {row['mug2 moved lo/hi'][0]:.0%}/{row['mug2 moved lo/hi'][1]:.0%}, gripper cmd "
          f"{row['gripper lo/hi'][0]:+.2f}/{row['gripper lo/hi'][1]:+.2f}")

print("\n" + "=" * 100 + "\nSUMMARY (medians; balanced accuracy 0.50 = chance; unimodal: median split of psi)\n" + "=" * 100)
med = lambda xs: float(np.nanmedian(xs))
for grp in (True, False):
    R = [r for r in rows if r["bimodal"] == grp]
    if not R:
        continue
    print(f"\n{'bimodal' if grp else 'unimodal'}: {len(R)} pairs")
    print("  modes separable from the signature S(u):  " + " | ".join(f"{nm} {med([r[f'acc S {nm}'] for r in R]):.2f}" for nm in CLASSIFIERS))
    print("  modes separable from the raw actions:     " + " | ".join(f"{nm} {med([r[f'acc a {nm}'] for r in R]):.2f}" for nm in CLASSIFIERS))
    print(f"  ranking of the samples: global probe {med([r['global rho (s5)'] for r in R]):+.2f} | local ridge on S "
          f"{med([r['local rho S'] for r in R]):+.2f} | local ridge on actions {med([r['local rho a'] for r in R]):+.2f}")
    print(f"  chunk difference between the modes / spread within a mode: {med([r['between/within'] for r in R]):.2f}")
    print("  largest per-dimension difference (t, median over pairs): " +
          " | ".join(f"{k} {med([r['dim t-max'][k] for r in R]):.1f}" for k in DIMS))
    print(f"  mug1 moved by the chunk, low / high mode: {med([r['mug1 moved lo/hi'][0] for r in R]):.0%} / "
          f"{med([r['mug1 moved lo/hi'][1] for r in R]):.0%} | mug2: {med([r['mug2 moved lo/hi'][0] for r in R]):.0%} / "
          f"{med([r['mug2 moved lo/hi'][1] for r in R]):.0%}")
    print(f"  pairs where a mug's contact differs between the modes (|difference in moved share| >= 50%): "
          f"{sum(max(abs(r['mug1 moved lo/hi'][0] - r['mug1 moved lo/hi'][1]), abs(r['mug2 moved lo/hi'][0] - r['mug2 moved lo/hi'][1])) >= 0.5 for r in R)}/{len(R)}")
np.savez(OUT, rows=np.array(rows, dtype=object))
print(f"""
READING
=======
separable from actions/S with a nonlinear classifier, not linearly, local ridge poor -> the information is in the chunk
    but a threshold (contact) separates the outcomes: a linear readout cannot express it; a nonlinear probe could
separable linearly and local ridge good, global probe poor -> one global coefficient c is wrong at these states:
    a local (state-specific) probe fixes it
separable from raw actions but not from S -> the level-2 signature loses the deciding detail (timing, gripper)
not separable from either (accuracy ~0.5) -> 16 samples cannot show it, or the outcome is decided by details of the
    simulation the chunk barely changes
small between/within with a large outcome gap -> small change of the chunk, large change of the outcome
saved {OUT}
""")
