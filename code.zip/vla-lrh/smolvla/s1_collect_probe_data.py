# ======================================================================
# DATA COLLECTION v2 — POSITION QoIs, ALL 50 LIBERO LAYOUTS  (SmolVLA + LIBERO sim)
#
# Static data at every snapshot; candidate chunks at every CAND_EVERY-th snapshot.
# Raw positions (EE, both mugs, both plates) are stored so any QoI can be derived later.
# Analysis: probing/q1_probe_extended.py (Q1 table), smolvla/s2-s4 (steering)
#
# Fresh Google Colab GPU runtime -> run THIS CELL ONLY. No restart needed.
#
# Paper claim (Def 3.1 / Thm 4.2):
#     psi(F_u(x))  ~=  < lambda(x), L S(u) >
# i.e. the FUTURE value of a physical quantity under a CANDIDATE action chunk u
# is a bilinear function of (representation, action signature).
#
# Pipeline
#   A. closed-loop SmolVLA rollouts in LIBERO -> snapshot states x
#      (full MuJoCo state + gripper state + camera obs + true object poses)
#   B. at every snapshot: restore x, run K candidate chunks open-loop for H steps,
#      record QoIs after the chunk.  Candidates = policy samples + smooth
#      perturbations of them (to widen the action set).
#   C. fit probes on held-out EPISODES (new states) and compare
#        static     : psi(F_u x) - psi(x) ~ w.z                (ignores u; usual probe)
#        action     : ~ v.S(u)                                 (ignores x)
#        additive   : ~ w.z + v.S(u)                           (no coupling)
#        BILINEAR   : ~ w.z + v.S(u) + z^T W S(u)              (paper's form)
#        shuffled   : bilinear with z permuted across states   (control)
#        oracle     : bilinear with TRUE sim state instead of z
#        flexible   : gradient boosting on [z, S(u)]           (reference)
#      z = PCA of the SmolVLA prefix representation, fitted on training states only.
#
# Key metric: WITHIN-STATE R^2 = how well the probe ranks different candidate
# actions at the SAME state. A static probe gets 0 by construction; this is
# exactly what "action-conditioned" adds.
#
# QoIs (task: put the white mug on the left plate and the yellow-white mug on the right plate)
#   eef_z              trivial control: delta-EEF actions integrate to it
#   eef-mug1 dist      geometry, nonlinear in u
#   mug1_z             moves only under contact / grasp
#   mug1-plate1 xy     task progress, contact
#   eef-mug2 dist, mug2-plate2 xy   same for the second mug
# ======================================================================

import sys
import subprocess

PY = sys.executable

print("=" * 100)
print("0. FRESH COLAB ENVIRONMENT SETUP")
print("=" * 100)
print("Python:", sys.version)

subprocess.run([PY, "-m", "pip", "install", "-q", "--upgrade", "pip>=25,<26"], check=True)

torch_check = subprocess.run(
    [PY, "-c", r"""
import torch
from packaging.version import Version
v = Version(torch.__version__.split("+")[0])
print(torch.__version__)
assert Version("2.7") <= v < Version("2.12")
"""],
    stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
)
print("Torch check:", torch_check.stdout.strip())
if torch_check.returncode != 0:
    subprocess.run([PY, "-m", "pip", "install", "-q", "--upgrade",
                    "torch==2.11.0", "torchvision==0.26.0"], check=True)

import os as _os
_os.environ["CMAKE_POLICY_VERSION_MINIMUM"] = "3.5"   # harmless; guards old CMake projects


def pip(*args, label=""):
    """pip with the error actually shown (Colab hides child-process stderr otherwise)."""
    r = subprocess.run([PY, "-m", "pip", "install", "-q", *args],
                       stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    if r.returncode != 0:
        print(f"\n----- pip failed ({label}) -----")
        print("\n".join(r.stdout.strip().splitlines()[-60:]))
        raise RuntimeError(f"pip install failed: {label}")
    print(f"  ok: {label}")


print("Installing ...")
pip("--upgrade", "--upgrade-strategy", "only-if-needed",
    "numpy==2.2.6",
    "lerobot[smolvla]==0.6.1",
    "transformers==5.5.4",
    "av==15.1.0",
    "datasets>=4.8.0,<5.0.0",
    "pandas>=2.0.0,<3.0.0",
    "pyarrow>=21.0.0,<30.0.0",
    "jsonlines>=4.0.0,<5.0.0",
    "scikit-learn==1.9.1",
    label="lerobot + smolvla")

# LIBERO sim WITHOUT robomimic: hf-libero pins robomimic==0.2.0 -> egl_probe, whose CMake
# project (cmake_minimum_required 2.8.12) does not build with CMake 4. The simulator path
# (libero.libero.envs / benchmark / asset download) never imports robomimic, so install
# the three sim packages with --no-deps and their real runtime deps explicitly.
pip("--no-deps", "hf-libero>=0.1.4,<0.2.0", "robosuite==1.4.0", "bddl==1.0.1",
    label="hf-libero / robosuite / bddl (no-deps)")
pip("--upgrade-strategy", "only-if-needed",
    "mujoco>=3.0.0,<3.9.0", "numba>=0.61", "scipy", "Pillow", "opencv-python-headless",
    "easydict", "gymnasium>=0.29.0", "h5py", "imageio", "matplotlib", "termcolor", "tqdm",
    "cloudpickle", "pyyaml", "networkx", "huggingface_hub", "PyOpenGL",
    label="sim runtime deps")

VERIFY = r'''
import os, importlib.util
os.environ.setdefault("MUJOCO_GL", "egl")
os.environ.setdefault("PYOPENGL_PLATFORM", "egl")
import importlib.metadata as im
for p in ["torch", "lerobot", "transformers", "numpy", "hf-libero", "robosuite", "mujoco"]:
    try:
        print(f"{p:14s}: {im.version(p)}")
    except Exception as e:
        print(f"{p:14s}: MISSING ({e})")
import torch
assert torch.cuda.is_available(), "Colab GPU runtime is required."
assert importlib.util.find_spec("libero") is not None, "libero not importable"
import yaml
_cfg = os.path.expanduser("~/.libero"); os.makedirs(_cfg, exist_ok=True)
_f = os.path.join(_cfg, "config.yaml")
if not os.path.exists(_f):
    _root = os.path.join(list(importlib.util.find_spec("libero").submodule_search_locations)[0], "libero")
    yaml.dump({"benchmark_root": _root, "bddl_files": _root + "/bddl_files",
               "init_states": _root + "/init_files", "datasets": _root + "/../datasets",
               "assets": _root + "/assets"}, open(_f, "w"))
import mujoco, robosuite
from libero.libero import benchmark
from libero.libero.envs import OffScreenRenderEnv
print("libero suites:", sorted(benchmark.get_benchmark_dict().keys())[:6])
from lerobot.policies.smolvla.modeling_smolvla import SmolVLAPolicy
print("GPU:", torch.cuda.get_device_name(0))
print("ENVIRONMENT SUCCESS")
'''
verify = subprocess.run([PY, "-c", VERIFY], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
print(verify.stdout)
if verify.returncode != 0:
    raise RuntimeError("Environment setup failed. The experiment has NOT started.")


# ======================================================================
# EXPERIMENT SCRIPT
# ======================================================================

SCRIPT = r'''
import os
os.environ.setdefault("MUJOCO_GL", "egl")
os.environ.setdefault("PYOPENGL_PLATFORM", "egl")
os.environ["TOKENIZERS_PARALLELISM"] = "false"
os.environ["HF_HUB_DISABLE_TELEMETRY"] = "1"

import warnings
warnings.filterwarnings("ignore")

import importlib.util
import math
import time

import numpy as np
import torch
import yaml

# ----------------------------------------------------------------------
# LIBERO asks for a config path interactively on first import -> pre-create it
# ----------------------------------------------------------------------
_cfg_dir = os.environ.setdefault("LIBERO_CONFIG_PATH", os.path.expanduser("~/.libero"))
os.makedirs(_cfg_dir, exist_ok=True)
_cfg_file = os.path.join(_cfg_dir, "config.yaml")
if not os.path.exists(_cfg_file):
    _root = os.path.join(list(importlib.util.find_spec("libero").submodule_search_locations)[0], "libero")
    with open(_cfg_file, "w") as f:
        yaml.dump({
            "benchmark_root": _root,
            "bddl_files": os.path.join(_root, "bddl_files"),
            "init_states": os.path.join(_root, "init_files"),
            "datasets": os.path.join(_root, "..", "datasets"),
            "assets": os.path.join(_root, "assets"),
        }, f)

import mujoco
from libero.libero import benchmark, get_libero_path
from libero.libero.envs import OffScreenRenderEnv

from sklearn.linear_model import RidgeCV
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.model_selection import GroupKFold

from lerobot.policies.factory import make_pre_post_processors
from lerobot.policies.smolvla.modeling_smolvla import SmolVLAPolicy
from lerobot.policies.common.vla_utils import make_att_2d_masks
from lerobot.policies.common.flow_matching import euler_integrate


# ======================================================================
# 1. SETTINGS
# ======================================================================

SEED = 0
MODEL_ID = "lerobot/smolvla_libero"
SUITE = "libero_10"
TASK_LANG = "put the white mug on the left plate and put the yellow and white mug on the right plate"

N_EPISODES = 50              # all LIBERO initial layouts of the task
MAX_STEPS = 520              # libero_10 limit used by lerobot-eval
NUM_STEPS_WAIT = 10          # settle steps after reset (same as lerobot)
SNAP_STRIDE = 16             # snapshot every k env steps
MAX_SNAPS_PER_EP = 30

H = 20                       # candidate chunk horizon (env steps, 1 s at 20 Hz)
K_POL = 16                   # policy-sampled candidates per candidate state
K_PERT = 16                  # smooth perturbations of policy candidates
CAND_EVERY = 2               # candidate chunks at every 2nd snapshot (static data at all)
PERT_SCALE = 0.3             # std of perturbation (normalized action units) on dims 0..5
PERT_KNOTS = 5

PCA_K = 32                   # representation dims after PCA (fit on train states only)
MOVE_TOL = 1e-3              # "QoI moves at this state" threshold (m)

CACHE = "/content/probe_v2.npz"
PARTIAL = "/content/probe_v2_partial.npz"     # per-episode checkpoint; rerun resumes from it
REUSE_CACHE = True           # skip simulation if the final cache exists
N_WORKERS = max(1, min((os.cpu_count() or 2) - 1, 16))
JOB_SPLIT = 4                # candidate blocks per snapshot (load balancing)

rng = np.random.default_rng(SEED)
torch.manual_seed(SEED)
assert torch.cuda.is_available()
DEVICE = torch.device("cuda")
T0 = time.time()


def stamp(msg):
    print(f"[{time.time() - T0:7.1f}s] {msg}", flush=True)


def header(title):
    print("\n" + "=" * 100)
    print(title)
    print("=" * 100, flush=True)


QOI_NAMES = ["ee_x", "ee_y", "ee_z", "mug1_x", "mug1_y", "mug1_z", "mug2_x", "mug2_y", "mug2_z",
             "plate1_x", "plate1_y", "plate1_z", "plate2_x", "plate2_y", "plate2_z"]


# ======================================================================
# 2. POLICY (same verified intervention path as before)
# ======================================================================

policy = None
preprocessor = postprocessor = None
PREFIX_DTYPE = None


def load_policy():
    global policy, preprocessor, postprocessor, CH, MAD, N_EXEC
    policy = SmolVLAPolicy.from_pretrained(MODEL_ID).to(torch.float32).to(DEVICE).eval()
    preprocessor, postprocessor = make_pre_post_processors(policy.config, pretrained_path=MODEL_ID)
    CH = policy.config.chunk_size
    MAD = policy.config.max_action_dim
    N_EXEC = policy.config.n_action_steps
    print("chunk_size:", CH, "| n_action_steps:", N_EXEC, "| num_steps:", policy.config.num_steps)


def quat2axisangle(q):
    """(x, y, z, w) -> axis-angle; identical to lerobot LiberoProcessorStep."""
    q = np.asarray(q, dtype=np.float64)
    w = float(np.clip(q[3], -1.0, 1.0))
    den = math.sqrt(max(1.0 - w * w, 0.0))
    if den < 1e-10:
        return np.zeros(3)
    return q[:3] / den * (2.0 * math.acos(w))


def obs_to_arrays(raw):
    """LIBERO raw obs -> (agentview, wrist, state8) in the HuggingFaceVLA/libero convention
    (images rotated 180 deg; state = eef pos, axis-angle, gripper qpos)."""
    img1 = np.ascontiguousarray(raw["agentview_image"][::-1, ::-1])
    img2 = np.ascontiguousarray(raw["robot0_eye_in_hand_image"][::-1, ::-1])
    state = np.concatenate([raw["robot0_eef_pos"], quat2axisangle(raw["robot0_eef_quat"]),
                            raw["robot0_gripper_qpos"]]).astype(np.float32)
    return img1, img2, state


def policy_batch(img1, img2, state):
    to_t = lambda im: torch.from_numpy(im).permute(2, 0, 1).float() / 255.0
    return preprocessor({
        "observation.images.image": to_t(img1),
        "observation.images.image2": to_t(img2),
        "observation.state": torch.from_numpy(state),
        "task": TASK_LANG,
    })


@torch.no_grad()
def prefix_of(batch):
    global PREFIX_DTYPE
    b = policy._prepare_batch(batch)
    images, img_masks = policy.prepare_images(b)
    state = policy.prepare_state(b)
    prefix, pad, att = policy.model.embed_prefix(
        images, img_masks, b["observation.language.tokens"],
        b["observation.language.attention_mask"], state=state,
    )
    PREFIX_DTYPE = prefix.dtype
    return prefix.float().cpu(), pad.cpu(), att.cpu()


@torch.inference_mode()
def build_kv(P, pm, am, B):
    P = P.to(DEVICE, PREFIX_DTYPE).expand(B, -1, -1).contiguous()
    pad = pm.to(DEVICE).expand(B, -1).contiguous()
    att = am.to(DEVICE).expand(B, -1).contiguous()
    _, kv = policy.model.vlm_with_expert.forward(
        attention_mask=make_att_2d_masks(pad, att), position_ids=torch.cumsum(pad, 1) - 1,
        past_key_values=None, inputs_embeds=[P, None], use_cache=policy.config.use_cache,
    )
    return pad, kv


@torch.inference_mode()
def denoise(pad, kv, noise):
    x = euler_integrate(
        lambda x_t, t: policy.model.denoise_step(
            x_t=x_t, prefix_pad_masks=pad, past_key_values=kv, timestep=t),
        noise, policy.config.num_steps)
    return x[:, :, :7]


@torch.inference_mode()
def sample_chunks(P, pm, am, K, seed):
    pad, kv = build_kv(P, pm, am, K)
    torch.manual_seed(seed)
    noise = policy.model.sample_noise((K, CH, MAD), DEVICE)
    a = postprocessor(denoise(pad, kv, noise))
    return torch.as_tensor(a).float().cpu().numpy()          # (K, CH, 7)


# ======================================================================
# 3. SIMULATOR
#
# main process : one camera env (closed-loop policy rollouts need images)
# workers      : camera-FREE envs (no renderer at all) that replay candidate chunks
#                from saved MuJoCo states, one per CPU core
# ======================================================================

env = None
BDDL = None
DUMMY = np.array([0, 0, 0, 0, 0, 0, -1], dtype=np.float64)
_SPEC = mujoco.mjtState.mjSTATE_INTEGRATION


def find_task():
    suite = benchmark.get_benchmark_dict()[SUITE]()
    ids = [i for i, t in enumerate(suite.tasks) if t.language == TASK_LANG]
    assert ids, f"task not found in {SUITE}"
    task = suite.get_task(ids[0])
    bddl = os.path.join(get_libero_path("bddl_files"), task.problem_folder, task.bddl_file)
    init_path = os.path.join(get_libero_path("init_states"), task.problem_folder,
                             os.path.basename(task.init_states_file))
    return ids[0], bddl, torch.load(init_path, weights_only=False)


def make_env():
    global env, INIT_STATES, BDDL
    tid, BDDL, INIT_STATES = find_task()
    env = OffScreenRenderEnv(bddl_file_name=BDDL, camera_heights=256, camera_widths=256,
                             control_freq=20)
    env.seed(SEED)
    env.reset()
    print("task id:", tid, "| init states:", len(INIT_STATES))


def set_cameras(e, on):
    """robosuite: `enabled` controls whether the sensor (renderer) runs at all;
    `active` only controls whether the value is returned. Toggle both."""
    for name in ("agentview_image", "robot0_eye_in_hand_image"):
        for attr in ("enabled", "active"):
            try:
                e.env.modify_observable(observable_name=name, attribute=attr, modifier=on)
            except Exception as ex:
                print(f"  [warn] could not set {attr}={on} on {name}: {ex}")


def reset_episode(ep):
    env.reset()
    env.env.ignore_done = True
    set_cameras(env, True)
    raw = env.set_init_state(INIT_STATES[ep % len(INIT_STATES)])
    for _ in range(NUM_STEPS_WAIT):
        raw, _, _, _ = env.step(DUMMY)
    for r in env.robots:
        r.controller.use_delta = True
    return raw


def save_sim(e):
    """Full integration state + the Panda gripper's internal `current_action`
    (not part of the MuJoCo state)."""
    M, D = e.sim.model._model, e.sim.data._data
    s = np.empty(mujoco.mj_stateSize(M, _SPEC))
    mujoco.mj_getState(M, D, s, _SPEC)
    g = getattr(e.robots[0].gripper, "current_action", None)
    return s, (None if g is None else np.array(g, copy=True))


def load_sim(e, snap):
    s, g = snap
    M, D = e.sim.model._model, e.sim.data._data
    mujoco.mj_setState(M, D, s, _SPEC)
    mujoco.mj_forward(M, D)
    if g is not None:
        e.robots[0].gripper.current_action = np.array(g, copy=True)
    e.robots[0].controller.update(force=True)


def qoi_now(e):
    """raw positions: EE, white mug, yellow-white mug, left plate, right plate (15 numbers)."""
    d = e.sim.data
    bid = e.env.obj_body_id
    return np.concatenate([np.array(d.site_xpos[e.robots[0].eef_site_id]),
                           np.array(d.body_xpos[bid["porcelain_mug_1"]]),
                           np.array(d.body_xpos[bid["white_yellow_mug_1"]]),
                           np.array(d.body_xpos[bid["plate_1"]]),
                           np.array(d.body_xpos[bid["plate_2"]])])


def true_state(e):
    d = e.sim.data
    bid = e.env.obj_body_id
    r = e.robots[0]
    parts = [np.array(d.site_xpos[r.eef_site_id]), np.array(d.site_xmat[r.eef_site_id]).ravel()]
    try:
        parts.append(np.array(d.qpos[r._ref_gripper_joint_pos_indexes]))
    except Exception:
        pass
    for name in ("porcelain_mug_1", "white_yellow_mug_1"):
        parts += [np.array(d.body_xpos[bid[name]]), np.array(d.body_xquat[bid[name]])]
    for name in ("plate_1", "plate_2"):
        parts.append(np.array(d.body_xpos[bid[name]]))
    return np.concatenate(parts)


def run_candidate(e, snap, actions):
    load_sim(e, snap)
    for a in actions:
        e.step(np.asarray(a, dtype=np.float64))
    return qoi_now(e)


def perturb(chunks, n):
    """Smooth random perturbation of randomly chosen policy chunks (dims 0..5; gripper kept)."""
    base = chunks[rng.integers(len(chunks), size=n)].copy()
    knots = rng.normal(0.0, PERT_SCALE, size=(n, PERT_KNOTS, 6))
    grid = np.linspace(0, 1, H)
    kx = np.linspace(0, 1, PERT_KNOTS)
    W = np.stack([np.interp(grid, kx, np.eye(PERT_KNOTS)[j]) for j in range(PERT_KNOTS)], axis=1)
    base[:, :, :6] += np.einsum("hk,nkd->nhd", W, knots)
    return np.clip(base, -1.0, 1.0)


# ---------------- workers (spawned; each builds a renderer-free env) ----------------
_WENV = None


def _worker_init(bddl):
    global _WENV
    torch.set_num_threads(1)
    from libero.libero.envs.env_wrapper import ControlEnv
    _WENV = ControlEnv(bddl_file_name=bddl, use_camera_obs=False, has_renderer=False,
                       has_offscreen_renderer=False, control_freq=20, ignore_done=True)
    _WENV.reset()
    for r in _WENV.robots:
        r.controller.use_delta = True


def _worker_job(args):
    sim, grip, cands = args
    return np.stack([run_candidate(_WENV, (sim, grip), c) for c in cands])


# ======================================================================
# 4. DATA COLLECTION  (checkpointed after every episode; resumable)
# ======================================================================

KEYS = ["LAM", "XT", "Q0", "EP", "TS", "STATE8", "SIM", "GRIP", "INIT_ID",   # every state
        "C_STATE", "U", "QF", "IMG1", "IMG2"]                               # candidate states


def _save(buf, successes, pm, am, path):
    data = {k: np.stack(buf[k]) if buf[k] else np.zeros(0) for k in KEYS}
    data.update(SRC=np.r_[np.zeros(K_POL, int), np.ones(K_PERT, int)],
                success=np.asarray(successes, dtype=bool),
                PAD_MASK=pm.numpy(), ATT_MASK=am.numpy())
    np.savez(path, **data)       # uncompressed: fast checkpoints
    return data


def collect():
    header("A. CLOSED-LOOP ROLLOUTS + B. CANDIDATE CHUNKS (parallel, renderer-free)")
    load_policy()
    make_env()

    buf = {k: [] for k in KEYS}
    successes, start_ep = [], 0
    PM_REF = AM_REF = None
    if os.path.exists(PARTIAL):
        old = dict(np.load(PARTIAL, allow_pickle=False))
        for k in KEYS:
            buf[k] = list(old[k])
        successes = list(old["success"])
        PM_REF, AM_REF = torch.from_numpy(old["PAD_MASK"]), torch.from_numpy(old["ATT_MASK"])
        start_ep = len(successes)
        print(f"resuming from checkpoint: {start_ep} episodes, {len(buf['EP'])} states")

    import concurrent.futures as cf
    import multiprocessing as mp
    pool = cf.ProcessPoolExecutor(max_workers=N_WORKERS, mp_context=mp.get_context("spawn"),
                                  initializer=_worker_init, initargs=(BDDL,))
    print(f"candidate workers: {N_WORKERS}")
    checked = False          # worker-vs-main replay check (once)
    checked_policy = False   # official-vs-custom sampler check (once)

    for ep in range(start_ep, N_EPISODES):
        raw = reset_episode(ep)
        snaps = []
        t, success = 0, False

        while t < MAX_STEPS and not success:
            img1, img2, st = obs_to_arrays(raw)
            batch = policy_batch(img1, img2, st)
            P, PM, AM = prefix_of(batch)

            if not checked_policy:
                policy.reset()
                torch.manual_seed(1)
                n1 = policy.model.sample_noise((1, CH, MAD), DEVICE)
                with torch.inference_mode():
                    off = policy.predict_action_chunk(batch, noise=n1.clone()).float()
                pad1, kv1 = build_kv(P, PM, AM, 1)
                dd = (off - denoise(pad1, kv1, n1.clone()).float()).abs().max().item()
                print(f"max |official - custom| on sim obs = {dd:.3e}")
                assert dd < 1e-4
                checked_policy = True

            chunk = sample_chunks(P, PM, AM, 1, seed=10_000 * ep + t)[0]
            for a in chunk[:N_EXEC]:
                if t % SNAP_STRIDE == 0 and len(snaps) < MAX_SNAPS_PER_EP:
                    i1, i2, s8 = obs_to_arrays(raw)
                    snaps.append({"t": t, "sim": save_sim(env), "img1": i1, "img2": i2,
                                  "state": s8, "q0": qoi_now(env), "x": true_state(env)})
                raw, _, _, _ = env.step(np.asarray(a, dtype=np.float64))
                t += 1
                if env.check_success():
                    success = True
                    break
                if t >= MAX_STEPS:
                    break
        stamp(f"episode {ep}: success={success} steps={t} snapshots={len(snaps)}")

        # ---- representation at every snapshot; candidates at every CAND_EVERY-th ----
        jobs, reps_, cand = [], [], {}
        for si, sn in enumerate(snaps):
            P, PM, AM = prefix_of(policy_batch(sn["img1"], sn["img2"], sn["state"]))
            if PM_REF is None:
                PM_REF, AM_REF = PM, AM
            assert torch.equal(PM, PM_REF) and torch.equal(AM, AM_REF), "token layout changed"
            reps_.append(P)
            if si % CAND_EVERY == 0:
                pol = sample_chunks(P, PM, AM, K_POL, seed=777_000 + 1000 * ep + si)[:, :H]
                cands = np.concatenate([pol, perturb(pol, K_PERT)], axis=0).astype(np.float64)
                cand[si] = cands
                for blk in np.array_split(np.arange(len(cands)), JOB_SPLIT):
                    jobs.append((si, blk, (sn["sim"][0], sn["sim"][1], cands[blk])))

        if not checked:   # worker env must reproduce the main env exactly
            sn = snaps[0]
            set_cameras(env, False)
            a_main = run_candidate(env, sn["sim"], cand[0][0])
            a_main2 = run_candidate(env, sn["sim"], cand[0][0])
            set_cameras(env, True)
            a_work = pool.submit(_worker_job, (sn["sim"][0], sn["sim"][1], cand[0][:1])).result()[0]
            print(f"replay determinism (main vs main)   : {np.abs(a_main - a_main2).max():.2e}")
            print(f"replay agreement   (main vs worker) : {np.abs(a_main - a_work).max():.2e}")
            if np.abs(a_main - a_work).max() > 1e-6:
                print("  [warn] worker env differs from main env; QoI noise floor is at least this big")
            checked = True

        t1 = time.time()
        results = list(pool.map(_worker_job, [j[2] for j in jobs]))
        dt_sim = time.time() - t1
        qf = {si: np.zeros((K_POL + K_PERT, len(QOI_NAMES))) for si in cand}
        for (si, blk, _), res in zip(jobs, results):
            qf[si][blk] = res

        for si, sn in enumerate(snaps):
            g = len(buf["EP"])                       # global state index
            buf["LAM"].append(reps_[si].reshape(-1).numpy().astype(np.float16))
            buf["XT"].append(sn["x"]); buf["Q0"].append(sn["q0"])
            buf["EP"].append(ep); buf["TS"].append(sn["t"])
            buf["STATE8"].append(sn["state"]); buf["SIM"].append(sn["sim"][0])
            buf["GRIP"].append(np.zeros(2) if sn["sim"][1] is None
                               else np.asarray(sn["sim"][1], dtype=np.float64))
            buf["INIT_ID"].append(ep % len(INIT_STATES))
            if si in cand:
                buf["C_STATE"].append(g)
                buf["U"].append(cand[si].astype(np.float32)); buf["QF"].append(qf[si])
                buf["IMG1"].append(sn["img1"]); buf["IMG2"].append(sn["img2"])
        successes.append(success)
        _save(buf, successes, PM_REF, AM_REF, PARTIAL)
        n_steps = len(cand) * (K_POL + K_PERT) * H
        stamp(f"episode {ep}: candidates done | {n_steps / max(dt_sim, 1e-9):.0f} sim steps/s "
              f"(all workers) | checkpoint saved")

    pool.shutdown()
    sr = float(np.mean(successes))
    print(f"\nclosed-loop success in this wrapper: {sr:.2f} ({int(np.sum(successes))}/{len(successes)})")
    if sr == 0:
        print("  [warn] 0 successes: check observation convention (image flip / state) before trusting λ")
    data = _save(buf, successes, PM_REF, AM_REF, CACHE)
    stamp(f"saved {CACHE}: {len(data['EP'])} states, {len(data['C_STATE'])} with "
          f"{data['U'].shape[1]} candidate chunks")
    return data


# ======================================================================
# 5. ANALYSIS
# ======================================================================

def sig2(U):
    """time-augmented signature up to level 2, dX = (dt, u dt)."""
    U = np.asarray(U, dtype=np.float64)
    N, Hh, A = U.shape
    dt = 1.0 / Hh
    dx = np.concatenate([np.full((N, Hh, 1), dt), U * dt], axis=2)
    prev = np.cumsum(dx, axis=1) - dx
    S2 = np.einsum("nti,ntj->nij", prev, dx) + 0.5 * np.einsum("nti,ntj->nij", dx, dx)
    return np.concatenate([dx.sum(axis=1), S2.reshape(N, -1)], axis=1)


def standardize(tr, *others):
    mu, sd = tr.mean(0), tr.std(0)
    keep = sd > 1e-12 * max(sd.max(), 1e-300)
    f = lambda a: (a[:, keep] - mu[keep]) / sd[keep]
    return (f(tr),) + tuple(f(o) for o in others)


def pca_fit(Xtr, k):
    mu = Xtr.mean(0)
    Xc = Xtr - mu
    G = Xc @ Xc.T
    ev, V = np.linalg.eigh(G.astype(np.float64))
    idx = np.argsort(ev)[::-1][:k]
    ev, V = ev[idx], V[:, idx]
    comps = (Xc.T.astype(np.float64) @ V) / np.sqrt(np.maximum(ev, 1e-12))
    return mu, comps.astype(np.float32), ev


def bilinear(z, s):
    return np.concatenate([z, s, np.einsum("ni,nj->nij", z, s).reshape(len(z), -1)], axis=1)


def r2(y, p):
    return 1.0 - np.sum((y - p) ** 2) / max(np.sum((y - y.mean()) ** 2), 1e-300)


def r2_within(y, p, g):
    """R^2 after removing each state's mean from both truth and prediction."""
    yc, pc = y.copy(), p.copy()
    for s in np.unique(g):
        m = g == s
        yc[m] -= yc[m].mean()
        pc[m] -= pc[m].mean()
    return 1.0 - np.sum((yc - pc) ** 2) / max(np.sum(yc ** 2), 1e-300)


def analyze(data):
    header("C. PROBES (held-out episodes = new states)")
    LAM = data["LAM"].astype(np.float32)
    XT, Q0, EP, U, QF, SRC = data["XT"], data["Q0"], data["EP"], data["U"], data["QF"], data["SRC"]
    NS, K = U.shape[:2]
    nq = Q0.shape[1]

    y_all = (QF - Q0[:, None, :]).reshape(NS * K, nq)          # delta psi
    yF_all = QF.reshape(NS * K, nq)                             # psi(F_u x)  (paper's literal target)
    S_all = sig2(U.reshape(NS * K, U.shape[2], U.shape[3]))
    state_of = np.repeat(np.arange(NS), K)
    src_of = np.tile(SRC, NS)
    ep_of = EP[state_of]

    print(f"states {NS}, candidates/state {K}, samples {NS * K}, episodes {len(np.unique(EP))}")
    print(f"closed-loop success {data['success'].mean():.2f}")

    # --- how much does each QoI actually move under different candidates? ---
    print("\nQoI movement across candidates at the same state")
    WITHIN_SHARE = np.zeros(nq)
    for j, nm in enumerate(QOI_NAMES):
        dq = QF[:, :, j] - Q0[:, None, j]
        sd_state = dq.std(axis=1)
        within = np.sum((dq - dq.mean(1, keepdims=True)) ** 2) / max(np.sum((dq - dq.mean()) ** 2), 1e-300)
        WITHIN_SHARE[j] = within
        print(f"  {nm:16s}: median within-state std {np.median(sd_state):.4f} m | "
              f"states moving (> {MOVE_TOL:g}) {np.mean(sd_state > MOVE_TOL):5.1%} | "
              f"within-state share of Var(Δψ) {within:5.1%}")

    models = ["static", "action", "additive", "BILINEAR", "shuffled", "oracle", "flexible"]
    pred = {m: np.zeros_like(y_all) for m in models}
    n_folds = min(4, len(np.unique(EP)))
    gkf = GroupKFold(n_splits=n_folds)
    alphas = np.logspace(-2, 5, 15)
    frng = np.random.default_rng(SEED + 7)

    for fold, (tr_s, te_s) in enumerate(gkf.split(np.arange(NS), groups=EP)):
        tr = np.isin(state_of, tr_s)
        te = np.isin(state_of, te_s)

        mu, comps, ev = pca_fit(LAM[tr_s], PCA_K)
        Zs = (LAM - mu) @ comps                                   # (NS, k)
        Z = Zs[state_of]
        z_tr, z_te = standardize(Z[tr], Z[te])
        s_tr, s_te = standardize(S_all[tr], S_all[te])
        x_tr, x_te = standardize(XT[state_of][tr], XT[state_of][te])

        # shuffled control: permute the state -> representation map within train and within test
        perm = np.arange(NS)
        perm[tr_s] = frng.permutation(tr_s)
        perm[te_s] = frng.permutation(te_s)
        Zp = Zs[perm][state_of]
        zp_tr, zp_te = standardize(Zp[tr], Zp[te])

        designs = {
            "static":   (z_tr, z_te),
            "action":   (s_tr, s_te),
            "additive": (np.c_[z_tr, s_tr], np.c_[z_te, s_te]),
            "BILINEAR": (bilinear(z_tr, s_tr), bilinear(z_te, s_te)),
            "shuffled": (bilinear(zp_tr, s_tr), bilinear(zp_te, s_te)),
            "oracle":   (bilinear(x_tr, s_tr), bilinear(x_te, s_te)),
        }
        for m, (A_tr, A_te) in designs.items():
            reg = RidgeCV(alphas=alphas, alpha_per_target=True).fit(A_tr, y_all[tr])
            pred[m][te] = reg.predict(A_te)

        F_tr, F_te = np.c_[z_tr, s_tr], np.c_[z_te, s_te]
        for j in range(nq):
            gb = HistGradientBoostingRegressor(max_iter=400, learning_rate=0.05,
                                               early_stopping=True, random_state=SEED)
            pred["flexible"][te, j] = gb.fit(F_tr, y_all[tr, j]).predict(F_te)
        stamp(f"fold {fold + 1}/{n_folds} done (PCA top-{PCA_K} explains "
              f"{ev.sum() / max(np.sum((LAM[tr_s] - mu) ** 2), 1e-300):.1%} of train λ variance)")

    # ---------------- report ----------------
    rows = {}
    for j, nm in enumerate(QOI_NAMES):
        print(f"\n{nm}")
        print(f"  {'model':10s} | R²(Δψ) | within-state R² | within (policy chunks only) | R²(ψ(F_u x))")
        for m in models:
            y, p = y_all[:, j], pred[m][:, j]
            a = r2(y, p)
            w = r2_within(y, p, state_of)
            pol = src_of == 0
            wp = r2_within(y[pol], p[pol], state_of[pol])
            rf = r2(yF_all[:, j], Q0[state_of, j] + p)
            rows[(nm, m)] = (a, w, wp, rf)
            if WITHIN_SHARE[j] < 0.01:   # nothing to rank: candidates barely differ in outcome
                print(f"  {m:10s} | {a:6.3f} | {'n/a':>15s} | {'n/a':>27s} | {rf:12.3f}")
            else:
                print(f"  {m:10s} | {a:6.3f} | {w:15.3f} | {wp:27.3f} | {rf:12.3f}")

    np.savez_compressed("/content/probe_results.npz",
                        qoi=np.array(QOI_NAMES), models=np.array(models),
                        table=np.array([[rows[(q, m)] for m in models] for q in QOI_NAMES]))

    print(r"""
READING
=======
within-state R²   how well the probe predicts which candidate chunk does what at the SAME
                  state. static = 0 by construction. This is what "action-conditioned" adds.

Paper's claim is supported for a QoI when
  BILINEAR within-R² is high,
  BILINEAR > additive      (the action effect depends on the state: the coupling in the paper),
  BILINEAR >> shuffled     (the information comes from λ, not from S(u) alone),
  BILINEAR close to oracle (λ encodes what the true state encodes),
  BILINEAR close to flexible (the bilinear-in-signature FORM is not the bottleneck).

eef_z is a trivial control: delta-EEF actions integrate to it, so `action` alone should
already do well there. Evidence must come from the object / contact QoIs, and only at
states where they actually move (see the movement table above).
""")


# ======================================================================
# MAIN
# ======================================================================

if __name__ == "__main__":
    if REUSE_CACHE and os.path.exists(CACHE):
        header(f"loading cached simulation data from {CACHE}")
        data = dict(np.load(CACHE, allow_pickle=False))
    else:
        data = collect()
    stamp("DONE — next: probing/q1_probe_extended.py and smolvla/s2_steering.py")
'''

FILE = "/content/run_smolvla_probe_v2_collect.py"
with open(FILE, "w") as f:
    f.write(SCRIPT)

print("\n" + "=" * 100)
print("START EXPERIMENT")
print("=" * 100)
p = subprocess.Popen([PY, FILE], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
for line in p.stdout:
    print(line, end="")
rc = p.wait()
print("\nReturn code:", rc)
print("✅ COMPLETE" if rc == 0 else "❌ Stopped. Traceback above is enough to diagnose it.")
if rc == 0:                                          # later steps (probing/q1, smolvla/s2, s3, s4) read it from Drive
    import shutil
    if not _os.path.isdir("/content/drive/MyDrive"):
        from google.colab import drive
        drive.mount("/content/drive")
    _os.makedirs("/content/drive/MyDrive/aclrh", exist_ok=True)
    shutil.copy("/content/probe_v2.npz", "/content/drive/MyDrive/aclrh/probe_v2.npz")
    print("copied /content/probe_v2.npz -> /content/drive/MyDrive/aclrh/probe_v2.npz")
