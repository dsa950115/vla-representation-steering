# ======================================================================
# Q1 PROBING, EXTENDED QoIs — OpenVLA-OFT and SmolVLA in one CPU cell
#   adds the rows missing from tab:vla_probe:  EE p_z, -d(EE,mug1), -d(EE,mug2), -d(mug1,plate)
#   (+ -d(mug2,plate)), and fills the SmolVLA MLP / unstructured columns.
# Same pipeline as 03 / 05a (OFT) and the SmolVLA probing in smolvla/s1 (part C): PCA-32 of the representation,
# S_{<=2} of the candidate chunk, 5 folds by episode, ridge with per-target penalty on validation episodes,
# identical random-number order, so the ridge columns of the existing rows are reproduced exactly (sanity check).
# CPU runtime is enough (no model, no simulator). ~10-20 min, most of it MLPs and the SmolVLA PCA.
# ======================================================================
import os, gc, time
import numpy as np
from sklearn.model_selection import GroupKFold
import torch
import torch.nn as nn
from google.colab import drive

if not os.path.exists("/content/drive/MyDrive"):
    drive.mount("/content/drive")

ROOT = "/content/drive/MyDrive/aclrh"
DATASETS = {
    "OpenVLA-OFT": dict(path=f"{ROOT}/oft_probe.npz", lam="LAM", u="U_EXEC", succ="SUCCESS_EP"),
    "SmolVLA":     dict(path=f"{ROOT}/probe_v2.npz",  lam="LAM", u="U",      succ="success"),
}
OUT = f"{ROOT}/q1_probe_extended.npz"
RUN_MLP = True                      # False: ridge columns only (~2 min)

SEED, PCA_K, N_FOLDS = 0, 32, 5
ALPHAS = np.logspace(-4, 4, 17)
MLP_HID, MLP_DEPTH = 256, 3
MLP_LR, MLP_WD, MLP_BATCH = 1e-3, 1e-4, 512
MLP_EPOCHS, MLP_PATIENCE = 400, 25
torch.set_num_threads(os.cpu_count() or 2)
DEV = torch.device("cpu")

# QoI groups: MLPs are trained jointly within a group (the position group = the 9 QoIs of 03 / smolvla/s1)
POS = ["EE x", "EE y", "EE z", "mug1 x", "mug1 y", "mug1 z", "mug2 x", "mug2 y", "mug2 z"]
TASK = ["-d(EE,mug1)", "-d(EE,mug2)", "-d(mug1,plate) xy", "-d(mug2,plate) xy"]
QOI = POS + TASK
MODELS = ["linear", "additive", "bilinear", "MLP readout", "unstructured"]
COLS = ["direct", "additive", "linear", "MLP", "unstr."]          # column names of tab:vla_probe
# rows already in tab:vla_probe (direct, additive, linear): ridge columns must match
REPORTED = {
    "OpenVLA-OFT": {"mug1 x": (.878, .933, .960), "mug1 y": (.806, .895, .959), "mug1 z": (.825, .877, .918),
                    "mug2 x": (.656, .801, .901), "mug2 y": (.908, .953, .979), "mug2 z": (.813, .864, .923)},
    "SmolVLA":     {"mug1 x": (.651, .837, .936), "mug1 y": (.760, .858, .943), "mug1 z": (.194, .538, .795),
                    "mug2 x": (.339, .598, .848), "mug2 y": (.725, .894, .959), "mug2 z": (.621, .783, .884)},
}
T0 = time.time()
stamp = lambda m: print(f"[{time.time() - T0:7.1f}s] {m}", flush=True)


def target_plates(Q0r, EP, success):
    """plate each mug is nearest to at the last snapshot of successful episodes (majority vote)"""
    out = []
    for m in (3, 6):
        votes = []
        for e in np.where(success)[0]:
            idx = np.where(EP == e)[0]
            if len(idx):
                p = Q0r[idx[-1]]
                votes.append(9 if np.linalg.norm(p[m:m + 2] - p[9:11]) < np.linalg.norm(p[m:m + 2] - p[12:14]) else 12)
        out.append(max(set(votes), key=votes.count) if votes else (9 if m == 3 else 12))
        print(f"  mug at cols {m}:{m + 3} -> plate cols {out[-1]} ({votes.count(out[-1])}/{len(votes)} successful episodes)")
    return out


def make_qoi(t1, t2):
    """15 raw positions ee(0:3) mug1(3:6) mug2(6:9) plate_1(9:12) plate_2(12:15) -> QOI (to increase)"""
    def f(P):
        P = np.asarray(P, dtype=np.float64)
        return np.concatenate([P[..., :9], np.stack([
            -np.linalg.norm(P[..., 0:3] - P[..., 3:6], axis=-1),
            -np.linalg.norm(P[..., 0:3] - P[..., 6:9], axis=-1),
            -np.linalg.norm(P[..., 3:5] - P[..., t1:t1 + 2], axis=-1),
            -np.linalg.norm(P[..., 6:8] - P[..., t2:t2 + 2], axis=-1)], axis=-1)], axis=-1)
    return f


def sig2(U):
    """time-augmented signature up to level 2, dX = (dt, u dt)"""
    U = np.asarray(U, dtype=np.float64)
    N, H, A = U.shape
    dx = np.concatenate([np.full((N, H, 1), 1.0 / H), U / H], axis=2)
    prev1 = np.cumsum(dx, axis=1) - dx
    S2 = (np.einsum("nti,ntj->nij", prev1, dx) + 0.5 * np.einsum("nti,ntj->nij", dx, dx))
    return np.concatenate([dx.sum(1), S2.reshape(N, -1)], axis=1)


def standardize(tr, *others):
    mu, sd = tr.mean(0), tr.std(0)
    keep = sd > 1e-12 * max(sd.max(), 1e-300)
    f = lambda a: (a[:, keep] - mu[keep]) / sd[keep]
    return (f(tr),) + tuple(f(o) for o in others)


def pca_fit(Xtr, k):
    mu = Xtr.mean(0)
    Xc = Xtr - mu
    ev, V = np.linalg.eigh((Xc @ Xc.T).astype(np.float64))
    idx = np.argsort(ev)[::-1]
    ev, V = ev[idx], V[:, idx]
    k = min(k, len(Xtr) - 1, int(np.sum(ev > 1e-8 * ev[0])))
    ev, V = ev[:k], V[:, :k]
    comps = (Xc.T.astype(np.float64) @ V) / np.sqrt(np.maximum(ev, 1e-12))
    return mu, comps.astype(np.float32)


def bilinear(z, s):
    return np.concatenate([z, s, np.einsum("ni,nj->nij", z, s).reshape(len(z), -1)], axis=1)


def _ridge_path(X, Y):
    n, p = X.shape
    if p <= n:
        e, V = np.linalg.eigh(X.T @ X)
        VtXtY = V.T @ (X.T @ Y)
        return lambda a: V @ (VtXtY / (e[:, None] + a * n))
    e, V = np.linalg.eigh(X @ X.T)
    VtY = V.T @ Y
    return lambda a: X.T @ (V @ (VtY / (e[:, None] + a * n)))


def ridge(Xtr, Ytr, Xva, Yva, Xte):
    mx, my = Xtr.mean(0), Ytr.mean(0)
    path = _ridge_path(Xtr - mx, Ytr - my)
    err = np.stack([np.mean(((Xva - mx) @ path(a) + my - Yva) ** 2, axis=0) for a in ALPHAS])
    best = ALPHAS[np.argmin(err, axis=0)]
    Xall, Yall = np.r_[Xtr, Xva], np.r_[Ytr, Yva]
    mx, my = Xall.mean(0), Yall.mean(0)
    path = _ridge_path(Xall - mx, Yall - my)
    W = np.zeros((Xall.shape[1], Yall.shape[1]))
    for a in np.unique(best):
        W[:, best == a] = path(a)[:, best == a]
    return (Xte - mx) @ W + my


class MLP(nn.Module):
    def __init__(self, din, dout):
        super().__init__()
        layers, d = [], din
        for _ in range(MLP_DEPTH):
            layers += [nn.Linear(d, MLP_HID), nn.GELU()]
            d = MLP_HID
        layers.append(nn.Linear(d, dout))
        self.net = nn.Sequential(*layers)
        nn.init.normal_(self.net[-1].weight, std=1e-3)
        nn.init.zeros_(self.net[-1].bias)

    def forward(self, x):
        return self.net(x)


def train_mlp(kind, A_tr, B_tr, Y_tr, A_va, B_va, Y_va, A_te, B_te):
    """kind='full': f([A, B]) -> y (unstructured).   kind='cf': g(A)^T [1, B] (MLP readout, linear in B)."""
    torch.manual_seed(SEED)
    ym, ys = Y_tr.mean(0), Y_tr.std(0) + 1e-12
    q = Y_tr.shape[1]
    T = lambda a: torch.as_tensor(a, dtype=torch.float32, device=DEV)
    if kind == "cf":
        one = lambda b: np.c_[np.ones(len(b)), b]
        B_tr, B_va, B_te = one(B_tr), one(B_va), one(B_te)
        ps = B_tr.shape[1]
        net = MLP(A_tr.shape[1], q * ps).to(DEV)
        fwd = lambda a, b: torch.einsum("nqp,np->nq", net(a).view(len(a), q, ps), b)
    else:
        net = MLP(A_tr.shape[1] + B_tr.shape[1], q).to(DEV)
        fwd = lambda a, b: net(torch.cat([a, b], dim=1))
    Atr, Btr, Ytr = T(A_tr), T(B_tr), T((Y_tr - ym) / ys)
    Ava, Bva, Yva = T(A_va), T(B_va), T((Y_va - ym) / ys)
    opt = torch.optim.AdamW(net.parameters(), lr=MLP_LR, weight_decay=MLP_WD)
    best, best_state, bad, n = float("inf"), None, 0, len(Atr)
    for ep in range(MLP_EPOCHS):
        net.train()
        perm = torch.randperm(n)
        for i in range(0, n, MLP_BATCH):
            b = perm[i:i + MLP_BATCH]
            loss = ((fwd(Atr[b], Btr[b]) - Ytr[b]) ** 2).mean()
            opt.zero_grad(); loss.backward(); opt.step()
        net.eval()
        with torch.no_grad():
            v = ((fwd(Ava, Bva) - Yva) ** 2).mean().item()
        if v < best - 1e-5:
            best, bad = v, 0
            best_state = {k: t.detach().clone() for k, t in net.state_dict().items()}
        else:
            bad += 1
            if bad >= MLP_PATIENCE:
                break
    net.load_state_dict(best_state); net.eval()
    with torch.no_grad():
        return fwd(T(A_te), T(B_te)).numpy() * ys + ym


def r2(y, p):
    return 1.0 - np.sum((y - p) ** 2, 0) / np.sum((y - y.mean(0)) ** 2, 0)


def run(name, cfg):
    stamp(f"===== {name}: loading {cfg['path']}")
    assert os.path.exists(cfg["path"]), f"{cfg['path']} not found"
    d = np.load(cfg["path"])
    LAM = d[cfg["lam"]].astype(np.float32)
    EP, CS, U = d["EP"], d["C_STATE"], d[cfg["u"]]
    NS, (NC, K, H, A) = len(EP), U.shape
    print("target plates:")
    qoi = make_qoi(*target_plates(d["Q0"], EP, d[cfg["succ"]]))
    POS0, POSF = qoi(d["Q0"]), qoi(d["QF"])
    NQ = POS0.shape[1]
    cstate = np.repeat(CS, K)
    DPSI = (POSF - POS0[CS][:, None, :]).reshape(NC * K, NQ)
    S2 = sig2(U.reshape(NC * K, H, A))
    RAW = U.reshape(NC * K, H * A).astype(np.float64)
    del d; gc.collect()
    print(f"states {NS} ({len(np.unique(EP))} episodes) | candidate states {NC} x {K} chunks of {H} steps "
          f"| representation dim {LAM.shape[1]}")

    folds = list(GroupKFold(n_splits=N_FOLDS).split(np.arange(NS), groups=EP))
    rng = np.random.default_rng(SEED)

    def split_val(tr):
        eps = np.unique(EP[tr])
        va = rng.choice(eps, size=max(1, len(eps) // 8), replace=False)
        return tr[~np.isin(EP[tr], va)], tr[np.isin(EP[tr], va)]

    reps = {}
    def rep(fi, tr):                                   # PCA-32, cached per fold
        if fi not in reps:
            mu, comps = pca_fit(LAM[tr], PCA_K)
            Z = (LAM - mu) @ comps
            reps[fi] = (Z - Z[tr].mean(0)) / (Z[tr].std(0) + 1e-12)
        return reps[fi]

    # (1) static psi(x), PCA-32 (also keeps the random-number order of the original scripts)
    static = np.zeros_like(POS0)
    for fi, (tr, te) in enumerate(folds):
        trn, va = split_val(tr)
        Z = rep(fi, tr)
        static[te] = ridge(Z[trn], POS0[trn], Z[va], POS0[va], Z[te])
    stamp("static done")

    # (2) increment Delta psi(x; u)
    gidx = {"pos": [QOI.index(q) for q in POS], "task": [QOI.index(q) for q in TASK]}
    models = MODELS if RUN_MLP else MODELS[:3]
    dpred = {m: np.zeros_like(DPSI) for m in models}
    for fi, (tr, te) in enumerate(folds):
        trn, va = split_val(tr)
        Zs = rep(fi, tr)
        m_tr, m_va, m_te = (np.isin(cstate, a) for a in (trn, va, te))
        Z = Zs[cstate]
        S_tr, S_va, S_te = standardize(S2[m_tr], S2[m_va], S2[m_te])
        Y_tr, Y_va = DPSI[m_tr], DPSI[m_va]
        dpred["linear"][m_te] = ridge(Z[m_tr], Y_tr, Z[m_va], Y_va, Z[m_te])
        dpred["additive"][m_te] = ridge(np.c_[Z[m_tr], S_tr], Y_tr, np.c_[Z[m_va], S_va], Y_va, np.c_[Z[m_te], S_te])
        dpred["bilinear"][m_te] = ridge(bilinear(Z[m_tr], S_tr), Y_tr, bilinear(Z[m_va], S_va), Y_va,
                                        bilinear(Z[m_te], S_te))
        if RUN_MLP:
            R_tr, R_va, R_te = standardize(RAW[m_tr], RAW[m_va], RAW[m_te])
            for g, ix in gidx.items():
                dpred["MLP readout"][np.ix_(m_te, ix)] = train_mlp(
                    "cf", Z[m_tr], S_tr, Y_tr[:, ix], Z[m_va], S_va, Y_va[:, ix], Z[m_te], S_te)
                dpred["unstructured"][np.ix_(m_te, ix)] = train_mlp(
                    "full", Z[m_tr], R_tr, Y_tr[:, ix], Z[m_va], R_va, Y_va[:, ix], Z[m_te], R_te)
        stamp(f"increment fold {fi + 1}/{N_FOLDS}")

    res = {m: r2(DPSI, dpred[m]) for m in models}
    res["static psi(x)"] = r2(POS0, static)
    print(f"\n{name}: held-out-episode R^2 of Delta psi (static: of psi(x))")
    print(f"{'':20s}" + "".join(f"{c:>9s}" for c in COLS[:len(models)]) + f"{'static':>9s}")
    for j, q in enumerate(QOI):
        print(f"{q:20s}" + "".join(f"{res[m][j]:9.3f}" for m in models) + f"{res['static psi(x)'][j]:9.3f}")
    print("\nsanity check vs tab:vla_probe (direct / additive / linear):")
    for q, ref in REPORTED[name].items():
        j = QOI.index(q)
        got = tuple(round(float(res[m][j]), 3) for m in MODELS[:3])
        print(f"  {q:8s} reported {ref}  now {got}  {'OK' if np.allclose(got, ref, atol=2e-3) else '<-- differs'}")
    del LAM, reps; gc.collect()
    return res


ALL = {name: run(name, cfg) for name, cfg in DATASETS.items()}
np.savez(OUT, qoi=np.array(QOI), **{f"{n}|{m}": v for n, r in ALL.items() for m, v in r.items()})
stamp(f"saved {OUT}")

# ---------------- LaTeX rows for tab:vla_probe ----------------
LABEL = {"EE z": r"EE $p_z$", "mug1 x": r"mug$_1$ $p_x$", "mug1 y": r"mug$_1$ $p_y$", "mug1 z": r"mug$_1$ $p_z$",
         "mug2 x": r"mug$_2$ $p_x$", "mug2 y": r"mug$_2$ $p_y$", "mug2 z": r"mug$_2$ $p_z$",
         "-d(EE,mug1)": r"$-d$(EE, mug$_1$)", "-d(EE,mug2)": r"$-d$(EE, mug$_2$)",
         "-d(mug1,plate) xy": r"$-d$(mug$_1$, plate)", "-d(mug2,plate) xy": r"$-d$(mug$_2$, plate)"}
ROWS = [["EE z", "mug1 x", "mug1 y", "mug1 z", "mug2 x", "mug2 y", "mug2 z"],
        ["-d(EE,mug1)", "-d(EE,mug2)", "-d(mug1,plate) xy", "-d(mug2,plate) xy"]]
def fmt(v):
    if v < -9.99:
        return r"$<\!-10$"
    s = f"{abs(v):.3f}"
    s = s[1:] if s.startswith("0") else s
    return s if v >= 0 else "$-$" + s
print("\n% ---- LaTeX rows (OpenVLA-OFT | SmolVLA), columns direct additive linear MLP unstr.")
for block in ROWS:
    for q in block:
        j = QOI.index(q)
        cells = [fmt(float(ALL[n][m][j])) if m in ALL[n] else r"\tbd" for n in DATASETS for m in MODELS]
        print(f"{LABEL[q]:24s} & " + " & ".join(cells) + r" \\")
    print(r"\hline")
