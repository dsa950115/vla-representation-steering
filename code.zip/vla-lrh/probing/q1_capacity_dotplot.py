# ======================================================================
# Method-wise probing accuracy: MLP bars span all widths, the point is the width closest to the linear probe's budget
# Reads:  aclrh/q1_capacity.npz
# Writes: aclrh/figs/q1_capacity_all_dotplot.(png|pdf)
# ======================================================================
import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator, FormatStrFormatter

try:
    from google.colab import drive
    if not os.path.isdir("/content/drive/MyDrive"):
        drive.mount("/content/drive")
except ImportError:
    pass

ROOT = os.environ.get("ACLRH_ROOT", "/content/drive/MyDrive/aclrh")
GROUP = "all"
MODELS = ["OpenVLA-OFT", "SmolVLA"]

R = np.load(f"{ROOT}/q1_capacity.npz")
WIDTHS = sorted(int(w) for w in R["widths"])

def get(model, config, key="mean"):
    return float(R[f"{model}|{config}|{GROUP}|{key}"])

# Top to bottom.
METHODS = [
    ("direct",       "Direct",           "#92918B", "s"),
    ("additive",     "Additive",         "#3980C6", "^"),
    ("linear",       "Linear (ours)",    "#E56836", "*"),
    ("MLP readout",  "MLP readout",      "#169D84", "o"),
    ("unstructured","Unstructured MLP", "#6379B5", "D"),
]

# marker area from parameters per QoI, the same rule for every point (log scale: 33 ... 40k)
area = lambda p: 22.0 + 18.0 * (np.log10(p) - 1.5)   # 33 -> 22, 2.3k -> 56, 40k -> 78 (points^2)
STAR = 2.6                                       # a star covers far less of its box than a circle; scale it up


def matched(model, key):
    """width whose parameter count per QoI is closest to the linear probe's (log distance)"""
    pl = get(model, "linear", "params")
    return min(WIDTHS, key=lambda w: abs(np.log(get(model, f"{key} w{w}", "params") / pl)))


STYLE = {
    "font.family": "DejaVu Sans",
    "font.size": 9,
    "axes.titlesize": 10,
    "axes.labelsize": 9,
    "axes.edgecolor": "#B8B8B8",
    "axes.linewidth": 0.7,
    "axes.labelcolor": "#333333",
    "xtick.color": "#555555",
    "ytick.color": "#333333",
    "xtick.labelsize": 8,
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
}

with plt.rc_context(STYLE):
    fig, axes = plt.subplots(
        1, 2, figsize=(7.4, 2.2), sharey=True
    )
    fig.subplots_adjust(
        left=0.17, right=0.99, top=0.85,
        bottom=0.24, wspace=0.12
    )

    for ax, model in zip(axes, MODELS):
        values = []

        for row, (key, label, color, marker) in enumerate(METHODS):
            if key in ["MLP readout", "unstructured"]:
                scores = np.array([get(model, f"{key} w{w}") for w in WIDTHS])
                values.extend(scores)
                # bar: range over all tested widths (not an uncertainty interval)
                ax.plot([scores.min(), scores.max()], [row, row], color=color, alpha=0.4, lw=3.2,
                        solid_capstyle="round", zorder=2)
                # point: the width whose parameter count per QoI is closest to the linear probe's
                wm = matched(model, key)
                # hollow marker: the widest MLP (end of the bar), drawn under the matched point
                ax.scatter(scores[WIDTHS.index(max(WIDTHS))], row, s=46, marker=marker, facecolor="white",
                           edgecolor=color, linewidth=1.1, zorder=4)
                ax.scatter(scores[WIDTHS.index(wm)], row, s=46, marker=marker, color=color,
                           edgecolor="white", linewidth=0.65, zorder=5)
            else:
                values.append(get(model, key))
                ax.scatter(get(model, key), row, s=120 if key == "linear" else 46, marker=marker, color=color,
                           edgecolor="white", linewidth=0.65, zorder=5)

        # Independent, explicitly labeled accuracy scales per model.
        lo, hi = min(values), max(values)
        span = max(hi - lo, 0.04)
        ax.set_xlim(lo - 0.10 * span, hi + 0.12 * span)
        ax.set_ylim(len(METHODS) - 0.55, -0.55)

        ax.set_title(model, pad=10)
        ax.set_xlabel(r"Mean held-out $R^2$", labelpad=8)
        ax.xaxis.set_major_locator(MaxNLocator(nbins=4))
        ax.xaxis.set_major_formatter(FormatStrFormatter("%.2f"))

        ax.set_yticks(range(len(METHODS)))
        ax.set_yticklabels([m[1] for m in METHODS])
        ax.tick_params(axis="y", length=0, pad=9)
        ax.tick_params(axis="x", length=3, width=0.7)
        ax.spines[["top", "right", "left"]].set_visible(False)
        ax.grid(axis="x", color="#E6E6E6", linewidth=0.65)
        ax.set_axisbelow(True)

    # Highlight the proposed method's row label.
    for tick in axes[0].get_yticklabels():
        if tick.get_text() == "Linear (ours)":
            tick.set_color("#D95F2C")
            tick.set_fontweight("bold")

    outdir = f"{ROOT}/figs"
    os.makedirs(outdir, exist_ok=True)
    stem = f"{outdir}/q1_capacity_{GROUP.replace(' ', '_')}_dotplot"

    for ext in ["png", "pdf"]:
        fig.savefig(
            f"{stem}.{ext}", dpi=300,
            bbox_inches="tight", pad_inches=0.07,
            facecolor="white"
        )
    plt.close(fig)

print(f"Saved:\n{stem}.png\n{stem}.pdf")

try:
    from IPython.display import display, Image
    display(Image(filename=f"{stem}.png"))
except Exception:
    pass