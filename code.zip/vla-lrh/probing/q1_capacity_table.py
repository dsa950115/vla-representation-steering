# ======================================================================
# Appendix table: held-out R^2 for every QoI, every probe and MLP width  (ONE Colab cell, CPU, seconds)
#   reads aclrh/q1_capacity.npz (probing/q1_capacity_sweep.py); prints the LaTeX table (one block per model)
#   and writes it to aclrh/figs/tab_q1_capacity_full.tex
# ======================================================================
import os
import numpy as np
try:
    from google.colab import drive
    if not os.path.isdir("/content/drive/MyDrive"):
        drive.mount("/content/drive")
except ImportError:
    pass
ROOT = os.environ.get("ACLRH_ROOT", "/content/drive/MyDrive/aclrh")
R = np.load(f"{ROOT}/q1_capacity.npz")
WIDTHS = [int(w) for w in R["widths"]]
MODELS = ["OpenVLA-OFT", "SmolVLA"]
SHADE = {"MLP readout": 32, "unstructured": 64}          # width closest to the linear probe's budget (fig:q1_capacity)

# QoI order of the "all" group in q1 (positions, then distances) and their column labels
QOI = ["EE x", "EE y", "EE z", "mug1 x", "mug1 y", "mug1 z", "mug2 x", "mug2 y", "mug2 z",
       "-d(EE,mug1)", "-d(EE,mug2)", "-d(mug1,plate) xy", "-d(mug2,plate) xy"]
HEAD = [r"$p_x$", r"$p_y$", r"$p_z$", r"$p_x$", r"$p_y$", r"$p_z$", r"$p_x$", r"$p_y$", r"$p_z$",
        r"EE,m$_1$", r"EE,m$_2$", r"m$_1$,pl.", r"m$_2$,pl."]
COLS = ["direct", "additive", "linear"] + [f"MLP readout w{w}" for w in WIDTHS] + [f"unstructured w{w}" for w in WIDTHS]
f3 = lambda x: (f"{x:.3f}".lstrip("0") if x >= 0 else "$-$" + f"{-x:.3f}".lstrip("0"))
fp = lambda p: f"{p:,.0f}" if p < 1000 else f"{p / 1000:.1f}k"


def label(c):
    if c == "linear":
        return r"\textbf{linear}"
    if " w" in c:
        k, w = c.split(" w")
        return (f"{'MLP readout' if k == 'MLP readout' else 'unstructured'}, {w}" if int(w) == WIDTHS[0] else rf"\quad {w}")
    return c


L = []
L.append(r"\begin{table}[t]")
L.append(r"\centering")
L.append(r"\scriptsize")
L.append(r"\setlength{\tabcolsep}{2.6pt}")
L.append(r"\renewcommand{\arraystretch}{0.92}")
L.append(r"\begin{tabular}{l|c|ccc|ccc|ccc|cccc}")
L.append(r"\hline")
L.append(r" & & \multicolumn{3}{c|}{EE} & \multicolumn{3}{c|}{mug$_1$} & \multicolumn{3}{c|}{mug$_2$} "
         r"& \multicolumn{4}{c}{$-d(\cdot,\cdot)$} \\")
L.append(r"probe & \#par. & " + " & ".join(HEAD) + r" \\")
for n in MODELS:
    L.append(r"\hline")
    L.append(rf"\multicolumn{{15}}{{l}}{{\textit{{{n}}}}} \\")
    L.append(r"\hline")
    for c in COLS:
        r2 = R[f"{n}|{c}|all|r2"]
        par = float(R[f"{n}|{c}|all|params"])
        shade = any(c == f"{k} w{w}" for k, w in SHADE.items())
        if c.endswith(f"w{WIDTHS[0]}") and c != COLS[3]:
            L.append(r"\hline")
        if c == COLS[3]:
            L.append(r"\hline")
        row = f"{label(c)} & {fp(par)} & " + " & ".join(f3(float(v)) for v in r2) + r" \\"
        L.append((r"\rowcolor{gray!12}" + "\n" if shade else "") + row)
L.append(r"\hline")
L.append(r"\end{tabular}")
L.append(r"\caption{\textbf{Probing accuracy for every QoI, probe and MLP width.} Held-out $R^2$ of the increment "
         r"$\Delta\psi(x;\mathbf{u})$. Columns: positions of the end effector and the two mugs, and the four distances "
         r"(EE to mug$_1$, EE to mug$_2$, mug$_1$ to its plate, mug$_2$ to its plate). Probes as defined in \Cref{sec:q1}; "
         r"MLPs: hidden width, depth 3. \#par.: fitted parameters per QoI, averaged over the thirteen QoIs (each MLP is "
         r"shared within the positions or the distances). Shaded: the width closest to the linear probe's parameter "
         r"count (filled markers in \Cref{fig:q1_capacity}).}")
L.append(r"\label{tab:q1_capacity_full}")
L.append(r"\end{table}")
tex = "\n".join(L)
print(tex)
os.makedirs(f"{ROOT}/figs", exist_ok=True)
open(f"{ROOT}/figs/tab_q1_capacity_full.tex", "w").write(tex + "\n")
print(f"\n% saved {ROOT}/figs/tab_q1_capacity_full.tex")
