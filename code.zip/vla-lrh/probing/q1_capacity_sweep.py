# ======================================================================
# Q1 PROBING, CAPACITY SWEEP — R^2 against the number of parameters, OpenVLA-OFT and SmolVLA (ONE Colab cell, CPU)
#   Same data, folds, PCA-32 and signature S_{<=2} as probing/q1_probe_extended.py (identical random-number order,
#   so the ridge probes and the width-256 MLPs reproduce tab:vla_probe). The two MLPs are trained at several widths:
#     MLP readout   g(z)^T [1, S(u)]   (linear in the signature, nonlinear in the representation)
#     unstructured  f([z, u])          (raw actions, no structure)
#   Parameters are counted per QoI: ridge probes are fitted per QoI; the MLPs are shared by the nine position QoIs
#   (as in the table), so their total is divided by nine. The PCA is shared by all probes and not counted.
#   Reported: held-out-episode R^2 of the chunk-induced increment for the six mug-position rows of tab:vla_probe.
# CPU runtime; ~30-60 min (mostly the wide MLPs and the SmolVLA PCA).
# Writes aclrh/q1_capacity.npz, aclrh/figs/q1_capacity.(png|pdf); prints LaTeX rows.
# ======================================================================
import os, gc, time
import numpy as np
from sklearn.model_selection import GroupKFold
import torch
import torch.nn as nn
try:
    from google.colab import drive
    if not os.path.exists("/content/drive/MyDrive"):
        drive.mount("/content/drive")
except ImportError:
    pass

ROOT = os.environ.get("ACLRH_ROOT", "/content/drive/MyDrive/aclrh")
DATASETS = {
    "OpenVLA-OFT": dict(path=f"{ROOT}/oft_probe.npz", lam="LAM", u="U_EXEC", succ="SUCCESS_EP"),
    "SmolVLA":     dict(path=f"{ROOT}/probe_v2.npz",  lam="LAM", u="U",      succ="success"),
}
OUT = f"{ROOT}/q1_capacity.npz"
FIG = f"{ROOT}/figs/q1_capacity"
os.makedirs(f"{ROOT}/figs", exist_ok=True)
RUN_MLP = True
WIDTHS = [8, 16, 32, 64, 128, 256]  # hidden width of both MLPs (depth fixed); 256 = tab:vla_probe
TABLE_ROWS = ["mug1 x", "mug1 y", "mug1 z", "mug2 x", "mug2 y", "mug2 z"]
GROUPS = {"mug positions": TABLE_ROWS, "EE positions": ["EE x", "EE y", "EE z"],
          "distances": ["-d(EE,mug1)", "-d(EE,mug2)", "-d(mug1,plate) xy", "-d(mug2,plate) xy"]}   # + "all" (13 QoIs)

SEED, PCA_K, N_FOLDS = 0, 32, 5
ALPHAS = np.logspace(-4, 4, 17)
MLP_HID, MLP_DEPTH = 256, 3
MLP_LR, MLP_WD, MLP_BATCH = 1e-3, 1e-4, 512
MLP_EPOCHS, MLP_PATIENCE = 400, 25
torch.set_num_threads(os.cpu_count() or 2)
DEV = torch.device("cuda" if torch.cuda.is_available() else "cpu")   # GPU: faster MLPs, last-digit differences

# QoI groups: MLPs are trained jointly within a group (the position group = the 9 QoIs of 03 / smolvla/s1)
POS = ["EE x", "EE y", "EE z", "mug1 x", "mug1 y", "mug1 z", "mug2 x", "mug2 y", "mug2 z"]
TASK = ["-d(EE,mug1)", "-d(EE,mug2)", "-d(mug1,plate) xy", "-d(mug2,plate) xy"]
QOI = POS + TASK
MODELS = ["linear", "additive", "bilinear", "MLP readout", "unstructured"]
COLS = ["direct", "additive", "linear", "MLP", "unstr."]          # column names of tab:vla_probe
# rows already in tab:vla_probe (direct, additive, linear): ridge columns must match
REPORTED = {
    "OpenVLA-OFT": {"mug1 x": (.878, .933, .960), "mug1 y": (.806, .895, .959), "mug1 z": (.825, .877, .918),
                    "mug2 x": (.656, .801, .901), "mug2 y": (.908, .953, .979), "mug2 z": (.813, .864, .923)},
    "SmolVLA":     {"mug1 x": (.651, .837, .936), "mug1 y": (.760, .858, .943), "mug1 z": (.194, .538, .795),
                    "mug2 x": (.339, .598, .848), "mug2 y": (.725, .894, .959), "mug2 z": (.621, .783, .884)},
}
T0 = time.time()
stamp = lambda m: print(f"[{time.time() - T0:7.1f}s] {m}", flush=True)


def target_plates(Q0r, EP, success):
    """plate each mug is nearest to at the last snapshot of successful episodes (majority vote)"""
    out = []
    for m in (3, 6):
        votes = []
        for e in np.where(success)[0]:
            idx = np.where(EP == e)[0]
            if len(idx):
                p = Q0r[idx[-1]]
                votes.append(9 if np.linalg.norm(p[m:m + 2] - p[9:11]) < np.linalg.norm(p[m:m + 2] - p[12:14]) else 12)
        out.append(max(set(votes), key=votes.count) if votes else (9 if m == 3 else 12))
        print(f"  mug at cols {m}:{m + 3} -> plate cols {out[-1]} ({votes.count(out[-1])}/{len(votes)} successful episodes)")
    return out


def make_qoi(t1, t2):
    """15 raw positions ee(0:3) mug1(3:6) mug2(6:9) plate_1(9:12) plate_2(12:15) -> QOI (to increase)"""
    def f(P):
        P = np.asarray(P, dtype=np.float64)
        return np.concatenate([P[..., :9], np.stack([
            -np.linalg.norm(P[..., 0:3] - P[..., 3:6], axis=-1),
            -np.linalg.norm(P[..., 0:3] - P[..., 6:9], axis=-1),
            -np.linalg.norm(P[..., 3:5] - P[..., t1:t1 + 2], axis=-1),
            -np.linalg.norm(P[..., 6:8] - P[..., t2:t2 + 2], axis=-1)], axis=-1)], axis=-1)
    return f


def sig2(U):
    """time-augmented signature up to level 2, dX = (dt, u dt)"""
    U = np.asarray(U, dtype=np.float64)
    N, H, A = U.shape
    dx = np.concatenate([np.full((N, H, 1), 1.0 / H), U / H], axis=2)
    prev1 = np.cumsum(dx, axis=1) - dx
    S2 = (np.einsum("nti,ntj->nij", prev1, dx) + 0.5 * np.einsum("nti,ntj->nij", dx, dx))
    return np.concatenate([dx.sum(1), S2.reshape(N, -1)], axis=1)


def standardize(tr, *others):
    mu, sd = tr.mean(0), tr.std(0)
    keep = sd > 1e-12 * max(sd.max(), 1e-300)
    f = lambda a: (a[:, keep] - mu[keep]) / sd[keep]
    return (f(tr),) + tuple(f(o) for o in others)


def pca_fit(Xtr, k):
    mu = Xtr.mean(0)
    Xc = Xtr - mu
    ev, V = np.linalg.eigh((Xc @ Xc.T).astype(np.float64))
    idx = np.argsort(ev)[::-1]
    ev, V = ev[idx], V[:, idx]
    k = min(k, len(Xtr) - 1, int(np.sum(ev > 1e-8 * ev[0])))
    ev, V = ev[:k], V[:, :k]
    comps = (Xc.T.astype(np.float64) @ V) / np.sqrt(np.maximum(ev, 1e-12))
    return mu, comps.astype(np.float32)


def bilinear(z, s):
    return np.concatenate([z, s, np.einsum("ni,nj->nij", z, s).reshape(len(z), -1)], axis=1)


def _ridge_path(X, Y):
    n, p = X.shape
    if p <= n:
        e, V = np.linalg.eigh(X.T @ X)
        VtXtY = V.T @ (X.T @ Y)
        return lambda a: V @ (VtXtY / (e[:, None] + a * n))
    e, V = np.linalg.eigh(X @ X.T)
    VtY = V.T @ Y
    return lambda a: X.T @ (V @ (VtY / (e[:, None] + a * n)))


def ridge(Xtr, Ytr, Xva, Yva, Xte):
    mx, my = Xtr.mean(0), Ytr.mean(0)
    path = _ridge_path(Xtr - mx, Ytr - my)
    err = np.stack([np.mean(((Xva - mx) @ path(a) + my - Yva) ** 2, axis=0) for a in ALPHAS])
    best = ALPHAS[np.argmin(err, axis=0)]
    Xall, Yall = np.r_[Xtr, Xva], np.r_[Ytr, Yva]
    mx, my = Xall.mean(0), Yall.mean(0)
    path = _ridge_path(Xall - mx, Yall - my)
    W = np.zeros((Xall.shape[1], Yall.shape[1]))
    for a in np.unique(best):
        W[:, best == a] = path(a)[:, best == a]
    return (Xte - mx) @ W + my


class MLP(nn.Module):
    def __init__(self, din, dout, hid=None):
        super().__init__()
        hid = hid or MLP_HID
        layers, d = [], din
        for _ in range(MLP_DEPTH):
            layers += [nn.Linear(d, hid), nn.GELU()]
            d = hid
        layers.append(nn.Linear(d, dout))
        self.net = nn.Sequential(*layers)
        nn.init.normal_(self.net[-1].weight, std=1e-3)
        nn.init.zeros_(self.net[-1].bias)

    def forward(self, x):
        return self.net(x)


NPARAM = {}


def train_mlp(kind, A_tr, B_tr, Y_tr, A_va, B_va, Y_va, A_te, B_te, hid=None):
    """kind='full': f([A, B]) -> y (unstructured).   kind='cf': g(A)^T [1, B] (MLP readout, linear in B)."""
    torch.manual_seed(SEED)
    ym, ys = Y_tr.mean(0), Y_tr.std(0) + 1e-12
    q = Y_tr.shape[1]
    T = lambda a: torch.as_tensor(a, dtype=torch.float32, device=DEV)
    if kind == "cf":
        one = lambda b: np.c_[np.ones(len(b)), b]
        B_tr, B_va, B_te = one(B_tr), one(B_va), one(B_te)
        ps = B_tr.shape[1]
        net = MLP(A_tr.shape[1], q * ps, hid).to(DEV)
        fwd = lambda a, b: torch.einsum("nqp,np->nq", net(a).view(len(a), q, ps), b)
    else:
        net = MLP(A_tr.shape[1] + B_tr.shape[1], q, hid).to(DEV)
        fwd = lambda a, b: net(torch.cat([a, b], dim=1))
    NPARAM[(kind, hid or MLP_HID, q)] = sum(p.numel() for p in net.parameters())
    Atr, Btr, Ytr = T(A_tr), T(B_tr), T((Y_tr - ym) / ys)
    Ava, Bva, Yva = T(A_va), T(B_va), T((Y_va - ym) / ys)
    opt = torch.optim.AdamW(net.parameters(), lr=MLP_LR, weight_decay=MLP_WD)
    best, best_state, bad, n = float("inf"), None, 0, len(Atr)
    for ep in range(MLP_EPOCHS):
        net.train()
        perm = torch.randperm(n).to(DEV)
        for i in range(0, n, MLP_BATCH):
            b = perm[i:i + MLP_BATCH]
            loss = ((fwd(Atr[b], Btr[b]) - Ytr[b]) ** 2).mean()
            opt.zero_grad(); loss.backward(); opt.step()
        net.eval()
        with torch.no_grad():
            v = ((fwd(Ava, Bva) - Yva) ** 2).mean().item()
        if v < best - 1e-5:
            best, bad = v, 0
            best_state = {k: t.detach().clone() for k, t in net.state_dict().items()}
        else:
            bad += 1
            if bad >= MLP_PATIENCE:
                break
    net.load_state_dict(best_state); net.eval()
    with torch.no_grad():
        return fwd(T(A_te), T(B_te)).cpu().numpy() * ys + ym


def r2(y, p):
    return 1.0 - np.sum((y - p) ** 2, 0) / np.sum((y - y.mean(0)) ** 2, 0)


def run(name, cfg):
    stamp(f"===== {name}: loading {cfg['path']}")
    assert os.path.exists(cfg["path"]), f"{cfg['path']} not found"
    d = np.load(cfg["path"])
    LAM = d[cfg["lam"]].astype(np.float32)
    EP, CS, U = d["EP"], d["C_STATE"], d[cfg["u"]]
    NS, (NC, K, H, A) = len(EP), U.shape
    print("target plates:")
    qoi = make_qoi(*target_plates(d["Q0"], EP, d[cfg["succ"]]))
    POS0, POSF = qoi(d["Q0"]), qoi(d["QF"])
    NQ = POS0.shape[1]
    cstate = np.repeat(CS, K)
    DPSI = (POSF - POS0[CS][:, None, :]).reshape(NC * K, NQ)
    S2 = sig2(U.reshape(NC * K, H, A))
    RAW = U.reshape(NC * K, H * A).astype(np.float64)
    del d; gc.collect()
    print(f"states {NS} ({len(np.unique(EP))} episodes) | candidate states {NC} x {K} chunks of {H} steps "
          f"| representation dim {LAM.shape[1]}")

    folds = list(GroupKFold(n_splits=N_FOLDS).split(np.arange(NS), groups=EP))
    rng = np.random.default_rng(SEED)

    def split_val(tr):
        eps = np.unique(EP[tr])
        va = rng.choice(eps, size=max(1, len(eps) // 8), replace=False)
        return tr[~np.isin(EP[tr], va)], tr[np.isin(EP[tr], va)]

    reps = {}
    def rep(fi, tr):                                   # PCA-32, cached per fold
        if fi not in reps:
            mu, comps = pca_fit(LAM[tr], PCA_K)
            Z = (LAM - mu) @ comps
            reps[fi] = (Z - Z[tr].mean(0)) / (Z[tr].std(0) + 1e-12)
        return reps[fi]

    # (1) static psi(x), PCA-32 (also keeps the random-number order of the original scripts)
    static = np.zeros_like(POS0)
    for fi, (tr, te) in enumerate(folds):
        trn, va = split_val(tr)
        Z = rep(fi, tr)
        static[te] = ridge(Z[trn], POS0[trn], Z[va], POS0[va], Z[te])
    stamp("static done")

    # (2) increment Delta psi(x; u)
    gidx = {"pos": [QOI.index(q) for q in POS], "task": [QOI.index(q) for q in TASK]}
    models = MODELS[:3] + [f"{k} w{w}" for k in ("MLP readout", "unstructured") for w in WIDTHS]
    dpred = {m: np.zeros_like(DPSI) for m in models}
    NPARAM.clear()
    for fi, (tr, te) in enumerate(folds):
        trn, va = split_val(tr)
        Zs = rep(fi, tr)
        m_tr, m_va, m_te = (np.isin(cstate, a) for a in (trn, va, te))
        Z = Zs[cstate]
        S_tr, S_va, S_te = standardize(S2[m_tr], S2[m_va], S2[m_te])
        Y_tr, Y_va = DPSI[m_tr], DPSI[m_va]
        dpred["linear"][m_te] = ridge(Z[m_tr], Y_tr, Z[m_va], Y_va, Z[m_te])
        dpred["additive"][m_te] = ridge(np.c_[Z[m_tr], S_tr], Y_tr, np.c_[Z[m_va], S_va], Y_va, np.c_[Z[m_te], S_te])
        dpred["bilinear"][m_te] = ridge(bilinear(Z[m_tr], S_tr), Y_tr, bilinear(Z[m_va], S_va), Y_va,
                                        bilinear(Z[m_te], S_te))
        R_tr, R_va, R_te = standardize(RAW[m_tr], RAW[m_va], RAW[m_te])
        ps_ = S_tr.shape[1]
        for g, ix in gidx.items():                         # MLPs shared within a group, as in tab:vla_probe
            for w in WIDTHS:
                dpred[f"MLP readout w{w}"][np.ix_(m_te, ix)] = train_mlp(
                    "cf", Z[m_tr], S_tr, Y_tr[:, ix], Z[m_va], S_va, Y_va[:, ix], Z[m_te], S_te, hid=w)
                dpred[f"unstructured w{w}"][np.ix_(m_te, ix)] = train_mlp(
                    "full", Z[m_tr], R_tr, Y_tr[:, ix], Z[m_va], R_va, Y_va[:, ix], Z[m_te], R_te, hid=w)
        stamp(f"increment fold {fi + 1}/{N_FOLDS} (signature features {ps_}, raw action features {R_tr.shape[1]})")

    res = {m: r2(DPSI, dpred[m]) for m in models}
    zk, pk = PCA_K, ps_
    n_pos, n_task = len(gidx["pos"]), len(gidx["task"])
    ridge_par = {"direct": zk + 1, "additive": zk + pk + 1, "linear": zk + pk + zk * pk + 1}
    name_of = {"linear": "direct", "additive": "additive", "bilinear": "linear"}     # q1 model -> table column
    grp = dict(GROUPS, all=QOI)

    def params(col, gname):
        if col in ridge_par:
            return float(ridge_par[col])
        kind, w = ("cf" if col.startswith("MLP") else "full"), int(col.split(" w")[1])
        tp, tt = NPARAM[(kind, w, n_pos)], NPARAM[(kind, w, n_task)]
        return {"distances": tt / n_task, "all": (tp + tt) / (n_pos + n_task)}.get(gname, tp / n_pos)

    out = {}
    for m in models:
        col = name_of.get(m, m)
        out[col] = {gn: dict(params=params(col, gn), r2=res[m][[QOI.index(q) for q in qs]],
                             mean=float(np.mean(res[m][[QOI.index(q) for q in qs]]))) for gn, qs in grp.items()}
    for gn, qs in grp.items():
        print(f"\n{name} | {gn}: mean held-out R^2 against parameters per QoI")
        print(f"  {'probe':22s} {'params/QoI':>11s} {'mean R2':>8s}   " + " ".join(f"{q[:9]:>9s}" for q in qs))
        for col, v in sorted(out.items(), key=lambda t: t[1][gn]["params"]):
            print(f"  {col:22s} {v[gn]['params']:11,.0f} {v[gn]['mean']:8.3f}   " + " ".join(f"{x:9.3f}" for x in v[gn]["r2"]))
        lin = out["linear"][gn]["mean"]
        best = max(v[gn]["mean"] for c, v in out.items() if c not in ridge_par)
        print(f"  gain additive -> linear {lin - out['additive'][gn]['mean']:+.3f} | best MLP over linear {best - lin:+.3f}")
    print("  check vs tab:vla_probe (direct / additive / linear, then MLP and unstr. at width 256):")
    for q in REPORTED[name]:
        j = TABLE_ROWS.index(q)
        print(f"    {q:8s} " + " ".join(f"{out[c]['mug positions']['r2'][j]:.3f}"
                                      for c in ["direct", "additive", "linear", "MLP readout w256", "unstructured w256"]))
    res = out
    del LAM, reps; gc.collect()
    return res


ALL = {name: run(name, cfg) for name, cfg in DATASETS.items()}
GN = list(GROUPS) + ["all"]
np.savez(OUT, groups=np.array(GN), widths=np.array(WIDTHS),
         **{f"{n}|{c}|{g}|{k}": np.asarray(v[g][k]) for n, r in ALL.items() for c, v in r.items() for g in GN
            for k in ("params", "r2", "mean")})
stamp(f"saved {OUT}")

# ---------------- figure: mean R^2 against parameters per QoI, one panel per model and QoI group ----------------
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
plt.rcParams.update({"font.size": 8, "axes.edgecolor": "#c3c2b7", "axes.labelcolor": "#52514e",
                     "xtick.color": "#52514e", "ytick.color": "#52514e"})
fig, axes = plt.subplots(len(ALL), len(GN), figsize=(3.0 * len(GN), 2.5 * len(ALL)), squeeze=False)
for i, (n, r) in enumerate(ALL.items()):
    for k, g in enumerate(GN):
        ax = axes[i][k]
        for kind, col in (("MLP readout", "#1baf7a"), ("unstructured", "#eda100")):
            P = [r[f"{kind} w{w}"][g]["params"] for w in WIDTHS]; Y = [r[f"{kind} w{w}"][g]["mean"] for w in WIDTHS]
            ax.plot(P, Y, marker="o", ms=3, lw=1.4, color=col, label=kind)
            for w, p_, y_ in zip(WIDTHS, P, Y):
                ax.annotate(str(w), (p_, y_), textcoords="offset points", xytext=(0, -9), fontsize=5.5, ha="center", color=col)
        for c, mk, col in (("direct", "s", "#898781"), ("additive", "^", "#2a78d6"), ("linear", "*", "#eb6834")):
            ax.scatter(r[c][g]["params"], r[c][g]["mean"], marker=mk, s=60 if c == "linear" else 28, color=col, zorder=3, label=c)
        ax.set_xscale("log"); ax.set_title(f"{n} · {g}", fontsize=8)
        ax.set_xlabel("parameters per QoI", fontsize=7)
        if k == 0:
            ax.set_ylabel("mean held-out $R^2$", fontsize=7)
        ax.tick_params(labelsize=6.5)
        ax.spines[["top", "right"]].set_visible(False); ax.yaxis.grid(True, color="#e1e0d9", lw=0.5); ax.set_axisbelow(True)
axes[0][-1].legend(frameon=False, fontsize=6, loc="lower right")
fig.tight_layout()
for ext in ("png", "pdf"):
    fig.savefig(f"{FIG}.{ext}", dpi=250, bbox_inches="tight")
print(f"saved {FIG}.png / .pdf")

# ---------------- summary over groups ----------------
print("\nSUMMARY: gain from conditioning on the chunk (additive -> linear) vs. remaining gain of the best MLP")
for n, r in ALL.items():
    for g in GN:
        lin = r["linear"][g]["mean"]
        mlps = {c: v[g] for c, v in r.items() if " w" in c}
        bc = max(mlps, key=lambda c: mlps[c]["mean"])
        cheaper = [c for c, v in mlps.items() if v["params"] <= r["linear"][g]["params"] and v["mean"] > lin]
        print(f"  {n:12s} {g:14s} linear {lin:.3f} | additive -> linear {lin - r['additive'][g]['mean']:+.3f} | best MLP "
              f"{mlps[bc]['mean']:.3f} ({bc}, {mlps[bc]['params']:,.0f}/QoI, {mlps[bc]['mean'] - lin:+.3f}) | MLPs better "
              f"with <= linear's parameters: {', '.join(cheaper) if cheaper else 'none'}")

# ---------------- LaTeX rows: probe & params & mean R2 per group, both models ----------------
fmtp = lambda p: f"{p:,.0f}" if p < 1000 else f"{p / 1000:.1f}k"
f3 = lambda x: f"{x:.3f}".lstrip("0") if x >= 0 else "$-$" + f"{-x:.3f}".lstrip("0")
print("\n% ---- LaTeX rows per model: probe & params (all QoIs) & mug pos. & EE pos. & distances & all")
cols = ["direct", "additive", "linear"] + [f"MLP readout w{w}" for w in WIDTHS] + [f"unstructured w{w}" for w in WIDTHS]
for n in ALL:
    print(f"% {n}")
    for c in cols:
        lab = c.replace("MLP readout w", "MLP, width ").replace("unstructured w", "unstr., width ")
        lab = r"\textbf{linear}" if c == "linear" else lab
        print(f"{lab:22s} & {fmtp(ALL[n][c]['all']['params'])} & " + " & ".join(f3(ALL[n][c][g]["mean"]) for g in GN) + r" \\")
