# ======================================================================
# Figure: probing accuracy against parameters, all 13 QoIs, OpenVLA-OFT and SmolVLA  (ONE Colab cell, CPU, seconds)
#   reads aclrh/q1_capacity.npz (probing/q1_capacity_sweep.py); writes aclrh/figs/q1_capacity_all.(png|pdf)
# ======================================================================
import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
try:
    from google.colab import drive
    if not os.path.isdir("/content/drive/MyDrive"):
        drive.mount("/content/drive")
except ImportError:
    pass
ROOT = os.environ.get("ACLRH_ROOT", "/content/drive/MyDrive/aclrh")
GROUP = "all"                                   # or "mug positions", "EE positions", "distances"
R = np.load(f"{ROOT}/q1_capacity.npz")
WIDTHS = [int(w) for w in R["widths"]]
MODELS = ["OpenVLA-OFT", "SmolVLA"]
get = lambda n, c, k: float(R[f"{n}|{c}|{GROUP}|{k}"])

plt.rcParams.update({"font.size": 8, "axes.edgecolor": "#c3c2b7", "axes.labelcolor": "#52514e",
                     "xtick.color": "#52514e", "ytick.color": "#52514e"})
fig, axes = plt.subplots(1, 2, figsize=(6.6, 2.35))
LABEL_W = [8, 32, 256]                          # widths written next to the points (all are plotted)
for ax, n in zip(axes, MODELS):
    for kind, lab, col, dy in (("MLP readout", r"MLP readout $\langle \mathrm{MLP}(z(x)), S_{1:2}(\mathbf{u})\rangle$", "#1baf7a", 5),
                               ("unstructured", r"unstructured $\mathrm{MLP}(z(x), \mathbf{u})$", "#eda100", -8)):
        P = [get(n, f"{kind} w{w}", "params") for w in WIDTHS]
        Y = [get(n, f"{kind} w{w}", "mean") for w in WIDTHS]
        ax.plot(P, Y, marker="o", ms=3, lw=1.4, color=col, label=lab)
        for w, p_, y_ in zip(WIDTHS, P, Y):        # readout labels above, unstructured below
            if w in LABEL_W:
                ax.annotate(str(w), (p_, y_), textcoords="offset points", xytext=(0, dy), fontsize=5, ha="center",
                            va="bottom" if dy > 0 else "top", color=col)
    for c, lab, mk, col, s in (("direct", r"direct $\langle z(x), a\rangle$", "s", "#898781", 26),
                               ("additive", r"additive $\langle z(x), a\rangle + \langle b, S_{1:2}(\mathbf{u})\rangle$", "^", "#2a78d6", 30),
                               ("linear", r"linear $\langle z(x), L_\psi^{1:2} S_{1:2}(\mathbf{u})\rangle$ (ours)", "*", "#eb6834", 80)):
        ax.scatter(get(n, c, "params"), get(n, c, "mean"), marker=mk, s=s, color=col, zorder=3, label=lab)
    ax.set_xscale("log"); ax.set_title(n, fontsize=8.5)
    ax.set_xlabel("parameters per QoI", fontsize=7); ax.tick_params(labelsize=6.5)
    ax.spines[["top", "right"]].set_visible(False); ax.yaxis.grid(True, color="#e1e0d9", lw=0.5); ax.set_axisbelow(True)
axes[0].set_ylabel(r"mean held-out $R^2$", fontsize=7)
h, l = axes[0].get_legend_handles_labels()
fig.legend(h, l, loc="lower center", ncol=3, frameon=False, fontsize=6, bbox_to_anchor=(0.5, 0.0),
           handlelength=1.6, columnspacing=1.2, labelspacing=0.4)
fig.tight_layout(rect=(0, 0.16, 1, 1), w_pad=1.0)
os.makedirs(f"{ROOT}/figs", exist_ok=True)
for ext in ("png", "pdf"):
    fig.savefig(f"{ROOT}/figs/q1_capacity_{GROUP.replace(' ', '_')}.{ext}", dpi=300, bbox_inches="tight")
print(f"saved {ROOT}/figs/q1_capacity_{GROUP.replace(' ', '_')}.png / .pdf")
