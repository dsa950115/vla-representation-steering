# ======================================================================
# OpenVLA-OFT — STEP 5c: steering for -d(EE, yellow-and-white mug), same protocol as 5b  (ONE Colab cell, A100)
#
#   1. builds a separate Python 3.10 venv (/content/oftenv) with torch 2.2 (cu121),
#      openvla-oft (+ its transformers fork) and LIBERO
#   2. runs a verification script inside that venv:
#        - loads moojink/openvla-7b-oft-finetuned-libero-10
#        - closed-loop rollouts on the mug task (success check)
#        - captures lambda = action-token hidden states entering the L1 action head
#        - checks that the head applied to the captured lambda reproduces the action chunk
#
#   Nothing is written to Drive in this step. Re-running the cell skips finished installs.
# ======================================================================
import os, subprocess, sys, textwrap, time

VENV = "/content/oftenv"
VPY = f"{VENV}/bin/python"
OFT = "/content/openvla-oft"
LIB = "/content/LIBERO"
MARK = f"{VENV}/.setup_done"


def sh(cmd, check=True):
    print(f"$ {cmd}", flush=True)
    r = subprocess.run(cmd, shell=True, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    tail = "\n".join(r.stdout.strip().splitlines()[-15:])
    if tail:
        print(tail, flush=True)
    if check and r.returncode != 0:
        raise RuntimeError(f"failed ({r.returncode}): {cmd}")
    return r.returncode


# ---------------------------------------------------------------- 0. Drive (checked before any model loading)
if not os.path.isdir("/content/drive/MyDrive"):
    from google.colab import drive
    drive.mount("/content/drive")
os.makedirs("/content/drive/MyDrive/aclrh", exist_ok=True)

# ---------------------------------------------------------------- 0b. GPU check
assert subprocess.run(["nvidia-smi"], stdout=subprocess.DEVNULL).returncode == 0, \
    "No GPU visible: switch the runtime to GPU (A100) and reconnect."

# ---------------------------------------------------------------- 1. setup (once)
if not os.path.exists(MARK):
    t0 = time.time()
    sh("pip install -q uv")
    sh("uv python install 3.10")
    sh(f"rm -rf {VENV}")                                # a half-built venv without the marker: start clean
    sh(f"uv venv {VENV} --python 3.10 --seed")
    UV = f"uv pip install --python {VPY}"
    sh(f"{UV} torch==2.2.0 torchvision==0.17.0 --index-url https://download.pytorch.org/whl/cu121")
    sh(f"{UV} numpy==1.26.4")
    if not os.path.exists(OFT):
        sh(f"git clone -q https://github.com/moojink/openvla-oft.git {OFT}")
    sh(f"{UV} -e {OFT}")                                   # pulls the transformers fork and pinned deps
    if not os.path.exists(LIB):
        sh(f"git clone -q https://github.com/Lifelong-Robot-Learning/LIBERO.git {LIB}")
    sh(f"{UV} -e {LIB}")
    sh(f"{UV} -r {OFT}/experiments/robot/libero/libero_requirements.txt")
    sh(f"{UV} numpy==1.26.4")                             # re-pin in case a dependency upgraded it
    # flash-attn: prebuilt wheel for torch 2.2 / py3.10; if it fails the verification falls back to sdpa
    rc = sh(f"{UV} https://github.com/Dao-AILab/flash-attention/releases/download/v2.5.5/"
            "flash_attn-2.5.5+cu122torch2.2cxx11abiFALSE-cp310-cp310-linux_x86_64.whl", check=False)
    print("flash-attn installed" if rc == 0 else "flash-attn NOT installed -> sdpa fallback")
    # LIBERO asks interactively for its data paths on first import: write the config up front
    os.makedirs(os.path.expanduser("~/.libero"), exist_ok=True)
    base = f"{LIB}/libero/libero"
    with open(os.path.expanduser("~/.libero/config.yaml"), "w") as f:
        f.write(textwrap.dedent(f"""\
            benchmark_root: {base}
            bddl_files: {base}/bddl_files
            init_states: {base}/init_files
            datasets: {LIB}/datasets
            assets: {base}/assets
            """))
    open(MARK, "w").write("ok")
    print(f"setup finished in {(time.time() - t0) / 60:.1f} min")
else:
    print("setup already done")

# ---------------------------------------------------------------- 1b. dependency fixes (idempotent)
# tensorflow_datasets is imported by openvla-oft at import time; a too-new tensorflow-metadata needs
# protobuf 5 (google.protobuf.runtime_version), which TF 2.15 cannot use -> pin the TF-2.15-era version
if sh(f"{VPY} -c \"import tensorflow_datasets\"", check=False) != 0:
    sh(f"uv pip install --python {VPY} tensorflow-metadata==1.14.0")
    sh(f"{VPY} -c \"import tensorflow_datasets, google.protobuf as p; print('tfds OK | protobuf', p.__version__)\"")

# robosuite 1.4 predates the MuJoCo >= 3.2 joint-type API (get_joint_qpos_addr assertion) -> pin 3.1.6
_mj = subprocess.run([VPY, "-c", "import mujoco; print(mujoco.__version__)"], text=True,
                     stdout=subprocess.PIPE, stderr=subprocess.DEVNULL).stdout.strip()
print("mujoco in venv:", _mj or "not installed")
if not _mj.startswith("3.1."):
    sh(f"uv pip install --python {VPY} mujoco==3.1.6")
os.makedirs(f"{LIB}/datasets", exist_ok=True)          # silences LIBERO's missing-datasets warning

sh(f"{VPY} -c \"import torch, transformers, numpy; print('torch', torch.__version__, 'cuda', "
   f"torch.cuda.is_available(), '| transformers', transformers.__version__, '| numpy', numpy.__version__)\"")

# ---------------------------------------------------------------- 2. verification script (runs in the venv)
SCRIPT = r'''
import os, sys, time, traceback
os.environ.setdefault("MUJOCO_GL", "egl")
os.environ.setdefault("PYOPENGL_PLATFORM", "egl")
os.environ["MPLBACKEND"] = "Agg"
sys.path.insert(0, "/content/openvla-oft")
sys.path.insert(0, "/content/LIBERO")          # LIBERO's setup.py is not exposed by uv editable installs
import numpy as np
import torch

CKPT = "moojink/openvla-7b-oft-finetuned-libero-10"
UNNORM = "libero_10_no_noops"
TASK_KEYWORDS = ("white mug", "left plate", "yellow and white mug", "right plate")
MAX_STEPS = 520
NUM_WAIT = 10

T0 = time.time()

def stamp(m):
    print(f"[{time.time() - T0:7.1f}s] {m}", flush=True)


def header(t):
    print("\n" + "=" * 90 + f"\n{t}\n" + "=" * 90, flush=True)

header("1. IMPORTS")
# wandb is only used for evaluation logging; the installed wandb needs a newer protobuf than
# TF 2.15 allows, so register a no-op stand-in instead of touching protobuf again
import types, importlib.machinery
_wb = types.ModuleType("wandb")
_wb.__spec__ = importlib.machinery.ModuleSpec("wandb", None)   # find_spec() (accelerate/transformers) needs a spec
_wb.__version__ = "0.0.0"
for _name in ("init", "log", "finish", "login", "config", "save", "watch"):
    setattr(_wb, _name, lambda *a, **k: None)
_wb.run = None
sys.modules["wandb"] = _wb
from experiments.robot.libero.run_libero_eval import GenerateConfig
import experiments.robot.libero.run_libero_eval as rle
import experiments.robot.openvla_utils as ou
import experiments.robot.libero.libero_utils as lu
import experiments.robot.robot_utils as ru
from libero.libero import benchmark
print("run_libero_eval exports:", [n for n in dir(rle) if not n.startswith("_")][:60])

try:
    import flash_attn  # noqa
    ATTN = "flash_attention_2"
except Exception:
    ATTN = "sdpa"
print("attention implementation:", ATTN)

header("2. LOAD OPENVLA-OFT (LIBERO-10)")
cfg = GenerateConfig(
    pretrained_checkpoint=CKPT, use_l1_regression=True, use_diffusion=False, use_film=False,
    num_images_in_input=2, use_proprio=True, load_in_8bit=False, load_in_4bit=False,
    center_crop=True, num_open_loop_steps=8, unnorm_key=UNNORM,
)
if hasattr(cfg, "task_suite_name"):
    cfg.task_suite_name = "libero_10"
if hasattr(cfg, "model_family"):
    cfg.model_family = "openvla"
t0 = time.time()
if ATTN != "flash_attention_2":
    # route the loader to sdpa if flash-attn is missing
    from transformers import AutoModelForVision2Seq
    _orig_fp = AutoModelForVision2Seq.from_pretrained
    def _fp(*a, **kw):
        kw["attn_implementation"] = "sdpa"
        return _orig_fp(*a, **kw)
    AutoModelForVision2Seq.from_pretrained = _fp
vla = ou.get_vla(cfg)
processor = ou.get_processor(cfg)
action_head = ou.get_action_head(cfg, llm_dim=vla.llm_dim)
proprio_projector = ou.get_proprio_projector(cfg, llm_dim=vla.llm_dim, proprio_dim=8)
print(f"loaded in {time.time() - t0:.0f}s | llm_dim {vla.llm_dim} | unnorm keys: {list(getattr(vla, 'norm_stats', {}).keys())[:8]}")

# ---- lambda hook: capture (and later intervene on) the input of the L1 action head ----
LAM = {"cap": None, "delta": None}
_orig_predict = action_head.predict_action
def _predict(actions_hidden_states, *a, **kw):
    LAM["cap"] = actions_hidden_states.detach().float().cpu()
    if LAM["delta"] is not None:
        actions_hidden_states = actions_hidden_states + LAM["delta"].to(actions_hidden_states.device,
                                                                          actions_hidden_states.dtype)
    return _orig_predict(actions_hidden_states, *a, **kw)
action_head.predict_action = _predict

def policy_chunk(obs, task_label):
    observation, _ = rle.prepare_observation(obs, ru.get_image_resize_size(cfg)) \
        if hasattr(rle, "prepare_observation") else (None, None)
    actions = ou.get_vla_action(cfg, vla, processor, observation, task_label, action_head, proprio_projector)
    return np.asarray(actions)


# constants used by the helpers shared with step 2 (perturb is not used for steering)
H = 8
N_KNOTS = 4
PERT_FRAC = 0.3
SEED = 0

header("3. TASK AND ENVIRONMENTS")
suite = benchmark.get_benchmark_dict()["libero_10"]()
tid = next(i for i in range(suite.n_tasks) if all(k in suite.get_task(i).language for k in TASK_KEYWORDS))
task = suite.get_task(tid)
init_states = suite.get_task_init_states(tid)
env, task_description = lu.get_libero_env(task, "openvla", resolution=256)
try:
    from libero.libero.envs import ControlEnv
except ImportError:
    from libero.libero.envs.env_wrapper import ControlEnv   # not re-exported in this LIBERO version
from libero.libero import get_libero_path
bddl = os.path.join(get_libero_path("bddl_files"), task.problem_folder, task.bddl_file)
cenv = ControlEnv(bddl_file_name=bddl, has_renderer=False, has_offscreen_renderer=False,
                  use_camera_obs=False, camera_heights=128, camera_widths=128)   # renderer-free twin
cenv.seed(0)
cenv.reset()
inner = env.env
print(f"task {tid}: {task_description} | init states {len(init_states)}")
print("objects:", list(inner.obj_body_id.keys()))

MUGS_PLATES = ["porcelain_mug_1", "white_yellow_mug_1", "plate_1", "plate_2"]
QOI_NAMES = ["ee_x", "ee_y", "ee_z"] + [f"{o}_{c}" for o in MUGS_PLATES for c in "xyz"]

def positions(e):
    s = e.env
    out = [np.array(s.sim.data.site_xpos[s.robots[0].eef_site_id])]
    out += [np.array(s.sim.data.body_xpos[s.obj_body_id[o]]) for o in MUGS_PLATES]
    return np.concatenate(out)

def grip_state(e):
    g = getattr(e.env.robots[0].gripper, "current_action", None)
    return None if g is None else np.array(g, dtype=np.float64).copy()

def restore(e, sim_state, grip):
    e.env.timestep, e.env.done = 0, False       # the twin env replays many chunks: never hit the horizon
    e.set_init_state(sim_state)
    if grip is not None and hasattr(e.env.robots[0].gripper, "current_action"):
        e.env.robots[0].gripper.current_action = grip.copy()

def run_chunk(e, sim_state, grip, actions):
    restore(e, sim_state, grip)
    for a in actions:
        e.step(np.asarray(a, dtype=np.float64).tolist())
    return positions(e)

# per-dimension scale for perturbations, from the checkpoint's action statistics (raw action space)
try:
    st_ = vla.norm_stats[UNNORM]["action"]
    half = (np.asarray(st_["q99"]) - np.asarray(st_["q01"])) / 2.0
except Exception as ex:
    print("[warn] norm stats unavailable, using 0.5:", repr(ex)); half = np.full(7, 0.5)
print("perturbation std per arm dim:", np.round(PERT_FRAC * half[:6], 4))
rng = np.random.default_rng(SEED)

def perturb(chunk, k):
    """k smooth perturbations of the raw policy chunk on the 6 arm dims; gripper unchanged"""
    tk = np.linspace(0, H - 1, N_KNOTS)
    out = np.repeat(chunk[None], k, 0).astype(np.float64)
    for i in range(k):
        knots = rng.normal(size=(N_KNOTS, 6)) * PERT_FRAC * half[:6]
        out[i, :, :6] += np.stack([np.interp(np.arange(H), tk, knots[:, j]) for j in range(6)], 1)
    return out

def executed(raw_chunk):
    return np.stack([np.asarray(rle.process_action(a.copy(), "openvla"), dtype=np.float64) for a in raw_chunk])


# ======================================================================
# STEP 4: STEERING  lambda_alpha = lambda(x) + alpha d(x), chunk = head(lambda_alpha)  (deterministic)
# ======================================================================
def sig_levels(U):
    """time-augmented signature, dX = (dt, u dt): returns S1, S<=2, S<=3."""
    U = np.asarray(U, dtype=np.float64)
    N, H, A = U.shape
    dt = 1.0 / H
    dx = np.concatenate([np.full((N, H, 1), dt), U * dt], axis=2)
    prev1 = np.cumsum(dx, axis=1) - dx
    inc2 = np.einsum("nti,ntj->ntij", prev1, dx) + 0.5 * np.einsum("nti,ntj->ntij", dx, dx)
    prev2 = np.cumsum(inc2, axis=1) - inc2
    S1 = dx.sum(axis=1)
    S2 = inc2.sum(axis=1)
    S3 = (np.einsum("ntij,ntk->nijk", prev2, dx, optimize=True)
          + 0.5 * np.einsum("nti,ntj,ntk->nijk", prev1, dx, dx, optimize=True)
          + np.einsum("nti,ntj,ntk->nijk", dx, dx, dx, optimize=True) / 6.0)
    M2 = np.concatenate([S1, S2.reshape(N, -1)], axis=1)
    return {"S1": S1, "S<=2": M2, "S<=3": np.concatenate([M2, S3.reshape(N, -1)], axis=1)}


DATA = "/content/drive/MyDrive/aclrh/oft_probe.npz"
OUT_ST = "/content/drive/MyDrive/aclrh/oft_steering_ee_mug2.npz"

# ---- task QoIs derived from the 15 stored positions: ee(0:3) mug1(3:6) mug2(6:9) plate_1(9:12) plate_2(12:15)
def target_plates(Q0, EP, success_ep):
    """plate each mug ends on in successful episodes (last snapshot), by horizontal distance"""
    last = [np.where(EP == e)[0][-1] for e in np.unique(EP) if success_ep[int(e)]]
    P = Q0[last]
    out = []
    for m in (3, 6):
        d1 = np.linalg.norm(P[:, m:m + 2] - P[:, 9:11], axis=1)
        d2 = np.linalg.norm(P[:, m:m + 2] - P[:, 12:14], axis=1)
        out.append(9 if np.mean(d1 < d2) >= 0.5 else 12)
        print(f"  mug at cols {m}:{m + 3}: nearer to plate_1 in {np.mean(d1 < d2):.0%} of successful end states "
              f"-> target plate_{1 if out[-1] == 9 else 2}")
    return out

def make_qoi(t1, t2):
    def qoi(P):
        """P (..., 15) -> (..., 3): psi to INCREASE (negative distances)"""
        return np.stack([-np.linalg.norm(P[..., 3:5] - P[..., t1:t1 + 2], axis=-1),
                         -np.linalg.norm(P[..., 6:8] - P[..., t2:t2 + 2], axis=-1),
                         -np.linalg.norm(P[..., 0:3] - P[..., 3:6], axis=-1),
                         -np.linalg.norm(P[..., 0:3] - P[..., 6:9], axis=-1)], axis=-1)
    return qoi

QOI_LIST = ["-d(mug1,plate) xy", "-d(mug2,plate) xy", "-d(EE,mug1)", "-d(EE,mug2)"]
STEER_ONLY = ["-d(EE,mug2)"]          # QoIs to steer in this run (probes are fitted for all)
PCA_K = 32
N_PER_FOLD = 10               # steered states per QoI and fold (2 folds)
MOVE_MM, MIN_FRAC = 2e-3, 0.5
H_Z = 0.25                    # finite-difference step (standardized PCA units) for D phi and the simulator gradient
STEP_REL = 0.005              # ||delta lambda|| / ||lambda|| per unit tau, identical for all directions
TAUS = [-8.0, -4.0, -2.0, 0.0, 2.0, 4.0, 8.0]
N_RANDOM = 3
ALPHAS_R = np.logspace(-3, 4, 15)

def ranks(v):
    v = np.asarray(v, float)
    r = np.empty(len(v)); r[np.argsort(v, kind="mergesort")] = np.arange(len(v), dtype=float)
    for val in np.unique(v):                     # average ranks for ties
        m = v == val
        r[m] = r[m].mean()
    return r

def spearman(x, y):
    y = np.asarray(y, float)
    if np.ptp(y) < 1e-12:                         # a flat response is not monotone
        return 0.0
    return float(np.corrcoef(ranks(x), ranks(y))[0, 1])

def ridge_fit(Xtr, Ytr, Xva, Yva):
    """primal ridge with standardized columns; penalty per target chosen on validation rows; refit on all"""
    def fit(X, Y, a_):
        mx, sx, my = X.mean(0), X.std(0) + 1e-12, Y.mean(0)
        Xs = (X - mx) / sx
        G = Xs.T @ Xs
        W = np.linalg.solve(G + a_ * len(X) * np.eye(G.shape[0]), Xs.T @ (Y - my))
        return W / sx[:, None], my - (mx / sx) @ W
    best = []
    for j in range(Ytr.shape[1]):
        errs = []
        for a_ in ALPHAS_R:
            W, b = fit(Xtr, Ytr[:, j:j + 1], a_)
            errs.append(np.mean((Xva @ W + b - Yva[:, j:j + 1]) ** 2))
        best.append(ALPHAS_R[int(np.argmin(errs))])
    X, Y = np.r_[Xtr, Xva], np.r_[Ytr, Yva]
    Ws, bs = zip(*[fit(X, Y[:, j:j + 1], best[j]) for j in range(Y.shape[1])])
    return np.concatenate(Ws, 1), np.concatenate(bs)          # coef (p, q), intercept (q,)

header("4. DATA, SIGNATURES, HEAD")
dd = np.load(DATA)
LAMS = dd["LAM"]                                              # float16 (NS, 229376)
EP, CS = dd["EP"], dd["C_STATE"]
UE, URAW, SIMS, GRIPS = dd["U_EXEC"], dd["U_RAW"], dd["SIM"], dd["GRIP"]
print("target plates:")
qoi = make_qoi(*target_plates(dd["Q0"], EP, dd["SUCCESS_EP"]))
Q0, QF = qoi(dd["Q0"]), qoi(dd["QF"])                         # psi(x) (NS, 3), psi(F_u x) (NC, K, 3)
QOIS = {name: i for i, name in enumerate(QOI_LIST)}
NS, (NC, K, H_, A_) = len(EP), UE.shape
S_all = sig_levels(UE.reshape(NC * K, H_, A_).astype(np.float64))["S<=2"]
s_mu, s_sd = S_all.mean(0), S_all.std(0)
keep = s_sd > 1e-8 * s_sd.max()
st = lambda UU: (sig_levels(np.asarray(UU, np.float64).reshape(-1, H_, A_))["S<=2"][:, keep] - s_mu[keep]) / s_sd[keep]
S_all = (S_all[:, keep] - s_mu[keep]) / s_sd[keep]
ps = S_all.shape[1]
hp = next(action_head.parameters())
LSHAPE = (56, 4096)

def head_chunks(lams):
    """lams: (n, 229376) float32 -> executed chunks (n, 8, 7), exactly as in the rollouts"""
    with torch.no_grad():
        na = _orig_predict(torch.from_numpy(lams.reshape((-1,) + LSHAPE)).to(hp.device, hp.dtype))
    na = na.float().cpu().numpy().reshape(-1, H_, A_)
    ua = np.asarray(vla._unnormalize_actions(na, UNNORM)).reshape(-1, H_, A_)
    return np.stack([executed(c) for c in ua])

# check: head(stored lambda) reproduces the stored policy chunk (candidate 0)
chk = head_chunks(LAMS[CS[:8]].astype(np.float32))
print(f"head(stored lambda) vs stored executed policy chunk: max|diff| arm {np.abs(chk[:, :, :6] - UE[:8, 0, :, :6]).max():.2e}")

eps = np.unique(EP)
folds = [(set(eps[::2].tolist()), set(eps[1::2].tolist())), (set(eps[1::2].tolist()), set(eps[::2].tolist()))]
qidx = list(QOIS.values())
OUTR = {qn: [] for qn in QOIS}
rng = np.random.default_rng(0)

for fi, (A_eps, B_eps) in enumerate(folds):
    header(f"5.{fi + 1} FOLD {fi + 1}: fit on {len(A_eps)} episodes, steer in {len(B_eps)} held-out episodes")
    inA = np.array([e in A_eps for e in EP])
    X32 = LAMS[inA].astype(np.float32)
    mu = X32.mean(0); Xc = X32 - mu
    ev, V = np.linalg.eigh((Xc @ Xc.T).astype(np.float64)); ix = np.argsort(ev)[::-1][:PCA_K]
    comps = ((Xc.T.astype(np.float64) @ V[:, ix]) / np.sqrt(ev[ix])).astype(np.float32)   # (D, 32) orthonormal
    del X32, Xc
    Zall = np.concatenate([(LAMS[i:i + 64].astype(np.float32) - mu) @ comps for i in range(0, NS, 64)])
    zm, zs = Zall[inA].mean(0), Zall[inA].std(0) + 1e-12
    Zall = (Zall - zm) / zs
    to_lam = lambda dz: (comps @ (zs * dz)).astype(np.float32)

    # ---- probes on fold A: increment (bilinear) and static ----
    cA = np.where(inA[CS])[0]
    vaE = set(rng.choice(sorted(A_eps), size=max(1, len(A_eps) // 8), replace=False).tolist())
    isva = np.array([EP[CS[j]] in vaE for j in cA])
    def design(js):
        Z = np.repeat(Zall[CS[js]], K, 0); S = S_all[np.concatenate([np.arange(j * K, (j + 1) * K) for j in js])]
        return np.c_[Z, S, (Z[:, :, None] * S[:, None, :]).reshape(len(Z), -1)]
    def target(js):
        return (QF[js][:, :, qidx] - Q0[CS[js]][:, None, qidx]).reshape(-1, len(qidx))
    Wc, bc = ridge_fit(design(cA[~isva]), target(cA[~isva]), design(cA[isva]), target(cA[isva]))
    a_inc, b_inc = Wc[:PCA_K].T, Wc[PCA_K:PCA_K + ps].T                     # (q, 32), (q, ps)
    W_inc = Wc[PCA_K + ps:].T.reshape(len(qidx), PCA_K, ps)
    sA = np.where(inA)[0]; sva = np.array([EP[i] in vaE for i in sA])
    Ws, _ = ridge_fit(Zall[sA[~sva]], Q0[sA[~sva]][:, qidx], Zall[sA[sva]], Q0[sA[sva]][:, qidx])
    a_sta = Ws.T                                                              # (q, 32)
    stamp("probes fitted on fold A")

    for q, (qn, qi) in enumerate(QOIS.items()):
        if qn not in STEER_ONLY:
            continue
        cB = np.where(~inA[CS])[0]
        dq = QF[cB][:, :, qi] - Q0[CS[cB], qi][:, None]
        frac, sd = (np.abs(dq) > MOVE_MM).mean(1), dq.std(1)
        ok = (frac >= (MIN_FRAC if "plate" in qn else 0.0)) & (sd > MOVE_MM)
        sel = cB[ok][np.argsort(-sd[ok])][:N_PER_FOLD]
        print(f"\n[{qn}] fold {fi + 1}: eligible {ok.sum()} -> steering {len(sel)}", flush=True)
        for j in sel:
            g = CS[j]
            lam0 = LAMS[g].astype(np.float32)
            z0 = Zall[g]
            sim_state, grip = SIMS[g], GRIPS[g].astype(np.float64)       # always restore (zeros is a valid state)
            u0 = head_chunks(lam0[None])[0]
            S0 = st(u0)[0]
            # ---- D phi (head only) and the simulator gradient, central differences along the 32 axes ----
            E = np.eye(PCA_K) * H_Z
            lp = np.stack([lam0 + to_lam(e) for e in E]); lm = np.stack([lam0 - to_lam(e) for e in E])
            up, um = head_chunks(lp), head_chunks(lm)
            Dphi = ((st(up) - st(um)) / (2 * H_Z)).T                                  # (ps, 32)
            psp = np.array([qoi(run_chunk(cenv, sim_state, grip, c))[qi] for c in up])
            psm = np.array([qoi(run_chunk(cenv, sim_state, grip, c))[qi] for c in um])
            g_sim = (psp - psm) / (2 * H_Z)
            c = b_inc[q] + W_inc[q].T @ z0                       # non-empty-word part of lambda_psi (fixed at x)
            dirs = {"gamma_psi": a_inc[q] + W_inc[q] @ S0,       # d psi_hat(F_u0 x) / d lambda, u0 fixed
                    "Dphi^T lambda_psi": Dphi.T @ c,
                    "static": a_sta[q].copy(),
                    "sim-gradient": g_sim.copy()}
            for i in range(N_RANDOM):
                dirs[f"random{i}"] = rng.normal(size=PCA_K)
            cos_sim = {k_: float(v @ g_sim / (np.linalg.norm(v) * np.linalg.norm(g_sim) + 1e-300))
                       for k_, v in dirs.items() if not k_.startswith("random")}
            lam_norm = float(np.linalg.norm(lam0))
            for k_ in dirs:
                dirs[k_] = dirs[k_] / (np.linalg.norm(zs * dirs[k_]) + 1e-300) * STEP_REL * lam_norm
            pred = float(c @ Dphi @ dirs["Dphi^T lambda_psi"])   # probe-predicted slope (per unit tau)
            curves = {}
            base = qoi(run_chunk(cenv, sim_state, grip, u0))[qi]
            for k_, dz in dirs.items():
                lams_ = np.stack([lam0 + to_lam(t_ * dz) for t_ in TAUS if t_ != 0.0])
                vals = [qoi(run_chunk(cenv, sim_state, grip, c_))[qi] for c_ in head_chunks(lams_)]
                curve = np.insert(np.array(vals), TAUS.index(0.0), base) - Q0[g, qi]
                curves[k_] = curve
            row = dict(state=int(g), fold=fi, cos_sim=cos_sim, pred=pred,
                       **{f"J|{k_}": v for k_, v in curves.items()},
                       **{f"rho|{k_}": spearman(TAUS, v) for k_, v in curves.items()},
                       **{f"eff|{k_}": float(v[-1] - v[0]) for k_, v in curves.items()},
                       meas=float((curves["Dphi^T lambda_psi"][TAUS.index(2.0)] -
                                   curves["Dphi^T lambda_psi"][TAUS.index(-2.0)]) / 4.0))
            OUTR[qn].append(row)
            print(f"  state {g:4d} | " + " | ".join(
                f"{k_} rho {row['rho|' + k_]:+.2f} eff {1e3 * row['eff|' + k_]:+.1f}mm"
                for k_ in ["gamma_psi", "Dphi^T lambda_psi", "static", "sim-gradient"])
                  + " | random eff " + " ".join(f"{1e3 * row[f'eff|random{i}']:+.1f}" for i in range(N_RANDOM))
                  + f" | cos(., sim-grad) gamma {cos_sim['gamma_psi']:+.2f} Dphi {cos_sim['Dphi^T lambda_psi']:+.2f}"
                  + f" static {cos_sim['static']:+.2f}", flush=True)

header("6. SUMMARY  (held-out episodes, 2 folds; equal lambda displacement per tau; deterministic)")
NAMES = ["sim-gradient", "Dphi^T lambda_psi", "gamma_psi", "static"]
save = {}
for qn, rows in OUTR.items():
    if not rows:
        continue
    print(f"\n{qn} ({len(rows)} states)")
    print(f"  {'direction':18s} | monotone (rho>0.8) | effect tau -8..8 (mm) | beats all randoms | cos to sim-gradient")
    for nm in NAMES:
        rh = np.array([r["rho|" + nm] for r in rows]); ef = np.array([r["eff|" + nm] for r in rows])
        beat = np.array([r["eff|" + nm] > max(r[f"eff|random{i}"] for i in range(N_RANDOM)) for r in rows])
        cs = np.array([r["cos_sim"][nm] for r in rows])
        print(f"  {nm:18s} |       {np.mean(rh > 0.8):4.0%}         |      {1e3 * np.median(ef):+7.1f}         |"
              f"      {np.mean(beat):4.0%}        |      {np.median(cs):+.2f}")
        save[f"{qn}|{nm}|J"] = np.stack([r["J|" + nm] for r in rows])
    rh = np.array([r[f"rho|random{i}"] for r in rows for i in range(N_RANDOM)])
    ef = np.array([r[f"eff|random{i}"] for r in rows for i in range(N_RANDOM)])
    print(f"  {'random':18s} |       {np.mean(rh > 0.8):4.0%}         |      {1e3 * np.median(ef):+7.1f}         |        -         |       -")
    ratio = np.array([r["meas"] / (r["pred"] + 1e-12) for r in rows])
    print(f"  Dphi^T lambda_psi: measured slope / probe-predicted slope (median) {np.median(ratio):.2f}")
    save[f"{qn}|state"] = np.array([r["state"] for r in rows])
np.savez(OUT_ST, taus=np.array(TAUS), step_rel=STEP_REL, **save)
print("""
READING (paper notation)
=======
lambda(x)          action-head input of OpenVLA-OFT; the chunk is head(lambda), so steering = adding
                   a displacement to lambda and re-applying the head (no LLM pass needed).
gamma_psi          gradient of the probe's prediction w.r.t. lambda with the chunk held fixed
                   (increment part only): the probe direction, no policy information.
Dphi^T lambda_psi  the probe direction lambda_psi realized through the head's Jacobian D phi.
sim-gradient       simulator gradient of psi(F_{u(lambda)} x) w.r.t. lambda (oracle, no probe).
static             static probe direction L_psi^empty.
All directions move lambda by the same amount per tau; evaluation on held-out episodes.
""")
stamp(f"saved {OUT_ST}")
'''

with open("/content/run_oft_steer_ee_mug2.py", "w") as f:
    f.write(SCRIPT)
print("\nrunning steering in the Python 3.10 venv ...\n", flush=True)
p = subprocess.Popen([VPY, "-u", "/content/run_oft_steer_ee_mug2.py"], stdout=subprocess.PIPE,
                     stderr=subprocess.STDOUT, text=True,
                     env={**os.environ, "MUJOCO_GL": "egl",
                          "MPLBACKEND": "Agg",          # Colab sets a notebook-only backend
                          "TF_CPP_MIN_LOG_LEVEL": "2",  # silence TensorFlow start-up noise
                          "PYTHONPATH": f"{OFT}:{LIB}:" + os.environ.get("PYTHONPATH", "")})
for line in p.stdout:
    print(line, end="")
p.wait()
print(f"\nReturn code: {p.returncode}")
