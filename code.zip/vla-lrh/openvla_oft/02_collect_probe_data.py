# ======================================================================
# OpenVLA-OFT — STEP 2: probing data collection  (run as ONE Colab cell, A100, Drive mounted)
#
#   1. builds a separate Python 3.10 venv (/content/oftenv) with torch 2.2 (cu121),
#      openvla-oft (+ its transformers fork) and LIBERO
#   2. runs a verification script inside that venv:
#        - loads moojink/openvla-7b-oft-finetuned-libero-10
#        - closed-loop rollouts on the mug task (success check)
#        - captures lambda = action-token hidden states entering the L1 action head
#        - checks that the head applied to the captured lambda reproduces the action chunk
#
#   Nothing is written to Drive in this step. Re-running the cell skips finished installs.
# ======================================================================
import os, subprocess, sys, textwrap, time

VENV = "/content/oftenv"
VPY = f"{VENV}/bin/python"
OFT = "/content/openvla-oft"
LIB = "/content/LIBERO"
MARK = f"{VENV}/.setup_done"


def sh(cmd, check=True):
    print(f"$ {cmd}", flush=True)
    r = subprocess.run(cmd, shell=True, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    tail = "\n".join(r.stdout.strip().splitlines()[-15:])
    if tail:
        print(tail, flush=True)
    if check and r.returncode != 0:
        raise RuntimeError(f"failed ({r.returncode}): {cmd}")
    return r.returncode


# ---------------------------------------------------------------- 0. Drive (checked before any model loading)
if not os.path.isdir("/content/drive/MyDrive"):
    from google.colab import drive
    drive.mount("/content/drive")
os.makedirs("/content/drive/MyDrive/aclrh", exist_ok=True)

# ---------------------------------------------------------------- 0b. GPU check
assert subprocess.run(["nvidia-smi"], stdout=subprocess.DEVNULL).returncode == 0, \
    "No GPU visible: switch the runtime to GPU (A100) and reconnect."

# ---------------------------------------------------------------- 1. setup (once)
if not os.path.exists(MARK):
    t0 = time.time()
    sh("pip install -q uv")
    sh("uv python install 3.10")
    sh(f"rm -rf {VENV}")                                # a half-built venv without the marker: start clean
    sh(f"uv venv {VENV} --python 3.10 --seed")
    UV = f"uv pip install --python {VPY}"
    sh(f"{UV} torch==2.2.0 torchvision==0.17.0 --index-url https://download.pytorch.org/whl/cu121")
    sh(f"{UV} numpy==1.26.4")
    if not os.path.exists(OFT):
        sh(f"git clone -q https://github.com/moojink/openvla-oft.git {OFT}")
    sh(f"{UV} -e {OFT}")                                   # pulls the transformers fork and pinned deps
    if not os.path.exists(LIB):
        sh(f"git clone -q https://github.com/Lifelong-Robot-Learning/LIBERO.git {LIB}")
    sh(f"{UV} -e {LIB}")
    sh(f"{UV} -r {OFT}/experiments/robot/libero/libero_requirements.txt")
    sh(f"{UV} numpy==1.26.4")                             # re-pin in case a dependency upgraded it
    # flash-attn: prebuilt wheel for torch 2.2 / py3.10; if it fails the verification falls back to sdpa
    rc = sh(f"{UV} https://github.com/Dao-AILab/flash-attention/releases/download/v2.5.5/"
            "flash_attn-2.5.5+cu122torch2.2cxx11abiFALSE-cp310-cp310-linux_x86_64.whl", check=False)
    print("flash-attn installed" if rc == 0 else "flash-attn NOT installed -> sdpa fallback")
    # LIBERO asks interactively for its data paths on first import: write the config up front
    os.makedirs(os.path.expanduser("~/.libero"), exist_ok=True)
    base = f"{LIB}/libero/libero"
    with open(os.path.expanduser("~/.libero/config.yaml"), "w") as f:
        f.write(textwrap.dedent(f"""\
            benchmark_root: {base}
            bddl_files: {base}/bddl_files
            init_states: {base}/init_files
            datasets: {LIB}/datasets
            assets: {base}/assets
            """))
    open(MARK, "w").write("ok")
    print(f"setup finished in {(time.time() - t0) / 60:.1f} min")
else:
    print("setup already done")

# ---------------------------------------------------------------- 1b. dependency fixes (idempotent)
# tensorflow_datasets is imported by openvla-oft at import time; a too-new tensorflow-metadata needs
# protobuf 5 (google.protobuf.runtime_version), which TF 2.15 cannot use -> pin the TF-2.15-era version
if sh(f"{VPY} -c \"import tensorflow_datasets\"", check=False) != 0:
    sh(f"uv pip install --python {VPY} tensorflow-metadata==1.14.0")
    sh(f"{VPY} -c \"import tensorflow_datasets, google.protobuf as p; print('tfds OK | protobuf', p.__version__)\"")

# robosuite 1.4 predates the MuJoCo >= 3.2 joint-type API (get_joint_qpos_addr assertion) -> pin 3.1.6
_mj = subprocess.run([VPY, "-c", "import mujoco; print(mujoco.__version__)"], text=True,
                     stdout=subprocess.PIPE, stderr=subprocess.DEVNULL).stdout.strip()
print("mujoco in venv:", _mj or "not installed")
if not _mj.startswith("3.1."):
    sh(f"uv pip install --python {VPY} mujoco==3.1.6")
os.makedirs(f"{LIB}/datasets", exist_ok=True)          # silences LIBERO's missing-datasets warning

sh(f"{VPY} -c \"import torch, transformers, numpy; print('torch', torch.__version__, 'cuda', "
   f"torch.cuda.is_available(), '| transformers', transformers.__version__, '| numpy', numpy.__version__)\"")

# ---------------------------------------------------------------- 2. verification script (runs in the venv)
SCRIPT = r'''
import os, sys, time, traceback
os.environ.setdefault("MUJOCO_GL", "egl")
os.environ.setdefault("PYOPENGL_PLATFORM", "egl")
os.environ["MPLBACKEND"] = "Agg"
sys.path.insert(0, "/content/openvla-oft")
sys.path.insert(0, "/content/LIBERO")          # LIBERO's setup.py is not exposed by uv editable installs
import numpy as np
import torch

CKPT = "moojink/openvla-7b-oft-finetuned-libero-10"
UNNORM = "libero_10_no_noops"
TASK_KEYWORDS = ("white mug", "left plate", "yellow and white mug", "right plate")
MAX_STEPS = 520
NUM_WAIT = 10

def header(t):
    print("\n" + "=" * 90 + f"\n{t}\n" + "=" * 90, flush=True)

header("1. IMPORTS")
# wandb is only used for evaluation logging; the installed wandb needs a newer protobuf than
# TF 2.15 allows, so register a no-op stand-in instead of touching protobuf again
import types, importlib.machinery
_wb = types.ModuleType("wandb")
_wb.__spec__ = importlib.machinery.ModuleSpec("wandb", None)   # find_spec() (accelerate/transformers) needs a spec
_wb.__version__ = "0.0.0"
for _name in ("init", "log", "finish", "login", "config", "save", "watch"):
    setattr(_wb, _name, lambda *a, **k: None)
_wb.run = None
sys.modules["wandb"] = _wb
from experiments.robot.libero.run_libero_eval import GenerateConfig
import experiments.robot.libero.run_libero_eval as rle
import experiments.robot.openvla_utils as ou
import experiments.robot.libero.libero_utils as lu
import experiments.robot.robot_utils as ru
from libero.libero import benchmark
print("run_libero_eval exports:", [n for n in dir(rle) if not n.startswith("_")][:60])

try:
    import flash_attn  # noqa
    ATTN = "flash_attention_2"
except Exception:
    ATTN = "sdpa"
print("attention implementation:", ATTN)

header("2. LOAD OPENVLA-OFT (LIBERO-10)")
cfg = GenerateConfig(
    pretrained_checkpoint=CKPT, use_l1_regression=True, use_diffusion=False, use_film=False,
    num_images_in_input=2, use_proprio=True, load_in_8bit=False, load_in_4bit=False,
    center_crop=True, num_open_loop_steps=8, unnorm_key=UNNORM,
)
if hasattr(cfg, "task_suite_name"):
    cfg.task_suite_name = "libero_10"
if hasattr(cfg, "model_family"):
    cfg.model_family = "openvla"
t0 = time.time()
if ATTN != "flash_attention_2":
    # route the loader to sdpa if flash-attn is missing
    from transformers import AutoModelForVision2Seq
    _orig_fp = AutoModelForVision2Seq.from_pretrained
    def _fp(*a, **kw):
        kw["attn_implementation"] = "sdpa"
        return _orig_fp(*a, **kw)
    AutoModelForVision2Seq.from_pretrained = _fp
vla = ou.get_vla(cfg)
processor = ou.get_processor(cfg)
action_head = ou.get_action_head(cfg, llm_dim=vla.llm_dim)
proprio_projector = ou.get_proprio_projector(cfg, llm_dim=vla.llm_dim, proprio_dim=8)
print(f"loaded in {time.time() - t0:.0f}s | llm_dim {vla.llm_dim} | unnorm keys: {list(getattr(vla, 'norm_stats', {}).keys())[:8]}")

# ---- lambda hook: capture (and later intervene on) the input of the L1 action head ----
LAM = {"cap": None, "delta": None}
_orig_predict = action_head.predict_action
def _predict(actions_hidden_states, *a, **kw):
    LAM["cap"] = actions_hidden_states.detach().float().cpu()
    if LAM["delta"] is not None:
        actions_hidden_states = actions_hidden_states + LAM["delta"].to(actions_hidden_states.device,
                                                                          actions_hidden_states.dtype)
    return _orig_predict(actions_hidden_states, *a, **kw)
action_head.predict_action = _predict

def policy_chunk(obs, task_label):
    observation, _ = rle.prepare_observation(obs, ru.get_image_resize_size(cfg)) \
        if hasattr(rle, "prepare_observation") else (None, None)
    actions = ou.get_vla_action(cfg, vla, processor, observation, task_label, action_head, proprio_projector)
    return np.asarray(actions)


# ======================================================================
# STEP 2: PROBING DATA  (all 50 layouts; lambda + positions at snapshots; candidate chunks)
# ======================================================================
OUT = "/content/drive/MyDrive/aclrh/oft_probe.npz"
N_EPISODES = 50
SNAP_EVERY_CALLS = 2          # snapshot every 2nd policy call = every 16 control steps
MAX_SNAPS_PER_EP = 30
CAND_EVERY = 2                # candidate chunks at every 2nd snapshot
K_PERT = 31                   # + the policy chunk itself = 32 candidates
H = 8                         # OFT chunk length (one chunk = 8 control steps)
N_KNOTS = 4                   # smooth perturbation: piecewise-linear through 4 Gaussian knots
PERT_FRAC = 0.3               # knot std as a fraction of the per-dim half range (q01..q99)
SEED = 0
assert os.path.isdir("/content/drive/MyDrive"), "mount Drive first: from google.colab import drive; drive.mount('/content/drive')"

header("3. TASK AND ENVIRONMENTS")
suite = benchmark.get_benchmark_dict()["libero_10"]()
tid = next(i for i in range(suite.n_tasks) if all(k in suite.get_task(i).language for k in TASK_KEYWORDS))
task = suite.get_task(tid)
init_states = suite.get_task_init_states(tid)
env, task_description = lu.get_libero_env(task, "openvla", resolution=256)
try:
    from libero.libero.envs import ControlEnv
except ImportError:
    from libero.libero.envs.env_wrapper import ControlEnv   # not re-exported in this LIBERO version
from libero.libero import get_libero_path
bddl = os.path.join(get_libero_path("bddl_files"), task.problem_folder, task.bddl_file)
cenv = ControlEnv(bddl_file_name=bddl, has_renderer=False, has_offscreen_renderer=False,
                  use_camera_obs=False, camera_heights=128, camera_widths=128)   # renderer-free twin
cenv.seed(0)
cenv.reset()
inner = env.env
print(f"task {tid}: {task_description} | init states {len(init_states)}")
print("objects:", list(inner.obj_body_id.keys()))

MUGS_PLATES = ["porcelain_mug_1", "white_yellow_mug_1", "plate_1", "plate_2"]
QOI_NAMES = ["ee_x", "ee_y", "ee_z"] + [f"{o}_{c}" for o in MUGS_PLATES for c in "xyz"]

def positions(e):
    s = e.env
    out = [np.array(s.sim.data.site_xpos[s.robots[0].eef_site_id])]
    out += [np.array(s.sim.data.body_xpos[s.obj_body_id[o]]) for o in MUGS_PLATES]
    return np.concatenate(out)

def grip_state(e):
    g = getattr(e.env.robots[0].gripper, "current_action", None)
    return None if g is None else np.array(g, dtype=np.float64).copy()

def restore(e, sim_state, grip):
    e.env.timestep, e.env.done = 0, False       # the twin env replays many chunks: never hit the horizon
    e.set_init_state(sim_state)
    if grip is not None and hasattr(e.env.robots[0].gripper, "current_action"):
        e.env.robots[0].gripper.current_action = grip.copy()

def run_chunk(e, sim_state, grip, actions):
    restore(e, sim_state, grip)
    for a in actions:
        e.step(np.asarray(a, dtype=np.float64).tolist())
    return positions(e)

# per-dimension scale for perturbations, from the checkpoint's action statistics (raw action space)
try:
    st_ = vla.norm_stats[UNNORM]["action"]
    half = (np.asarray(st_["q99"]) - np.asarray(st_["q01"])) / 2.0
except Exception as ex:
    print("[warn] norm stats unavailable, using 0.5:", repr(ex)); half = np.full(7, 0.5)
print("perturbation std per arm dim:", np.round(PERT_FRAC * half[:6], 4))
rng = np.random.default_rng(SEED)

def perturb(chunk, k):
    """k smooth perturbations of the raw policy chunk on the 6 arm dims; gripper unchanged"""
    tk = np.linspace(0, H - 1, N_KNOTS)
    out = np.repeat(chunk[None], k, 0).astype(np.float64)
    for i in range(k):
        knots = rng.normal(size=(N_KNOTS, 6)) * PERT_FRAC * half[:6]
        out[i, :, :6] += np.stack([np.interp(np.arange(H), tk, knots[:, j]) for j in range(6)], 1)
    return out

def executed(raw_chunk):
    return np.stack([np.asarray(rle.process_action(a.copy(), "openvla"), dtype=np.float64) for a in raw_chunk])

# ---------------- per-episode shards (resume = skip finished episodes) ----------------
SHARDS = "/content/drive/MyDrive/aclrh/oft_probe_shards"
os.makedirs(SHARDS, exist_ok=True)
shard = lambda ep: f"{SHARDS}/ep{ep:02d}.npz"
done_eps = {ep for ep in range(N_EPISODES) if os.path.exists(shard(ep))}
if done_eps:
    print(f"resuming: {len(done_eps)} episodes already collected")

header("4. COLLECTION")
checked, T0 = False, time.time()
for ep in range(N_EPISODES):
    if ep in done_eps:
        continue
    B = {k: [] for k in ["LAM", "Q0", "TS", "SIM", "GRIP", "C_LOCAL", "U_RAW", "U_EXEC", "QF"]}
    env.reset()
    obs = env.set_init_state(init_states[ep])
    t, calls, nsnap, queue, success, pending = 0, 0, 0, [], False, None
    while t < MAX_STEPS + NUM_WAIT:
        if t < NUM_WAIT:
            obs, _, done, _ = env.step(lu.get_libero_dummy_action("openvla")); t += 1
            continue
        if not queue:
            sim_state, grip = env.get_sim_state().copy(), grip_state(env)
            raw = np.asarray(ou.get_vla_action(cfg, vla, processor,
                                               rle.prepare_observation(obs, ru.get_image_resize_size(cfg))[0],
                                               task_description, action_head, proprio_projector), dtype=np.float64)
            if calls % SNAP_EVERY_CALLS == 0 and nsnap < MAX_SNAPS_PER_EP:
                B["LAM"].append(LAM["cap"][0].numpy().astype(np.float16).reshape(-1))
                B["Q0"].append(positions(env)); B["TS"].append(t); B["SIM"].append(sim_state)
                B["GRIP"].append(np.zeros(2) if grip is None else grip)
                if nsnap % CAND_EVERY == 0:
                    cands_raw = np.concatenate([raw[None], perturb(raw, K_PERT)], 0)       # (32, 8, 7)
                    cands_exec = np.stack([executed(c) for c in cands_raw])
                    qf = np.stack([run_chunk(cenv, sim_state, grip, c) for c in cands_exec])
                    B["C_LOCAL"].append(len(B["LAM"]) - 1); B["U_RAW"].append(cands_raw.astype(np.float32))
                    B["U_EXEC"].append(cands_exec.astype(np.float32)); B["QF"].append(qf)
                    pending = qf[0]
                nsnap += 1
            calls += 1
            queue = list(executed(raw))
        obs, _, done, _ = env.step(queue.pop(0).tolist())
        t += 1
        if pending is not None and not queue:          # the policy chunk just finished in the main env
            diff = float(np.abs(positions(env) - pending).max())
            if not checked or diff > 1e-5:
                print(f"  [check] main env vs renderer-free replay of the policy chunk: max|diff| {diff:.2e}")
                checked = True
            pending = None
        if done:
            success = True
            break
    np.savez(shard(ep), **{k: np.stack(v) for k, v in B.items()}, SUCCESS=np.array(success), EP=np.array(ep))
    print(f"[{time.time() - T0:7.0f}s] episode {ep:2d} | success {success} | steps {t} | "
          f"snapshots {len(B['LAM'])} | candidate states {len(B['C_LOCAL'])}", flush=True)

# ---------------- merge shards ----------------
M = {k: [] for k in ["LAM", "Q0", "EP", "TS", "SIM", "GRIP", "C_STATE", "U_RAW", "U_EXEC", "QF"]}
succ = []
for ep in range(N_EPISODES):
    z = np.load(shard(ep))
    off = len(M["EP"])
    n = len(z["LAM"])
    for k in ["LAM", "Q0", "TS", "SIM", "GRIP", "U_RAW", "U_EXEC", "QF"]:
        M[k] += list(z[k])
    M["EP"] += [ep] * n
    M["C_STATE"] += list(z["C_LOCAL"] + off)
    succ.append(bool(z["SUCCESS"]))
np.savez(OUT, **{k: np.stack(v) for k, v in M.items()}, SUCCESS_EP=np.array(succ),
         QOI_NAMES=np.array(QOI_NAMES), TASK=np.array(task_description))
header("5. SUMMARY")
print(f"episodes {len(succ)} | success {sum(succ)}/{len(succ)}")
print(f"states {len(M['EP'])} | candidate states {len(M['C_STATE'])} x {K_PERT + 1} chunks of {H} steps")
print(f"lambda dim {M['LAM'][0].size} (float16) | saved {OUT}")
'''

with open("/content/run_oft_collect.py", "w") as f:
    f.write(SCRIPT)
print("\nrunning collection in the Python 3.10 venv ...\n", flush=True)
p = subprocess.Popen([VPY, "-u", "/content/run_oft_collect.py"], stdout=subprocess.PIPE,
                     stderr=subprocess.STDOUT, text=True,
                     env={**os.environ, "MUJOCO_GL": "egl",
                          "MPLBACKEND": "Agg",          # Colab sets a notebook-only backend
                          "TF_CPP_MIN_LOG_LEVEL": "2",  # silence TensorFlow start-up noise
                          "PYTHONPATH": f"{OFT}:{LIB}:" + os.environ.get("PYTHONPATH", "")})
for line in p.stdout:
    print(line, end="")
p.wait()
print(f"\nReturn code: {p.returncode}")
