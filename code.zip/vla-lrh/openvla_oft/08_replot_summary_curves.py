# Re-draw the steering summary curves J(alpha) - J(0) from the saved steering results.
# Plain Colab Python (no model, no simulator). Needs Drive mounted.
import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = "/content/drive/MyDrive/aclrh"
FIG = f"{ROOT}/figs"
os.makedirs(FIG, exist_ok=True)
FILES = [(f"{ROOT}/oft_steering.npz", ["EE z (control)", "mug1 z", "mug2 z"]),
         (f"{ROOT}/oft_steering_taskqoi.npz", ["-d(mug1,plate) xy", "-d(mug2,plate) xy", "-d(EE,mug1)"]),
         (f"{ROOT}/oft_steering_ee_mug2.npz", ["-d(EE,mug2)"])]
TITLES = {"EE z (control)": r"EE $p_z$ (control)", "mug1 z": r"mug$_1$ $p_z$", "mug2 z": r"mug$_2$ $p_z$",
          "-d(mug1,plate) xy": r"$-d$(mug$_1$, plate)", "-d(mug2,plate) xy": r"$-d$(mug$_2$, plate)",
          "-d(EE,mug1)": r"$-d$(EE, mug$_1$)", "-d(EE,mug2)": r"$-d$(EE, mug$_2$)"}
DIRS = [("sim-gradient", "gray", "--", "simulator gradient"),
        ("Dphi^T lambda_psi", "C3", "-", r"$\lambda_\psi$ (ours)"),
        ("gamma_psi", "C0", "-", r"$\gamma_\psi$"),
        ("static", "k", "-", "static")]

panels = [(f, qn) for f, qs in FILES if os.path.exists(f) for qn in qs]
missing = [f for f, _ in FILES if not os.path.exists(f)]
if missing:
    print("missing (skipped):", missing)
ncol = 4 if len(panels) > 6 else 3
nrow = int(np.ceil(len(panels) / ncol))
fig, axes = plt.subplots(nrow, ncol, figsize=(4.2 * ncol, 3.4 * nrow))
axes = np.atleast_1d(axes).ravel()
for ax, (f, qn) in zip(axes, panels):
    R = np.load(f)
    taus = R["taus"]
    i0 = list(taus).index(0.0)
    for key, col, ls, lab in DIRS:
        k = f"{qn}|{key}|J"
        if k not in R.files:
            continue
        J = 1e3 * R[k]
        J = J - J[:, [i0]]                                  # per state: relative to alpha = 0
        med, lo, hi = np.median(J, 0), np.percentile(J, 25, 0), np.percentile(J, 75, 0)
        ax.plot(taus, med, ls, color=col, lw=2, label=lab)
        ax.fill_between(taus, lo, hi, color=col, alpha=0.15, lw=0)
    ax.axhline(0, color="0.8", lw=0.8, zorder=0)
    ax.set_title(TITLES.get(qn, qn), fontsize=11)
    ax.set_xlabel(r"$\alpha$")
    ax.grid(alpha=0.3)
for ax in axes[::ncol]:
    ax.set_ylabel(r"$J(\alpha)-J(0)$ (mm)")
for ax in axes[len(panels):]:
    ax.set_axis_off()
h, l = axes[0].get_legend_handles_labels()
if len(panels) < len(axes):                               # legend in the empty slot
    axes[len(panels)].legend(h, l, loc="center", fontsize=10, frameon=False)
else:
    fig.legend(h, l, loc="lower center", ncol=len(DIRS), frameon=False)
plt.tight_layout()
out = f"{FIG}/A_summary_curves.png"
plt.savefig(out, dpi=170, bbox_inches="tight")
print("saved", out, f"({len(panels)} QoIs)")
