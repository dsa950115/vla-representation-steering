# ======================================================================
# OpenVLA-OFT — STEP 6: steering figures (one-chunk paths + closed-loop concept steering)  (ONE Colab cell, A100)
#
#   1. builds a separate Python 3.10 venv (/content/oftenv) with torch 2.2 (cu121),
#      openvla-oft (+ its transformers fork) and LIBERO
#   2. runs a verification script inside that venv:
#        - loads moojink/openvla-7b-oft-finetuned-libero-10
#        - closed-loop rollouts on the mug task (success check)
#        - captures lambda = action-token hidden states entering the L1 action head
#        - checks that the head applied to the captured lambda reproduces the action chunk
#
#   Nothing is written to Drive in this step. Re-running the cell skips finished installs.
# ======================================================================
import os, subprocess, sys, textwrap, time

VENV = "/content/oftenv"
VPY = f"{VENV}/bin/python"
OFT = "/content/openvla-oft"
LIB = "/content/LIBERO"
MARK = f"{VENV}/.setup_done"


def sh(cmd, check=True):
    print(f"$ {cmd}", flush=True)
    r = subprocess.run(cmd, shell=True, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    tail = "\n".join(r.stdout.strip().splitlines()[-15:])
    if tail:
        print(tail, flush=True)
    if check and r.returncode != 0:
        raise RuntimeError(f"failed ({r.returncode}): {cmd}")
    return r.returncode


# ---------------------------------------------------------------- 0. Drive (checked before any model loading)
if not os.path.isdir("/content/drive/MyDrive"):
    from google.colab import drive
    drive.mount("/content/drive")
os.makedirs("/content/drive/MyDrive/aclrh", exist_ok=True)

# ---------------------------------------------------------------- 0b. GPU check
assert subprocess.run(["nvidia-smi"], stdout=subprocess.DEVNULL).returncode == 0, \
    "No GPU visible: switch the runtime to GPU (A100) and reconnect."

# ---------------------------------------------------------------- 1. setup (once)
if not os.path.exists(MARK):
    t0 = time.time()
    sh("pip install -q uv")
    sh("uv python install 3.10")
    sh(f"rm -rf {VENV}")                                # a half-built venv without the marker: start clean
    sh(f"uv venv {VENV} --python 3.10 --seed")
    UV = f"uv pip install --python {VPY}"
    sh(f"{UV} torch==2.2.0 torchvision==0.17.0 --index-url https://download.pytorch.org/whl/cu121")
    sh(f"{UV} numpy==1.26.4")
    if not os.path.exists(OFT):
        sh(f"git clone -q https://github.com/moojink/openvla-oft.git {OFT}")
    sh(f"{UV} -e {OFT}")                                   # pulls the transformers fork and pinned deps
    if not os.path.exists(LIB):
        sh(f"git clone -q https://github.com/Lifelong-Robot-Learning/LIBERO.git {LIB}")
    sh(f"{UV} -e {LIB}")
    sh(f"{UV} -r {OFT}/experiments/robot/libero/libero_requirements.txt")
    sh(f"{UV} numpy==1.26.4")                             # re-pin in case a dependency upgraded it
    # flash-attn: prebuilt wheel for torch 2.2 / py3.10; if it fails the verification falls back to sdpa
    rc = sh(f"{UV} https://github.com/Dao-AILab/flash-attention/releases/download/v2.5.5/"
            "flash_attn-2.5.5+cu122torch2.2cxx11abiFALSE-cp310-cp310-linux_x86_64.whl", check=False)
    print("flash-attn installed" if rc == 0 else "flash-attn NOT installed -> sdpa fallback")
    # LIBERO asks interactively for its data paths on first import: write the config up front
    os.makedirs(os.path.expanduser("~/.libero"), exist_ok=True)
    base = f"{LIB}/libero/libero"
    with open(os.path.expanduser("~/.libero/config.yaml"), "w") as f:
        f.write(textwrap.dedent(f"""\
            benchmark_root: {base}
            bddl_files: {base}/bddl_files
            init_states: {base}/init_files
            datasets: {LIB}/datasets
            assets: {base}/assets
            """))
    open(MARK, "w").write("ok")
    print(f"setup finished in {(time.time() - t0) / 60:.1f} min")
else:
    print("setup already done")

# ---------------------------------------------------------------- 1b. dependency fixes (idempotent)
# tensorflow_datasets is imported by openvla-oft at import time; a too-new tensorflow-metadata needs
# protobuf 5 (google.protobuf.runtime_version), which TF 2.15 cannot use -> pin the TF-2.15-era version
if sh(f"{VPY} -c \"import tensorflow_datasets\"", check=False) != 0:
    sh(f"uv pip install --python {VPY} tensorflow-metadata==1.14.0")
    sh(f"{VPY} -c \"import tensorflow_datasets, google.protobuf as p; print('tfds OK | protobuf', p.__version__)\"")

# robosuite 1.4 predates the MuJoCo >= 3.2 joint-type API (get_joint_qpos_addr assertion) -> pin 3.1.6
_mj = subprocess.run([VPY, "-c", "import mujoco; print(mujoco.__version__)"], text=True,
                     stdout=subprocess.PIPE, stderr=subprocess.DEVNULL).stdout.strip()
print("mujoco in venv:", _mj or "not installed")
if not _mj.startswith("3.1."):
    sh(f"uv pip install --python {VPY} mujoco==3.1.6")
os.makedirs(f"{LIB}/datasets", exist_ok=True)          # silences LIBERO's missing-datasets warning

sh(f"{VPY} -c \"import torch, transformers, numpy; print('torch', torch.__version__, 'cuda', "
   f"torch.cuda.is_available(), '| transformers', transformers.__version__, '| numpy', numpy.__version__)\"")

# ---------------------------------------------------------------- 2. verification script (runs in the venv)
SCRIPT = r'''
import os, sys, time, traceback
os.environ.setdefault("MUJOCO_GL", "egl")
os.environ.setdefault("PYOPENGL_PLATFORM", "egl")
os.environ["MPLBACKEND"] = "Agg"
sys.path.insert(0, "/content/openvla-oft")
sys.path.insert(0, "/content/LIBERO")          # LIBERO's setup.py is not exposed by uv editable installs
import numpy as np
import torch

CKPT = "moojink/openvla-7b-oft-finetuned-libero-10"
UNNORM = "libero_10_no_noops"
TASK_KEYWORDS = ("white mug", "left plate", "yellow and white mug", "right plate")
MAX_STEPS = 520
NUM_WAIT = 10

T0 = time.time()

def stamp(m):
    print(f"[{time.time() - T0:7.1f}s] {m}", flush=True)


def header(t):
    print("\n" + "=" * 90 + f"\n{t}\n" + "=" * 90, flush=True)

header("1. IMPORTS")
# wandb is only used for evaluation logging; the installed wandb needs a newer protobuf than
# TF 2.15 allows, so register a no-op stand-in instead of touching protobuf again
import types, importlib.machinery
_wb = types.ModuleType("wandb")
_wb.__spec__ = importlib.machinery.ModuleSpec("wandb", None)   # find_spec() (accelerate/transformers) needs a spec
_wb.__version__ = "0.0.0"
for _name in ("init", "log", "finish", "login", "config", "save", "watch"):
    setattr(_wb, _name, lambda *a, **k: None)
_wb.run = None
sys.modules["wandb"] = _wb
from experiments.robot.libero.run_libero_eval import GenerateConfig
import experiments.robot.libero.run_libero_eval as rle
import experiments.robot.openvla_utils as ou
import experiments.robot.libero.libero_utils as lu
import experiments.robot.robot_utils as ru
from libero.libero import benchmark
print("run_libero_eval exports:", [n for n in dir(rle) if not n.startswith("_")][:60])

try:
    import flash_attn  # noqa
    ATTN = "flash_attention_2"
except Exception:
    ATTN = "sdpa"
print("attention implementation:", ATTN)

header("2. LOAD OPENVLA-OFT (LIBERO-10)")
cfg = GenerateConfig(
    pretrained_checkpoint=CKPT, use_l1_regression=True, use_diffusion=False, use_film=False,
    num_images_in_input=2, use_proprio=True, load_in_8bit=False, load_in_4bit=False,
    center_crop=True, num_open_loop_steps=8, unnorm_key=UNNORM,
)
if hasattr(cfg, "task_suite_name"):
    cfg.task_suite_name = "libero_10"
if hasattr(cfg, "model_family"):
    cfg.model_family = "openvla"
t0 = time.time()
if ATTN != "flash_attention_2":
    # route the loader to sdpa if flash-attn is missing
    from transformers import AutoModelForVision2Seq
    _orig_fp = AutoModelForVision2Seq.from_pretrained
    def _fp(*a, **kw):
        kw["attn_implementation"] = "sdpa"
        return _orig_fp(*a, **kw)
    AutoModelForVision2Seq.from_pretrained = _fp
vla = ou.get_vla(cfg)
processor = ou.get_processor(cfg)
action_head = ou.get_action_head(cfg, llm_dim=vla.llm_dim)
proprio_projector = ou.get_proprio_projector(cfg, llm_dim=vla.llm_dim, proprio_dim=8)
print(f"loaded in {time.time() - t0:.0f}s | llm_dim {vla.llm_dim} | unnorm keys: {list(getattr(vla, 'norm_stats', {}).keys())[:8]}")

# ---- lambda hook: capture (and later intervene on) the input of the L1 action head ----
LAM = {"cap": None, "delta": None}
_orig_predict = action_head.predict_action
def _predict(actions_hidden_states, *a, **kw):
    LAM["cap"] = actions_hidden_states.detach().float().cpu()
    if LAM["delta"] is not None:
        actions_hidden_states = actions_hidden_states + LAM["delta"].to(actions_hidden_states.device,
                                                                          actions_hidden_states.dtype)
    return _orig_predict(actions_hidden_states, *a, **kw)
action_head.predict_action = _predict

def policy_chunk(obs, task_label):
    observation, _ = rle.prepare_observation(obs, ru.get_image_resize_size(cfg)) \
        if hasattr(rle, "prepare_observation") else (None, None)
    actions = ou.get_vla_action(cfg, vla, processor, observation, task_label, action_head, proprio_projector)
    return np.asarray(actions)


# constants used by the helpers shared with step 2 (perturb is not used for steering)
H = 8
N_KNOTS = 4
PERT_FRAC = 0.3
SEED = 0

header("3. TASK AND ENVIRONMENTS")
suite = benchmark.get_benchmark_dict()["libero_10"]()
tid = next(i for i in range(suite.n_tasks) if all(k in suite.get_task(i).language for k in TASK_KEYWORDS))
task = suite.get_task(tid)
init_states = suite.get_task_init_states(tid)
env, task_description = lu.get_libero_env(task, "openvla", resolution=256)
try:
    from libero.libero.envs import ControlEnv
except ImportError:
    from libero.libero.envs.env_wrapper import ControlEnv   # not re-exported in this LIBERO version
from libero.libero import get_libero_path
bddl = os.path.join(get_libero_path("bddl_files"), task.problem_folder, task.bddl_file)
cenv = ControlEnv(bddl_file_name=bddl, has_renderer=False, has_offscreen_renderer=False,
                  use_camera_obs=False, camera_heights=128, camera_widths=128)   # renderer-free twin
cenv.seed(0)
cenv.reset()
inner = env.env
print(f"task {tid}: {task_description} | init states {len(init_states)}")
print("objects:", list(inner.obj_body_id.keys()))

MUGS_PLATES = ["porcelain_mug_1", "white_yellow_mug_1", "plate_1", "plate_2"]
QOI_NAMES = ["ee_x", "ee_y", "ee_z"] + [f"{o}_{c}" for o in MUGS_PLATES for c in "xyz"]

def positions(e):
    s = e.env
    out = [np.array(s.sim.data.site_xpos[s.robots[0].eef_site_id])]
    out += [np.array(s.sim.data.body_xpos[s.obj_body_id[o]]) for o in MUGS_PLATES]
    return np.concatenate(out)

def grip_state(e):
    g = getattr(e.env.robots[0].gripper, "current_action", None)
    return None if g is None else np.array(g, dtype=np.float64).copy()

def restore(e, sim_state, grip):
    e.env.timestep, e.env.done = 0, False       # the twin env replays many chunks: never hit the horizon
    e.set_init_state(sim_state)
    if grip is not None and hasattr(e.env.robots[0].gripper, "current_action"):
        e.env.robots[0].gripper.current_action = grip.copy()

def run_chunk(e, sim_state, grip, actions):
    restore(e, sim_state, grip)
    for a in actions:
        e.step(np.asarray(a, dtype=np.float64).tolist())
    return positions(e)

# per-dimension scale for perturbations, from the checkpoint's action statistics (raw action space)
try:
    st_ = vla.norm_stats[UNNORM]["action"]
    half = (np.asarray(st_["q99"]) - np.asarray(st_["q01"])) / 2.0
except Exception as ex:
    print("[warn] norm stats unavailable, using 0.5:", repr(ex)); half = np.full(7, 0.5)
print("perturbation std per arm dim:", np.round(PERT_FRAC * half[:6], 4))
rng = np.random.default_rng(SEED)

def perturb(chunk, k):
    """k smooth perturbations of the raw policy chunk on the 6 arm dims; gripper unchanged"""
    tk = np.linspace(0, H - 1, N_KNOTS)
    out = np.repeat(chunk[None], k, 0).astype(np.float64)
    for i in range(k):
        knots = rng.normal(size=(N_KNOTS, 6)) * PERT_FRAC * half[:6]
        out[i, :, :6] += np.stack([np.interp(np.arange(H), tk, knots[:, j]) for j in range(6)], 1)
    return out

def executed(raw_chunk):
    return np.stack([np.asarray(rle.process_action(a.copy(), "openvla"), dtype=np.float64) for a in raw_chunk])


# ======================================================================
# STEP 4: STEERING  lambda_alpha = lambda(x) + alpha d(x), chunk = head(lambda_alpha)  (deterministic)
# ======================================================================
def sig_levels(U):
    """time-augmented signature, dX = (dt, u dt): returns S1, S<=2, S<=3."""
    U = np.asarray(U, dtype=np.float64)
    N, H, A = U.shape
    dt = 1.0 / H
    dx = np.concatenate([np.full((N, H, 1), dt), U * dt], axis=2)
    prev1 = np.cumsum(dx, axis=1) - dx
    inc2 = np.einsum("nti,ntj->ntij", prev1, dx) + 0.5 * np.einsum("nti,ntj->ntij", dx, dx)
    prev2 = np.cumsum(inc2, axis=1) - inc2
    S1 = dx.sum(axis=1)
    S2 = inc2.sum(axis=1)
    S3 = (np.einsum("ntij,ntk->nijk", prev2, dx, optimize=True)
          + 0.5 * np.einsum("nti,ntj,ntk->nijk", prev1, dx, dx, optimize=True)
          + np.einsum("nti,ntj,ntk->nijk", dx, dx, dx, optimize=True) / 6.0)
    M2 = np.concatenate([S1, S2.reshape(N, -1)], axis=1)
    return {"S1": S1, "S<=2": M2, "S<=3": np.concatenate([M2, S3.reshape(N, -1)], axis=1)}


DATA = "/content/drive/MyDrive/aclrh/oft_probe.npz"
OUT_ST = None

# ---- task QoIs derived from the 15 stored positions: ee(0:3) mug1(3:6) mug2(6:9) plate_1(9:12) plate_2(12:15)
def target_plates(Q0, EP, success_ep):
    """plate each mug ends on in successful episodes (last snapshot), by horizontal distance"""
    last = [np.where(EP == e)[0][-1] for e in np.unique(EP) if success_ep[int(e)]]
    P = Q0[last]
    out = []
    for m in (3, 6):
        d1 = np.linalg.norm(P[:, m:m + 2] - P[:, 9:11], axis=1)
        d2 = np.linalg.norm(P[:, m:m + 2] - P[:, 12:14], axis=1)
        out.append(9 if np.mean(d1 < d2) >= 0.5 else 12)
        print(f"  mug at cols {m}:{m + 3}: nearer to plate_1 in {np.mean(d1 < d2):.0%} of successful end states "
              f"-> target plate_{1 if out[-1] == 9 else 2}")
    return out

def make_qoi(t1, t2):
    def qoi(P):
        """P (..., 15) -> (..., 3): psi to INCREASE (negative distances)"""
        return np.stack([-np.linalg.norm(P[..., 3:5] - P[..., t1:t1 + 2], axis=-1),
                         -np.linalg.norm(P[..., 6:8] - P[..., t2:t2 + 2], axis=-1),
                         -np.linalg.norm(P[..., 0:3] - P[..., 3:6], axis=-1),
                         -np.linalg.norm(P[..., 0:3] - P[..., 6:9], axis=-1)], axis=-1)
    return qoi

QOI_LIST = ["-d(mug1,plate) xy", "-d(mug2,plate) xy", "-d(EE,mug1)", "-d(EE,mug2)"]
PCA_K = 32
N_PER_FOLD = 10               # steered states per QoI and fold (2 folds)
MOVE_MM, MIN_FRAC = 2e-3, 0.5
H_Z = 0.25                    # finite-difference step (standardized PCA units) for D phi and the simulator gradient
STEP_REL = 0.005              # ||delta lambda|| / ||lambda|| per unit tau, identical for all directions
TAUS = [-8.0, -4.0, -2.0, 0.0, 2.0, 4.0, 8.0]
N_RANDOM = 3
ALPHAS_R = np.logspace(-3, 4, 15)

def ranks(v):
    v = np.asarray(v, float)
    r = np.empty(len(v)); r[np.argsort(v, kind="mergesort")] = np.arange(len(v), dtype=float)
    for val in np.unique(v):                     # average ranks for ties
        m = v == val
        r[m] = r[m].mean()
    return r

def spearman(x, y):
    y = np.asarray(y, float)
    if np.ptp(y) < 1e-12:                         # a flat response is not monotone
        return 0.0
    return float(np.corrcoef(ranks(x), ranks(y))[0, 1])

def ridge_fit(Xtr, Ytr, Xva, Yva):
    """primal ridge with standardized columns; penalty per target chosen on validation rows; refit on all"""
    def fit(X, Y, a_):
        mx, sx, my = X.mean(0), X.std(0) + 1e-12, Y.mean(0)
        Xs = (X - mx) / sx
        G = Xs.T @ Xs
        W = np.linalg.solve(G + a_ * len(X) * np.eye(G.shape[0]), Xs.T @ (Y - my))
        return W / sx[:, None], my - (mx / sx) @ W
    best = []
    for j in range(Ytr.shape[1]):
        errs = []
        for a_ in ALPHAS_R:
            W, b = fit(Xtr, Ytr[:, j:j + 1], a_)
            errs.append(np.mean((Xva @ W + b - Yva[:, j:j + 1]) ** 2))
        best.append(ALPHAS_R[int(np.argmin(errs))])
    X, Y = np.r_[Xtr, Xva], np.r_[Ytr, Yva]
    Ws, bs = zip(*[fit(X, Y[:, j:j + 1], best[j]) for j in range(Y.shape[1])])
    return np.concatenate(Ws, 1), np.concatenate(bs)          # coef (p, q), intercept (q,)

header("4. DATA, SIGNATURES, HEAD")
dd = np.load(DATA)
LAMS = dd["LAM"]                                              # float16 (NS, 229376)
EP, CS = dd["EP"], dd["C_STATE"]
UE, URAW, SIMS, GRIPS = dd["U_EXEC"], dd["U_RAW"], dd["SIM"], dd["GRIP"]
print("target plates:")
qoi = make_qoi(*target_plates(dd["Q0"], EP, dd["SUCCESS_EP"]))
Q0, QF = qoi(dd["Q0"]), qoi(dd["QF"])                         # psi(x) (NS, 3), psi(F_u x) (NC, K, 3)
QOIS = {name: i for i, name in enumerate(QOI_LIST)}
NS, (NC, K, H_, A_) = len(EP), UE.shape
S_all = sig_levels(UE.reshape(NC * K, H_, A_).astype(np.float64))["S<=2"]
s_mu, s_sd = S_all.mean(0), S_all.std(0)
keep = s_sd > 1e-8 * s_sd.max()
st = lambda UU: (sig_levels(np.asarray(UU, np.float64).reshape(-1, H_, A_))["S<=2"][:, keep] - s_mu[keep]) / s_sd[keep]
S_all = (S_all[:, keep] - s_mu[keep]) / s_sd[keep]
ps = S_all.shape[1]
hp = next(action_head.parameters())
LSHAPE = (56, 4096)

def head_chunks(lams):
    """lams: (n, 229376) float32 -> executed chunks (n, 8, 7), exactly as in the rollouts"""
    with torch.no_grad():
        na = _orig_predict(torch.from_numpy(lams.reshape((-1,) + LSHAPE)).to(hp.device, hp.dtype))
    na = na.float().cpu().numpy().reshape(-1, H_, A_)
    ua = np.asarray(vla._unnormalize_actions(na, UNNORM)).reshape(-1, H_, A_)
    return np.stack([executed(c) for c in ua])

# check: head(stored lambda) reproduces the stored policy chunk (candidate 0)
chk = head_chunks(LAMS[CS[:8]].astype(np.float32))
print(f"head(stored lambda) vs stored executed policy chunk: max|diff| arm {np.abs(chk[:, :, :6] - UE[:8, 0, :, :6]).max():.2e}")


# ======================================================================
# STEP 6: FIGURES  (A) one-chunk steering paths   (B) closed-loop steering towards a concept
# ======================================================================
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import imageio
FIG = "/content/drive/MyDrive/aclrh/figs"
os.makedirs(FIG, exist_ok=True)
RUN_A, RUN_SUMMARY, RUN_B = True, True, True   # one-chunk paths / summary curves / closed-loop figures
N_A = 3                               # states for panel A
A_QOI = "-d(EE,mug1)"
CL_EPISODES = 2                       # held-out episodes for panel B
CL_CONCEPTS = ["-d(EE,mug1)", "-d(EE,mug2)"]
CL_ALPHAS = [-16.0, -8.0, 0.0, 8.0, 16.0]
CL_CHUNKS = 6                         # 6 chunks = 48 control steps = 2.4 s

# ---------------- fold: fit on even episodes, show held-out odd episodes ----------------
eps = np.unique(EP)
A_eps, B_eps = set(eps[::2].tolist()), set(eps[1::2].tolist())
inA = np.array([e in A_eps for e in EP])
X32 = LAMS[inA].astype(np.float32)
mu = X32.mean(0); Xc = X32 - mu
ev, V = np.linalg.eigh((Xc @ Xc.T).astype(np.float64)); ix = np.argsort(ev)[::-1][:PCA_K]
comps = ((Xc.T.astype(np.float64) @ V[:, ix]) / np.sqrt(ev[ix])).astype(np.float32)
del X32, Xc
Zall = np.concatenate([(LAMS[i:i + 64].astype(np.float32) - mu) @ comps for i in range(0, NS, 64)])
zm, zs = Zall[inA].mean(0), Zall[inA].std(0) + 1e-12
Zall = (Zall - zm) / zs
to_lam = lambda dz: (comps @ (zs * dz)).astype(np.float32)          # latent displacement -> backbone
z_of = lambda lam: ((lam.astype(np.float32) - mu) @ comps - zm) / zs
rng = np.random.default_rng(0)
cA = np.where(inA[CS])[0]
vaE = set(rng.choice(sorted(A_eps), size=max(1, len(A_eps) // 8), replace=False).tolist())
isva = np.array([EP[CS[j]] in vaE for j in cA])
qidx = list(QOIS.values())
def design(js):
    Z = np.repeat(Zall[CS[js]], K, 0); S = S_all[np.concatenate([np.arange(j * K, (j + 1) * K) for j in js])]
    return np.c_[Z, S, (Z[:, :, None] * S[:, None, :]).reshape(len(Z), -1)]
def target(js):
    return (QF[js][:, :, qidx] - Q0[CS[js]][:, None, qidx]).reshape(-1, len(qidx))
Wc, bc = ridge_fit(design(cA[~isva]), target(cA[~isva]), design(cA[isva]), target(cA[isva]))
a_inc, b_inc = Wc[:PCA_K].T, Wc[PCA_K:PCA_K + ps].T
W_inc = Wc[PCA_K + ps:].T.reshape(len(qidx), PCA_K, ps)
sA = np.where(inA)[0]; sva = np.array([EP[i] in vaE for i in sA])
Ws, _ = ridge_fit(Zall[sA[~sva]], Q0[sA[~sva]][:, qidx], Zall[sA[sva]], Q0[sA[sva]][:, qidx])
a_sta = Ws.T
stamp("PCA and probes fitted on the even episodes")

def directions(q, lam0):
    """probe-derived latent directions at the current state, scaled to STEP_REL * ||lambda_bar||"""
    z0 = z_of(lam0[None])[0]
    u0 = head_chunks(lam0[None])[0]
    E = np.eye(PCA_K) * H_Z
    up = head_chunks(np.stack([lam0 + to_lam(e) for e in E])); um = head_chunks(np.stack([lam0 - to_lam(e) for e in E]))
    Dphi = ((st(up) - st(um)) / (2 * H_Z)).T                          # (|S|, 32)
    lam_psi = b_inc[q] + W_inc[q].T @ z0                              # lambda_psi(x), non-empty words
    d = {"Dphi^T lambda_psi": Dphi.T @ lam_psi,
         "gamma_psi": a_inc[q] + W_inc[q] @ st(u0)[0],
         "static": a_sta[q].copy()}
    n = float(np.linalg.norm(lam0))
    return {k: v / (np.linalg.norm(zs * v) + 1e-300) * STEP_REL * n for k, v in d.items()}

def ee(e):
    s_ = e.env; return np.array(s_.sim.data.site_xpos[s_.robots[0].eef_site_id])

def run_chunk_path(e, sim_state, grip, actions):
    restore(e, sim_state, grip)
    path = [ee(e)]
    for a in actions:
        e.step(np.asarray(a, dtype=np.float64).tolist()); path.append(ee(e))
    return np.array(path), positions(e)

# ---------------- camera projection (robosuite) + orientation check ----------------
from robosuite.utils.camera_utils import get_camera_transform_matrix, project_points_from_world_to_camera
IMG = 256
PROJ_MODE = "mirror_cols" # verified with A_projection_check.png (markers on EE and both mugs)
PROJ_MAPS = {"rot180": lambda r, c: (IMG - 1 - r, IMG - 1 - c),
             "mirror_cols": lambda r, c: (r, IMG - 1 - c),
             "none": lambda r, c: (r, c)}
def scene_and_projector(sim_state, grip, mode=None):
    env.env.timestep, env.env.done = 0, False
    obs = env.set_init_state(sim_state)
    img = lu.get_libero_image(obs)                                   # image as fed to the policy (rotated)
    Mcam = get_camera_transform_matrix(env.env.sim, "agentview", IMG, IMG)
    fmap = PROJ_MAPS[mode or PROJ_MODE]
    def proj(P):
        rc = project_points_from_world_to_camera(np.asarray(P, float).reshape(-1, 3), Mcam, IMG, IMG)
        r_, c_ = fmap(rc[:, 0], rc[:, 1])
        return np.stack([r_, c_], 1)
    return img, proj

def projection_check(sim_state, grip, P0):
    fig, axes = plt.subplots(1, len(PROJ_MAPS), figsize=(4 * len(PROJ_MAPS), 4))
    for ax, mode in zip(axes, PROJ_MAPS):
        img, proj = scene_and_projector(sim_state, grip, mode)
        ax.imshow(img); ax.set_axis_off(); ax.set_title(mode + (" (in use)" if mode == PROJ_MODE else ""))
        for pp, mk, col in [(P0[0:3], "x", "white"), (P0[3:6], "o", "lime"), (P0[6:9], "s", "yellow")]:
            uv = proj(pp); ax.plot(uv[:, 1], uv[:, 0], mk, mfc="none", mec=col, color=col, ms=14, mew=2)
    fig.suptitle("markers must sit on the EE (x), white mug (o), yellow-white mug (s)", fontsize=10)
    plt.tight_layout(); plt.savefig(f"{FIG}/A_projection_check.png", dpi=120); plt.close()

# ======================================================================
# (A) one-chunk steering paths
# ======================================================================
if RUN_A:
    header("6A. ONE-CHUNK STEERING PATHS")
    q = QOIS[A_QOI]
    cB = np.where(~inA[CS])[0]
    RES_T = "/content/drive/MyDrive/aclrh/oft_steering_taskqoi.npz"
    if os.path.exists(RES_T):
        # representative states: held-out states whose steering effect is closest to the median effect
        R_ = np.load(RES_T)
        st_ids = R_[f"{A_QOI}|state"]; Jd = R_[f"{A_QOI}|Dphi^T lambda_psi|J"]
        eff_ = Jd[:, -1] - Jd[:, 0]
        held = np.array([EP[s_] in B_eps for s_ in st_ids])
        order = np.argsort(np.abs(eff_[held] - np.median(eff_[held])))
        selA = [int(np.where(CS == s_)[0][0]) for s_ in st_ids[held][order][:N_A]]
        print("panel A states (effect closest to the median):", [int(CS[j]) for j in selA])
    else:
        sd = (QF[cB][:, :, q] - Q0[CS[cB], q][:, None]).std(1)
        selA = cB[np.argsort(-sd)][:N_A]
    cmap = plt.get_cmap("coolwarm")
    fig, axes = plt.subplots(N_A, 3, figsize=(15, 4.6 * N_A))
    for r, j in enumerate(selA):
        g = CS[j]; lam0 = LAMS[g].astype(np.float32); sim_state, grip = SIMS[g], GRIPS[g].astype(np.float64)
        dirs = directions(q, lam0)
        paths, finals = {}, {}
        for name, v in dirs.items():
            chunks = head_chunks(np.stack([lam0 + to_lam(t_ * v) for t_ in TAUS]))
            res = [run_chunk_path(cenv, sim_state, grip, c_) for c_ in chunks]
            paths[name] = np.stack([p for p, _ in res]); finals[name] = np.array([qoi(pos)[q] for _, pos in res])
        restore(cenv, sim_state, grip); P0 = positions(cenv)
        if r == 0:
            projection_check(sim_state, grip, P0)
            stamp(f"saved {FIG}/A_projection_check.png (check the marker positions)")
        img, proj = scene_and_projector(sim_state, grip)
        # scene with projected EE paths
        ax = axes[r, 0]; ax.imshow(img); ax.set_axis_off()
        for k_, t_ in enumerate(TAUS):
            uv = proj(paths["Dphi^T lambda_psi"][k_])
            ax.plot(uv[:, 1], uv[:, 0], "-", color=cmap((t_ - TAUS[0]) / (TAUS[-1] - TAUS[0])), lw=2)
        for k_, t_ in enumerate(TAUS):
            uv = proj(paths["static"][k_]); ax.plot(uv[:, 1], uv[:, 0], ":", color="k", lw=1)
        m1 = proj(P0[3:6]); m2 = proj(P0[6:9]); e0 = proj(P0[0:3])
        ax.plot(m1[:, 1], m1[:, 0], "o", mfc="none", mec="lime", ms=14, mew=2, label="white mug")
        ax.plot(m2[:, 1], m2[:, 0], "s", mfc="none", mec="yellow", ms=14, mew=2, label="yellow-white mug")
        ax.plot(e0[:, 1], e0[:, 0], "x", color="white", ms=10, mew=2, label="EE")
        ax.set_title(f"state {g}: EE paths (solid: $\\lambda_\\psi$, dotted: static)", fontsize=9)
        ax.legend(loc="lower left", fontsize=7)
        # top-down xy
        ax = axes[r, 1]
        for k_, t_ in enumerate(TAUS):
            c_ = cmap((t_ - TAUS[0]) / (TAUS[-1] - TAUS[0]))
            ax.plot(paths["Dphi^T lambda_psi"][k_][:, 0] * 100, paths["Dphi^T lambda_psi"][k_][:, 1] * 100, "-", color=c_, lw=2,
                    label=f"$\\alpha$={t_:+.0f}" if r == 0 else None)
            ax.plot(paths["static"][k_][:, 0] * 100, paths["static"][k_][:, 1] * 100, ":", color="gray", lw=1)
        for (pp, mk, col, lab) in [(P0[3:6], "o", "green", "white mug"), (P0[6:9], "s", "goldenrod", "yellow-white mug"),
                                   (P0[9:12], "D", "gray", "plate 1"), (P0[12:15], "D", "silver", "plate 2")]:
            ax.plot(pp[0] * 100, pp[1] * 100, mk, color=col, ms=10, label=lab if r == 0 else None)
        ax.plot(P0[0] * 100, P0[1] * 100, "kx", ms=9)
        # zoom on the paths; indicate the direction of the mugs with arrows
        allp = np.concatenate([paths["Dphi^T lambda_psi"].reshape(-1, 3), paths["static"].reshape(-1, 3)]) * 100
        cx, cy = allp[:, 0].mean(), allp[:, 1].mean()
        half = max(np.ptp(allp[:, 0]), np.ptp(allp[:, 1])) / 2 + 0.5
        ax.set_xlim(cx - half, cx + half); ax.set_ylim(cy - half, cy + half)
        for pp, col, lab in [(P0[3:6], "green", "to white mug"), (P0[6:9], "goldenrod", "to yellow-white mug")]:
            dvec = pp[:2] * 100 - np.array([P0[0] * 100, P0[1] * 100])
            dvec = dvec / (np.linalg.norm(dvec) + 1e-12) * 0.8 * half
            ax.annotate("", xy=(P0[0] * 100 + dvec[0], P0[1] * 100 + dvec[1]), xytext=(P0[0] * 100, P0[1] * 100),
                        arrowprops=dict(arrowstyle="->", color=col, lw=2))
            ax.text(P0[0] * 100 + dvec[0], P0[1] * 100 + dvec[1], lab, color=col, fontsize=7)
        ax.set_xlabel("x (cm)"); ax.set_ylabel("y (cm)"); ax.set_aspect("equal"); ax.grid(alpha=.3)
        ax.set_title("top-down view, zoomed (steered chunk, 8 steps)", fontsize=9)
        if r == 0: ax.legend(fontsize=7, ncol=2)
        # J(alpha) at this state
        ax = axes[r, 2]
        for name, col in [("Dphi^T lambda_psi", "C3"), ("gamma_psi", "C0"), ("static", "k")]:
            ax.plot(TAUS, -1e3 * finals[name], "o-", color=col, label=name.replace("Dphi^T lambda_psi", "$\\lambda_\\psi$")
                    .replace("gamma_psi", "$\\gamma_\\psi$"))
        ax.set_xlabel("$\\alpha$"); ax.set_ylabel("EE–white mug distance after chunk (mm)"); ax.grid(alpha=.3)
        ax.legend(fontsize=8); ax.set_title("QoI vs steering strength", fontsize=9)
        print(f"  state {g}: distance (mm) at alpha=-8/0/+8 along Dphi^T lambda_psi: "
              f"{-1e3 * finals['Dphi^T lambda_psi'][0]:.1f} / {-1e3 * finals['Dphi^T lambda_psi'][3]:.1f} / {-1e3 * finals['Dphi^T lambda_psi'][-1]:.1f}", flush=True)
    plt.tight_layout(); plt.savefig(f"{FIG}/A_one_chunk_paths.png", dpi=150); plt.close()
    stamp(f"saved {FIG}/A_one_chunk_paths.png")

if RUN_SUMMARY:
    # summary J(alpha) curves over all steered states (from the saved steering results)
    files = [("/content/drive/MyDrive/aclrh/oft_steering.npz", ["EE z (control)", "mug1 z", "mug2 z"]),
             ("/content/drive/MyDrive/aclrh/oft_steering_taskqoi.npz", ["-d(mug1,plate) xy", "-d(mug2,plate) xy", "-d(EE,mug1)"]),
             ("/content/drive/MyDrive/aclrh/oft_steering_ee_mug2.npz", ["-d(EE,mug2)"])]
    panels = [(f, qn) for f, qs in files if os.path.exists(f) for qn in qs]
    if panels:
        ncol = 4 if len(panels) > 6 else 3
        nrow = int(np.ceil(len(panels) / ncol))
        fig, axes = plt.subplots(nrow, ncol, figsize=(5 * ncol, 4 * nrow)); axes = np.atleast_1d(axes).ravel()
        for ax in axes[len(panels):]:
            ax.set_axis_off()
        for ax, (f, qn) in zip(axes, panels):
            R = np.load(f); taus = R["taus"]
            for name, col in [("sim-gradient", "gray"), ("Dphi^T lambda_psi", "C3"), ("gamma_psi", "C0"), ("static", "k")]:
                key = f"{qn}|{name}|J"
                if key not in R.files: continue
                J_ = 1e3 * R[key]
                J_ = J_ - J_[:, [list(taus).index(0.0)]]              # per state: change relative to alpha = 0
                med = np.median(J_, 0); lo, hi = np.percentile(J_, 25, 0), np.percentile(J_, 75, 0)
                ls = "--" if name == "sim-gradient" else "-"
                ax.plot(taus, med, ls, color=col, lw=2, label=name.replace("Dphi^T lambda_psi", "$\\lambda_\\psi$")
                        .replace("gamma_psi", "$\\gamma_\\psi$"))
                ax.fill_between(taus, lo, hi, color=col, alpha=.15)
            ax.set_title(qn); ax.set_xlabel("$\\alpha$"); ax.set_ylabel("$J(\\alpha) - J(0)$ (mm)"); ax.grid(alpha=.3)
        axes[0].legend(fontsize=8)
        plt.tight_layout(); plt.savefig(f"{FIG}/A_summary_curves.png", dpi=150); plt.close()
        stamp(f"saved {FIG}/A_summary_curves.png")

# ======================================================================
# (B) closed-loop steering towards a concept
# ======================================================================
if RUN_B:
    header("6B. CLOSED-LOOP STEERING TOWARDS A CONCEPT")
    resize = ru.get_image_resize_size(cfg)
    TRAJ, START = {}, {}
    for ep in sorted(B_eps)[:CL_EPISODES]:
        for concept in CL_CONCEPTS:
            qc = QOIS[concept]
            frames, dists = {}, {}
            for alpha in CL_ALPHAS:
                env.env.timestep, env.env.done = 0, False
                env.reset(); obs = env.set_init_state(init_states[ep])
                for _ in range(NUM_WAIT):
                    obs, _, _, _ = env.step(lu.get_libero_dummy_action("openvla"))
                sim0, grip0 = env.get_sim_state().copy(), grip_state(env)
                fr, dd_ = [lu.get_libero_image(obs)], [positions(env)]
                for k_ in range(CL_CHUNKS):
                    raw = np.asarray(ou.get_vla_action(cfg, vla, processor, rle.prepare_observation(obs, resize)[0],
                                                       task_description, action_head, proprio_projector), dtype=np.float64)
                    lam0 = LAM["cap"][0].numpy().reshape(-1).astype(np.float32)
                    if alpha == 0.0:
                        chunk = executed(raw)
                    else:
                        v = directions(qc, lam0)["Dphi^T lambda_psi"]            # recomputed at every re-plan
                        chunk = head_chunks((lam0 + to_lam(alpha * v))[None])[0]
                    for a in chunk:
                        obs, _, _, _ = env.step(np.asarray(a).tolist())
                        fr.append(lu.get_libero_image(obs)); dd_.append(positions(env))
                frames[alpha], dists[alpha] = np.stack(fr), np.stack(dd_)
                P = dists[alpha]
                print(f"  episode {ep} | concept {concept} | alpha {alpha:+.0f}: EE-white mug {1e3 * np.linalg.norm(P[-1, 0:3] - P[-1, 3:6]):.0f} mm, "
                      f"EE-yellow-white mug {1e3 * np.linalg.norm(P[-1, 0:3] - P[-1, 6:9]):.0f} mm after {CL_CHUNKS} chunks", flush=True)
            tag = f"ep{ep:02d}_{concept.replace('-d(EE,', 'towards_').replace(')', '')}"
            # GIF: the three alphas side by side
            gif = [np.concatenate([frames[a][t] for a in CL_ALPHAS], 1) for t in range(len(frames[CL_ALPHAS[0]]))]
            imageio.mimsave(f"{FIG}/B_{tag}.gif", gif, duration=0.08)
            TRAJ.setdefault(ep, {})[concept] = {a: dists[a].copy() for a in CL_ALPHAS}
            START[ep] = (sim0, grip0)
            # filmstrip: rows = alpha, columns = every chunk
            cols = list(range(0, len(frames[CL_ALPHAS[0]]), 8))
            fig, axes = plt.subplots(len(CL_ALPHAS), len(cols), figsize=(2.2 * len(cols), 2.3 * len(CL_ALPHAS)))
            for r_, a in enumerate(CL_ALPHAS):
                for c_, t_ in enumerate(cols):
                    axes[r_, c_].imshow(frames[a][t_]); axes[r_, c_].set_xticks([]); axes[r_, c_].set_yticks([])
                    if r_ == 0: axes[r_, c_].set_title(f"t = {t_ / 20:.1f} s", fontsize=9)
                axes[r_, 0].set_ylabel(f"$\\alpha$ = {a:+.0f}", fontsize=10)
            fig.suptitle(f"closed-loop steering along $\\lambda_\\psi$, concept: {concept} (episode {ep}, held out)", fontsize=11)
            plt.tight_layout(); plt.savefig(f"{FIG}/B_{tag}_filmstrip.png", dpi=130); plt.close()
            # distances over time
            fig, ax = plt.subplots(1, 2, figsize=(10, 3.4))
            tt = np.arange(len(dists[CL_ALPHAS[0]])) / 20.0
            acols = [cmap((a - CL_ALPHAS[0]) / (CL_ALPHAS[-1] - CL_ALPHAS[0])) if a != 0 else "k" for a in CL_ALPHAS]
            for a, col in zip(CL_ALPHAS, acols):
                P = dists[a]
                ax[0].plot(tt, 1e2 * np.linalg.norm(P[:, 0:3] - P[:, 3:6], axis=1), color=col, label=f"$\\alpha$={a:+.0f}")
                ax[1].plot(tt, 1e2 * np.linalg.norm(P[:, 0:3] - P[:, 6:9], axis=1), color=col)
            ax[0].set_title("EE – white mug (cm)"); ax[1].set_title("EE – yellow-white mug (cm)")
            for a_ in ax: a_.set_xlabel("time (s)"); a_.grid(alpha=.3)
            ax[0].legend(fontsize=8); fig.suptitle(f"concept: {concept}", fontsize=10)
            plt.tight_layout(); plt.savefig(f"{FIG}/B_{tag}_distances.png", dpi=150); plt.close()
            stamp(f"saved B_{tag} (gif, filmstrip, distances)")
    # ---- closed-loop EE trajectories: saved to npz and plotted (camera view + top-down) ----
    def plot_trajectories(D, out_png):
        """D: dict with img (H,W,3), alphas, concepts, and per concept: uv[a] (T,2), xyz[a] (T,3), p0 (15,)"""
        import numpy as np
        import matplotlib.pyplot as plt
        from matplotlib import cm, colors
        alphas = list(D["alphas"])
        norm = colors.Normalize(vmin=min(alphas), vmax=max(alphas))
        cmap_ = plt.get_cmap("coolwarm")
        col = lambda a: "k" if a == 0 else cmap_(norm(a))
        concepts = list(D["concepts"])
        nice = {"-d(EE,mug1)": "approach the white mug", "-d(EE,mug2)": "approach the yellow-and-white mug"}
        fig, axes = plt.subplots(len(concepts), 2, figsize=(10.5, 5.0 * len(concepts)),
                                 gridspec_kw=dict(width_ratios=[1, 1], wspace=0.08, hspace=0.18))
        axes = np.atleast_2d(axes)
        for r, c in enumerate(concepts):
            C = D[c]; p0 = C["p0"]
            # ---- camera image with projected trajectories ----
            ax = axes[r, 0]; ax.imshow(D["img"]); ax.set_axis_off()
            for a in alphas:
                uv = C["uv"][a]; ax.plot(uv[:, 1], uv[:, 0], "-", color=col(a), lw=2.4, solid_capstyle="round")
                ax.plot(uv[-1, 1], uv[-1, 0], "o", color=col(a), ms=4)
            for key, mk, ec in [("uv_mug1", "o", "lime"), ("uv_mug2", "s", "yellow")]:
                q = C[key]; ax.plot(q[1], q[0], mk, mfc="none", mec=ec, ms=15, mew=2.5)
            ax.set_title(f"concept: {nice.get(c, c)}", fontsize=11, loc="left")
            # ---- top-down view, oriented like the camera (horizontal = -y, vertical = x) ----
            ax = axes[r, 1]
            H = lambda P: -P[..., 1] * 100          # horizontal: left/right as in the image
            V = lambda P: P[..., 0] * 100           # vertical
            pts = [np.stack([H(C["xyz"][a]), V(C["xyz"][a])], -1) for a in alphas]
            mugs = [(p0[3:6], "green", "white mug"), (p0[6:9], "goldenrod", "yellow-and-white mug")]
            allp = np.concatenate(pts + [np.array([[H(m), V(m)]]) for m, _, _ in mugs])
            cx, cy = (allp.min(0) + allp.max(0)) / 2
            half = (allp.max(0) - allp.min(0)).max() / 2 + 5.0
            for m, fc, lab in mugs:
                ax.add_patch(plt.Circle((H(m), V(m)), 4.0, fc=fc, ec="none", alpha=0.25))
                ax.add_patch(plt.Circle((H(m), V(m)), 4.0, fc="none", ec=fc, lw=1.5))
                ax.text(H(m), V(m) - 5.6, lab, ha="center", va="top", fontsize=8, color=fc)
            for a, p in zip(alphas, pts):
                ax.plot(p[:, 0], p[:, 1], "-", color=col(a), lw=2.2, solid_capstyle="round")
                ax.plot(p[-1, 0], p[-1, 1], "o", color=col(a), ms=5)
            ax.plot(pts[0][0, 0], pts[0][0, 1], "kx", ms=9, mew=2)
            ax.text(pts[0][0, 0], pts[0][0, 1] + 1.2, "start", ha="center", va="bottom", fontsize=8)
            ax.set_xlim(cx - half, cx + half); ax.set_ylim(cy - half, cy + half); ax.set_aspect("equal")
            ax.set_xticks([]); ax.set_yticks([])
            for s_ in ax.spines.values(): s_.set_color("0.7")
            ax.plot([cx + half - 11, cx + half - 1], [cy - half + 2] * 2, "k-", lw=2)      # 10 cm scale bar
            ax.text(cx + half - 6, cy - half + 2.8, "10 cm", ha="center", va="bottom", fontsize=8)
            ax.set_title("top-down view (end effector)", fontsize=11, loc="left")
        sm = cm.ScalarMappable(norm=norm, cmap=cmap_); sm.set_array([])
        cb = fig.colorbar(sm, ax=axes.ravel().tolist(), fraction=0.025, pad=0.02, ticks=alphas)
        cb.set_label(r"steering strength $\alpha$ (0 = unsteered policy)")
        fig.savefig(out_png, dpi=170, bbox_inches="tight"); plt.close(fig)



    def plot_trajectories_compact(D, out_png):
        """main-text version: the two top-down views side by side, shared alpha colorbar (wide and short)"""
        import numpy as np
        import matplotlib.pyplot as plt
        from matplotlib import cm, colors
        alphas = list(D["alphas"])
        norm = colors.Normalize(vmin=min(alphas), vmax=max(alphas))
        cmap_ = plt.get_cmap("coolwarm")
        col = lambda a: "k" if a == 0 else cmap_(norm(a))
        concepts = list(D["concepts"])
        titles = {"-d(EE,mug1)": r"$\psi=-d(\mathrm{EE},\mathrm{mug}_1)$  (white mug)",
                  "-d(EE,mug2)": r"$\psi=-d(\mathrm{EE},\mathrm{mug}_2)$  (yellow-and-white mug)"}
        H = lambda P: -P[..., 1] * 100
        V = lambda P: P[..., 0] * 100
        # common view window for both panels
        allp = []
        for c in concepts:
            C = D[c]
            allp += [np.stack([H(C["xyz"][a]), V(C["xyz"][a])], -1) for a in alphas]
            allp += [np.array([[H(C["p0"][3:6]), V(C["p0"][3:6])]]), np.array([[H(C["p0"][6:9]), V(C["p0"][6:9])]])]
        allp = np.concatenate(allp)
        cx, cy = (allp.min(0) + allp.max(0)) / 2
        hx = (allp[:, 0].max() - allp[:, 0].min()) / 2 + 5.0
        hy = (allp[:, 1].max() - allp[:, 1].min()) / 2 + 7.0
        fig, axes = plt.subplots(1, len(concepts), figsize=(4.6 * len(concepts) + 1.0, 3.3))
        axes = np.atleast_1d(axes)
        for ax, c in zip(axes, concepts):
            C = D[c]; p0 = C["p0"]
            for m, fc, lab in [(p0[3:6], "green", "white mug"), (p0[6:9], "goldenrod", "yellow-and-white mug")]:
                ax.add_patch(plt.Circle((H(m), V(m)), 4.0, fc=fc, ec="none", alpha=0.25))
                ax.add_patch(plt.Circle((H(m), V(m)), 4.0, fc="none", ec=fc, lw=1.5))
                ax.text(H(m), V(m) - 5.3, lab, ha="center", va="top", fontsize=8, color=fc)
            for a in alphas:
                p = np.stack([H(C["xyz"][a]), V(C["xyz"][a])], -1)
                ax.plot(p[:, 0], p[:, 1], "-", color=col(a), lw=2.0, solid_capstyle="round")
                ax.plot(p[-1, 0], p[-1, 1], "o", color=col(a), ms=4)
            s0 = np.array([H(C["xyz"][alphas[0]][0]), V(C["xyz"][alphas[0]][0])])
            ax.plot(*s0, "kx", ms=8, mew=2); ax.text(s0[0], s0[1] + 1.2, "start", ha="center", va="bottom", fontsize=8)
            ax.set_xlim(cx - hx, cx + hx); ax.set_ylim(cy - hy, cy + hy); ax.set_aspect("equal")
            ax.set_xticks([]); ax.set_yticks([])
            for s_ in ax.spines.values(): s_.set_color("0.7")
            ax.plot([cx - hx + 1, cx - hx + 11], [cy - hy + 1.5] * 2, "k-", lw=2)
            ax.text(cx - hx + 6, cy - hy + 2.3, "10 cm", ha="center", va="bottom", fontsize=7)
            ax.set_title(titles.get(c, c), fontsize=10)
        sm = cm.ScalarMappable(norm=norm, cmap=cmap_); sm.set_array([])
        cb = fig.colorbar(sm, ax=list(axes), fraction=0.03, pad=0.02, ticks=alphas)
        cb.set_label(r"$\alpha$")
        fig.savefig(out_png, dpi=200, bbox_inches="tight"); plt.close(fig)


    import pickle
    for ep, per in TRAJ.items():
        sim0, grip0 = START[ep]
        img, proj = scene_and_projector(sim0, grip0)
        D = {"img": img, "alphas": CL_ALPHAS, "concepts": list(per.keys())}
        for concept, tr in per.items():
            p0 = tr[0.0][0]
            D[concept] = {"p0": p0, "xyz": {a: tr[a][:, 0:3] for a in CL_ALPHAS},
                          "uv": {a: proj(tr[a][:, 0:3]) for a in CL_ALPHAS},
                          "uv_mug1": proj(p0[3:6])[0], "uv_mug2": proj(p0[6:9])[0],
                          "dist": {a: np.stack([np.linalg.norm(tr[a][:, 0:3] - tr[a][:, 3:6], axis=1),
                                                np.linalg.norm(tr[a][:, 0:3] - tr[a][:, 6:9], axis=1)], 1)
                                   for a in CL_ALPHAS}}
        with open(f"{FIG}/B_ep{ep:02d}_trajectories.pkl", "wb") as f:
            pickle.dump(D, f)
        plot_trajectories(D, f"{FIG}/B_ep{ep:02d}_trajectories.png")
        plot_trajectories_compact(D, f"{FIG}/B_ep{ep:02d}_trajectories_compact.png")
        stamp(f"saved {FIG}/B_ep{ep:02d}_trajectories.png (+ .pkl for re-plotting without the simulator)")

print(f"\nall figures in {FIG}")
'''

with open("/content/run_oft_figures.py", "w") as f:
    f.write(SCRIPT)
print("\nrunning figures in the Python 3.10 venv ...\n", flush=True)
p = subprocess.Popen([VPY, "-u", "/content/run_oft_figures.py"], stdout=subprocess.PIPE,
                     stderr=subprocess.STDOUT, text=True,
                     env={**os.environ, "MUJOCO_GL": "egl",
                          "MPLBACKEND": "Agg",          # Colab sets a notebook-only backend
                          "TF_CPP_MIN_LOG_LEVEL": "2",  # silence TensorFlow start-up noise
                          "PYTHONPATH": f"{OFT}:{LIB}:" + os.environ.get("PYTHONPATH", "")})
for line in p.stdout:
    print(line, end="")
p.wait()
print(f"\nReturn code: {p.returncode}")
