# ======================================================================
# OpenVLA-OFT — STEP 3: PROBING ANALYSIS  (position QoIs, 50 LIBERO layouts)
# lambda(x) = action-head input (56 action tokens x 4096), H = 8 (one OFT chunk)
# Runs in the normal Colab Python (numpy / sklearn / torch); no model or simulator needed.
#
#   (1) static         psi(x)            ~ <lambda(x), a_psi>                    all states
#   (2) increment      Delta psi(x;u)    ~ <lambda(x), L_psi S_{<=2}(u)>        candidate states
#                      (+ static / additive / MLP readout / unstructured references)
#   (3) propagated     psi_hat(F_u(x))   = psi_hat(x) + Delta psi_hat(x;u)      Definition 3.1,
#                      computed from the representation alone
# Held-out EPISODES (5 folds). Run in a Colab GPU cell.
# ======================================================================
import os, math, time
import numpy as np
from sklearn.model_selection import GroupKFold
try:
    import torch
    import torch.nn as nn
except ImportError:
    torch = None

DATA = "/content/drive/MyDrive/aclrh/oft_probe.npz"
OUT = "/content/drive/MyDrive/aclrh/oft_probe_results.npz"
SEED = 0
QOI = ["EE x", "EE y", "EE z", "mug1 x", "mug1 y", "mug1 z", "mug2 x", "mug2 y", "mug2 z"]
CONTROL = {"EE x", "EE y", "EE z"}      # delta-EE actions act on these directly
PCA_K = 32
K_STATIC = 256                          # static probe: all leading components (as in the paper)
N_FOLDS = 5
ALPHAS = np.logspace(-4, 4, 17)
MLP_HID, MLP_DEPTH = 256, 3
MLP_LR, MLP_WD, MLP_BATCH = 1e-3, 1e-4, 512
MLP_EPOCHS, MLP_PATIENCE = 400, 25
USE_GPU = torch is not None and torch.cuda.is_available()
DEV = torch.device("cuda") if USE_GPU else None
T0 = time.time()


def stamp(m):
    print(f"[{time.time() - T0:7.1f}s] {m}", flush=True)


def sig_levels(U):
    """time-augmented signature, dX = (dt, u dt): returns S1, S<=2, S<=3."""
    U = np.asarray(U, dtype=np.float64)
    N, H, A = U.shape
    dt = 1.0 / H
    dx = np.concatenate([np.full((N, H, 1), dt), U * dt], axis=2)
    prev1 = np.cumsum(dx, axis=1) - dx
    inc2 = np.einsum("nti,ntj->ntij", prev1, dx) + 0.5 * np.einsum("nti,ntj->ntij", dx, dx)
    prev2 = np.cumsum(inc2, axis=1) - inc2
    S1 = dx.sum(axis=1)
    S2 = inc2.sum(axis=1)
    S3 = (np.einsum("ntij,ntk->nijk", prev2, dx, optimize=True)
          + 0.5 * np.einsum("nti,ntj,ntk->nijk", prev1, dx, dx, optimize=True)
          + np.einsum("nti,ntj,ntk->nijk", dx, dx, dx, optimize=True) / 6.0)
    M2 = np.concatenate([S1, S2.reshape(N, -1)], axis=1)
    return {"S1": S1, "S<=2": M2, "S<=3": np.concatenate([M2, S3.reshape(N, -1)], axis=1)}


def standardize(tr, *others):
    mu, sd = tr.mean(0), tr.std(0)
    keep = sd > 1e-12 * max(sd.max(), 1e-300)
    f = lambda a: (a[:, keep] - mu[keep]) / sd[keep]
    return (f(tr),) + tuple(f(o) for o in others)


def pca_fit(Xtr, k):
    """PCA via the (n x n) Gram matrix. k is capped at the number of non-degenerate
    components (at most n_train_states - 1): near-null directions divided by ~0
    eigenvalues otherwise explode on held-out states."""
    mu = Xtr.mean(0)
    Xc = Xtr - mu
    ev, V = np.linalg.eigh((Xc @ Xc.T).astype(np.float64))
    idx = np.argsort(ev)[::-1]
    ev, V = ev[idx], V[:, idx]
    k = min(k, len(Xtr) - 1, int(np.sum(ev > 1e-8 * ev[0])))
    ev, V = ev[:k], V[:, :k]
    comps = (Xc.T.astype(np.float64) @ V) / np.sqrt(np.maximum(ev, 1e-12))
    return mu, comps.astype(np.float32)


def bilinear(z, s):
    return np.concatenate([z, s, np.einsum("ni,nj->nij", z, s).reshape(len(z), -1)], axis=1)


def _eig(M):
    if USE_GPU:
        e, V = torch.linalg.eigh(torch.as_tensor(M, device=DEV, dtype=torch.float64))
        return e.cpu().numpy(), V.cpu().numpy()
    return np.linalg.eigh(M)


def _mm(A, B):
    if USE_GPU:
        return (torch.as_tensor(A, device=DEV, dtype=torch.float64)
                @ torch.as_tensor(B, device=DEV, dtype=torch.float64)).cpu().numpy()
    return A @ B


def _ridge_path(X, Y):
    """alpha -> W for centred X, Y (primal if p <= n, dual otherwise)."""
    n, p = X.shape
    if p <= n:
        e, V = _eig(_mm(X.T, X))
        VtXtY = _mm(V.T, _mm(X.T, Y))
        return lambda a: _mm(V, VtXtY / (e[:, None] + a * n))
    e, V = _eig(_mm(X, X.T))
    VtY = _mm(V.T, Y)
    return lambda a: _mm(X.T, _mm(V, VtY / (e[:, None] + a * n)))


def ridge(Xtr, Ytr, Xva, Yva, Xte):
    mx, my = Xtr.mean(0), Ytr.mean(0)
    path = _ridge_path(Xtr - mx, Ytr - my)
    err = np.stack([np.mean(((Xva - mx) @ path(a) + my - Yva) ** 2, axis=0) for a in ALPHAS])
    best = ALPHAS[np.argmin(err, axis=0)]                       # per target
    Xall, Yall = np.r_[Xtr, Xva], np.r_[Ytr, Yva]
    mx, my = Xall.mean(0), Yall.mean(0)
    path = _ridge_path(Xall - mx, Yall - my)
    W = np.zeros((Xall.shape[1], Yall.shape[1]))
    for a in np.unique(best):
        cols = best == a
        W[:, cols] = path(a)[:, cols]
    return (Xte - mx) @ W + my


if torch is not None:
    class MLP(nn.Module):
        def __init__(self, din, dout):
            super().__init__()
            layers, d = [], din
            for _ in range(MLP_DEPTH):
                layers += [nn.Linear(d, MLP_HID), nn.GELU()]
                d = MLP_HID
            layers.append(nn.Linear(d, dout))
            self.net = nn.Sequential(*layers)
            nn.init.normal_(self.net[-1].weight, std=1e-3)
            nn.init.zeros_(self.net[-1].bias)

        def forward(self, x):
            return self.net(x)


def train_mlp(kind, A_tr, B_tr, Y_tr, A_va, B_va, Y_va, A_te, B_te):
    """kind='full': f([A, B]) -> y.   kind='cf': g(A)^T [1, B]  (linear in B)."""
    dev = DEV if USE_GPU else torch.device("cpu")
    torch.manual_seed(SEED)
    ym, ys = Y_tr.mean(0), Y_tr.std(0) + 1e-12
    q = Y_tr.shape[1]
    T = lambda a: torch.as_tensor(a, dtype=torch.float32, device=dev)
    if kind == "cf":
        one = lambda b: np.c_[np.ones(len(b)), b]
        B_tr, B_va, B_te = one(B_tr), one(B_va), one(B_te)
        ps = B_tr.shape[1]
        net = MLP(A_tr.shape[1], q * ps).to(dev)
        fwd = lambda a, b: torch.einsum("nqp,np->nq", net(a).view(len(a), q, ps), b)
    else:
        net = MLP(A_tr.shape[1] + B_tr.shape[1], q).to(dev)
        fwd = lambda a, b: net(torch.cat([a, b], dim=1))

    Atr, Btr, Ytr = T(A_tr), T(B_tr), T((Y_tr - ym) / ys)
    Ava, Bva, Yva = T(A_va), T(B_va), T((Y_va - ym) / ys)
    opt = torch.optim.AdamW(net.parameters(), lr=MLP_LR, weight_decay=MLP_WD)
    best, best_state, bad = float("inf"), None, 0
    n = len(Atr)
    for ep in range(MLP_EPOCHS):
        net.train()
        perm = torch.randperm(n, device=dev)
        for i in range(0, n, MLP_BATCH):
            b = perm[i:i + MLP_BATCH]
            loss = ((fwd(Atr[b], Btr[b]) - Ytr[b]) ** 2).mean()
            opt.zero_grad()
            loss.backward()
            opt.step()
        net.eval()
        with torch.no_grad():
            v = ((fwd(Ava, Bva) - Yva) ** 2).mean().item()
        if v < best - 1e-5:
            best, bad = v, 0
            best_state = {k: t.detach().clone() for k, t in net.state_dict().items()}
        else:
            bad += 1
            if bad >= MLP_PATIENCE:
                break
    net.load_state_dict(best_state)
    net.eval()
    with torch.no_grad():
        p = fwd(T(A_te), T(B_te)).cpu().numpy()
    return p * ys + ym


def r2(y, p):
    return 1.0 - np.sum((y - p) ** 2, 0) / np.sum((y - y.mean(0)) ** 2, 0)


def fmt_row(name, vals):
    return f"{name:22s}" + "".join(f"{v:9.3f}" for v in vals)


def dual_ridge(Ztr, Ytr, Zva, Yva, Zte, alphas=np.logspace(-3, 5, 17)):
    """ridge in dual form, penalty per target chosen on validation episodes, refit on train+val"""
    def fit(Z, Y):
        mz, my = Z.mean(0), Y.mean(0); Zc = Z - mz
        e, V = np.linalg.eigh(Zc @ Zc.T); return mz, my, Zc, e, V, V.T @ (Y - my)
    def pred(m, Zn, a_):
        mz, my, Zc, e, V, VtY = m
        return (Zn - mz) @ Zc.T @ (V @ (VtY / (e[:, None] + a_ * len(Zc)))) + my
    m = fit(Ztr, Ytr)
    best = alphas[np.stack([np.mean((pred(m, Zva, a_) - Yva) ** 2, 0) for a_ in alphas]).argmin(0)]
    m = fit(np.r_[Ztr, Zva], np.r_[Ytr, Yva]); out = np.zeros((len(Zte), Ytr.shape[1]))
    for a_ in np.unique(best):
        c = best == a_; out[:, c] = pred(m, Zte, a_)[:, c]
    return out


def run():
    assert os.path.exists(DATA), f"{DATA} not found: mount Drive first"
    d = np.load(DATA)
    LAM = d["LAM"].astype(np.float32)
    EP = d["EP"]
    NS = len(EP)
    POS0 = d["Q0"][:, :9]                                   # psi(x) for the 9 movable coordinates
    CS = d["C_STATE"]
    U = d["U_EXEC"]                                         # executed candidate chunks (NC, K, H, 7)
    POSF = d["QF"][:, :, :9]
    NC, K, H, A = U.shape
    cstate = np.repeat(CS, K)
    DPSI = (POSF - POS0[CS][:, None, :]).reshape(NC * K, 9)
    PSIF = POSF.reshape(NC * K, 9)
    S2 = sig_levels(U.reshape(NC * K, H, A).astype(np.float64))["S<=2"]
    RAW = U.reshape(NC * K, H * A).astype(np.float64)
    print(f"states {NS} ({len(np.unique(EP))} episodes, success {int(d['SUCCESS_EP'].sum())}/{len(d['SUCCESS_EP'])}) "
          f"| candidate states {NC} x {K} chunks of {H} steps | lambda dim {LAM.shape[1]}")

    def rep(k, tr):
        mu, comps = pca_fit(LAM[tr], k)
        Z = (LAM - mu) @ comps
        return (Z - Z[tr].mean(0)) / (Z[tr].std(0) + 1e-12)

    folds = list(GroupKFold(n_splits=N_FOLDS).split(np.arange(NS), groups=EP))
    rng = np.random.default_rng(SEED)

    def split_val(tr):
        eps = np.unique(EP[tr])
        va = rng.choice(eps, size=max(1, len(eps) // 8), replace=False)
        return tr[~np.isin(EP[tr], va)], tr[np.isin(EP[tr], va)]

    # ---------------- (1) static probing, all states ----------------
    REPS = {"PCA-32": PCA_K, f"PCA-{K_STATIC}": K_STATIC}
    static_pred = {r_: np.zeros_like(POS0) for r_ in REPS}
    for tr, te in folds:
        trn, va = split_val(tr)
        for r_, k in REPS.items():
            Z = rep(min(k, len(tr) - 2), tr)
            static_pred[r_][te] = dual_ridge(Z[trn], POS0[trn], Z[va], POS0[va], Z[te])
    MAIN_REP = f"PCA-{K_STATIC}"
    stamp("(1) static done")

    # ---------------- (2) increment on candidate states ----------------
    models = ["linear", "additive", "bilinear", "MLP readout", "unstructured"]
    if torch is None:
        models = models[:3]
    dpred = {m: np.zeros_like(DPSI) for m in models}
    for fi, (tr, te) in enumerate(folds):
        trn, va = split_val(tr)
        Zs = rep(PCA_K, tr)
        m_tr, m_va, m_te = (np.isin(cstate, a) for a in (trn, va, te))
        Z = Zs[cstate]
        S_tr, S_va, S_te = standardize(S2[m_tr], S2[m_va], S2[m_te])
        R_tr, R_va, R_te = standardize(RAW[m_tr], RAW[m_va], RAW[m_te])
        Y_tr, Y_va = DPSI[m_tr], DPSI[m_va]
        dpred["linear"][m_te] = ridge(Z[m_tr], Y_tr, Z[m_va], Y_va, Z[m_te])
        dpred["additive"][m_te] = ridge(np.c_[Z[m_tr], S_tr], Y_tr, np.c_[Z[m_va], S_va], Y_va,
                                        np.c_[Z[m_te], S_te])
        dpred["bilinear"][m_te] = ridge(bilinear(Z[m_tr], S_tr), Y_tr, bilinear(Z[m_va], S_va), Y_va,
                                        bilinear(Z[m_te], S_te))
        if torch is not None:
            dpred["MLP readout"][m_te] = train_mlp("cf", Z[m_tr], S_tr, Y_tr, Z[m_va], S_va, Y_va,
                                                   Z[m_te], S_te)
            dpred["unstructured"][m_te] = train_mlp("full", Z[m_tr], R_tr, Y_tr, Z[m_va], R_va, Y_va,
                                                    Z[m_te], R_te)
        stamp(f"(2) fold {fi + 1}/{N_FOLDS}")

    # ---------------- (3) propagated = static + increment (representation only) ----------------
    psi_hat = static_pred[MAIN_REP][cstate]
    prop = {"static only: psi_hat(x)": psi_hat}
    for m in models:
        prop[f"psi_hat(x) + {m}"] = psi_hat + dpred[m]

    hdr = f"{'':22s}" + "".join(f"{q:>9s}" for q in QOI)
    print("\n(1) STATIC  R^2 of psi(x)   [all states, held-out episodes]")
    print(hdr)
    for r_ in REPS:
        print(fmt_row(r_, r2(POS0, static_pred[r_])))
    print(f"\n(2) INCREMENT  R^2 of Delta psi(x;u)   [candidate states, held-out episodes, PCA-{PCA_K}]")
    print(hdr)
    for m in models:
        print(fmt_row(m, r2(DPSI, dpred[m])))
    print(f"\n(3) PROPAGATED  R^2 of psi(F_u(x)) from the representation alone  [static: {MAIN_REP}, increment: PCA-{PCA_K}]")
    print(hdr)
    for k, v in prop.items():
        print(fmt_row(k, r2(PSIF, v)))
    print("\nEE x/y/z are control QoIs (delta end-effector actions act on them directly).")
    np.savez(OUT, qoi=np.array(QOI),
             static={r_: r2(POS0, static_pred[r_]) for r_ in REPS},
             increment={m: r2(DPSI, dpred[m]) for m in models},
             propagated={k: r2(PSIF, v) for k, v in prop.items()},
             **{f"pred_{m}": dpred[m] for m in models},
             **{f"static_{r_}": static_pred[r_] for r_ in REPS})
    stamp(f"saved {OUT}")


run()
