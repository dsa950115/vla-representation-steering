# ======================================================================
# OpenVLA-OFT — STEP 11: steering along the directions of NONLINEAR probes  (ONE Colab cell, GPU: A100)
#
#   Same protocol as 04 / 05b / 05c (two folds by episode, held-out states, the same state selection, the same
#   lambda displacement per tau, the same head-only Jacobian D phi). Only the probe that turns into a direction
#   changes. The direction always follows the chunk path only (u(z) through the head, z fixed elsewhere):
#
#     linear (ours)    Dphi^T c(z0),          c(z0) = b + W^T z0              (ridge, as in 04/05b/05c)
#     MLP readout      Dphi^T g(z0)[1:],      g(z0) = MLP(z0), linear in S    (forward pass only, no backprop)
#     unstructured     Dphi_u^T grad_u f(z0, u0), f = MLP([z, u])             (backprop; Dphi_u = Jacobian of the
#                                                                               raw executed chunk w.r.t. z)
#     CAA              mean z of high-outcome states minus mean z of low-outcome states (contrastive activation
#                      addition, Rimsky et al. 2024): top vs bottom quartile of Delta psi under the policy chunk, fold A
#     probe weight     weight a of a linear probe <z, a> -> Delta psi under the policy chunk (ITI-style probe direction,
#                      Li et al. 2023): no action conditioning, the same direction in every state
#     sim-gradient     simulator finite differences (oracle)
#     random           3 random directions (baseline)
#
#   MLP widths: the budget closest to the linear probe (readout 32, unstructured 64, as in fig:q1_capacity)
#   and 256. MLPs are trained on fold A as in probing/q1_capacity_sweep.py (positions and distances as two groups).
#
#   QoIs: EE z (control), mug1 z, mug2 z (step 04) and the four task distances (05b, 05c). Selected states are the
#   same as in those steps (selection depends only on the stored data).
#
#   Output: aclrh/oft_steering_mlp.npz ({qoi}|{direction}|J, {qoi}|{direction}|cos, {qoi}|state)
#   Resumable: finished states are kept in aclrh/oft_steering_mlp_partial.pkl, MLP weights in aclrh/oft_steer_mlp_fold*.pt
#   Log: aclrh/oft_steering_mlp_log.txt. AUTO_SHUTDOWN disconnects the runtime when the run ends.
# ======================================================================
AUTO_SHUTDOWN = True
import os, subprocess, sys, textwrap, time

VENV = "/content/oftenv"
VPY = f"{VENV}/bin/python"
OFT = "/content/openvla-oft"
LIB = "/content/LIBERO"
MARK = f"{VENV}/.setup_done"


def sh(cmd, check=True):
    print(f"$ {cmd}", flush=True)
    r = subprocess.run(cmd, shell=True, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    tail = "\n".join(r.stdout.strip().splitlines()[-15:])
    if tail:
        print(tail, flush=True)
    if check and r.returncode != 0:
        raise RuntimeError(f"failed ({r.returncode}): {cmd}")
    return r.returncode


# ---------------------------------------------------------------- 0. Drive (checked before any model loading)
if not os.path.isdir("/content/drive/MyDrive"):
    from google.colab import drive
    drive.mount("/content/drive")
os.makedirs("/content/drive/MyDrive/aclrh", exist_ok=True)

# ---------------------------------------------------------------- 0b. GPU check
assert subprocess.run(["nvidia-smi"], stdout=subprocess.DEVNULL).returncode == 0, \
    "No GPU visible: switch the runtime to GPU (A100) and reconnect."

# ---------------------------------------------------------------- 1. setup (once)
if not os.path.exists(MARK):
    t0 = time.time()
    sh("pip install -q uv")
    sh("uv python install 3.10")
    sh(f"rm -rf {VENV}")                                # a half-built venv without the marker: start clean
    sh(f"uv venv {VENV} --python 3.10 --seed")
    UV = f"uv pip install --python {VPY}"
    sh(f"{UV} torch==2.2.0 torchvision==0.17.0 --index-url https://download.pytorch.org/whl/cu121")
    sh(f"{UV} numpy==1.26.4")
    if not os.path.exists(OFT):
        sh(f"git clone -q https://github.com/moojink/openvla-oft.git {OFT}")
    sh(f"{UV} -e {OFT}")                                   # pulls the transformers fork and pinned deps
    if not os.path.exists(LIB):
        sh(f"git clone -q https://github.com/Lifelong-Robot-Learning/LIBERO.git {LIB}")
    sh(f"{UV} -e {LIB}")
    sh(f"{UV} -r {OFT}/experiments/robot/libero/libero_requirements.txt")
    sh(f"{UV} numpy==1.26.4")                             # re-pin in case a dependency upgraded it
    # flash-attn: prebuilt wheel for torch 2.2 / py3.10; if it fails the verification falls back to sdpa
    rc = sh(f"{UV} https://github.com/Dao-AILab/flash-attention/releases/download/v2.5.5/"
            "flash_attn-2.5.5+cu122torch2.2cxx11abiFALSE-cp310-cp310-linux_x86_64.whl", check=False)
    print("flash-attn installed" if rc == 0 else "flash-attn NOT installed -> sdpa fallback")
    # LIBERO asks interactively for its data paths on first import: write the config up front
    os.makedirs(os.path.expanduser("~/.libero"), exist_ok=True)
    base = f"{LIB}/libero/libero"
    with open(os.path.expanduser("~/.libero/config.yaml"), "w") as f:
        f.write(textwrap.dedent(f"""\
            benchmark_root: {base}
            bddl_files: {base}/bddl_files
            init_states: {base}/init_files
            datasets: {LIB}/datasets
            assets: {base}/assets
            """))
    open(MARK, "w").write("ok")
    print(f"setup finished in {(time.time() - t0) / 60:.1f} min")
else:
    print("setup already done")

# ---------------------------------------------------------------- 1b. dependency fixes (idempotent)
# tensorflow_datasets is imported by openvla-oft at import time; a too-new tensorflow-metadata needs
# protobuf 5 (google.protobuf.runtime_version), which TF 2.15 cannot use -> pin the TF-2.15-era version
if sh(f"{VPY} -c \"import tensorflow_datasets\"", check=False) != 0:
    sh(f"uv pip install --python {VPY} tensorflow-metadata==1.14.0")
    sh(f"{VPY} -c \"import tensorflow_datasets, google.protobuf as p; print('tfds OK | protobuf', p.__version__)\"")

# robosuite 1.4 predates the MuJoCo >= 3.2 joint-type API (get_joint_qpos_addr assertion) -> pin 3.1.6
_mj = subprocess.run([VPY, "-c", "import mujoco; print(mujoco.__version__)"], text=True,
                     stdout=subprocess.PIPE, stderr=subprocess.DEVNULL).stdout.strip()
print("mujoco in venv:", _mj or "not installed")
if not _mj.startswith("3.1."):
    sh(f"uv pip install --python {VPY} mujoco==3.1.6")
os.makedirs(f"{LIB}/datasets", exist_ok=True)          # silences LIBERO's missing-datasets warning

sh(f"{VPY} -c \"import torch, transformers, numpy; print('torch', torch.__version__, 'cuda', "
   f"torch.cuda.is_available(), '| transformers', transformers.__version__, '| numpy', numpy.__version__)\"")

# ---------------------------------------------------------------- 2. verification script (runs in the venv)
SCRIPT = r'''
import os, sys, time, traceback
os.environ.setdefault("MUJOCO_GL", "egl")
os.environ.setdefault("PYOPENGL_PLATFORM", "egl")
os.environ["MPLBACKEND"] = "Agg"
sys.path.insert(0, "/content/openvla-oft")
sys.path.insert(0, "/content/LIBERO")          # LIBERO's setup.py is not exposed by uv editable installs
import numpy as np
import torch

CKPT = "moojink/openvla-7b-oft-finetuned-libero-10"
UNNORM = "libero_10_no_noops"
TASK_KEYWORDS = ("white mug", "left plate", "yellow and white mug", "right plate")
MAX_STEPS = 520
NUM_WAIT = 10

T0 = time.time()

def stamp(m):
    print(f"[{time.time() - T0:7.1f}s] {m}", flush=True)


def header(t):
    print("\n" + "=" * 90 + f"\n{t}\n" + "=" * 90, flush=True)

header("1. IMPORTS")
# wandb is only used for evaluation logging; the installed wandb needs a newer protobuf than
# TF 2.15 allows, so register a no-op stand-in instead of touching protobuf again
import types, importlib.machinery
_wb = types.ModuleType("wandb")
_wb.__spec__ = importlib.machinery.ModuleSpec("wandb", None)   # find_spec() (accelerate/transformers) needs a spec
_wb.__version__ = "0.0.0"
for _name in ("init", "log", "finish", "login", "config", "save", "watch"):
    setattr(_wb, _name, lambda *a, **k: None)
_wb.run = None
sys.modules["wandb"] = _wb
from experiments.robot.libero.run_libero_eval import GenerateConfig
import experiments.robot.libero.run_libero_eval as rle
import experiments.robot.openvla_utils as ou
import experiments.robot.libero.libero_utils as lu
import experiments.robot.robot_utils as ru
from libero.libero import benchmark
print("run_libero_eval exports:", [n for n in dir(rle) if not n.startswith("_")][:60])

try:
    import flash_attn  # noqa
    ATTN = "flash_attention_2"
except Exception:
    ATTN = "sdpa"
print("attention implementation:", ATTN)

header("2. LOAD OPENVLA-OFT (LIBERO-10)")
cfg = GenerateConfig(
    pretrained_checkpoint=CKPT, use_l1_regression=True, use_diffusion=False, use_film=False,
    num_images_in_input=2, use_proprio=True, load_in_8bit=False, load_in_4bit=False,
    center_crop=True, num_open_loop_steps=8, unnorm_key=UNNORM,
)
if hasattr(cfg, "task_suite_name"):
    cfg.task_suite_name = "libero_10"
if hasattr(cfg, "model_family"):
    cfg.model_family = "openvla"
t0 = time.time()
if ATTN != "flash_attention_2":
    # route the loader to sdpa if flash-attn is missing
    from transformers import AutoModelForVision2Seq
    _orig_fp = AutoModelForVision2Seq.from_pretrained
    def _fp(*a, **kw):
        kw["attn_implementation"] = "sdpa"
        return _orig_fp(*a, **kw)
    AutoModelForVision2Seq.from_pretrained = _fp
vla = ou.get_vla(cfg)
processor = ou.get_processor(cfg)
action_head = ou.get_action_head(cfg, llm_dim=vla.llm_dim)
proprio_projector = ou.get_proprio_projector(cfg, llm_dim=vla.llm_dim, proprio_dim=8)
print(f"loaded in {time.time() - t0:.0f}s | llm_dim {vla.llm_dim} | unnorm keys: {list(getattr(vla, 'norm_stats', {}).keys())[:8]}")

# ---- lambda hook: capture (and later intervene on) the input of the L1 action head ----
LAM = {"cap": None, "delta": None}
_orig_predict = action_head.predict_action
def _predict(actions_hidden_states, *a, **kw):
    LAM["cap"] = actions_hidden_states.detach().float().cpu()
    if LAM["delta"] is not None:
        actions_hidden_states = actions_hidden_states + LAM["delta"].to(actions_hidden_states.device,
                                                                          actions_hidden_states.dtype)
    return _orig_predict(actions_hidden_states, *a, **kw)
action_head.predict_action = _predict

def policy_chunk(obs, task_label):
    observation, _ = rle.prepare_observation(obs, ru.get_image_resize_size(cfg)) \
        if hasattr(rle, "prepare_observation") else (None, None)
    actions = ou.get_vla_action(cfg, vla, processor, observation, task_label, action_head, proprio_projector)
    return np.asarray(actions)


# constants used by the helpers shared with step 2 (perturb is not used for steering)
H = 8
N_KNOTS = 4
PERT_FRAC = 0.3
SEED = 0

header("3. TASK AND ENVIRONMENTS")
suite = benchmark.get_benchmark_dict()["libero_10"]()
tid = next(i for i in range(suite.n_tasks) if all(k in suite.get_task(i).language for k in TASK_KEYWORDS))
task = suite.get_task(tid)
init_states = suite.get_task_init_states(tid)
env, task_description = lu.get_libero_env(task, "openvla", resolution=256)
try:
    from libero.libero.envs import ControlEnv
except ImportError:
    from libero.libero.envs.env_wrapper import ControlEnv   # not re-exported in this LIBERO version
from libero.libero import get_libero_path
bddl = os.path.join(get_libero_path("bddl_files"), task.problem_folder, task.bddl_file)
cenv = ControlEnv(bddl_file_name=bddl, has_renderer=False, has_offscreen_renderer=False,
                  use_camera_obs=False, camera_heights=128, camera_widths=128)   # renderer-free twin
cenv.seed(0)
cenv.reset()
inner = env.env
print(f"task {tid}: {task_description} | init states {len(init_states)}")
print("objects:", list(inner.obj_body_id.keys()))

MUGS_PLATES = ["porcelain_mug_1", "white_yellow_mug_1", "plate_1", "plate_2"]
QOI_NAMES = ["ee_x", "ee_y", "ee_z"] + [f"{o}_{c}" for o in MUGS_PLATES for c in "xyz"]

def positions(e):
    s = e.env
    out = [np.array(s.sim.data.site_xpos[s.robots[0].eef_site_id])]
    out += [np.array(s.sim.data.body_xpos[s.obj_body_id[o]]) for o in MUGS_PLATES]
    return np.concatenate(out)

def grip_state(e):
    g = getattr(e.env.robots[0].gripper, "current_action", None)
    return None if g is None else np.array(g, dtype=np.float64).copy()

def restore(e, sim_state, grip):
    e.env.timestep, e.env.done = 0, False       # the twin env replays many chunks: never hit the horizon
    e.set_init_state(sim_state)
    if grip is not None and hasattr(e.env.robots[0].gripper, "current_action"):
        e.env.robots[0].gripper.current_action = grip.copy()

def run_chunk(e, sim_state, grip, actions):
    restore(e, sim_state, grip)
    for a in actions:
        e.step(np.asarray(a, dtype=np.float64).tolist())
    return positions(e)

# per-dimension scale for perturbations, from the checkpoint's action statistics (raw action space)
try:
    st_ = vla.norm_stats[UNNORM]["action"]
    half = (np.asarray(st_["q99"]) - np.asarray(st_["q01"])) / 2.0
except Exception as ex:
    print("[warn] norm stats unavailable, using 0.5:", repr(ex)); half = np.full(7, 0.5)
print("perturbation std per arm dim:", np.round(PERT_FRAC * half[:6], 4))
rng = np.random.default_rng(SEED)

def perturb(chunk, k):
    """k smooth perturbations of the raw policy chunk on the 6 arm dims; gripper unchanged"""
    tk = np.linspace(0, H - 1, N_KNOTS)
    out = np.repeat(chunk[None], k, 0).astype(np.float64)
    for i in range(k):
        knots = rng.normal(size=(N_KNOTS, 6)) * PERT_FRAC * half[:6]
        out[i, :, :6] += np.stack([np.interp(np.arange(H), tk, knots[:, j]) for j in range(6)], 1)
    return out

def executed(raw_chunk):
    return np.stack([np.asarray(rle.process_action(a.copy(), "openvla"), dtype=np.float64) for a in raw_chunk])



# ======================================================================
# STEP 11: STEERING ALONG LINEAR AND NONLINEAR PROBE DIRECTIONS
# ======================================================================
import pickle
import torch.nn as nn

def sig_levels(U):
    """time-augmented signature, dX = (dt, u dt): returns S1, S<=2."""
    U = np.asarray(U, dtype=np.float64)
    N, H, A = U.shape
    dt = 1.0 / H
    dx = np.concatenate([np.full((N, H, 1), dt), U * dt], axis=2)
    prev1 = np.cumsum(dx, axis=1) - dx
    inc2 = np.einsum("nti,ntj->ntij", prev1, dx) + 0.5 * np.einsum("nti,ntj->ntij", dx, dx)
    S1 = dx.sum(axis=1)
    S2 = inc2.sum(axis=1)
    return {"S1": S1, "S<=2": np.concatenate([S1, S2.reshape(N, -1)], axis=1)}


ROOT = "/content/drive/MyDrive/aclrh"
DATA = f"{ROOT}/oft_probe.npz"
OUT_ST = f"{ROOT}/oft_steering_mlp.npz"
PART = f"{ROOT}/oft_steering_mlp_partial.pkl"
MLP_CKPT = f"{ROOT}/oft_steer_mlp_fold{{}}.pt"

# 13 QoIs as in q1 (9 positions, then 4 distances); MLPs are trained jointly within each group
POS = ["EE x", "EE y", "EE z", "mug1 x", "mug1 y", "mug1 z", "mug2 x", "mug2 y", "mug2 z"]
TASK = ["-d(EE,mug1)", "-d(EE,mug2)", "-d(mug1,plate) xy", "-d(mug2,plate) xy"]
QOI_ALL = POS + TASK
GROUPS = {"pos": [QOI_ALL.index(q) for q in POS], "task": [QOI_ALL.index(q) for q in TASK]}
STEER = ["EE z", "mug1 z", "mug2 z", "-d(mug1,plate) xy", "-d(mug2,plate) xy", "-d(EE,mug1)", "-d(EE,mug2)"]
NEED_MOVE = {"mug1 z", "mug2 z", "-d(mug1,plate) xy", "-d(mug2,plate) xy"}   # MIN_FRAC rule of 04 / 05b

PCA_K = 32
N_PER_FOLD = 10               # steered states per QoI and fold (2 folds)
MOVE_MM, MIN_FRAC = 2e-3, 0.5
H_Z = 0.25                    # finite-difference step (standardized PCA units) for D phi and the simulator gradient
STEP_REL = 0.005              # ||delta lambda|| / ||lambda|| per unit tau, identical for all directions
TAUS = [-8.0, -4.0, -2.0, 0.0, 2.0, 4.0, 8.0]
N_RANDOM = 3
ALPHAS_R = np.logspace(-3, 4, 15)
READOUT_W = [32, 256]
UNSTR_W = [64, 256]
MLP_DEPTH, MLP_LR, MLP_WD, MLP_BATCH, MLP_EPOCHS, MLP_PATIENCE = 3, 1e-3, 1e-4, 512, 400, 25
DEV = torch.device("cuda" if torch.cuda.is_available() else "cpu")

def make_qoi(t1, t2):
    """15 raw positions ee(0:3) mug1(3:6) mug2(6:9) plate_1(9:12) plate_2(12:15) -> 13 QoIs (to increase)"""
    def f(P):
        P = np.asarray(P, dtype=np.float64)
        return np.concatenate([P[..., :9], np.stack([
            -np.linalg.norm(P[..., 0:3] - P[..., 3:6], axis=-1),
            -np.linalg.norm(P[..., 0:3] - P[..., 6:9], axis=-1),
            -np.linalg.norm(P[..., 3:5] - P[..., t1:t1 + 2], axis=-1),
            -np.linalg.norm(P[..., 6:8] - P[..., t2:t2 + 2], axis=-1)], axis=-1)], axis=-1)
    return f

def target_plates(Q0, EP, success_ep):
    last = [np.where(EP == e)[0][-1] for e in np.unique(EP) if success_ep[int(e)]]
    P = Q0[last]
    out = []
    for m in (3, 6):
        d1 = np.linalg.norm(P[:, m:m + 2] - P[:, 9:11], axis=1)
        d2 = np.linalg.norm(P[:, m:m + 2] - P[:, 12:14], axis=1)
        out.append(9 if np.mean(d1 < d2) >= 0.5 else 12)
        print(f"  mug at cols {m}:{m + 3} -> plate_{1 if out[-1] == 9 else 2}")
    return out

def ranks(v):
    v = np.asarray(v, float)
    r = np.empty(len(v)); r[np.argsort(v, kind="mergesort")] = np.arange(len(v), dtype=float)
    for val in np.unique(v):
        m = v == val
        r[m] = r[m].mean()
    return r

def spearman(x, y):
    y = np.asarray(y, float)
    if np.ptp(y) < 1e-12:
        return 0.0
    return float(np.corrcoef(ranks(x), ranks(y))[0, 1])

def ridge_fit(Xtr, Ytr, Xva, Yva):
    """primal ridge with standardized columns; penalty per target chosen on validation rows; refit on all"""
    def fit(X, Y, a_):
        mx, sx, my = X.mean(0), X.std(0) + 1e-12, Y.mean(0)
        Xs = (X - mx) / sx
        G = Xs.T @ Xs
        W = np.linalg.solve(G + a_ * len(X) * np.eye(G.shape[0]), Xs.T @ (Y - my))
        return W / sx[:, None], my - (mx / sx) @ W
    best = []
    for j in range(Ytr.shape[1]):
        errs = []
        for a_ in ALPHAS_R:
            W, b = fit(Xtr, Ytr[:, j:j + 1], a_)
            errs.append(np.mean((Xva @ W + b - Yva[:, j:j + 1]) ** 2))
        best.append(ALPHAS_R[int(np.argmin(errs))])
    X, Y = np.r_[Xtr, Xva], np.r_[Ytr, Yva]
    Ws, bs = zip(*[fit(X, Y[:, j:j + 1], best[j]) for j in range(Y.shape[1])])
    return np.concatenate(Ws, 1), np.concatenate(bs)

class MLP(nn.Module):
    def __init__(self, din, dout, hid):
        super().__init__()
        layers, d = [], din
        for _ in range(MLP_DEPTH):
            layers += [nn.Linear(d, hid), nn.GELU()]
            d = hid
        layers.append(nn.Linear(d, dout))
        self.net = nn.Sequential(*layers)
        nn.init.normal_(self.net[-1].weight, std=1e-3)
        nn.init.zeros_(self.net[-1].bias)

    def forward(self, x):
        return self.net(x)

T_ = lambda a: torch.as_tensor(np.asarray(a), dtype=torch.float32, device=DEV)

def mlp_forward(kind, net, q, A, B):
    """kind 'cf': g(A)^T [1, B] (MLP readout);  kind 'full': f([A, B]) (unstructured). Standardized targets."""
    if kind == "cf":
        Bp = torch.cat([torch.ones(len(B), 1, device=DEV), B], 1)
        return torch.einsum("nqp,np->nq", net(A).view(len(A), q, Bp.shape[1]), Bp)
    return net(torch.cat([A, B], 1))

def train_mlp(kind, A_tr, B_tr, Y_tr, A_va, B_va, Y_va, hid):
    """same recipe as probing/q1_capacity_sweep.py; returns state_dict, (ym, ys)"""
    torch.manual_seed(0)
    ym, ys = Y_tr.mean(0), Y_tr.std(0) + 1e-12
    q = Y_tr.shape[1]
    din = A_tr.shape[1] + (0 if kind == "cf" else B_tr.shape[1])
    net = MLP(din, q * (B_tr.shape[1] + 1) if kind == "cf" else q, hid).to(DEV)
    Atr, Btr, Ytr = T_(A_tr), T_(B_tr), T_((Y_tr - ym) / ys)
    Ava, Bva, Yva = T_(A_va), T_(B_va), T_((Y_va - ym) / ys)
    opt = torch.optim.AdamW(net.parameters(), lr=MLP_LR, weight_decay=MLP_WD)
    best, best_state, bad, n = float("inf"), None, 0, len(Atr)
    for ep in range(MLP_EPOCHS):
        net.train()
        perm = torch.randperm(n, device=DEV)
        for i in range(0, n, MLP_BATCH):
            b = perm[i:i + MLP_BATCH]
            loss = ((mlp_forward(kind, net, q, Atr[b], Btr[b]) - Ytr[b]) ** 2).mean()
            opt.zero_grad(); loss.backward(); opt.step()
        net.eval()
        with torch.no_grad():
            v = ((mlp_forward(kind, net, q, Ava, Bva) - Yva) ** 2).mean().item()
        if v < best - 1e-5:
            best, bad = v, 0
            best_state = {k: t.detach().clone().cpu() for k, t in net.state_dict().items()}
        else:
            bad += 1
            if bad >= MLP_PATIENCE:
                break
    return best_state, (ym, ys), ep + 1

def r2(y, p):
    return 1.0 - np.sum((y - p) ** 2, 0) / np.sum((y - y.mean(0)) ** 2, 0)

header("4. DATA, SIGNATURES, HEAD")
dd = np.load(DATA)
LAMS = dd["LAM"]                                              # float16 (NS, 229376)
EP, CS = dd["EP"], dd["C_STATE"]
UE, SIMS, GRIPS = dd["U_EXEC"], dd["SIM"], dd["GRIP"]
print("target plates:")
qoi = make_qoi(*target_plates(dd["Q0"], EP, dd["SUCCESS_EP"]))
Q0, QF = qoi(dd["Q0"]), qoi(dd["QF"])                         # (NS, 13), (NC, K, 13)
NS, (NC, K, H_, A_) = len(EP), UE.shape
S_all = sig_levels(UE.reshape(NC * K, H_, A_).astype(np.float64))["S<=2"]
s_mu, s_sd = S_all.mean(0), S_all.std(0)
keep = s_sd > 1e-8 * s_sd.max()
st = lambda UU: (sig_levels(np.asarray(UU, np.float64).reshape(-1, H_, A_))["S<=2"][:, keep] - s_mu[keep]) / s_sd[keep]
S_all = (S_all[:, keep] - s_mu[keep]) / s_sd[keep]
ps = S_all.shape[1]
RAW = UE.reshape(NC * K, H_ * A_).astype(np.float64)          # raw executed chunks (unstructured probe input)
r_mu, r_sd = RAW.mean(0), RAW.std(0)
keep_r = r_sd > 1e-8 * r_sd.max()
rst = lambda UU: (np.asarray(UU, np.float64).reshape(-1, H_ * A_)[:, keep_r] - r_mu[keep_r]) / r_sd[keep_r]
RAW = (RAW[:, keep_r] - r_mu[keep_r]) / r_sd[keep_r]
pr = RAW.shape[1]
print(f"signature features {ps} | raw action features {pr} | candidate states {NC} x {K} | device {DEV}")
hp = next(action_head.parameters())
LSHAPE = (56, 4096)

def head_chunks(lams):
    """lams: (n, 229376) float32 -> executed chunks (n, 8, 7), exactly as in the rollouts"""
    with torch.no_grad():
        na = _orig_predict(torch.from_numpy(lams.reshape((-1,) + LSHAPE)).to(hp.device, hp.dtype))
    na = na.float().cpu().numpy().reshape(-1, H_, A_)
    ua = np.asarray(vla._unnormalize_actions(na, UNNORM)).reshape(-1, H_, A_)
    return np.stack([executed(c) for c in ua])

chk = head_chunks(LAMS[CS[:8]].astype(np.float32))
print(f"head(stored lambda) vs stored executed policy chunk: max|diff| arm {np.abs(chk[:, :, :6] - UE[:8, 0, :, :6]).max():.2e}")

DONE = pickle.load(open(PART, "rb")) if os.path.exists(PART) else []
done_keys = {(r["qoi"], r["state"]) for r in DONE}
print(f"resuming with {len(DONE)} finished (QoI, state) pairs" if DONE else "fresh run")

eps = np.unique(EP)
folds = [(set(eps[::2].tolist()), set(eps[1::2].tolist())), (set(eps[1::2].tolist()), set(eps[::2].tolist()))]
sidx = [QOI_ALL.index(q) for q in STEER]
rng = np.random.default_rng(0)
DIRS = (["sim-gradient", "linear"] + [f"MLP readout w{w}" for w in READOUT_W]
        + [f"unstructured w{w}" for w in UNSTR_W] + ["CAA", "probe weight"])
CAA_Q = 0.25                  # CAA contrast: top vs bottom quartile of the policy-chunk outcome
R2LOG = []

for fi, (A_eps, B_eps) in enumerate(folds):
    header(f"5.{fi + 1} FOLD {fi + 1}: fit on {len(A_eps)} episodes, steer in {len(B_eps)} held-out episodes")
    inA = np.array([e in A_eps for e in EP])
    X32 = LAMS[inA].astype(np.float32)
    mu = X32.mean(0); Xc = X32 - mu
    ev, V = np.linalg.eigh((Xc @ Xc.T).astype(np.float64)); ix = np.argsort(ev)[::-1][:PCA_K]
    comps = ((Xc.T.astype(np.float64) @ V[:, ix]) / np.sqrt(ev[ix])).astype(np.float32)
    del X32, Xc
    Zall = np.concatenate([(LAMS[i:i + 64].astype(np.float32) - mu) @ comps for i in range(0, NS, 64)])
    zm, zs = Zall[inA].mean(0), Zall[inA].std(0) + 1e-12
    Zall = (Zall - zm) / zs
    to_lam = lambda dz: (comps @ (zs * dz)).astype(np.float32)

    cA = np.where(inA[CS])[0]; cB = np.where(~inA[CS])[0]
    vaE = set(rng.choice(sorted(A_eps), size=max(1, len(A_eps) // 8), replace=False).tolist())
    isva = np.array([EP[CS[j]] in vaE for j in cA])
    rows_of = lambda js: np.concatenate([np.arange(j * K, (j + 1) * K) for j in js])
    tgt = lambda js: (QF[js] - Q0[CS[js]][:, None, :]).reshape(-1, Q0.shape[1])     # (rows, 13)
    Zrow = lambda js: np.repeat(Zall[CS[js]], K, 0)

    # ---- linear probe (ridge, as in 04/05b/05c), fitted for the steered QoIs ----
    def design(js):
        Z = Zrow(js); S = S_all[rows_of(js)]
        return np.c_[Z, S, (Z[:, :, None] * S[:, None, :]).reshape(len(Z), -1)]
    trj, vaj = cA[~isva], cA[isva]
    Wc, bc = ridge_fit(design(trj), tgt(trj)[:, sidx], design(vaj), tgt(vaj)[:, sidx])
    a_inc, b_inc = Wc[:PCA_K].T, Wc[PCA_K:PCA_K + ps].T
    W_inc = Wc[PCA_K + ps:].T.reshape(len(sidx), PCA_K, ps)
    stamp("linear probe fitted on fold A")

    # ---- state-independent baselines from the policy chunk (candidate 0) on fold A ----
    dpol = QF[cA, 0, :][:, sidx] - Q0[CS[cA]][:, sidx]                          # (states, q)
    ZA = Zall[CS[cA]]
    caa = np.stack([ZA[dpol[:, q] >= np.quantile(dpol[:, q], 1 - CAA_Q)].mean(0)
                    - ZA[dpol[:, q] <= np.quantile(dpol[:, q], CAA_Q)].mean(0) for q in range(len(sidx))])
    Wp, _ = ridge_fit(ZA[~isva], dpol[~isva], ZA[isva], dpol[isva])
    a_pw = Wp.T                                                                   # (q, 32)

    # ---- MLP probes on fold A (both groups), cached on Drive ----
    ck = MLP_CKPT.format(fi)
    if os.path.exists(ck):
        NETS = torch.load(ck, weights_only=False)
        print(f"MLP weights loaded from {ck}")
    else:
        NETS = {}
        Ztr, Zva = Zrow(trj), Zrow(vaj)
        Str, Sva = S_all[rows_of(trj)], S_all[rows_of(vaj)]
        Rtr, Rva = RAW[rows_of(trj)], RAW[rows_of(vaj)]
        Ytr, Yva = tgt(trj), tgt(vaj)
        for gname, gi in GROUPS.items():
            for kind, widths, Btr, Bva in (("cf", READOUT_W, Str, Sva), ("full", UNSTR_W, Rtr, Rva)):
                for w in widths:
                    sd_, nrm, n_ep = train_mlp(kind, Ztr, Btr, Ytr[:, gi], Zva, Bva, Yva[:, gi], w)
                    NETS[(gname, kind, w)] = (sd_, nrm)
                    stamp(f"  trained {gname:4s} {'MLP readout' if kind == 'cf' else 'unstructured'} w{w} "
                          f"({n_ep} epochs)")
        torch.save(NETS, ck)

    def get_net(gname, kind, w):
        sd_, (ym, ys) = NETS[(gname, kind, w)]
        q = len(GROUPS[gname])
        din = PCA_K + (0 if kind == "cf" else pr)
        net = MLP(din, q * (ps + 1) if kind == "cf" else q, w).to(DEV)
        net.load_state_dict(sd_); net.eval()
        return net, q, ym, ys
    NET = {(g, k, w): get_net(g, k, w) for (g, k, w) in NETS}

    # ---- held-out R^2 on fold B (sanity: should match q1_capacity) ----
    with torch.no_grad():
        ZB, SB, RB, YB = Zrow(cB), S_all[rows_of(cB)], RAW[rows_of(cB)], tgt(cB)
        pred = {"linear": np.einsum("np,qp->nq", design(cB), Wc.T) + bc}
        for (g, k, w), (net, q, ym, ys) in NET.items():
            nm = f"{'MLP readout' if k == 'cf' else 'unstructured'} w{w}"
            P_ = pred.setdefault(nm, np.zeros_like(YB))
            out = np.concatenate([mlp_forward(k, net, q, T_(ZB[i:i + 8192]),
                                              T_((SB if k == "cf" else RB)[i:i + 8192])).cpu().numpy()
                                  for i in range(0, len(ZB), 8192)])
            P_[:, GROUPS[g]] = out * ys + ym
        print("held-out R^2 (fold B), steered QoIs:")
        for nm, P_ in pred.items():
            rr = r2(YB[:, sidx], P_ if nm == "linear" else P_[:, sidx])
            R2LOG.append((fi, nm, rr))
            print(f"  {nm:18s} mean {rr.mean():.3f} | " + " ".join(f"{q_} {v:.3f}" for q_, v in zip(STEER, rr)))

    def mlp_dir(qname, kind, w, z0, r0, Dphi, Dphi_u):
        """direction in standardized PCA coordinates along the chunk path"""
        g = "pos" if qname in POS else "task"
        net, q, ym, ys = NET[(g, kind, w)]
        ql = GROUPS[g].index(QOI_ALL.index(qname))
        if kind == "cf":                                   # g(z0) is the coefficient on [1, S]: no backprop
            with torch.no_grad():
                G = net(T_(z0[None])).view(q, ps + 1)[ql, 1:].cpu().numpy().astype(np.float64) * ys[ql]
            return Dphi.T @ G
        zt = T_(z0[None]); rt = T_(r0[None]).requires_grad_(True)
        out = net(torch.cat([zt, rt], 1))[0, ql]
        gr, = torch.autograd.grad(out, rt)
        return Dphi_u.T @ (gr[0].cpu().numpy().astype(np.float64) * ys[ql])

    for q, qn in enumerate(STEER):
        qi = QOI_ALL.index(qn)
        dq = QF[cB][:, :, qi] - Q0[CS[cB], qi][:, None]
        frac, sd = (np.abs(dq) > MOVE_MM).mean(1), dq.std(1)
        ok = (frac >= (MIN_FRAC if qn in NEED_MOVE else 0.0)) & (sd > MOVE_MM)
        sel = cB[ok][np.argsort(-sd[ok])][:N_PER_FOLD]
        print(f"\n[{qn}] fold {fi + 1}: eligible {ok.sum()} -> steering {len(sel)}", flush=True)
        for j in sel:
            g = CS[j]
            rr_ = np.random.default_rng(int(g) * 100 + q)       # random directions do not depend on resume order
            if (qn, int(g)) in done_keys:
                continue
            lam0 = LAMS[g].astype(np.float32)
            z0 = Zall[g]
            sim_state, grip = SIMS[g], GRIPS[g].astype(np.float64)
            u0 = head_chunks(lam0[None])[0]
            r0 = rst(u0)[0]
            E = np.eye(PCA_K) * H_Z
            lp = np.stack([lam0 + to_lam(e) for e in E]); lm = np.stack([lam0 - to_lam(e) for e in E])
            up, um = head_chunks(lp), head_chunks(lm)
            Dphi = ((st(up) - st(um)) / (2 * H_Z)).T                                   # (ps, 32)
            Dphi_u = ((rst(up) - rst(um)) / (2 * H_Z)).T                               # (pr, 32)
            psp = np.array([qoi(run_chunk(cenv, sim_state, grip, c))[qi] for c in up])
            psm = np.array([qoi(run_chunk(cenv, sim_state, grip, c))[qi] for c in um])
            g_sim = (psp - psm) / (2 * H_Z)
            dirs = {"sim-gradient": g_sim.copy(), "linear": Dphi.T @ (b_inc[q] + W_inc[q].T @ z0)}
            for w in READOUT_W:
                dirs[f"MLP readout w{w}"] = mlp_dir(qn, "cf", w, z0, r0, Dphi, Dphi_u)
            for w in UNSTR_W:
                dirs[f"unstructured w{w}"] = mlp_dir(qn, "full", w, z0, r0, Dphi, Dphi_u)
            dirs["CAA"] = caa[q].copy()
            dirs["probe weight"] = a_pw[q].copy()
            for i in range(N_RANDOM):
                dirs[f"random{i}"] = rr_.normal(size=PCA_K)
            unit = {k_: v / (np.linalg.norm(v) + 1e-300) for k_, v in dirs.items()}
            cos_sim = {k_: float(unit[k_] @ unit["sim-gradient"]) for k_ in DIRS}
            cos_lin = {k_: float(unit[k_] @ unit["linear"]) for k_ in DIRS}
            lam_norm = float(np.linalg.norm(lam0))
            for k_ in dirs:
                dirs[k_] = dirs[k_] / (np.linalg.norm(zs * dirs[k_]) + 1e-300) * STEP_REL * lam_norm
            base = qoi(run_chunk(cenv, sim_state, grip, u0))[qi]
            curves = {}
            for k_, dz in dirs.items():
                lams_ = np.stack([lam0 + to_lam(t_ * dz) for t_ in TAUS if t_ != 0.0])
                vals = [qoi(run_chunk(cenv, sim_state, grip, c_))[qi] for c_ in head_chunks(lams_)]
                curves[k_] = np.insert(np.array(vals), TAUS.index(0.0), base) - Q0[g, qi]
            row = dict(qoi=qn, state=int(g), fold=fi, cos_sim=cos_sim, cos_lin=cos_lin,
                       J={k_: v for k_, v in curves.items()},
                       rho={k_: spearman(TAUS, v) for k_, v in curves.items()},
                       eff={k_: float(v[-1] - v[0]) for k_, v in curves.items()})
            DONE.append(row); done_keys.add((qn, int(g)))
            pickle.dump(DONE, open(PART + ".tmp", "wb")); os.replace(PART + ".tmp", PART)
            print(f"  state {g:5d} | " + " | ".join(
                f"{k_.replace('MLP readout ', 'RO ').replace('unstructured ', 'UN ')} rho {row['rho'][k_]:+.2f} "
                f"eff {1e3 * row['eff'][k_]:+5.1f} cos {cos_sim[k_]:+.2f}" for k_ in DIRS)
                  + " | random eff " + " ".join(f"{1e3 * row['eff'][f'random{i}']:+.1f}" for i in range(N_RANDOM)),
                  flush=True)
    torch.cuda.empty_cache()

header("6. SUMMARY  (held-out episodes, 2 folds; equal lambda displacement per tau; deterministic)")
save = {}
ALL = {}
for qn in STEER:
    rows = [r for r in DONE if r["qoi"] == qn]
    if not rows:
        continue
    print(f"\n{qn} ({len(rows)} states)")
    print(f"  {'direction':18s} | monotone (rho>0.8) | effect tau -8..8 (mm) | beats all randoms | cos to sim-grad | cos to linear")
    for nm in DIRS:
        rh = np.array([r["rho"][nm] for r in rows]); ef = np.array([r["eff"][nm] for r in rows])
        beat = np.array([r["eff"][nm] > max(r["eff"][f"random{i}"] for i in range(N_RANDOM)) for r in rows])
        cs = np.array([r["cos_sim"][nm] for r in rows]); cl = np.array([r["cos_lin"][nm] for r in rows])
        print(f"  {nm:18s} |       {np.mean(rh > 0.8):4.0%}         |      {1e3 * np.median(ef):+7.1f}         |"
              f"      {np.mean(beat):4.0%}        |     {np.median(cs):+.2f}       |    {np.median(cl):+.2f}")
        save[f"{qn}|{nm}|J"] = np.stack([r["J"][nm] for r in rows])
        save[f"{qn}|{nm}|cos"] = cs
        for key, v in (("mono", rh > 0.8), ("beat", beat), ("cos", cs), ("coslin", cl)):
            ALL.setdefault((nm, key), []).append(v)
    rh = np.array([r["rho"][f"random{i}"] for r in rows for i in range(N_RANDOM)])
    ef = np.array([r["eff"][f"random{i}"] for r in rows for i in range(N_RANDOM)])
    print(f"  {'random':18s} |       {np.mean(rh > 0.8):4.0%}         |      {1e3 * np.median(ef):+7.1f}         |        -         |       -")
    save[f"{qn}|state"] = np.array([r["state"] for r in rows])

print("\nPOOLED over all steered QoIs and states")
print(f"  {'direction':18s} | monotone | beats randoms | median cos to sim-grad | median cos to linear")
for nm in DIRS:
    m_ = np.concatenate(ALL[(nm, "mono")]); b_ = np.concatenate(ALL[(nm, "beat")])
    c_ = np.concatenate(ALL[(nm, "cos")]); l_ = np.concatenate(ALL[(nm, "coslin")])
    print(f"  {nm:18s} |   {m_.mean():4.0%}   |     {b_.mean():4.0%}      |        {np.median(c_):+.2f}            |     {np.median(l_):+.2f}")
for fi, nm, rr in R2LOG:
    save[f"r2|fold{fi}|{nm}"] = rr
np.savez(OUT_ST, taus=np.array(TAUS), step_rel=STEP_REL, steer=np.array(STEER), dirs=np.array(DIRS), **save)
print("""
READING
=======
linear ~ MLP readout (cos to linear near 1, same monotone share)
    -> the nonlinear readout finds the same direction; the bilinear structure is what carries steering.
unstructured clearly below the readouts despite similar R^2
    -> a good fit of f(z, u) does not give a usable gradient in u; the signature structure is what makes
       the probe's gradient reliable (it is linear in S, so its gradient is the fitted coefficient itself).
unstructured ~ linear
    -> steering does not need the structure either; the case for the linear probe rests on Q1/Q2/Q3, not on Q4.
""")
stamp(f"saved {OUT_ST}")
'''

with open("/content/run_oft_steer_mlp.py", "w") as f:
    f.write(SCRIPT)
LOG = "/content/drive/MyDrive/aclrh/oft_steering_mlp_log.txt"
print(f"\nrunning steering in the Python 3.10 venv ... (log: {LOG})\n", flush=True)
rc = -1
try:
    with open(LOG, "a") as logf:
        p = subprocess.Popen([VPY, "-u", "/content/run_oft_steer_mlp.py"], stdout=subprocess.PIPE,
                             stderr=subprocess.STDOUT, text=True, bufsize=1,
                             env={**os.environ, "MUJOCO_GL": "egl", "MPLBACKEND": "Agg", "TF_CPP_MIN_LOG_LEVEL": "2",
                                  "PYTHONPATH": f"{OFT}:{LIB}:" + os.environ.get("PYTHONPATH", "")})
        for line in p.stdout:
            print(line, end="")
            logf.write(line); logf.flush()
        rc = p.wait()
        msg = f"\nReturn code: {rc}\n" + ("COMPLETE" if rc == 0 else "Stopped; rerun the cell to resume.") + "\n"
        print(msg); logf.write(msg)
finally:
    if AUTO_SHUTDOWN:
        print("shutting the runtime down (AUTO_SHUTDOWN) ...", flush=True)
        try:
            from google.colab import drive as _d
            _d.flush_and_unmount()
        except Exception as ex:
            print("  (flush:", ex, ")")
        from google.colab import runtime
        runtime.unassign()
