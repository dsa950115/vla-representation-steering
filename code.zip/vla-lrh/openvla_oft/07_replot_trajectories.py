# Re-plot the closed-loop trajectory figures from the saved .pkl files (normal Colab Python, no simulator).
# Usage: mount Drive, run this cell; edit plot_trajectories() to change the style.
import glob, pickle
import numpy as np
import matplotlib
matplotlib.use("Agg")

def plot_trajectories(D, out_png):
    """D: dict with img (H,W,3), alphas, concepts, and per concept: uv[a] (T,2), xyz[a] (T,3), p0 (15,)"""
    import numpy as np
    import matplotlib.pyplot as plt
    from matplotlib import cm, colors
    alphas = list(D["alphas"])
    norm = colors.Normalize(vmin=min(alphas), vmax=max(alphas))
    cmap_ = plt.get_cmap("coolwarm")
    col = lambda a: "k" if a == 0 else cmap_(norm(a))
    concepts = list(D["concepts"])
    nice = {"-d(EE,mug1)": "approach the white mug", "-d(EE,mug2)": "approach the yellow-and-white mug"}
    fig, axes = plt.subplots(len(concepts), 2, figsize=(10.5, 5.0 * len(concepts)),
                             gridspec_kw=dict(width_ratios=[1, 1], wspace=0.08, hspace=0.18))
    axes = np.atleast_2d(axes)
    for r, c in enumerate(concepts):
        C = D[c]; p0 = C["p0"]
        # ---- camera image with projected trajectories ----
        ax = axes[r, 0]; ax.imshow(D["img"]); ax.set_axis_off()
        for a in alphas:
            uv = C["uv"][a]; ax.plot(uv[:, 1], uv[:, 0], "-", color=col(a), lw=2.4, solid_capstyle="round")
            ax.plot(uv[-1, 1], uv[-1, 0], "o", color=col(a), ms=4)
        for key, mk, ec in [("uv_mug1", "o", "lime"), ("uv_mug2", "s", "yellow")]:
            q = C[key]; ax.plot(q[1], q[0], mk, mfc="none", mec=ec, ms=15, mew=2.5)
        ax.set_title(f"concept: {nice.get(c, c)}", fontsize=11, loc="left")
        # ---- top-down view, oriented like the camera (horizontal = -y, vertical = x) ----
        ax = axes[r, 1]
        H = lambda P: -P[..., 1] * 100          # horizontal: left/right as in the image
        V = lambda P: P[..., 0] * 100           # vertical
        pts = [np.stack([H(C["xyz"][a]), V(C["xyz"][a])], -1) for a in alphas]
        mugs = [(p0[3:6], "green", "white mug"), (p0[6:9], "goldenrod", "yellow-and-white mug")]
        allp = np.concatenate(pts + [np.array([[H(m), V(m)]]) for m, _, _ in mugs])
        cx, cy = (allp.min(0) + allp.max(0)) / 2
        half = (allp.max(0) - allp.min(0)).max() / 2 + 5.0
        for m, fc, lab in mugs:
            ax.add_patch(plt.Circle((H(m), V(m)), 4.0, fc=fc, ec="none", alpha=0.25))
            ax.add_patch(plt.Circle((H(m), V(m)), 4.0, fc="none", ec=fc, lw=1.5))
            ax.text(H(m), V(m) - 5.6, lab, ha="center", va="top", fontsize=8, color=fc)
        for a, p in zip(alphas, pts):
            ax.plot(p[:, 0], p[:, 1], "-", color=col(a), lw=2.2, solid_capstyle="round")
            ax.plot(p[-1, 0], p[-1, 1], "o", color=col(a), ms=5)
        ax.plot(pts[0][0, 0], pts[0][0, 1], "kx", ms=9, mew=2)
        ax.text(pts[0][0, 0], pts[0][0, 1] + 1.2, "start", ha="center", va="bottom", fontsize=8)
        ax.set_xlim(cx - half, cx + half); ax.set_ylim(cy - half, cy + half); ax.set_aspect("equal")
        ax.set_xticks([]); ax.set_yticks([])
        for s_ in ax.spines.values(): s_.set_color("0.7")
        ax.plot([cx + half - 11, cx + half - 1], [cy - half + 2] * 2, "k-", lw=2)      # 10 cm scale bar
        ax.text(cx + half - 6, cy - half + 2.8, "10 cm", ha="center", va="bottom", fontsize=8)
        ax.set_title("top-down view (end effector)", fontsize=11, loc="left")
    sm = cm.ScalarMappable(norm=norm, cmap=cmap_); sm.set_array([])
    cb = fig.colorbar(sm, ax=axes.ravel().tolist(), fraction=0.025, pad=0.02, ticks=alphas)
    cb.set_label(r"steering strength $\alpha$ (0 = unsteered policy)")
    fig.savefig(out_png, dpi=170, bbox_inches="tight"); plt.close(fig)


def plot_trajectories_compact(D, out_png):
    """main-text version: the two top-down views side by side, shared alpha colorbar (wide and short)"""
    import numpy as np
    import matplotlib.pyplot as plt
    from matplotlib import cm, colors
    alphas = list(D["alphas"])
    norm = colors.Normalize(vmin=min(alphas), vmax=max(alphas))
    cmap_ = plt.get_cmap("coolwarm")
    col = lambda a: "k" if a == 0 else cmap_(norm(a))
    concepts = list(D["concepts"])
    titles = {"-d(EE,mug1)": r"$\psi=-d(\mathrm{EE},\mathrm{mug}_1)$  (white mug)",
              "-d(EE,mug2)": r"$\psi=-d(\mathrm{EE},\mathrm{mug}_2)$  (yellow-and-white mug)"}
    H = lambda P: -P[..., 1] * 100
    V = lambda P: P[..., 0] * 100
    # common view window for both panels
    allp = []
    for c in concepts:
        C = D[c]
        allp += [np.stack([H(C["xyz"][a]), V(C["xyz"][a])], -1) for a in alphas]
        allp += [np.array([[H(C["p0"][3:6]), V(C["p0"][3:6])]]), np.array([[H(C["p0"][6:9]), V(C["p0"][6:9])]])]
    allp = np.concatenate(allp)
    cx, cy = (allp.min(0) + allp.max(0)) / 2
    hx = (allp[:, 0].max() - allp[:, 0].min()) / 2 + 5.0
    hy = (allp[:, 1].max() - allp[:, 1].min()) / 2 + 7.0
    fig, axes = plt.subplots(1, len(concepts), figsize=(4.6 * len(concepts) + 1.0, 3.3))
    axes = np.atleast_1d(axes)
    for ax, c in zip(axes, concepts):
        C = D[c]; p0 = C["p0"]
        for m, fc, lab in [(p0[3:6], "green", "white mug"), (p0[6:9], "goldenrod", "yellow-and-white mug")]:
            ax.add_patch(plt.Circle((H(m), V(m)), 4.0, fc=fc, ec="none", alpha=0.25))
            ax.add_patch(plt.Circle((H(m), V(m)), 4.0, fc="none", ec=fc, lw=1.5))
            ax.text(H(m), V(m) - 5.3, lab, ha="center", va="top", fontsize=8, color=fc)
        for a in alphas:
            p = np.stack([H(C["xyz"][a]), V(C["xyz"][a])], -1)
            ax.plot(p[:, 0], p[:, 1], "-", color=col(a), lw=2.0, solid_capstyle="round")
            ax.plot(p[-1, 0], p[-1, 1], "o", color=col(a), ms=4)
        s0 = np.array([H(C["xyz"][alphas[0]][0]), V(C["xyz"][alphas[0]][0])])
        ax.plot(*s0, "kx", ms=8, mew=2); ax.text(s0[0], s0[1] + 1.2, "start", ha="center", va="bottom", fontsize=8)
        ax.set_xlim(cx - hx, cx + hx); ax.set_ylim(cy - hy, cy + hy); ax.set_aspect("equal")
        ax.set_xticks([]); ax.set_yticks([])
        for s_ in ax.spines.values(): s_.set_color("0.7")
        ax.plot([cx - hx + 1, cx - hx + 11], [cy - hy + 1.5] * 2, "k-", lw=2)     # scale bar, lower left
        ax.text(cx - hx + 6, cy - hy + 2.3, "10 cm", ha="center", va="bottom", fontsize=7)
        ax.set_title(titles.get(c, c), fontsize=10)
    sm = cm.ScalarMappable(norm=norm, cmap=cmap_); sm.set_array([])
    cb = fig.colorbar(sm, ax=list(axes), fraction=0.03, pad=0.02, ticks=alphas)
    cb.set_label(r"$\alpha$")
    fig.savefig(out_png, dpi=200, bbox_inches="tight"); plt.close(fig)


FIG = "/content/drive/MyDrive/aclrh/figs"
import os
assert os.path.isdir("/content/drive/MyDrive"), "Drive is not mounted: from google.colab import drive; drive.mount('/content/drive')"
PKLS = sorted(glob.glob(f"{FIG}/B_ep*_trajectories.pkl"))
print(f"found {len(PKLS)} trajectory file(s) in {FIG}:", [os.path.basename(f) for f in PKLS])
if not PKLS:
    raise FileNotFoundError("no B_ep*_trajectories.pkl: run 06_figures.py once with RUN_B = True "
                            "(it saves the .pkl and the figures)")
for f in PKLS:
    with open(f, "rb") as fh:
        D = pickle.load(fh)
    out = f.replace(".pkl", ".png")
    plot_trajectories(D, out)
    plot_trajectories_compact(D, out.replace(".png", "_compact.png"))
    print("saved", out, "and", out.replace(".png", "_compact.png"))
