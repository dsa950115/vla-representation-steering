# Main-text figure: (a,b) closed-loop EE trajectories on the camera image for the two EE-mug QoIs,
# (c) single-chunk response curves J(alpha) - J(0) for one QoI (all held-out states).
# Plain Colab Python (no model, no simulator). Needs Drive mounted and:
#   figs/B_epXX_trajectories.pkl   (written by 06_figures.py, RUN_B)
#   oft_steering_taskqoi.npz       (written by 05b)
import pickle
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patheffects as pe
from matplotlib import cm, colors

ROOT = "/content/drive/MyDrive/aclrh"
EP = 3                                        # held-out episode shown in (a, b)
CURVE_FILE, CURVE_QOI = f"{ROOT}/oft_steering_taskqoi.npz", "-d(mug1,plate) xy"
CURVE_TITLE = r"(c) $\psi=-d(\mathrm{mug}_1,\mathrm{plate})$, one chunk"
OUT = f"{ROOT}/figs/main_steering.png"
CROP_PAD = 28                                 # pixels around trajectories and mugs

plt.rcParams.update({"font.family": "serif", "mathtext.fontset": "stix", "font.size": 8})
TEXT_W = 5.5          # inches: text width of the paper, so fonts print at their nominal size


def crop_box(C_list, img_shape, pad):
    pts = []
    for C in C_list:
        for a in C["uv"]:
            pts.append(C["uv"][a])
        pts += [C["uv_mug1"][None], C["uv_mug2"][None]]
    pts = np.concatenate(pts)
    r0, c0 = np.maximum(pts.min(0) - pad, 0).astype(int)
    r1, c1 = np.minimum(pts.max(0) + pad, np.array(img_shape[:2]) - 1).astype(int)
    # make it roughly square so both panels look alike
    h, w = r1 - r0, c1 - c0
    if h < w:
        d = (w - h) // 2; r0, r1 = max(r0 - d, 0), min(r1 + d, img_shape[0] - 1)
    else:
        d = (h - w) // 2; c0, c1 = max(c0 - d, 0), min(c1 + d, img_shape[1] - 1)
    return r0, r1, c0, c1


def main():
    with open(f"{ROOT}/figs/B_ep{EP:02d}_trajectories.pkl", "rb") as f:
        D = pickle.load(f)
    alphas = list(D["alphas"])
    norm = colors.Normalize(vmin=min(alphas), vmax=max(alphas))
    cmap_ = plt.get_cmap("coolwarm")
    col = lambda a: "k" if a == 0 else cmap_(norm(a))
    concepts = ["-d(EE,mug1)", "-d(EE,mug2)"]
    names = {"-d(EE,mug1)": r"(a) $\psi=-d(\mathrm{EE},\mathrm{mug}_1)$",
             "-d(EE,mug2)": r"(b) $\psi=-d(\mathrm{EE},\mathrm{mug}_2)$"}
    r0, r1, c0, c1 = crop_box([D[c] for c in concepts], D["img"].shape, CROP_PAD)

    fig = plt.figure(figsize=(TEXT_W, 1.85))
    gs = fig.add_gridspec(1, 5, width_ratios=[1, 1, 0.045, 0.62, 1.25], wspace=0.07)   # col 3 = spacer
    outline = [pe.Stroke(linewidth=2.4, foreground="white", alpha=0.85), pe.Normal()]
    for k, c in enumerate(concepts):
        ax = fig.add_subplot(gs[0, k]); C = D[c]
        ax.imshow(D["img"][r0:r1 + 1, c0:c1 + 1], extent=(c0, c1 + 1, r1 + 1, r0))
        for a in alphas:
            uv = C["uv"][a]
            ax.plot(uv[:, 1], uv[:, 0], "-", color=col(a), lw=1.3, solid_capstyle="round", path_effects=outline)
            ax.plot(uv[-1, 1], uv[-1, 0], "o", color=col(a), ms=2.6, mec="white", mew=0.5)
        s = C["uv"][alphas[0]][0]
        ax.plot(s[1], s[0], "X", color="white", ms=5, mec="k", mew=0.6)
        for key, mk, ec, lab in [("uv_mug1", "o", "#39ff14", r"mug$_1$"), ("uv_mug2", "s", "#ffd400", r"mug$_2$")]:
            q = C[key]
            ax.plot(q[1], q[0], mk, mfc="none", mec=ec, ms=8, mew=1.2)
            ax.text(q[1], q[0] + 12, lab, color=ec, ha="center", va="top", fontsize=7,
                    path_effects=[pe.withStroke(linewidth=1.5, foreground="black")])
        ax.set_xlim(c0, c1 + 1); ax.set_ylim(r1 + 1, r0)
        ax.set_xticks([]); ax.set_yticks([])
        ax.set_title(names[c], fontsize=7.5, loc="left", pad=2)
        img_ax = ax
    cax = fig.add_subplot(gs[0, 2])
    sm = cm.ScalarMappable(norm=norm, cmap=cmap_); sm.set_array([])
    fig.canvas.draw()                                   # match the colorbar height to the image panels
    pi, pc = img_ax.get_position(), cax.get_position()
    cax.set_position([pc.x0, pi.y0, pc.width, pi.height])
    cb = fig.colorbar(sm, cax=cax, ticks=alphas); cb.set_label(r"$\alpha$", labelpad=1)
    cb.ax.tick_params(labelsize=6.5, length=2)

    # (c) response curves for one QoI, all held-out states
    ax = fig.add_subplot(gs[0, 4])
    R = np.load(CURVE_FILE); taus = R["taus"]; i0 = list(taus).index(0.0)
    for key, c_, ls, lab in [("sim-gradient", "0.45", "--", "oracle (simulator)"),
                             ("Dphi^T lambda_psi", "C3", "-", r"$\lambda_\psi$ (ours)"),
                             ("gamma_psi", "C0", "-", r"$\gamma_\psi$"),
                             ("static", "k", "-", "static")]:
        J = 1e3 * R[f"{CURVE_QOI}|{key}|J"]; J = J - J[:, [i0]]
        med, lo, hi = np.median(J, 0), np.percentile(J, 25, 0), np.percentile(J, 75, 0)
        ax.plot(taus, med, ls, color=c_, lw=1.3, label=lab)
        ax.fill_between(taus, lo, hi, color=c_, alpha=0.15, lw=0)
    ax.axhline(0, color="0.85", lw=0.8, zorder=0)
    ax.set_xlabel(r"$\alpha$", labelpad=1); ax.set_ylabel(r"$J(\alpha)-J(0)$ (mm)", labelpad=1)
    ax.tick_params(labelsize=6.5, length=2, pad=1)
    lo_, hi_ = ax.get_ylim(); ax.set_ylim(lo_, hi_ + 0.75 * (hi_ - lo_))          # room for the legend
    ax.grid(alpha=0.3)
    ax.legend(fontsize=5.8, loc="upper left", ncol=2, frameon=False, handlelength=1.4, columnspacing=0.8,
              borderaxespad=0.15, labelspacing=0.25)
    ax.set_title(CURVE_TITLE, fontsize=7.5, loc="left", pad=2)
    fig.savefig(OUT, dpi=400, bbox_inches="tight", pad_inches=0.02)
    print("saved", OUT)


main()
