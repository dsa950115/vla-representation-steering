# ======================================================================
# OpenVLA-OFT — STEP 1: environment + verification  (run as ONE Colab cell, A100)
#
#   1. builds a separate Python 3.10 venv (/content/oftenv) with torch 2.2 (cu121),
#      openvla-oft (+ its transformers fork) and LIBERO
#   2. runs a verification script inside that venv:
#        - loads moojink/openvla-7b-oft-finetuned-libero-10
#        - closed-loop rollouts on the mug task (success check)
#        - captures lambda = action-token hidden states entering the L1 action head
#        - checks that the head applied to the captured lambda reproduces the action chunk
#
#   Nothing is written to Drive in this step. Re-running the cell skips finished installs.
# ======================================================================
import os, subprocess, sys, textwrap, time

VENV = "/content/oftenv"
VPY = f"{VENV}/bin/python"
OFT = "/content/openvla-oft"
LIB = "/content/LIBERO"
MARK = f"{VENV}/.setup_done"


def sh(cmd, check=True):
    print(f"$ {cmd}", flush=True)
    r = subprocess.run(cmd, shell=True, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    tail = "\n".join(r.stdout.strip().splitlines()[-15:])
    if tail:
        print(tail, flush=True)
    if check and r.returncode != 0:
        raise RuntimeError(f"failed ({r.returncode}): {cmd}")
    return r.returncode


# ---------------------------------------------------------------- 0. GPU check
assert subprocess.run(["nvidia-smi"], stdout=subprocess.DEVNULL).returncode == 0, \
    "No GPU visible: switch the runtime to GPU (A100) and reconnect."

# ---------------------------------------------------------------- 1. setup (once)
if not os.path.exists(MARK):
    t0 = time.time()
    sh("pip install -q uv")
    sh("uv python install 3.10")
    sh(f"rm -rf {VENV}")                                # a half-built venv without the marker: start clean
    sh(f"uv venv {VENV} --python 3.10 --seed")
    UV = f"uv pip install --python {VPY}"
    sh(f"{UV} torch==2.2.0 torchvision==0.17.0 --index-url https://download.pytorch.org/whl/cu121")
    sh(f"{UV} numpy==1.26.4")
    if not os.path.exists(OFT):
        sh(f"git clone -q https://github.com/moojink/openvla-oft.git {OFT}")
    sh(f"{UV} -e {OFT}")                                   # pulls the transformers fork and pinned deps
    if not os.path.exists(LIB):
        sh(f"git clone -q https://github.com/Lifelong-Robot-Learning/LIBERO.git {LIB}")
    sh(f"{UV} -e {LIB}")
    sh(f"{UV} -r {OFT}/experiments/robot/libero/libero_requirements.txt")
    sh(f"{UV} numpy==1.26.4")                             # re-pin in case a dependency upgraded it
    # flash-attn: prebuilt wheel for torch 2.2 / py3.10; if it fails the verification falls back to sdpa
    rc = sh(f"{UV} https://github.com/Dao-AILab/flash-attention/releases/download/v2.5.5/"
            "flash_attn-2.5.5+cu122torch2.2cxx11abiFALSE-cp310-cp310-linux_x86_64.whl", check=False)
    print("flash-attn installed" if rc == 0 else "flash-attn NOT installed -> sdpa fallback")
    # LIBERO asks interactively for its data paths on first import: write the config up front
    os.makedirs(os.path.expanduser("~/.libero"), exist_ok=True)
    base = f"{LIB}/libero/libero"
    with open(os.path.expanduser("~/.libero/config.yaml"), "w") as f:
        f.write(textwrap.dedent(f"""\
            benchmark_root: {base}
            bddl_files: {base}/bddl_files
            init_states: {base}/init_files
            datasets: {LIB}/datasets
            assets: {base}/assets
            """))
    open(MARK, "w").write("ok")
    print(f"setup finished in {(time.time() - t0) / 60:.1f} min")
else:
    print("setup already done")

# ---------------------------------------------------------------- 1b. dependency fixes (idempotent)
# tensorflow_datasets is imported by openvla-oft at import time; a too-new tensorflow-metadata needs
# protobuf 5 (google.protobuf.runtime_version), which TF 2.15 cannot use -> pin the TF-2.15-era version
if sh(f"{VPY} -c \"import tensorflow_datasets\"", check=False) != 0:
    sh(f"uv pip install --python {VPY} tensorflow-metadata==1.14.0")
    sh(f"{VPY} -c \"import tensorflow_datasets, google.protobuf as p; print('tfds OK | protobuf', p.__version__)\"")

# robosuite 1.4 predates the MuJoCo >= 3.2 joint-type API (get_joint_qpos_addr assertion) -> pin 3.1.6
_mj = subprocess.run([VPY, "-c", "import mujoco; print(mujoco.__version__)"], text=True,
                     stdout=subprocess.PIPE, stderr=subprocess.DEVNULL).stdout.strip()
print("mujoco in venv:", _mj or "not installed")
if not _mj.startswith("3.1."):
    sh(f"uv pip install --python {VPY} mujoco==3.1.6")
os.makedirs(f"{LIB}/datasets", exist_ok=True)          # silences LIBERO's missing-datasets warning

sh(f"{VPY} -c \"import torch, transformers, numpy; print('torch', torch.__version__, 'cuda', "
   f"torch.cuda.is_available(), '| transformers', transformers.__version__, '| numpy', numpy.__version__)\"")

# ---------------------------------------------------------------- 2. verification script (runs in the venv)
SCRIPT = r'''
import os, sys, time, traceback
os.environ.setdefault("MUJOCO_GL", "egl")
os.environ.setdefault("PYOPENGL_PLATFORM", "egl")
os.environ["MPLBACKEND"] = "Agg"
sys.path.insert(0, "/content/openvla-oft")
sys.path.insert(0, "/content/LIBERO")          # LIBERO's setup.py is not exposed by uv editable installs
import numpy as np
import torch

CKPT = "moojink/openvla-7b-oft-finetuned-libero-10"
UNNORM = "libero_10_no_noops"
TASK_KEYWORDS = ("white mug", "left plate", "yellow and white mug", "right plate")
N_EPISODES = 3
MAX_STEPS = 520
NUM_WAIT = 10

def header(t):
    print("\n" + "=" * 90 + f"\n{t}\n" + "=" * 90, flush=True)

header("1. IMPORTS")
# wandb is only used for evaluation logging; the installed wandb needs a newer protobuf than
# TF 2.15 allows, so register a no-op stand-in instead of touching protobuf again
import types, importlib.machinery
_wb = types.ModuleType("wandb")
_wb.__spec__ = importlib.machinery.ModuleSpec("wandb", None)   # find_spec() (accelerate/transformers) needs a spec
_wb.__version__ = "0.0.0"
for _name in ("init", "log", "finish", "login", "config", "save", "watch"):
    setattr(_wb, _name, lambda *a, **k: None)
_wb.run = None
sys.modules["wandb"] = _wb
from experiments.robot.libero.run_libero_eval import GenerateConfig
import experiments.robot.libero.run_libero_eval as rle
import experiments.robot.openvla_utils as ou
import experiments.robot.libero.libero_utils as lu
import experiments.robot.robot_utils as ru
from libero.libero import benchmark
print("run_libero_eval exports:", [n for n in dir(rle) if not n.startswith("_")][:60])

try:
    import flash_attn  # noqa
    ATTN = "flash_attention_2"
except Exception:
    ATTN = "sdpa"
print("attention implementation:", ATTN)

header("2. LOAD OPENVLA-OFT (LIBERO-10)")
cfg = GenerateConfig(
    pretrained_checkpoint=CKPT, use_l1_regression=True, use_diffusion=False, use_film=False,
    num_images_in_input=2, use_proprio=True, load_in_8bit=False, load_in_4bit=False,
    center_crop=True, num_open_loop_steps=8, unnorm_key=UNNORM,
)
if hasattr(cfg, "task_suite_name"):
    cfg.task_suite_name = "libero_10"
if hasattr(cfg, "model_family"):
    cfg.model_family = "openvla"
t0 = time.time()
if ATTN != "flash_attention_2":
    # route the loader to sdpa if flash-attn is missing
    from transformers import AutoModelForVision2Seq
    _orig_fp = AutoModelForVision2Seq.from_pretrained
    def _fp(*a, **kw):
        kw["attn_implementation"] = "sdpa"
        return _orig_fp(*a, **kw)
    AutoModelForVision2Seq.from_pretrained = _fp
vla = ou.get_vla(cfg)
processor = ou.get_processor(cfg)
action_head = ou.get_action_head(cfg, llm_dim=vla.llm_dim)
proprio_projector = ou.get_proprio_projector(cfg, llm_dim=vla.llm_dim, proprio_dim=8)
print(f"loaded in {time.time() - t0:.0f}s | llm_dim {vla.llm_dim} | unnorm keys: {list(getattr(vla, 'norm_stats', {}).keys())[:8]}")

# ---- lambda hook: capture (and later intervene on) the input of the L1 action head ----
LAM = {"cap": None, "delta": None}
_orig_predict = action_head.predict_action
def _predict(actions_hidden_states, *a, **kw):
    LAM["cap"] = actions_hidden_states.detach().float().cpu()
    if LAM["delta"] is not None:
        actions_hidden_states = actions_hidden_states + LAM["delta"].to(actions_hidden_states.device,
                                                                          actions_hidden_states.dtype)
    return _orig_predict(actions_hidden_states, *a, **kw)
action_head.predict_action = _predict

def policy_chunk(obs, task_label):
    observation, _ = rle.prepare_observation(obs, ru.get_image_resize_size(cfg)) \
        if hasattr(rle, "prepare_observation") else (None, None)
    actions = ou.get_vla_action(cfg, vla, processor, observation, task_label, action_head, proprio_projector)
    return np.asarray(actions)

header("3. TASK")
suite = benchmark.get_benchmark_dict()["libero_10"]()
tid = None
for i in range(suite.n_tasks):
    lang = suite.get_task(i).language
    if all(k in lang for k in TASK_KEYWORDS):
        tid = i
        break
assert tid is not None, [suite.get_task(i).language for i in range(suite.n_tasks)]
task = suite.get_task(tid)
init_states = suite.get_task_init_states(tid)
env, task_description = lu.get_libero_env(task, "openvla", resolution=256)
print(f"task {tid}: {task_description} | init states {len(init_states)}")

header("4. CLOSED-LOOP ROLLOUTS + LAMBDA CHECKS")
succ, t_policy, lam_shape, head_err = [], [], None, []
for ep in range(N_EPISODES):
    env.reset()
    obs = env.set_init_state(init_states[ep])
    done, t, queue = False, 0, []
    while t < MAX_STEPS + NUM_WAIT:
        if t < NUM_WAIT:
            obs, _, done, _ = env.step(lu.get_libero_dummy_action("openvla")); t += 1; continue
        if not queue:
            t1 = time.time()
            chunk = policy_chunk(obs, task_description)
            t_policy.append(time.time() - t1)
            lam = LAM["cap"]
            lam_shape = tuple(lam.shape)
            if len(t_policy) <= 3:   # head reproducibility: apply the head to the captured lambda
                with torch.no_grad():
                    na = _orig_predict(lam.to(next(action_head.parameters()).device,
                                              next(action_head.parameters()).dtype))
                    na = na.float().cpu().numpy().reshape(chunk.shape)
                try:
                    ua = vla._unnormalize_actions(na[None] if na.ndim == 2 else na, UNNORM)
                    head_err.append(float(np.abs(np.asarray(ua).reshape(chunk.shape)[:, :6] - chunk[:, :6]).max()))
                except Exception as e:
                    head_err.append(float("nan")); print("[info] unnormalize check skipped:", repr(e))
            queue = list(chunk)
        a = rle.process_action(queue.pop(0), "openvla")
        obs, _, done, _ = env.step(a.tolist())
        t += 1
        if done:
            break
    succ.append(bool(done))
    print(f"episode {ep}: success {done} | steps {t} | policy calls {len(t_policy)}", flush=True)

header("5. SUMMARY")
print(f"success {sum(succ)}/{len(succ)}")
print(f"policy call time: median {np.median(t_policy) * 1e3:.0f} ms")
print(f"lambda (action-head input) shape: {lam_shape}  -> dim {int(np.prod(lam_shape[1:])) if lam_shape else None}")
print(f"head(lambda) vs policy chunk, max abs diff on arm dims: {head_err}")
print("""
READING
=======
success          should be high for this checkpoint (the paper reports ~95% on LIBERO-10);
                 a low value means the observation / action conventions are off.
lambda shape     (1, 56, 4096) expected: 8 steps x 7 action dims, llm_dim 4096.
head check       ~0 means the action is a function of the captured lambda alone, i.e. lambda is the
                 complete input of the action map and can be intervened on directly.
""")
'''

with open("/content/run_oft_verify.py", "w") as f:
    f.write(SCRIPT)
print("\nrunning verification in the Python 3.10 venv ...\n", flush=True)
p = subprocess.Popen([VPY, "-u", "/content/run_oft_verify.py"], stdout=subprocess.PIPE,
                     stderr=subprocess.STDOUT, text=True,
                     env={**os.environ, "MUJOCO_GL": "egl",
                          "MPLBACKEND": "Agg",          # Colab sets a notebook-only backend
                          "TF_CPP_MIN_LOG_LEVEL": "2",  # silence TensorFlow start-up noise
                          "PYTHONPATH": f"{OFT}:{LIB}:" + os.environ.get("PYTHONPATH", "")})
for line in p.stdout:
    print(line, end="")
p.wait()
print(f"\nReturn code: {p.returncode}")
