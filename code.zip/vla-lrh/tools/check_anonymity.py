"""Anonymity check before a release: fails if a forbidden string, an e-mail address or a hidden file is found.

    python tools/check_anonymity.py --forbid "<author name>" "<affiliation>" "<e-mail>"
"""
import argparse, os, re, sys

ap = argparse.ArgumentParser()
ap.add_argument("--forbid", nargs="*", default=[], help="strings that must not appear (case-insensitive)")
ap.add_argument("--root", default=os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
a = ap.parse_args()
pats = [(s, re.compile(re.escape(s), re.I)) for s in a.forbid if s]
email = re.compile(r"[\w.+-]+@[\w-]+\.[a-z]{2,}", re.I)
ALLOWED_EMAIL = set()                                    # add addresses that may appear (none by default)
ALLOWED_HIDDEN = {".gitignore"}
hits = []
for dp, dns, fns in os.walk(a.root):
    dns[:] = [d for d in dns if d != ".git"]
    for fn in fns:
        p = os.path.join(dp, fn); rel = os.path.relpath(p, a.root)
        if fn.startswith(".") and fn not in ALLOWED_HIDDEN:
            hits.append((rel, "hidden file"))
        try:
            text = open(p, encoding="utf-8").read()
        except (UnicodeDecodeError, OSError):
            continue
        for s, r in pats:
            for m in r.finditer(text):
                hits.append((rel, f"'{s}' at line {text.count(chr(10), 0, m.start()) + 1}"))
        for m in email.finditer(text):
            if m.group(0) not in ALLOWED_EMAIL:
                hits.append((rel, f"e-mail address {m.group(0)}"))
for rel, what in hits:
    print(f"[!] {rel}: {what}")
if not a.forbid:
    print("(no --forbid strings given: only e-mail addresses and hidden files were checked)")
print("anonymity check:", "FAILED" if hits else "OK")
sys.exit(1 if hits else 0)
