# ======================================================================
# Use-case figure for the paper (Figure 2)  --  ONE Colab cell, CPU runtime
#   reads   aclrh/intent_change_confirm/ (step 18: key frames, headline numbers, strength sweep if it ran one)
#           aclrh/intent_change/          (step 16: strength sweep for panel b otherwise)
#   writes  <key-frame dir>/fig_usecase.(png|pdf): (a) key frames, instruction vs. steering, on one held-out start
#                                                   (b) outcome by steering strength
# ======================================================================
import os, json
import numpy as np
import imageio.v2 as imageio
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
try:
    from google.colab import drive
    if not os.path.isdir("/content/drive/MyDrive"):
        drive.mount("/content/drive")
except ImportError:
    pass

ROOT = os.environ.get("UC_ROOT", "/content/drive/MyDrive/aclrh")
DIR = f"{ROOT}/intent_change_confirm" if os.path.exists(f"{ROOT}/intent_change_confirm/results.json") else f"{ROOT}/intent_change"
# panel (b): the confirmation run's own sweep if step 18 ran one, else step 16's
SWEEP_DIR = DIR if any("|sweep" in k for k in json.load(open(f"{DIR}/results.json"))["test"]) else f"{ROOT}/intent_change"
EPISODE = None                         # None: the first test start where steering succeeds
ROWS = ["B_lang_put", "D_steer"]       # rows of panel (a); add "A_original", "C_lang_move" or "sweep16", ... if wanted
TIMES = [0.5, 3.0, 5.5, 8.0, 10.5]    # s; a run that ended earlier shows its last frame
CROP_TOP = 54                          # px of the on-screen text overlay to cut from each frame (0 keeps it)
ROW_LABEL = {"A_original": "original instruction", "B_lang_put": "new instruction",
             "C_lang_move": "new instruction (2)", "D_steer": "steering (ours)"}
OUTCOMES = ["success", "knocked a mug", "went for the white mug", "grasped, not placed", "no grasp"]
CAT = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4"]          # categorical slots 1-5, fixed order
INK, INK2, GRIDC, SURF = "#0b0b0b", "#52514e", "#e1e0d9", "#ffffff"


def outcome(r):
    if r["success"]:
        return "success"
    if r["tipped"] or (r["white_move_cm"] >= 3.0 and r["first_lift"] != "white"):
        return "knocked a mug"
    if r["first_lift"] == "white":
        return "went for the white mug"
    if r["first_lift"] == "yellow":
        return "grasped, not placed"
    return "no grasp"


R = json.load(open(f"{DIR}/results.json"))
eps = sorted({int(k.split("|")[0]) for k in R["test"]})
chosen = float(R["chosen"]["alpha"])
E = EPISODE if EPISODE is not None else next((e for e in eps if R["test"].get(f"{e}|D_steer", {}).get("success")), eps[0])
print(f"key frames from held-out start {E}; steering alpha {chosen:.0f}")

def frames_at(path, times, fps=20):
    fr = imageio.mimread(path, memtest=False)
    return [fr[min(int(t * fps), len(fr) - 1)][CROP_TOP:] for t in times], len(fr) / fps

plt.rcParams.update({"font.size": 8, "axes.edgecolor": "#c3c2b7", "axes.labelcolor": INK2,
                     "xtick.color": INK2, "ytick.color": INK2})
nT, nR = len(TIMES), len(ROWS)
fig = plt.figure(figsize=(7.0, 0.86 * nR + 0.5))
gs = fig.add_gridspec(nR, nT + 3, width_ratios=[1] * nT + [0.42, 1.25, 0.55], wspace=0.04, hspace=0.06)
for i, cond in enumerate(ROWS):
    fr, dur = frames_at(f"{DIR}/test_ep{E:02d}_{cond}.mp4", TIMES)
    res = R["test"].get(f"{E}|{cond}")
    for j, (img, t) in enumerate(zip(fr, TIMES)):
        ax = fig.add_subplot(gs[i, j]); ax.imshow(img); ax.set_xticks([]); ax.set_yticks([])
        for sp in ax.spines.values():
            sp.set_visible(False)
        if i == 0:
            ax.set_title(f"t = {min(t, dur):.1f} s", fontsize=7.5, color=INK2, pad=2)
        if j == 0:
            lab = ROW_LABEL.get(cond, cond.replace("sweep", "steering, α = "))
            ax.set_ylabel(lab + (f"\n→ {outcome(res)}" if res else ""), fontsize=7.5, color=INK, rotation=0,
                          ha="right", va="center", labelpad=4)

# (b) outcome by strength
axb = fig.add_subplot(gs[:, nT + 1])
RS = json.load(open(f"{SWEEP_DIR}/results.json"))
eps_s = sorted({int(k.split("|")[0]) for k in RS["test"]})
chosen_s = float(RS["chosen"]["alpha"])
sweep = sorted({float(k.split("|")[1][5:]) for k in RS["test"] if "|sweep" in k} | {chosen_s})
xs = np.arange(len(sweep)); bottom = np.zeros(len(sweep))
for o, c in zip(OUTCOMES, CAT):
    h = np.array([sum(outcome(RS["test"][k]) == o for k in
                      [f"{e}|sweep{a:.0f}" if f"{e}|sweep{a:.0f}" in RS["test"] else f"{e}|D_steer" for e in eps_s]
                      ) for a in sweep], float)
    axb.bar(xs, h, bottom=bottom, color=c, width=0.65, edgecolor=SURF, linewidth=1.5, label=o)
    bottom += h
axb.set_xticks(xs, [f"{a:.0f}" for a in sweep], fontsize=7)
axb.set_xlabel(r"steering strength $\alpha$", fontsize=7.5); axb.set_ylabel("held-out starts", fontsize=7.5)
axb.yaxis.set_major_locator(matplotlib.ticker.MaxNLocator(integer=True))
axb.spines[["top", "right"]].set_visible(False); axb.yaxis.grid(True, color=GRIDC, lw=0.5); axb.set_axisbelow(True)
axb.legend(frameon=False, fontsize=6.5, loc="upper left", bbox_to_anchor=(1.0, 1.0), handlelength=1.0)
fig.text(0.01, 0.98, "(a)", fontsize=9, fontweight="bold", va="top")
fig.text(gs[0, nT + 1].get_position(fig).x0 - 0.05, 0.98, "(b)", fontsize=9, fontweight="bold", va="top")
for ext in ("png", "pdf"):
    fig.savefig(f"{DIR}/fig_usecase.{ext}", dpi=300, bbox_inches="tight", facecolor=SURF)
print(f"saved {DIR}/fig_usecase.png / .pdf")
ns = {c: sum(R["test"].get(f"{e}|{c}", {}).get("success", False) for e in eps) for c in
      ["A_original", "B_lang_put", "C_lang_move", "D_steer"]}
print("success on test starts:", {c: f"{k}/{len(eps)}" for c, k in ns.items()})
print("strength sweep (panel b) from", SWEEP_DIR, "| key frames and the numbers above from", DIR)
