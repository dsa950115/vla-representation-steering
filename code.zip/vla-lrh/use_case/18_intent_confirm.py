# ======================================================================
# OpenVLA-OFT — STEP 18: INTENT CHANGE, CONFIRMATION  (ONE Colab cell, GPU: A100 or L4, ~1-1.5 h, resumable)
#   alpha = 56 fixed in advance; probes fitted on the odd episodes; all 25 even (held-out) episodes; conditions A-D
#
#   new intent: "move only the yellow-and-white mug to the right plate".
#   compares changing the instruction (two phrasings) with steering the representation (original instruction).
#   Copy of step 16 with nothing tuned: alpha and the pre-grasp height margin are fixed from step 16, the probes are
#   refit on the other fold (odd episodes), and A-D run once on the 25 even held-out episodes. Same success criterion.
#   RUN_SWEEP: also run D at the weaker strengths ALPHA_SWEEP (second row of the composite video, section B of the page).
#   STOP_ON_WHITE_LIFT = False keeps filming after the white mug is lifted; the run is scored at the lift either way,
#   so the reported numbers do not depend on it (the reported run used True).
#   outputs (Drive, aclrh/intent_change_confirm/): results.json, test_epXX_<condition>.mp4, test_epXX_grid.mp4
# ======================================================================
import os, subprocess, sys, textwrap, time

VENV = "/content/oftenv"
VPY = f"{VENV}/bin/python"
OFT = "/content/openvla-oft"
LIB = "/content/LIBERO"
MARK = f"{VENV}/.setup_done"


def sh(cmd, check=True):
    print(f"$ {cmd}", flush=True)
    r = subprocess.run(cmd, shell=True, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    tail = "\n".join(r.stdout.strip().splitlines()[-15:])
    if tail:
        print(tail, flush=True)
    if check and r.returncode != 0:
        raise RuntimeError(f"failed ({r.returncode}): {cmd}")
    return r.returncode


# ---------------------------------------------------------------- 0. Drive (checked before any model loading)
if not os.path.isdir("/content/drive/MyDrive"):
    from google.colab import drive
    drive.mount("/content/drive")
os.makedirs("/content/drive/MyDrive/aclrh", exist_ok=True)

# ---------------------------------------------------------------- 0b. GPU check
assert subprocess.run(["nvidia-smi"], stdout=subprocess.DEVNULL).returncode == 0, \
    "No GPU visible: switch the runtime to GPU (A100) and reconnect."

# ---------------------------------------------------------------- 1. setup (once)
if not os.path.exists(MARK):
    t0 = time.time()
    sh("pip install -q uv")
    sh("uv python install 3.10")
    sh(f"rm -rf {VENV}")                                # a half-built venv without the marker: start clean
    sh(f"uv venv {VENV} --python 3.10 --seed")
    UV = f"uv pip install --python {VPY}"
    sh(f"{UV} torch==2.2.0 torchvision==0.17.0 --index-url https://download.pytorch.org/whl/cu121")
    sh(f"{UV} numpy==1.26.4")
    if not os.path.exists(OFT):
        sh(f"git clone -q https://github.com/moojink/openvla-oft.git {OFT}")
    sh(f"{UV} -e {OFT}")                                   # pulls the transformers fork and pinned deps
    if not os.path.exists(LIB):
        sh(f"git clone -q https://github.com/Lifelong-Robot-Learning/LIBERO.git {LIB}")
    sh(f"{UV} -e {LIB}")
    sh(f"{UV} -r {OFT}/experiments/robot/libero/libero_requirements.txt")
    sh(f"{UV} numpy==1.26.4")                             # re-pin in case a dependency upgraded it
    # flash-attn: prebuilt wheel for torch 2.2 / py3.10; if it fails the verification falls back to sdpa
    rc = sh(f"{UV} https://github.com/Dao-AILab/flash-attention/releases/download/v2.5.5/"
            "flash_attn-2.5.5+cu122torch2.2cxx11abiFALSE-cp310-cp310-linux_x86_64.whl", check=False)
    print("flash-attn installed" if rc == 0 else "flash-attn NOT installed -> sdpa fallback")
    # LIBERO asks interactively for its data paths on first import: write the config up front
    os.makedirs(os.path.expanduser("~/.libero"), exist_ok=True)
    base = f"{LIB}/libero/libero"
    with open(os.path.expanduser("~/.libero/config.yaml"), "w") as f:
        f.write(textwrap.dedent(f"""\
            benchmark_root: {base}
            bddl_files: {base}/bddl_files
            init_states: {base}/init_files
            datasets: {LIB}/datasets
            assets: {base}/assets
            """))
    open(MARK, "w").write("ok")
    print(f"setup finished in {(time.time() - t0) / 60:.1f} min")
else:
    print("setup already done")

# ---------------------------------------------------------------- 1b. dependency fixes (idempotent)
# tensorflow_datasets is imported by openvla-oft at import time; a too-new tensorflow-metadata needs
# protobuf 5 (google.protobuf.runtime_version), which TF 2.15 cannot use -> pin the TF-2.15-era version
if sh(f"{VPY} -c \"import tensorflow_datasets\"", check=False) != 0:
    sh(f"uv pip install --python {VPY} tensorflow-metadata==1.14.0")
    sh(f"{VPY} -c \"import tensorflow_datasets, google.protobuf as p; print('tfds OK | protobuf', p.__version__)\"")

# robosuite 1.4 predates the MuJoCo >= 3.2 joint-type API (get_joint_qpos_addr assertion) -> pin 3.1.6
_mj = subprocess.run([VPY, "-c", "import mujoco; print(mujoco.__version__)"], text=True,
                     stdout=subprocess.PIPE, stderr=subprocess.DEVNULL).stdout.strip()
print("mujoco in venv:", _mj or "not installed")
if not _mj.startswith("3.1."):
    sh(f"uv pip install --python {VPY} mujoco==3.1.6")
os.makedirs(f"{LIB}/datasets", exist_ok=True)          # silences LIBERO's missing-datasets warning

sh(f"{VPY} -c \"import torch, transformers, numpy; print('torch', torch.__version__, 'cuda', "
   f"torch.cuda.is_available(), '| transformers', transformers.__version__, '| numpy', numpy.__version__)\"")

# ---------------------------------------------------------------- 2. verification script (runs in the venv)
SCRIPT = r'''
import os, sys, time, traceback
os.environ.setdefault("MUJOCO_GL", "egl")
os.environ.setdefault("PYOPENGL_PLATFORM", "egl")
os.environ["MPLBACKEND"] = "Agg"
sys.path.insert(0, "/content/openvla-oft")
sys.path.insert(0, "/content/LIBERO")          # LIBERO's setup.py is not exposed by uv editable installs
import numpy as np
import torch

CKPT = "moojink/openvla-7b-oft-finetuned-libero-10"
UNNORM = "libero_10_no_noops"
TASK_KEYWORDS = ("white mug", "left plate", "yellow and white mug", "right plate")
MAX_STEPS = 520
NUM_WAIT = 10

T0 = time.time()

def stamp(m):
    print(f"[{time.time() - T0:7.1f}s] {m}", flush=True)


def header(t):
    print("\n" + "=" * 90 + f"\n{t}\n" + "=" * 90, flush=True)

header("1. IMPORTS")
# wandb is only used for evaluation logging; the installed wandb needs a newer protobuf than
# TF 2.15 allows, so register a no-op stand-in instead of touching protobuf again
import types, importlib.machinery
_wb = types.ModuleType("wandb")
_wb.__spec__ = importlib.machinery.ModuleSpec("wandb", None)   # find_spec() (accelerate/transformers) needs a spec
_wb.__version__ = "0.0.0"
for _name in ("init", "log", "finish", "login", "config", "save", "watch"):
    setattr(_wb, _name, lambda *a, **k: None)
_wb.run = None
sys.modules["wandb"] = _wb
from experiments.robot.libero.run_libero_eval import GenerateConfig
import experiments.robot.libero.run_libero_eval as rle
import experiments.robot.openvla_utils as ou
import experiments.robot.libero.libero_utils as lu
import experiments.robot.robot_utils as ru
from libero.libero import benchmark
print("run_libero_eval exports:", [n for n in dir(rle) if not n.startswith("_")][:60])

try:
    import flash_attn  # noqa
    ATTN = "flash_attention_2"
except Exception:
    ATTN = "sdpa"
print("attention implementation:", ATTN)

header("2. LOAD OPENVLA-OFT (LIBERO-10)")
cfg = GenerateConfig(
    pretrained_checkpoint=CKPT, use_l1_regression=True, use_diffusion=False, use_film=False,
    num_images_in_input=2, use_proprio=True, load_in_8bit=False, load_in_4bit=False,
    center_crop=True, num_open_loop_steps=8, unnorm_key=UNNORM,
)
if hasattr(cfg, "task_suite_name"):
    cfg.task_suite_name = "libero_10"
if hasattr(cfg, "model_family"):
    cfg.model_family = "openvla"
t0 = time.time()
if ATTN != "flash_attention_2":
    # route the loader to sdpa if flash-attn is missing
    from transformers import AutoModelForVision2Seq
    _orig_fp = AutoModelForVision2Seq.from_pretrained
    def _fp(*a, **kw):
        kw["attn_implementation"] = "sdpa"
        return _orig_fp(*a, **kw)
    AutoModelForVision2Seq.from_pretrained = _fp
vla = ou.get_vla(cfg)
processor = ou.get_processor(cfg)
action_head = ou.get_action_head(cfg, llm_dim=vla.llm_dim)
proprio_projector = ou.get_proprio_projector(cfg, llm_dim=vla.llm_dim, proprio_dim=8)
print(f"loaded in {time.time() - t0:.0f}s | llm_dim {vla.llm_dim} | unnorm keys: {list(getattr(vla, 'norm_stats', {}).keys())[:8]}")

# ---- lambda hook: capture (and later intervene on) the input of the L1 action head ----
LAM = {"cap": None, "delta": None}
_orig_predict = action_head.predict_action
def _predict(actions_hidden_states, *a, **kw):
    LAM["cap"] = actions_hidden_states.detach().float().cpu()
    if LAM["delta"] is not None:
        actions_hidden_states = actions_hidden_states + LAM["delta"].to(actions_hidden_states.device,
                                                                          actions_hidden_states.dtype)
    return _orig_predict(actions_hidden_states, *a, **kw)
action_head.predict_action = _predict

def policy_chunk(obs, task_label):
    observation, _ = rle.prepare_observation(obs, ru.get_image_resize_size(cfg)) \
        if hasattr(rle, "prepare_observation") else (None, None)
    actions = ou.get_vla_action(cfg, vla, processor, observation, task_label, action_head, proprio_projector)
    return np.asarray(actions)


# constants used by the helpers shared with step 2 (perturb is not used for steering)
H = 8
N_KNOTS = 4
PERT_FRAC = 0.3
SEED = 0

header("3. TASK AND ENVIRONMENTS")
suite = benchmark.get_benchmark_dict()["libero_10"]()
tid = next(i for i in range(suite.n_tasks) if all(k in suite.get_task(i).language for k in TASK_KEYWORDS))
task = suite.get_task(tid)
init_states = suite.get_task_init_states(tid)
env, task_description = lu.get_libero_env(task, "openvla", resolution=256)
try:
    from libero.libero.envs import ControlEnv
except ImportError:
    from libero.libero.envs.env_wrapper import ControlEnv   # not re-exported in this LIBERO version
from libero.libero import get_libero_path
bddl = os.path.join(get_libero_path("bddl_files"), task.problem_folder, task.bddl_file)
cenv = ControlEnv(bddl_file_name=bddl, has_renderer=False, has_offscreen_renderer=False,
                  use_camera_obs=False, camera_heights=128, camera_widths=128)   # renderer-free twin
cenv.seed(0)
cenv.reset()
inner = env.env
print(f"task {tid}: {task_description} | init states {len(init_states)}")
print("objects:", list(inner.obj_body_id.keys()))

MUGS_PLATES = ["porcelain_mug_1", "white_yellow_mug_1", "plate_1", "plate_2"]
QOI_NAMES = ["ee_x", "ee_y", "ee_z"] + [f"{o}_{c}" for o in MUGS_PLATES for c in "xyz"]

def positions(e):
    s = e.env
    out = [np.array(s.sim.data.site_xpos[s.robots[0].eef_site_id])]
    out += [np.array(s.sim.data.body_xpos[s.obj_body_id[o]]) for o in MUGS_PLATES]
    return np.concatenate(out)

def grip_state(e):
    g = getattr(e.env.robots[0].gripper, "current_action", None)
    return None if g is None else np.array(g, dtype=np.float64).copy()

def restore(e, sim_state, grip):
    e.env.timestep, e.env.done = 0, False       # the twin env replays many chunks: never hit the horizon
    e.set_init_state(sim_state)
    if grip is not None and hasattr(e.env.robots[0].gripper, "current_action"):
        e.env.robots[0].gripper.current_action = grip.copy()

def run_chunk(e, sim_state, grip, actions):
    restore(e, sim_state, grip)
    for a in actions:
        e.step(np.asarray(a, dtype=np.float64).tolist())
    return positions(e)

# per-dimension scale for perturbations, from the checkpoint's action statistics (raw action space)
try:
    st_ = vla.norm_stats[UNNORM]["action"]
    half = (np.asarray(st_["q99"]) - np.asarray(st_["q01"])) / 2.0
except Exception as ex:
    print("[warn] norm stats unavailable, using 0.5:", repr(ex)); half = np.full(7, 0.5)
print("perturbation std per arm dim:", np.round(PERT_FRAC * half[:6], 4))
rng = np.random.default_rng(SEED)

def perturb(chunk, k):
    """k smooth perturbations of the raw policy chunk on the 6 arm dims; gripper unchanged"""
    tk = np.linspace(0, H - 1, N_KNOTS)
    out = np.repeat(chunk[None], k, 0).astype(np.float64)
    for i in range(k):
        knots = rng.normal(size=(N_KNOTS, 6)) * PERT_FRAC * half[:6]
        out[i, :, :6] += np.stack([np.interp(np.arange(H), tk, knots[:, j]) for j in range(6)], 1)
    return out

def executed(raw_chunk):
    return np.stack([np.asarray(rle.process_action(a.copy(), "openvla"), dtype=np.float64) for a in raw_chunk])


# ======================================================================
# STEP 4: STEERING  lambda_alpha = lambda(x) + alpha d(x), chunk = head(lambda_alpha)  (deterministic)
# ======================================================================
def sig_levels(U):
    """time-augmented signature, dX = (dt, u dt): returns S1, S<=2, S<=3."""
    U = np.asarray(U, dtype=np.float64)
    N, H, A = U.shape
    dt = 1.0 / H
    dx = np.concatenate([np.full((N, H, 1), dt), U * dt], axis=2)
    prev1 = np.cumsum(dx, axis=1) - dx
    inc2 = np.einsum("nti,ntj->ntij", prev1, dx) + 0.5 * np.einsum("nti,ntj->ntij", dx, dx)
    prev2 = np.cumsum(inc2, axis=1) - inc2
    S1 = dx.sum(axis=1)
    S2 = inc2.sum(axis=1)
    S3 = (np.einsum("ntij,ntk->nijk", prev2, dx, optimize=True)
          + 0.5 * np.einsum("nti,ntj,ntk->nijk", prev1, dx, dx, optimize=True)
          + np.einsum("nti,ntj,ntk->nijk", dx, dx, dx, optimize=True) / 6.0)
    M2 = np.concatenate([S1, S2.reshape(N, -1)], axis=1)
    return {"S1": S1, "S<=2": M2, "S<=3": np.concatenate([M2, S3.reshape(N, -1)], axis=1)}


DATA = "/content/drive/MyDrive/aclrh/oft_probe.npz"
OUT_ST = None

# ---- task QoIs derived from the 15 stored positions: ee(0:3) mug1(3:6) mug2(6:9) plate_1(9:12) plate_2(12:15)
def target_plates(Q0, EP, success_ep):
    """plate each mug ends on in successful episodes (last snapshot), by horizontal distance"""
    last = [np.where(EP == e)[0][-1] for e in np.unique(EP) if success_ep[int(e)]]
    P = Q0[last]
    out = []
    for m in (3, 6):
        d1 = np.linalg.norm(P[:, m:m + 2] - P[:, 9:11], axis=1)
        d2 = np.linalg.norm(P[:, m:m + 2] - P[:, 12:14], axis=1)
        out.append(9 if np.mean(d1 < d2) >= 0.5 else 12)
        print(f"  mug at cols {m}:{m + 3}: nearer to plate_1 in {np.mean(d1 < d2):.0%} of successful end states "
              f"-> target plate_{1 if out[-1] == 9 else 2}")
    return out

def make_qoi(t1, t2):
    def qoi(P):
        """P (..., 15) -> (..., 3): psi to INCREASE (negative distances)"""
        return np.stack([-np.linalg.norm(P[..., 3:5] - P[..., t1:t1 + 2], axis=-1),
                         -np.linalg.norm(P[..., 6:8] - P[..., t2:t2 + 2], axis=-1),
                         -np.linalg.norm(P[..., 0:3] - P[..., 3:6], axis=-1),
                         -np.linalg.norm(P[..., 0:3] - P[..., 6:9], axis=-1)], axis=-1)
    return qoi

QOI_LIST = ["-d(mug1,plate) xy", "-d(mug2,plate) xy", "-d(EE,mug1)", "-d(EE,mug2)"]
PCA_K = 32
N_PER_FOLD = 10               # steered states per QoI and fold (2 folds)
MOVE_MM, MIN_FRAC = 2e-3, 0.5
H_Z = 0.25                    # finite-difference step (standardized PCA units) for D phi and the simulator gradient
STEP_REL = 0.005              # ||delta lambda|| / ||lambda|| per unit tau, identical for all directions
TAUS = [-8.0, -4.0, -2.0, 0.0, 2.0, 4.0, 8.0]
N_RANDOM = 3
ALPHAS_R = np.logspace(-3, 4, 15)

def ranks(v):
    v = np.asarray(v, float)
    r = np.empty(len(v)); r[np.argsort(v, kind="mergesort")] = np.arange(len(v), dtype=float)
    for val in np.unique(v):                     # average ranks for ties
        m = v == val
        r[m] = r[m].mean()
    return r

def spearman(x, y):
    y = np.asarray(y, float)
    if np.ptp(y) < 1e-12:                         # a flat response is not monotone
        return 0.0
    return float(np.corrcoef(ranks(x), ranks(y))[0, 1])

def ridge_fit(Xtr, Ytr, Xva, Yva):
    """primal ridge with standardized columns; penalty per target chosen on validation rows; refit on all"""
    def fit(X, Y, a_):
        mx, sx, my = X.mean(0), X.std(0) + 1e-12, Y.mean(0)
        Xs = (X - mx) / sx
        G = Xs.T @ Xs
        W = np.linalg.solve(G + a_ * len(X) * np.eye(G.shape[0]), Xs.T @ (Y - my))
        return W / sx[:, None], my - (mx / sx) @ W
    best = []
    for j in range(Ytr.shape[1]):
        errs = []
        for a_ in ALPHAS_R:
            W, b = fit(Xtr, Ytr[:, j:j + 1], a_)
            errs.append(np.mean((Xva @ W + b - Yva[:, j:j + 1]) ** 2))
        best.append(ALPHAS_R[int(np.argmin(errs))])
    X, Y = np.r_[Xtr, Xva], np.r_[Ytr, Yva]
    Ws, bs = zip(*[fit(X, Y[:, j:j + 1], best[j]) for j in range(Y.shape[1])])
    return np.concatenate(Ws, 1), np.concatenate(bs)          # coef (p, q), intercept (q,)

header("4. DATA, SIGNATURES, HEAD")
dd = np.load(DATA)
LAMS = dd["LAM"]                                              # float16 (NS, 229376)
EP, CS = dd["EP"], dd["C_STATE"]
UE, URAW, SIMS, GRIPS = dd["U_EXEC"], dd["U_RAW"], dd["SIM"], dd["GRIP"]
print("target plates:")
qoi = make_qoi(*target_plates(dd["Q0"], EP, dd["SUCCESS_EP"]))
Q0, QF = qoi(dd["Q0"]), qoi(dd["QF"])                         # psi(x) (NS, 3), psi(F_u x) (NC, K, 3)
QOIS = {name: i for i, name in enumerate(QOI_LIST)}
NS, (NC, K, H_, A_) = len(EP), UE.shape
S_all = sig_levels(UE.reshape(NC * K, H_, A_).astype(np.float64))["S<=2"]
s_mu, s_sd = S_all.mean(0), S_all.std(0)
keep = s_sd > 1e-8 * s_sd.max()
st = lambda UU: (sig_levels(np.asarray(UU, np.float64).reshape(-1, H_, A_))["S<=2"][:, keep] - s_mu[keep]) / s_sd[keep]
S_all = (S_all[:, keep] - s_mu[keep]) / s_sd[keep]
ps = S_all.shape[1]
hp = next(action_head.parameters())
LSHAPE = (56, 4096)

def head_chunks(lams):
    """lams: (n, 229376) float32 -> executed chunks (n, 8, 7), exactly as in the rollouts"""
    with torch.no_grad():
        na = _orig_predict(torch.from_numpy(lams.reshape((-1,) + LSHAPE)).to(hp.device, hp.dtype))
    na = na.float().cpu().numpy().reshape(-1, H_, A_)
    ua = np.asarray(vla._unnormalize_actions(na, UNNORM)).reshape(-1, H_, A_)
    return np.stack([executed(c) for c in ua])

# check: head(stored lambda) reproduces the stored policy chunk (candidate 0)
chk = head_chunks(LAMS[CS[:8]].astype(np.float32))
print(f"head(stored lambda) vs stored executed policy chunk: max|diff| arm {np.abs(chk[:, :, :6] - UE[:8, 0, :, :6]).max():.2e}")



# ---- shared with step 9 ----
import pickle, math
to_lam = lambda dz: (comps @ (zs * dz)).astype(np.float32)          # latent displacement -> head input
z_of = lambda lam: ((lam.astype(np.float32) - mu) @ comps - zm) / zs


def fit_fold(fi):
    """PCA and probes on one half of the episodes (fold 0: even, as in step 8); returns the held-out episodes"""
    global mu, comps, zm, zs, Zall, a_inc, b_inc, W_inc, a_sta, inA
    eps = np.unique(EP)
    A_eps = set((eps[::2] if fi == 0 else eps[1::2]).tolist())
    inA = np.array([e in A_eps for e in EP])
    X32 = LAMS[inA].astype(np.float32)
    mu = X32.mean(0); Xc = X32 - mu
    ev, V = np.linalg.eigh((Xc @ Xc.T).astype(np.float64)); ix = np.argsort(ev)[::-1][:PCA_K]
    comps = ((Xc.T.astype(np.float64) @ V[:, ix]) / np.sqrt(ev[ix])).astype(np.float32)
    del X32, Xc
    Zr = np.concatenate([(LAMS[i:i + 64].astype(np.float32) - mu) @ comps for i in range(0, NS, 64)])
    zm, zs = Zr[inA].mean(0), Zr[inA].std(0) + 1e-12
    Zall = (Zr - zm) / zs
    rng_ = np.random.default_rng(0)
    cA = np.where(inA[CS])[0]
    vaE = set(rng_.choice(sorted(A_eps), size=max(1, len(A_eps) // 8), replace=False).tolist())
    isva = np.array([EP[CS[j]] in vaE for j in cA])
    qidx = list(QOIS.values())
    def design(js):
        Z = np.repeat(Zall[CS[js]], K, 0); S = S_all[np.concatenate([np.arange(j * K, (j + 1) * K) for j in js])]
        return np.c_[Z, S, (Z[:, :, None] * S[:, None, :]).reshape(len(Z), -1)]
    def target(js):
        return (QF[js][:, :, qidx] - Q0[CS[js]][:, None, qidx]).reshape(-1, len(qidx))
    Wc, _ = ridge_fit(design(cA[~isva]), target(cA[~isva]), design(cA[isva]), target(cA[isva]))
    a_inc, b_inc = Wc[:PCA_K].T, Wc[PCA_K:PCA_K + ps].T
    W_inc = Wc[PCA_K + ps:].T.reshape(len(qidx), PCA_K, ps)
    sA = np.where(inA)[0]; sva = np.array([EP[i] in vaE for i in sA])
    Ws, _ = ridge_fit(Zall[sA[~sva]], Q0[sA[~sva]][:, qidx], Zall[sA[sva]], Q0[sA[sva]][:, qidx])
    a_sta = Ws.T
    stamp(f"fold {fi + 1}: PCA and probes fitted on {len(A_eps)} episodes")
    return sorted(set(eps.tolist()) - A_eps)


def directions(q, lam0):
    """probe-derived latent directions at the current state, scaled to STEP_REL * ||lambda||"""
    z0 = z_of(lam0[None])[0]
    u0 = head_chunks(lam0[None])[0]
    E = np.eye(PCA_K) * H_Z
    up = head_chunks(np.stack([lam0 + to_lam(e) for e in E])); um = head_chunks(np.stack([lam0 - to_lam(e) for e in E]))
    Dphi = ((st(up) - st(um)) / (2 * H_Z)).T                          # (|S|, 32)
    lam_psi = b_inc[q] + W_inc[q].T @ z0                              # probe coefficient at the current state
    d = {"Dphi^T lambda_psi": Dphi.T @ lam_psi,
         "gamma_psi": a_inc[q] + W_inc[q] @ st(u0)[0],
         "static": a_sta[q].copy()}
    n = float(np.linalg.norm(lam0))
    return {k: v / (np.linalg.norm(zs * v) + 1e-300) * STEP_REL * n for k, v in d.items()}


resize9 = ru.get_image_resize_size(cfg)


def reset_to(start):
    """start = ("init", episode) or ("snap", state index) -> first observation"""
    env.env.timestep, env.env.done = 0, False
    env.reset()
    kind, idx = start
    if kind == "init":
        obs = env.set_init_state(init_states[idx])
        for _ in range(NUM_WAIT):
            obs, _, _, _ = env.step(lu.get_libero_dummy_action("openvla"))
    else:
        obs = env.set_init_state(SIMS[idx])
        g_ = GRIPS[idx]
        if g_ is not None and hasattr(env.env.robots[0].gripper, "current_action"):
            env.env.robots[0].gripper.current_action = np.asarray(g_, np.float64).copy()
    return obs




# ======================================================================
# STEP 12: INTENT CHANGE — "move only the yellow-and-white mug to the right plate"
#   A  original instruction, no steering (reference: the policy starts with the white mug)
#   B  instruction changed to the new intent (two phrasings), no steering
#   D  original instruction, steering along the probe direction of psi = -d(EE, pre-grasp point of mug2),
#      recomputed at every re-plan, released near the mug; the policy does the rest
#   success (fixed before running): the yellow-and-white mug rests on the right plate (0.5 s, upright),
#   the white mug is never lifted and moves < 3 cm, within T_LIMIT.
#   dev/test: D's settings are chosen on DEV episodes; all conditions are then run once on TEST episodes.
# ======================================================================
from PIL import Image, ImageDraw, ImageFont
import subprocess, json, itertools
try:
    import imageio_ffmpeg  # noqa: F401
except ImportError:
    subprocess.run([sys.executable, "-m", "pip", "install", "-q", "imageio", "imageio-ffmpeg"], check=False)
import imageio
OUT12 = "/content/drive/MyDrive/aclrh/intent_change_confirm"
# ---------------- confirmation run (step 18): the setting is fixed in advance, new probes, new held-out starts ----------------
CONFIRM_ALPHA, CONFIRM_UP = 56.0, 0.02   # fixed from step 16 (its strength sweep); nothing is tuned here
CONFIRM_FOLD = 1                         # probes fitted on the odd episodes, steering on the 25 even (held-out) episodes,
                                         # none of which was used in step 16 (dev/test there were odd episodes)
os.makedirs(OUT12, exist_ok=True)
RES12 = f"{OUT12}/results.json"
# ---------------- success criterion (do not change after the test run) ----------------
T_LIMIT = 15.0                   # s
WHITE_MOVE_MAX = 0.03            # m, horizontal displacement of the white mug
LIFT_M, PLACE_XY, PLACE_Z, STABLE_STEPS = 0.03, 0.06, 0.03, 10
UPRIGHT, TIPPED = 0.866, 0.5
# ---------------- conditions ----------------
INSTR = {"A_original": None,                                         # None = the task's own instruction
         "B_lang_put": "put the yellow and white mug on the right plate",
         "C_lang_move": "move the yellow and white mug to the right plate",
         "D_steer": None}
DEV_N, TEST_N = 12, 13           # held-out episodes of fold 1: the first DEV_N for dev, the next TEST_N for test
GRID = {"alpha": [], "up": [0.02]}                                  # no dev search in the confirmation run                    # D settings searched on dev
RELEASE_PRE = 0.05
MAX_STEER_CHUNKS = 12
SAVE_DEV_VIDEO = False
STOP_ON_WHITE_LIFT = False       # False: keep simulating (and filming) after the white mug is lifted, up to the time
                                 # limit; the run is still scored at the moment of the lift, so results are unchanged
RUN_SWEEP = True                 # test episodes: D at further strengths (second row of the composite video)
ALPHA_SWEEP = [16.0, 24.0, 32.0, 40.0]   # weaker than the fixed alpha, run afterwards; A-D results already saved are reused
OUTCOMES = ["success", "knocked a mug", "went for the white mug", "grasped, not placed", "no grasp"]
FPS = 20
MUG = {"white": "porcelain_mug_1", "yellow": "white_yellow_mug_1", "red": "red_coffee_mug_1"}
BID = {k: env.env.obj_body_id[v] for k, v in MUG.items() if v in env.env.obj_body_id}
TP = target_plates(dd["Q0"], EP, dd["SUCCESS_EP"])
YPLATE = env.env.obj_body_id[["plate_1", "plate_2"][(int(TP[1]) - 9) // 3]]
try:
    FONT = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 12)
except Exception:
    FONT = ImageFont.load_default()


def cos_tilt(k):
    return float(env.env.sim.data.body_xmat[BID[k]].reshape(3, 3)[2, 2])


def body_pos(k):
    return np.array(env.env.sim.data.body_xpos[BID[k]])


def overlay(img, lines):
    im = Image.fromarray(np.ascontiguousarray(img)).convert("RGB")
    d = ImageDraw.Draw(im)
    d.rectangle([0, 0, im.width, 16 * len(lines) + 6], fill=(0, 0, 0))
    for i, s_ in enumerate(lines):
        d.text((5, 3 + 16 * i), s_, fill=(255, 255, 255), font=FONT)
    return np.asarray(im)


# ---- pre-grasp offset of mug2 from the demonstrations, and one steering QoI per height margin ----
def pregrasp_offset():
    Qr = dd["Q0"]; offs = []
    for e in np.unique(EP):
        if not dd["SUCCESS_EP"][int(e)] or int(e) % 2 != CONFIRM_FOLD:       # fitting-fold episodes only
            continue
        idx = np.where(EP == e)[0]
        lifted = [i for i in idx if Qr[i, 8] > Qr[idx[0], 8] + LIFT_M]
        if not lifted:
            continue
        before = [i for i in idx if i < lifted[0] and np.linalg.norm(Qr[i, 0:2] - Qr[i, 6:8]) < 0.05]
        if before:
            offs.append(Qr[before[-1], 0:3] - Qr[before[-1], 6:9])
    off = np.median(np.array(offs), 0) if offs else np.array([0.0, 0.0, 0.08])
    print(f"pre-grasp offset EE - yellow-and-white mug from {len(offs)} successful episodes: {np.round(100 * off, 1)} cm")
    return off

OFF2 = pregrasp_offset()
PRE_UP = {u: OFF2 + np.array([0.0, 0.0, u]) for u in GRID["up"]}
_qoi_base = qoi
def qoi(P):
    P = np.asarray(P, np.float64)
    extra = [-np.linalg.norm(P[..., 0:3] - (P[..., 6:9] + PRE_UP[u]), axis=-1)[..., None] for u in GRID["up"]]
    return np.concatenate([_qoi_base(P)] + extra, axis=-1)
QOI_LIST = QOI_LIST + [f"-d(EE,pregrasp2+{u:.2f})" for u in GRID["up"]]
QOIS = {name: i for i, name in enumerate(QOI_LIST)}
Q0, QF = qoi(dd["Q0"]), qoi(dd["QF"])


def run(start, cond, alpha=0.0, up=None, record=False):
    """one rollout under a condition; returns events, success and frames"""
    obs = reset_to(start)
    instr = INSTR[cond] or task_description
    w0, y0 = body_pos("white"), body_pos("yellow")
    q = QOIS[f"-d(EE,pregrasp2+{up:.2f})"] if cond == "D_steer" else None
    steering = cond == "D_steer"
    ev = {"lift": {}, "place": {}, "tipped": {}, "release": None}
    stable, step, n_steer, frames, frozen = 0, 0, 0, [], None
    path = [positions(env)[0:2].tolist()]
    objs0 = {k: body_pos(k)[:2].tolist() for k in BID}
    objs0["right plate"] = env.env.sim.data.body_xpos[YPLATE][:2].tolist()
    max_steps = int(T_LIMIT / 0.05)
    while step < max_steps:
        raw = np.asarray(ou.get_vla_action(cfg, vla, processor, rle.prepare_observation(obs, resize9)[0],
                                           instr, action_head, proprio_projector), dtype=np.float64)
        lam0 = LAM["cap"][0].numpy().reshape(-1).astype(np.float32)
        p_ = positions(env)
        if steering and (np.linalg.norm(p_[0:3] - (p_[6:9] + PRE_UP[up])) < RELEASE_PRE
                         or "yellow" in ev["lift"] or n_steer >= MAX_STEER_CHUNKS):
            steering, ev["release"] = False, round(step * 0.05, 2)
        if steering:
            v = directions(q, lam0)["Dphi^T lambda_psi"]
            chunk = head_chunks((lam0 + to_lam(alpha * v))[None])[0]
            n_steer += 1
        else:
            chunk = executed(raw)
        stop = False
        for a in chunk:
            obs, _, _, _ = env.step(np.asarray(a).tolist())
            step += 1
            t = round(step * 0.05, 2)
            if step % 4 == 0:
                path.append(positions(env)[0:2].tolist())
            for k, z_ in (("white", w0[2]), ("yellow", y0[2])):
                if k not in ev["lift"] and body_pos(k)[2] > z_ + LIFT_M and cos_tilt(k) > UPRIGHT:
                    ev["lift"][k] = t
            for k in BID:
                if k not in ev["tipped"] and cos_tilt(k) < TIPPED:
                    ev["tipped"][k] = t
            py = body_pos("yellow")
            ok_ = ("yellow" in ev["lift"] and np.linalg.norm(py[:2] - env.env.sim.data.body_xpos[YPLATE][:2]) < PLACE_XY
                   and py[2] < y0[2] + PLACE_Z and cos_tilt("yellow") > UPRIGHT)
            stable = stable + 1 if ok_ else 0
            if "yellow" not in ev["place"] and stable >= STABLE_STEPS:
                ev["place"]["yellow"] = round(t - 0.45, 2)
            if "white" in ev["lift"] and frozen is None:                     # failure is decided here: score as of now
                frozen = ({k: (dict(v) if isinstance(v, dict) else v) for k, v in ev.items()},
                          float(np.linalg.norm(body_pos("white")[:2] - w0[:2])), step)
            if record:
                phase = ("steering" if steering else "released") if cond == "D_steer" else "no steering"
                frames.append(overlay(lu.get_libero_image(obs), [
                    (f"{cond} alpha={alpha:.0f}" if cond == "D_steer" else cond) + f" | {phase} | t = {t:4.1f} s",
                    f"instruction: {instr[:44]}",
                    "white mug lifted: counted as failed from here" if frozen else
                    ("yellow mug on right plate" if "yellow" in ev["place"] else "")]))
            if (frozen and STOP_ON_WHITE_LIFT) or ("yellow" in ev["place"] and t >= ev["place"]["yellow"] + 1.5):
                stop = True
                break
        if stop:
            break
    step_v = step
    if frozen:
        ev, white_move, step = frozen
    else:
        white_move = float(np.linalg.norm(body_pos("white")[:2] - w0[:2]))
    success = bool("yellow" in ev["place"] and "white" not in ev["lift"] and white_move < WHITE_MOVE_MAX)
    first = min(ev["lift"], key=ev["lift"].get) if ev["lift"] else None
    return dict(success=success, first_lift=first, white_move_cm=round(100 * white_move, 1),
                placed_at=ev["place"].get("yellow"), release=ev["release"], tipped=ev["tipped"],
                seconds=round(step * 0.05, 1), seconds_video=round(step_v * 0.05, 1), full=not STOP_ON_WHITE_LIFT,
                path=path, objs0=objs0), frames


def outcome(r):
    if r["success"]:
        return "success"
    if r["tipped"] or (r["white_move_cm"] >= 100 * WHITE_MOVE_MAX and r["first_lift"] != "white"):
        return "knocked a mug"
    if r["first_lift"] == "white":
        return "went for the white mug"
    if r["first_lift"] == "yellow":
        return "grasped, not placed"
    return "no grasp"


header("12. INTENT CHANGE: move only the yellow-and-white mug")
held = fit_fold(CONFIRM_FOLD)
dev_eps, test_eps = [], held
print(f"dev episodes {dev_eps} | test episodes {test_eps}")
print("success: yellow-and-white mug on the right plate, white mug never lifted and moved < "
      f"{100 * WHITE_MOVE_MAX:.0f} cm, within {T_LIMIT:.0f} s", flush=True)
R = json.load(open(RES12)) if os.path.exists(RES12) else {"dev": {}, "test": {}, "chosen": None}
R["chosen"] = {"alpha": CONFIRM_ALPHA, "up": CONFIRM_UP}
R["sweep"] = ALPHA_SWEEP if RUN_SWEEP else []                        # second row of the composite video (read by the page)
save = lambda: json.dump(R, open(RES12, "w"), indent=1)

# ---------------- dev: choose alpha and the height margin for D ----------------
configs = list(itertools.product(GRID["alpha"], GRID["up"]))
for e in dev_eps:
    for a, u in configs:
        key = f"{e}|{a:.0f}|{u:.2f}"
        if key in R["dev"]:
            continue
        r, fr = run(("init", e), "D_steer", a, u, record=SAVE_DEV_VIDEO)
        R["dev"][key] = r; save()
        if SAVE_DEV_VIDEO:
            imageio.mimsave(f"{OUT12}/dev_ep{e:02d}_a{a:.0f}_up{u:.2f}.mp4", fr, fps=FPS, macro_block_size=1)
        print(f"  dev ep {e:2d} | alpha {a:+.0f} up {100 * u:.0f} cm | success {r['success']} | first lift "
              f"{r['first_lift']} | released {r['release']} | white moved {r['white_move_cm']} cm", flush=True)
score = {c: sum(R["dev"][f"{e}|{c[0]:.0f}|{c[1]:.2f}"]["success"] for e in dev_eps) for c in configs}
for c, s_ in score.items():
    print(f"  dev  alpha {c[0]:+.0f} up {100 * c[1]:.0f} cm: {s_}/{len(dev_eps)}")
if R["chosen"] is None:
    best = max(configs, key=lambda c: (score[c], -c[0]))                # ties: smaller alpha
    R["chosen"] = {"alpha": best[0], "up": best[1]}; save()
ALPHA_C, UP_C = R["chosen"]["alpha"], R["chosen"]["up"]
stamp(f"fixed in advance: alpha {ALPHA_C:+.0f}, height margin {100 * UP_C:.0f} cm")

# ---------------- test: all conditions once, fixed settings; then the alpha sweep ----------------
TILE = 256
blank = lambda: np.full((TILE, TILE, 3), 255, np.uint8)
for e in test_eps:
    vids, have_grid = {}, os.path.exists(f"{OUT12}/test_ep{e:02d}_grid.mp4")
    jobs = [(c, ALPHA_C) for c in INSTR] + ([("D_steer", a) for a in ALPHA_SWEEP] if RUN_SWEEP else [])
    for i, (cond, a) in enumerate(jobs):
        sweep = i >= len(INSTR)
        key = f"{e}|sweep{a:.0f}" if sweep else f"{e}|{cond}"
        vkey = ("sweep", a) if sweep else (cond, a)
        vpath = f"{OUT12}/test_ep{e:02d}_{key.split('|')[1]}.mp4"
        if (key in R["test"] and os.path.exists(vpath)
                and R["test"][key].get("full", False) == (not STOP_ON_WHITE_LIFT)):  # done before: reuse its video
            vids[vkey] = imageio.mimread(vpath, memtest=False); continue
        if sweep and a == ALPHA_C and ("D_steer", ALPHA_C) in vids:                 # same run as D: reuse it
            R["test"][key] = R["test"][f"{e}|D_steer"]; vids[vkey] = vids[("D_steer", ALPHA_C)]; save(); continue
        r, fr = run(("init", e), cond, a, UP_C, record=True)
        if key in R["test"] and R["test"][key]["success"] != r["success"]:
            print(f"  [!] ep {e} {key.split('|')[1]}: success changed {R['test'][key]['success']} -> {r['success']} (not deterministic?)")
        R["test"][key] = r; save()
        vids[vkey] = fr
        imageio.mimsave(f"{OUT12}/test_ep{e:02d}_{key.split('|')[1]}.mp4", fr, fps=FPS, macro_block_size=1)
        print(f"  test ep {e:2d} | {key.split('|')[1]:12s} | {outcome(r):22s} | first lift {r['first_lift']} "
              f"| placed {r['placed_at']} | white moved {r['white_move_cm']} cm | tipped {', '.join(r['tipped']) or '-'}",
              flush=True)
    # composite video: row 1 = A | B | C | D (chosen alpha), row 2 = D at the sweep strengths
    row1 = [vids.get((c, ALPHA_C)) for c in INSTR]
    row2 = [vids.get(("sweep", a)) for a in ALPHA_SWEEP] if RUN_SWEEP else []
    if all(v is not None for v in row1 + row2):
        T = max(len(v) for v in row1 + row2)
        fr_ = lambda v, t: v[min(t, len(v) - 1)]
        w = max(len(row1), len(row2))
        pad = lambda row, t: [fr_(v, t) for v in row] + [blank() for _ in range(w - len(row))]
        frames = [np.concatenate([np.concatenate(pad(row1, t), axis=1)]
                                 + ([np.concatenate(pad(row2, t), axis=1)] if row2 else []), axis=0) for t in range(T)]
        imageio.mimsave(f"{OUT12}/test_ep{e:02d}_grid.mp4", frames, fps=FPS, macro_block_size=1)

header("SUMMARY (confirmation: 25 new held-out starts, setting fixed in advance)")
for cond in INSTR:
    rs = [R["test"][f"{e}|{cond}"] for e in test_eps if f"{e}|{cond}" in R["test"]]
    n = len(rs)
    print(f"  {cond:12s} | success {sum(r['success'] for r in rs)}/{n} | "
          + " | ".join(f"{o} {sum(outcome(r) == o for r in rs)}" for o in OUTCOMES[1:]))
print(f"\n  D (steering) at the fixed alpha = {ALPHA_C:.0f}:")
SWEEP_ALL = sorted(set(ALPHA_SWEEP + [ALPHA_C])) if RUN_SWEEP else [ALPHA_C]   # only this run's strengths
tab = {}
for a in SWEEP_ALL:
    rs = [R["test"].get(f"{e}|sweep{a:.0f}") or (R["test"].get(f"{e}|D_steer") if a == ALPHA_C else None) for e in test_eps]
    rs = [r for r in rs if r is not None]
    tab[a] = {o: sum(outcome(r) == o for r in rs) for o in OUTCOMES}; tab[a]["n"] = len(rs)
    print(f"  alpha {a:4.0f} ({0.5 * a:4.1f}% of ||lambda|| per re-plan) | " + " | ".join(f"{o} {tab[a][o]}" for o in OUTCOMES)
          + f" | n {len(rs)}")
print("successful D episodes:", [e for e in test_eps if R["test"].get(f"{e}|D_steer", {}).get("success")],
      f"-> {OUT12}/test_epXX_grid.mp4 (row 1: A | B | C | D, row 2: D at alpha {ALPHA_SWEEP})")

# ---------------- figures: outcomes vs alpha, and top-down EE paths ----------------
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
INK, INK2, MUTED, GRIDC, SURF = "#0b0b0b", "#52514e", "#898781", "#e1e0d9", "#fcfcfb"
CAT = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4"]          # categorical slots 1-5, fixed order
plt.rcParams.update({"font.size": 9, "axes.edgecolor": "#c3c2b7", "axes.labelcolor": INK2, "xtick.color": INK2,
                     "ytick.color": INK2, "figure.facecolor": SURF, "axes.facecolor": SURF})
fig, ax = plt.subplots(figsize=(5.2, 3.0))
xs = np.arange(len(SWEEP_ALL)); bottom = np.zeros(len(SWEEP_ALL))
for o, c in zip(OUTCOMES, CAT):
    h = np.array([tab[a][o] for a in SWEEP_ALL], float)
    ax.bar(xs, h, bottom=bottom, color=c, width=0.6, edgecolor=SURF, linewidth=2, label=o)
    bottom += h
ax.set_xticks(xs, [f"{a:.0f}" + (" (chosen)" if a == ALPHA_C else "") for a in SWEEP_ALL])
ax.set_xlabel(r"steering strength $\alpha$"); ax.set_ylabel("test episodes")
ax.spines[["top", "right"]].set_visible(False); ax.yaxis.grid(True, color=GRIDC, lw=0.6); ax.set_axisbelow(True)
from matplotlib.ticker import MaxNLocator
ax.yaxis.set_major_locator(MaxNLocator(integer=True))
ax.legend(frameon=False, fontsize=8, bbox_to_anchor=(1.0, 1.0), loc="upper left")
plt.tight_layout(); plt.savefig(f"{OUT12}/alpha_outcomes.png", dpi=200); plt.savefig(f"{OUT12}/alpha_outcomes.pdf"); plt.close()

SEQ = {16.0: "#86b6ef", 24.0: "#5598e7", 32.0: "#3987e5", 40.0: "#256abf", 56.0: "#0d366b"}
for e in test_eps:
    fig, ax = plt.subplots(figsize=(6.4, 3.6))
    ref = R["test"].get(f"{e}|A_original")
    if ref is None:
        plt.close(); continue
    P = np.array(ref["path"]) * 100
    ax.plot(P[:, 0], P[:, 1], color=MUTED, lw=2, ls="--", label="no steering")
    for a in SWEEP_ALL:
        r = R["test"].get(f"{e}|sweep{a:.0f}") or (R["test"].get(f"{e}|D_steer") if a == ALPHA_C else None)
        if r is None:
            continue
        P = np.array(r["path"]) * 100
        ax.plot(P[:, 0], P[:, 1], color=SEQ.get(a, "#256abf"), lw=2, label=rf"$\alpha$ = {a:.0f}: {outcome(r)}")
    for k, xy in ref["objs0"].items():
        ax.plot(100 * xy[0], 100 * xy[1], "o", ms=9, mfc="none", mec=INK, mew=1.5)
        ax.annotate({"white": "white mug", "yellow": "yellow-and-white mug", "red": "red mug"}.get(k, k),
                    (100 * xy[0], 100 * xy[1]), xytext=(6, 4), textcoords="offset points", color=INK, fontsize=8)
    ax.set_aspect("equal"); ax.set_xlabel("x (cm)"); ax.set_ylabel("y (cm)")
    ax.spines[["top", "right"]].set_visible(False)
    ax.legend(frameon=False, fontsize=7, loc="upper left", bbox_to_anchor=(1.02, 1.0)); ax.set_title(f"held-out episode {e}: end-effector path", fontsize=9, color=INK)
    plt.tight_layout(); plt.savefig(f"{OUT12}/paths_ep{e:02d}.png", dpi=200); plt.close()
save()
stamp("done")
'''

with open("/content/run_oft_intent_confirm.py", "w") as f:
    f.write(SCRIPT)
print("\nrunning in the Python 3.10 venv ...\n", flush=True)
p = subprocess.Popen([VPY, "-u", "/content/run_oft_intent_confirm.py"], stdout=subprocess.PIPE,
                     stderr=subprocess.STDOUT, text=True,
                     env={**os.environ, "MUJOCO_GL": "egl",
                          "MPLBACKEND": "Agg",          # Colab sets a notebook-only backend
                          "TF_CPP_MIN_LOG_LEVEL": "2",  # silence TensorFlow start-up noise
                          "PYTHONPATH": f"{OFT}:{LIB}:" + os.environ.get("PYTHONPATH", "")})
for line in p.stdout:
    print(line, end="")
p.wait()
print(f"\nReturn code: {p.returncode}")
