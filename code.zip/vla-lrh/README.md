# The Linear Representation Hypothesis for VLA Models: code

Code for the vision-language-action (VLA) experiments of the paper: action-conditioned probing of OpenVLA-OFT and
SmolVLA (Q1), local steering through the action head (Corollary 5.4), and the use case on the project page
(changing the policy's intent by steering instead of rewording the instruction).

Every table and figure is mapped to the script that produces it in [`PAPER_MAP.md`](PAPER_MAP.md).

> Anonymous release for double-blind review. Model checkpoints, LIBERO and the other third-party code are fetched from
> their public sources by the scripts and are not part of this repository.

## Layout

```
openvla_oft/   01-09   OpenVLA-OFT: environment, data collection, probing, one-chunk steering, closed-loop figures
probing/       q1      Q1 probing table for both models (OpenVLA-OFT and SmolVLA)
smolvla/       s1-s4   SmolVLA: data collection, steering, analysis of the steering run, bimodality check
use_case/      16-18   use case: instruction vs. steering (16), Figure 2 (17), confirmation run (18)
site/          12, 19  anonymous project page (12) and a Colab cell that builds Figure 2 + the page and serves it (19)
extras/        10-15   runs that are not reported in the paper (closed-loop comparisons, redirection pilots)
tools/                 anonymity check before a release
colab/                 launcher notebook: one cell per step
```

The numbers in the file names are the step numbers used in comments and printed output (for example "step 16").

## How to run

All scripts are written as **one self-contained Google Colab cell each**: paste the file into a new cell, or run it
from the launcher notebook [`colab/launcher.ipynb`](colab/launcher.ipynb), which does
`exec(open(path).read(), {"__name__": "__main__"})` per step. Google Drive is mounted by the cells; data and results
are read from and written to **`/content/drive/MyDrive/aclrh/`** (the analysis scripts on CPU also accept
`ACLRH_ROOT=<dir>` where noted in their header).

Two kinds of cells:

- **GPU cells** (model or simulator; A100, or L4 where noted). The first run builds a separate Python 3.10 venv in
  `/content/oftenv` (OpenVLA-OFT: torch 2.2 cu121, openvla-oft, LIBERO; 15-25 min) or installs `lerobot[smolvla]`
  (SmolVLA), then runs the experiment in a subprocess. Later runs in the same runtime skip the installation. The long
  runs checkpoint to Drive and resume when the cell is run again.
- **CPU cells** (analysis, tables, figures, page). Plain Colab Python, CPU runtime is enough;
  [`requirements-cpu.txt`](requirements-cpu.txt) lists what they import.

### Run order

| step | file | runtime | time | reads | writes (in `aclrh/`) |
|---|---|---|---|---|---|
| 01 | `openvla_oft/01_setup_verify.py` | GPU | 20-30 min | – | console check only |
| 02 | `openvla_oft/02_collect_probe_data.py` | GPU | ~30 min | – | `oft_probe.npz` |
| 03 | `openvla_oft/03_probing_positions.py` | CPU | ~2 min | 02 | `oft_probe_results.npz` |
| 05a | `openvla_oft/05a_probing_task_qoi.py` | CPU | ~2 min | 02 | `oft_probe_results_taskqoi.npz` |
| 04 | `openvla_oft/04_steering_heights.py` | GPU | ~30 min | 02 | `oft_steering.npz` |
| 05b | `openvla_oft/05b_steering_task_qoi.py` | GPU | ~30 min | 02 | `oft_steering_taskqoi.npz` |
| 05c | `openvla_oft/05c_steering_ee_mug2.py` | GPU | ~15 min | 02 | `oft_steering_ee_mug2.npz` |
| 06 | `openvla_oft/06_figures.py` | GPU | 10-20 min | 02, 04, 05b, 05c | `figs/*` (+ closed-loop `.pkl`) |
| 07 | `openvla_oft/07_replot_trajectories.py` | CPU | seconds | 06 | `figs/B_ep*_trajectories*.png` |
| 08 | `openvla_oft/08_replot_summary_curves.py` | CPU | seconds | 04, 05b, 05c | `figs/A_summary_curves.png` |
| 09 | `openvla_oft/09_plot_main_figure.py` | CPU | seconds | 06 | `figs/main_steering.png` |
| s1 | `smolvla/s1_collect_probe_data.py` | GPU (A100) | hours, resumable | – | `probe_v2.npz` |
| q1 | `probing/q1_probe_extended.py` | CPU | 10-20 min | 02, s1 | `q1_probe_extended.npz`, printed LaTeX rows |
| s2 | `smolvla/s2_steering.py` | GPU (A100) | hours, resumable | s1 | `smolvla_steering_v6.npz`, `smolvla_steering_v6_partial.pkl` |
| s3 | `smolvla/s3_steering_analysis.py` | CPU | 5-10 min | s1, s2 | `smolvla_steering_v6_analysis.npz`, printed LaTeX rows |
| s4 | `smolvla/s4_bimodality.py` | CPU | ~1 min | s1, s2 | printed counts |
| 16 | `use_case/16_intent_change.py` | GPU (A100 or L4) | 1.5-2 h, resumable | 02 | `intent_change/` |
| 18 | `use_case/18_intent_confirm.py` | GPU (A100 or L4) | 1-1.5 h (+ ~1 h with the sweep), resumable | 02, 16 | `intent_change_confirm/` |
| 17 | `use_case/17_usecase_figure.py` | CPU | seconds | 16, 18 | `intent_change_confirm/fig_usecase.(png\|pdf)` |
| 12 | `site/12_build_project_page.py` | CPU | ~1 min | 16, 18 | `site_v1/`, `site_v1.zip` |
| 19 | `site/19_figure_and_site.py` | CPU | ~1 min | 16, 18 | 17 + 12 in one cell, then serves the page in Colab |

Steps within one block can run in any order once their inputs exist; 03/05a and 04/05b/05c are independent of each
other.

## Settings that the reported numbers depend on

- OpenVLA-OFT checkpoint `moojink/openvla-7b-oft-finetuned-libero-10`, unnorm key `libero_10_no_noops`, two images +
  proprio, L1 regression head, chunks of 8 actions, re-plan every 8 steps, 10 waiting steps, at most 520 steps.
- Task: LIBERO-10 "put the white mug on the left plate and put the yellow and white mug on the right plate", all 50
  initial layouts.
- Representation z(x): the 32 leading principal coordinates of the action-head input, fitted on training episodes only.
- Folds: even / odd episode ids (2-fold cross-fitting for steering, 5 folds by episode for probing). `SEED = 0`.
- Finite-difference step `H_Z = 0.25` (standardized principal coordinates); steering step `STEP_REL = 0.005`, i.e.
  one unit of α moves the head input by 0.5% of its norm.
- SmolVLA: `lerobot[smolvla]==0.6.1`, 50 layouts, candidate chunks of 20 steps (1 s) at every 2nd snapshot (16 policy
  samples + 16 smooth perturbations); steering with `STEP_REL = 0.003` per unit τ and K_ST = 16 fresh samples per level,
  shared across strengths and directions (`smolvla/s2`).
- Use case: success = the yellow-and-white mug upright on the right plate for 0.5 s, the white mug never lifted and
  moved less than 3 cm, within 15 s (fixed before the runs). Step 16 chooses α and the height margin on 12 development
  starts and tests on 13 others; step 18 fixes α = 56 in advance, refits the probes on the other fold and runs the 25
  held-out starts of that fold once.

## Notes

- The environment fixes needed for OpenVLA-OFT + LIBERO in Colab are built into the GPU cells (LIBERO on
  `PYTHONPATH`, `~/.libero/config.yaml`, `MPLBACKEND=Agg`, `tensorflow-metadata==1.14.0`, a no-op `wandb` module,
  `mujoco==3.1.6`, LIBERO assets downloaded once in the main process). Keep them.
- Step 18 as reported used `STOP_ON_WHITE_LIFT = True` and `RUN_SWEEP = False`. The current defaults keep filming
  after the white mug is lifted (runs are still scored at the lift, so the numbers do not change) and add a sweep over
  weaker strengths for the project page; set them back to reproduce the reported run exactly.
- The bimodality criterion in `smolvla/s4_bimodality.py` was chosen after inspecting the outcomes; the paper reports
  it as a pattern, not as a test.
- The project page (`site/12`) shows the paper's numbers for the one-chunk steering table directly (`STEER`, `PROP`,
  `INC` at the top of the file) and prints a check of the result files against them.
- `extras/` holds runs that informed the experiments but are not reported in the paper.
- Figure `fig:Libero_figure` (the task layout) is not generated by code.

## Before a release

Run `python tools/check_anonymity.py --forbid "<name>" "<affiliation>" "<e-mail>"` from the repository root. It
fails if any of those strings, an e-mail address or a hidden file appears in the repository. The project page has its
own check (`FORBIDDEN` in `site/19_figure_and_site.py`) and strips video metadata. To link the code from the page as `code.zip`, copy this repository to `aclrh/code/` on Drive before running step 19.

## License

MIT, see [`LICENSE`](LICENSE). Third-party code (OpenVLA-OFT, LIBERO, LeRobot) keeps its own license.
