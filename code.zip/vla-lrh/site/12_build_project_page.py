# ======================================================================
# OpenVLA-OFT project page v1 (anonymous)  --  ONE Colab cell, CPU runtime is enough (no GPU, no venv)
#
#   reads   aclrh/oft_steering.npz, oft_steering_taskqoi.npz, oft_steering_ee_mug2.npz   (steps 04, 05b, 05c)
#           aclrh/rebuttal/page_data.json + rebuttal/videos/*.mp4                       (step 10)
#   writes  aclrh/site_v1/index.html (+ videos/), aclrh/site_v1.zip
#
#   Tables, tiles and the probing chart use the paper's numbers (PAPER below), so the page matches the PDF;
#   the result files are used for the curves, paths and videos, and are checked against PAPER.
#   PREVIEW = True builds the layout with placeholder curves/paths (clearly marked) and needs no Drive.
# ======================================================================
import glob, json, os, re, shutil, subprocess, sys, threading
import numpy as np

PREVIEW = os.environ.get("PAGE_PREVIEW") == "1"      # set True to see the layout without the result files
ROOT = os.environ.get("PAGE_ROOT", "/content/drive/MyDrive/aclrh")
OUT = os.environ.get("PAGE_OUT", f"{ROOT}/site_v1")
FORBIDDEN = list(globals().get("_FORBIDDEN", []))   # filled by the combined cell (19)
SERVE_IN_COLAB = False    # show the page inside the notebook after building

if not PREVIEW:
    try:
        from google.colab import drive
        if not os.path.isdir("/content/drive/MyDrive"):
            drive.mount("/content/drive")
    except ImportError:
        pass

# ---------------------------------------------------------------- the paper's numbers
QOI_LABEL = {"EE z (control)": "end-effector height (control)",
             "mug1 z": "white mug height",
             "mug2 z": "yellow-and-white mug height",
             "-d(mug1,plate) xy": "white mug → its plate",
             "-d(mug2,plate) xy": "yellow-and-white mug → its plate",
             "-d(EE,mug1)": "end effector → white mug",
             "-d(EE,mug2)": "end effector → yellow-and-white mug"}
QOI_ORDER = list(QOI_LABEL)
DIR_KEYS = ["sim-gradient", "Dphi^T lambda_psi", "gamma_psi", "static"]
# steering table (appendix, tab:oft_steering): monotone %, median effect J(8)-J(-8) mm, beats random %, cos to sim. grad.
STEER = {
 "EE z (control)":    {"sim-gradient": (100, 9.5, 100, 1.00), "Dphi^T lambda_psi": (100, 9.8, 100, 1.00),
                       "gamma_psi": (50, 0.4, 15, 0.03), "static": (0, -4.2, 0, -0.33), "random": (52, 0.6)},
 "mug1 z":            {"sim-gradient": (100, 12.9, 100, 1.00), "Dphi^T lambda_psi": (100, 12.9, 100, 1.00),
                       "gamma_psi": (65, 2.1, 30, 0.13), "static": (0, -2.2, 5, -0.14), "random": (45, -0.6)},
 "mug2 z":            {"sim-gradient": (100, 11.6, 100, 1.00), "Dphi^T lambda_psi": (100, 11.2, 100, 1.00),
                       "gamma_psi": (100, 5.5, 80, 0.27), "static": (0, -2.1, 5, -0.12), "random": (40, -1.0)},
 "-d(mug1,plate) xy": {"sim-gradient": (100, 12.3, 100, 1.00), "Dphi^T lambda_psi": (100, 11.9, 100, 0.98),
                       "gamma_psi": (100, 7.6, 70, 0.37), "static": (0, -11.3, 0, -0.61), "random": (42, -1.8)},
 "-d(mug2,plate) xy": {"sim-gradient": (100, 12.4, 100, 1.00), "Dphi^T lambda_psi": (100, 12.2, 100, 0.99),
                       "gamma_psi": (100, 9.2, 100, 0.43), "static": (100, 3.5, 25, 0.10), "random": (45, -0.2)},
 "-d(EE,mug1)":       {"sim-gradient": (100, 9.0, 100, 1.00), "Dphi^T lambda_psi": (95, 8.9, 95, 1.00),
                       "gamma_psi": (100, 5.3, 60, 0.35), "static": (45, -0.0, 20, -0.01), "random": (52, 0.2)},
 # TODO: check this row against the printed summary of 05c before release
 "-d(EE,mug2)":       {"sim-gradient": (100, 9.4, 100, 1.00), "Dphi^T lambda_psi": (95, 9.3, 95, 1.00),
                       "gamma_psi": (60, 1.7, 60, 0.35), "static": (95, 2.9, 20, -0.01), "random": (42, -0.4)},
}
N_STATES = 20
# probing tables (tab:oft_propagated: current, static only, +linear, +additive, +bilinear, +MLP readout, +unstructured;
#                 tab:oft_increment: linear, additive, bilinear, MLP readout, unstructured)
PROBE_ROWS = ["EE px", "EE py", "EE pz", "mug1 px", "mug1 py", "mug1 pz", "mug2 px", "mug2 py", "mug2 pz"]
PROBE_LABEL = {"EE px": "end effector x", "EE py": "end effector y", "EE pz": "end effector z",
               "mug1 px": "white mug x", "mug1 py": "white mug y", "mug1 pz": "white mug z (height)",
               "mug2 px": "yellow-and-white mug x", "mug2 py": "yellow-and-white mug y",
               "mug2 pz": "yellow-and-white mug z (height)"}
PROP = {"EE px": [.836, .510, .770, .820, .822, .820, .820], "EE py": [.833, .809, .848, .851, .851, .851, .851],
        "EE pz": [.944, .593, .902, .943, .943, .946, .945], "mug1 px": [.777, .671, .753, .763, .767, .768, .766],
        "mug1 py": [.865, .821, .853, .858, .861, .861, .862], "mug1 pz": [.956, .636, .918, .938, .946, .949, .949],
        "mug2 px": [.580, .453, .565, .586, .593, .593, .600], "mug2 py": [.814, .752, .842, .844, .846, .847, .846],
        "mug2 pz": [.965, .620, .921, .940, .959, .959, .960]}
INC = {"EE px": [.829, .983, .981, .982, .981], "EE py": [.912, .995, .995, .993, .995],
       "EE pz": [.867, .986, .986, .987, .988], "mug1 px": [.878, .933, .960, .970, .973],
       "mug1 py": [.806, .895, .959, .962, .967], "mug1 pz": [.825, .877, .918, .933, .941],
       "mug2 px": [.656, .801, .901, .916, .934], "mug2 py": [.908, .953, .979, .983, .983],
       "mug2 pz": [.813, .864, .923, .940, .939]}

# ---------------------------------------------------------------- one-chunk curves
def spearman(x, y):
    rx, ry = np.argsort(np.argsort(x)), np.argsort(np.argsort(y))
    return 0.0 if np.ptp(y) < 1e-12 else float(np.corrcoef(rx, ry)[0, 1])

TAUS = [-8.0, -4.0, -2.0, 0.0, 2.0, 4.0, 8.0]
curves, missing = {}, []
if PREVIEW:
    rng = np.random.default_rng(1)
    for qn in QOI_ORDER:
        sim_e = STEER[qn]["sim-gradient"][1]
        base = rng.normal(1, .3, N_STATES)
        Jq = {}
        for d in DIR_KEYS:
            e = STEER[qn][d][1]
            if d in ("sim-gradient", "Dphi^T lambda_psi"):
                s = e / 16 * base * (1 if d == "sim-gradient" else rng.normal(.98, .03, N_STATES))
            else:
                s = e / 16 + abs(sim_e) / 16 * .35 * rng.normal(size=N_STATES)
            c = rng.normal(0, .004, N_STATES) * abs(sim_e) / 16
            Jq[d] = [[round(float(si * t + ci * t * t + (0 if t == 0 else rng.normal(0, .05))), 3) for t in TAUS]
                     for si, ci in zip(s, c)]
        curves[qn] = Jq
else:
    for f in [f"{ROOT}/oft_steering.npz", f"{ROOT}/oft_steering_taskqoi.npz", f"{ROOT}/oft_steering_ee_mug2.npz"]:
        if not os.path.exists(f):
            missing.append(f); continue
        R = np.load(f)
        TAUS = [float(t) for t in R["taus"]]
        i0 = TAUS.index(0.0)
        for qn in QOI_ORDER:
            Jq = {}
            for d in DIR_KEYS:
                k = f"{qn}|{d}|J"
                if k in R.files:
                    M = 1e3 * R[k]
                    Jq[d] = np.round(M - M[:, [i0]], 3).tolist()
            if Jq:
                curves[qn] = Jq
    # consistency check against the paper's table
    print("one-chunk results vs the paper's table (median effect mm / monotone %):")
    for qn, Jq in curves.items():
        for d, M in Jq.items():
            M = np.array(M); eff = float(np.median(M[:, -1] - M[:, 0]))
            mono = 100 * np.mean([spearman(TAUS, r) >= 0.8 for r in M])
            p_mono, p_eff = STEER[qn][d][0], STEER[qn][d][1]
            flag = "" if (abs(eff - p_eff) <= 0.15 and abs(mono - p_mono) <= 2.6) else "   <-- differs from PAPER"
            print(f"  {qn:20s} {d:18s} data {eff:+6.1f} / {mono:4.0f}%   paper {p_eff:+6.1f} / {p_mono:4.0f}%{flag}")

# ---------------------------------------------------------------- closed loop
def synth_closed_loop():
    """placeholder closed-loop data with the structure of step 10's page_data.json (preview only)"""
    rng = np.random.default_rng(2)
    T = 25                                                       # 2.4 s at 0.1 s per point
    scen = [("carry", "-d(mug1,plate) xy", "carry the white mug to its plate", (-9.0, -16.0), (-4.0, -31.0)),
            ("approach", "-d(EE,mug1)", "approach the white mug", (-6.3, 0.9), (-10.0, -17.2)),
            ("approach", "-d(EE,mug2)", "approach the yellow-and-white mug", (-6.3, 0.9), (-4.5, 10.5))]
    gain = {"Dphi^T lambda_psi": 1.0, "static": -0.55, "gamma_psi": 0.25}
    other = {"-d(EE,mug1)": (-4.5, 10.5), "-d(EE,mug2)": (-10.0, -17.2)}
    page = {"scenarios": [], "alphas": [-16.0, 0.0, 16.0], "directions": list(gain), "dt": 0.05, "rows": []}
    for sc, psi, title, s0, g0 in scen:
        for si in range(6):
            s = np.array(s0) + rng.normal(0, 1.2, 2); g = np.array(g0) + rng.normal(0, 1.2, 2)
            t = np.linspace(0, 1, T)[:, None]
            heading = (np.array((-10.0, -17.2)) - s) if sc == "approach" else (g + np.array((6.0, 5.0)) - s)
            base = s + 0.55 * heading * (3 * t ** 2 - 2 * t ** 3)
            runs = []
            for dn, k in gain.items():
                for a in page["alphas"]:
                    to_g = (g - base); to_g /= np.linalg.norm(to_g, axis=1, keepdims=True)
                    side = np.stack([-to_g[:, 1], to_g[:, 0]], 1)
                    push = to_g + 0.7 * side
                    P = base + (a / 16) * k * (4.0 + rng.normal(0, .6)) * (t ** 1.6) * push if a else base
                    psi_cm = -np.linalg.norm(P - g, axis=1)
                    runs.append({"direction": dn, "alpha": a, "ee_xy_cm": np.round(P, 2).tolist(),
                                 "psi_cm": np.round(psi_cm, 2).tolist()})
            entry = {"scenario": sc, "title": title, "start": 100 + 10 * si, "psi": psi,
                     "target_xy_cm": np.round(g, 2).tolist(), "runs": runs}
            if psi in other:
                entry["_other"] = np.array(other[psi]) + rng.normal(0, 1.2, 2)
            page["scenarios"].append(entry)
    return page

def summarize(page):
    rows = []
    for e in page["scenarios"]:
        end = {(r["direction"], r["alpha"]): r["psi_cm"][-1] for r in e["runs"]}
        for dn in page["directions"]:
            lo, mid, hi = end[(dn, -16.0)], end[(dn, 0.0)], end[(dn, 16.0)]
            oth = None
            if "_other" in e:
                pe = {a: np.array([r for r in e["runs"] if r["direction"] == dn and r["alpha"] == a][0]["ee_xy_cm"][-1])
                      for a in (-16.0, 16.0)}
                oth = float(np.linalg.norm(pe[-16.0] - e["_other"]) - np.linalg.norm(pe[16.0] - e["_other"]))
            rows.append(dict(scenario=e["scenario"], psi=e["psi"], start=e["start"], direction=dn,
                             effect_cm=hi - lo, other_cm=oth, ordered=bool(lo < mid < hi)))
    for e in page["scenarios"]:
        e.pop("_other", None)
    return rows

closed = None
if PREVIEW:
    closed = synth_closed_loop()
    closed["rows"] = summarize(closed)
elif os.path.exists(f"{ROOT}/rebuttal/page_data.json"):
    closed = json.load(open(f"{ROOT}/rebuttal/page_data.json"))
    for e in closed["scenarios"]:                                 # keep only what the page needs
        e.pop("target_xy_px", None)
        for r in e["runs"]:
            r.pop("ee_px", None)
else:
    missing.append(f"{ROOT}/rebuttal/page_data.json")

# ---------------------------------------------------------------- use case (step 16): move only the yellow-and-white mug
UC_COND = ["A_original", "B_lang_put", "C_lang_move", "D_steer"]
UC_LABEL = {"A_original": "original instruction", "B_lang_put": "new instruction (1)", "C_lang_move": "new instruction (2)",
            "D_steer": "steering (ours)"}
UC_INSTR = {"A_original": "put the white mug on the left plate and put the yellow and white mug on the right plate",
            "B_lang_put": "put the yellow and white mug on the right plate",
            "C_lang_move": "move the yellow and white mug to the right plate",
            "D_steer": "put the white mug on the left plate and put the yellow and white mug on the right plate"}
UC_OUT = ["success", "knocked a mug", "went for the white mug", "grasped, not placed", "no grasp"]

def uc_outcome(r):
    if r["success"]:
        return "success"
    if r["tipped"] or (r["white_move_cm"] >= 3.0 and r["first_lift"] != "white"):
        return "knocked a mug"
    if r["first_lift"] == "white":
        return "went for the white mug"
    if r["first_lift"] == "yellow":
        return "grasped, not placed"
    return "no grasp"

def synth_usecase():
    """placeholder with the structure of step 16's results (preview only)"""
    rng = np.random.default_rng(5)
    eps, sweep, chosen = list(range(25, 51, 2)), [16.0, 24.0, 40.0, 56.0], 32.0
    out = {"eps": eps, "sweep": sorted(set(sweep + [chosen])), "row2": sweep, "chosen": chosen, "rows": {}, "paths": {}, "objs": {},
           "videos": {}}
    prob = {16.0: [.05, .05, .8, .05, .05], 24.0: [.25, .05, .4, .1, .2], 32.0: [.45, .1, .2, .1, .15],
            40.0: [.45, .2, .1, .15, .1], 56.0: [.2, .45, .05, .2, .1]}
    for e in eps:
        y, w, pl = np.array([30.0, 0.0]), np.array([0.0, 20.0]), np.array([30.0, -30.0])
        out["objs"][e] = {"white mug": w.tolist(), "yellow-and-white mug": y.tolist(), "right plate": pl.tolist()}
        r = {c: ("went for the white mug" if c != "D_steer" else None) for c in UC_COND}
        paths = {"none": [[float(v) for v in w * min(1, t / 20) + rng.normal(0, .3, 2)] for t in range(30)]}
        for a in out["sweep"]:
            o = UC_OUT[rng.choice(5, p=prob[a])]
            r[f"a{a:.0f}"] = o
            k = min(1.0, a / 40)
            tgt = (1 - k) * w + k * y
            paths[f"{a:.0f}"] = [[float(v) for v in tgt * min(1, t / 20) + rng.normal(0, .3, 2)] for t in range(30)]
        r["D_steer"] = r[f"a{chosen:.0f}"]
        out["rows"][e], out["paths"][e] = r, paths
    out["confirm"], out["grid_rows"] = False, {}
    out["weak"] = {"alphas": [16.0, 24.0, 32.0], "n_eps": len(eps), "n_fail": 30, "n_switch": 12, "n_tip": 5,
                   "sets": [{"video": None, "cases": [{"alpha": a, "start": eps[3 * i + j], "outcome": "went for the white mug",
                                                       "story": "Heads for the yellow-and-white mug → the white mug."}
                                                      for j, a in enumerate([16.0, 24.0, 32.0])]} for i in range(3)]}
    return out

usecase = None
UC_DIR = f"{ROOT}/intent_change_confirm"                    # step 18: confirmation run (fixed alpha + weaker strengths)
if not os.path.exists(f"{UC_DIR}/results.json"):
    UC_DIR = f"{ROOT}/intent_change"                        # fall back to step 16
UC_RES = f"{UC_DIR}/results.json"
if PREVIEW:
    usecase = synth_usecase()
elif os.path.exists(UC_RES):
    U = json.load(open(UC_RES))
    eps = sorted({int(k.split("|")[0]) for k in U["test"]})
    chosen = float(U["chosen"]["alpha"])
    row2 = [float(a) for a in U["sweep"]] if U.get("sweep") else \
        sorted({float(k.split("|")[1][5:]) for k in U["test"] if "|sweep" in k})     # strengths in the video's second row
    sweep = sorted(set(row2) | {chosen})
    usecase = {"eps": eps, "sweep": sweep, "row2": row2, "chosen": chosen, "rows": {}, "paths": {}, "objs": {}, "videos": {},
               "confirm": UC_DIR.endswith("_confirm")}
    cam = lambda xy: [round(100 * xy[0], 2), round(100 * xy[1], 2)]
    for e in eps:
        row, paths = {}, {}
        for c in UC_COND:
            r = U["test"].get(f"{e}|{c}")
            if r:
                row[c] = uc_outcome(r)
                if c == "A_original":
                    paths["none"] = [cam(p_) for p_ in r["path"]]
                    usecase["objs"][e] = {{"white": "white mug", "yellow": "yellow-and-white mug", "red": "red mug"}.get(k, k): cam(v)
                                          for k, v in r["objs0"].items()}
        for a in sweep:
            r = U["test"].get(f"{e}|sweep{a:.0f}") or (U["test"].get(f"{e}|D_steer") if a == chosen else None)
            if r:
                row[f"a{a:.0f}"] = uc_outcome(r); paths[f"{a:.0f}"] = [cam(p_) for p_ in r["path"]]
        usecase["rows"][e], usecase["paths"][e] = row, paths
        if os.path.exists(f"{UC_DIR}/test_ep{e:02d}_grid.mp4"):
            usecase["videos"][e] = f"usecase_ep{e:02d}.mp4"
else:
    missing.append(UC_RES)
if usecase:
    usecase.update(cond=UC_COND, label=UC_LABEL, instr=UC_INSTR, outcomes=UC_OUT)

# ---------------------------------------------------------------- success rate by strength
def strength_rows(R_, eps_, alphas, chosen_):
    out = {}
    for a in alphas:
        rs = [R_["test"].get(f"{e}|sweep{a:.0f}") or (R_["test"].get(f"{e}|D_steer") if abs(a - chosen_) < 1e-9 else None)
              for e in eps_]
        rs = [r for r in rs if r is not None]
        if rs:
            out[a] = ([sum(uc_outcome(r) == o for r in rs) for o in UC_OUT], len(rs))
    return out

if usecase:
    if PREVIEW:
        own = {a: ([sum(usecase["rows"][e].get(f"a{a:.0f}") == o for e in usecase["eps"]) for o in UC_OUT], len(usecase["eps"]))
               for a in usecase["sweep"]}
        other = {}
    else:
        own, other = strength_rows(U, eps, sweep, chosen), {}
        F16 = f"{ROOT}/intent_change/results.json"
        if UC_DIR.endswith("_confirm") and os.path.exists(F16):          # weaker strengths not run here: from the first run
            S16 = json.load(open(F16)); e16 = sorted({int(k.split("|")[0]) for k in S16["test"]}); c16 = float(S16["chosen"]["alpha"])
            a16 = sorted({float(k.split("|sweep")[1]) for k in S16["test"] if "|sweep" in k} | {c16})
            other = {a: v for a, v in strength_rows(S16, e16, a16, c16).items() if a not in own and a < chosen}
    usecase["strength"] = sorted([{"alpha": a, "counts": c, "n": n, "first_run": False} for a, (c, n) in own.items()] +
                                 [{"alpha": a, "counts": c, "n": n, "first_run": True} for a, (c, n) in other.items()],
                                 key=lambda d: d["alpha"])

# ---------------------------------------------------------------- section B: indecisive failures at weaker strengths
WEAK_ALPHAS, WEAK_SETS = [16.0, 24.0, 32.0], 3          # one failure per strength in each example, most indecisive first
MUG_NAME = {"white": "the white mug", "yellow": "the yellow-and-white mug", "red": "the red mug"}

def headings(r, win=3, min_rate=0.01, min_run=3):
    """mugs the end effector heads for, in order; from the top-down path (a point every 0.2 s):
    at each time the mug it closes in on fastest over the next 0.6 s (at least 1 cm), kept if held for >= 0.6 s"""
    P = np.asarray(r["path"], float)
    M = {k: np.asarray(v, float) for k, v in r["objs0"].items() if k in MUG_NAME}
    if len(P) <= win or not M:
        return []
    Dk = {k: np.linalg.norm(P - v, axis=1) for k, v in M.items()}
    seq = []
    for t in range(len(P) - win):
        rate = {k: d[t] - d[t + win] for k, d in Dk.items()}
        k = max(rate, key=rate.get)
        seq.append(k if rate[k] > min_rate else None)
    runs = []
    for k in seq:
        if runs and runs[-1][0] == k:
            runs[-1][1] += 1
        else:
            runs.append([k, 1])
    out = []
    for k, n in runs:
        if k and n >= min_run and (not out or out[-1] != k):
            out.append(k)
    return out

def tipped_of(r):
    t = r.get("tipped") or {}
    return [k for k in t if k in MUG_NAME] if isinstance(t, (dict, list)) else ["a mug"]

def story(r):
    h, tip = headings(r), tipped_of(r)
    s_ = ("Heads for " + " → ".join(MUG_NAME[k] for k in h)) if h else "Never heads clearly for any mug"
    return s_ + ("; knocks over " + " and ".join(MUG_NAME.get(k, k) for k in tip) if tip else "") + "."

def indecision(r):
    h = headings(r)
    return 2 * max(0, len(h) - 1) + 2 * len(tipped_of(r)) + (len(set(h)) >= 2)

def first_height(path):
    try:
        import imageio.v2 as iio
        rd = iio.get_reader(path); h = rd.get_data(0).shape[0]; rd.close(); return h
    except Exception:
        return None

if usecase and not PREVIEW:
    # rows in each composite video (1 before the sweep of step 18 ran, 2 after), so the page crops it right
    usecase["grid_rows"] = {}
    for e in usecase["videos"]:
        hg, hs = first_height(f"{UC_DIR}/test_ep{e:02d}_grid.mp4"), first_height(f"{UC_DIR}/test_ep{e:02d}_A_original.mp4")
        usecase["grid_rows"][e] = max(1, round(hg / hs)) if hg and hs else 1
    key = lambda e, a: f"{e}|sweep{a:.0f}"
    # weaker-strength runs: from the confirmation run if its sweep (step 18) ran, else from the first run (step 16)
    WDIR, WU = UC_DIR, U
    have = lambda R_, a: any(k.endswith(f"|sweep{a:.0f}") for k in R_["test"])
    if not any(have(WU, a) for a in WEAK_ALPHAS) and os.path.exists(f"{ROOT}/intent_change/results.json"):
        WDIR = f"{ROOT}/intent_change"; WU = json.load(open(f"{WDIR}/results.json"))
    W_ALPHAS = [a for a in WEAK_ALPHAS if have(WU, a)]
    W_ALPHAS += [a for a in sorted({float(k.split("|sweep")[1]) for k in WU["test"] if "|sweep" in k})
                 if a not in W_ALPHAS and a < float(WU["chosen"]["alpha"]) + 1e-9 and a < chosen][:max(0, 3 - len(W_ALPHAS))]
    W_ALPHAS = sorted(W_ALPHAS)
    weps = sorted({int(k.split("|")[0]) for k in WU["test"]})
    print(f"section B: weaker strengths {W_ALPHAS} from {WDIR} ({len(weps)} starts)")
    fails = {a: [e for e in weps if key(e, a) in WU["test"] and not WU["test"][key(e, a)]["success"]] for a in W_ALPHAS}
    cand = {a: sorted(fails[a], key=lambda e: (-indecision(WU["test"][key(e, a)]), e)) for a in W_ALPHAS}
    used, sets = {a: set() for a in W_ALPHAS}, []
    os.makedirs(f"{OUT}/videos", exist_ok=True)
    for k in range(WEAK_SETS):
        here, cases = set(), []
        for a in W_ALPHAS:
            e = next((e for e in cand[a] if e not in used[a] and e not in here), None)
            if e is None:
                break
            used[a].add(e); here.add(e); r = WU["test"][key(e, a)]
            cases.append({"alpha": a, "start": e, "outcome": uc_outcome(r), "story": story(r)})
        if not W_ALPHAS or len(cases) < len(W_ALPHAS):
            break
        # the run at the run's own fixed alpha was saved as D_steer, not as a separate sweep video
        vsrc = lambda e, a: next((v for v in (f"{WDIR}/test_ep{e:02d}_sweep{a:.0f}.mp4", f"{WDIR}/test_ep{e:02d}_D_steer.mp4")
                                  if os.path.exists(v) and (v.endswith(f"sweep{a:.0f}.mp4") or abs(a - float(WU["chosen"]["alpha"])) < 1e-9)),
                                 f"{WDIR}/test_ep{e:02d}_sweep{a:.0f}.mp4")
        srcs = [vsrc(c["start"], c["alpha"]) for c in cases]
        name = None
        if all(os.path.exists(v) for v in srcs):
            try:
                import imageio.v2 as iio
                vs = [iio.mimread(v, memtest=False) for v in srcs]
                T, h = max(len(v) for v in vs), min(v[0].shape[0] for v in vs)
                iio.mimsave(f"{OUT}/videos/weak_{k + 1}.mp4", [np.concatenate([v[min(t, len(v) - 1)][:h] for v in vs], axis=1)
                                                             for t in range(T)], fps=20, macro_block_size=1)
                name = f"weak_{k + 1}.mp4"; del vs
            except Exception as ex:
                print(f"  [!] section B: could not compose example {k + 1}: {type(ex).__name__}: {ex}")
        else:
            missing += [v for v in srcs if not os.path.exists(v)]
            print("  [!] section B: video files missing, e.g.", next(v for v in srcs if not os.path.exists(v)))
        sets.append({"video": name, "cases": cases})
    allf = [WU["test"][key(e, a)] for a in W_ALPHAS for e in fails[a]]
    usecase["weak"] = {"alphas": W_ALPHAS, "sets": sets, "n_eps": len(weps), "n_fail": len(allf),
                       "first_run": WDIR != UC_DIR,
                       "n_switch": sum(len(headings(r)) >= 2 for r in allf), "n_tip": sum(bool(tipped_of(r)) for r in allf)}
    print(f"section B: {len(sets)} examples, videos " + (", ".join(x["video"] for x in sets if x["video"]) or "NONE"))

# ---------------------------------------------------------------- page data
data = {
    "preview": PREVIEW, "taus": TAUS, "curves": curves, "closed": closed,
    "qoi_order": QOI_ORDER, "qoi_label": QOI_LABEL,
    "steer": {q: {d: list(v) for d, v in s.items()} for q, s in STEER.items()}, "n_states": N_STATES,
    "probe": {"rows": PROBE_ROWS, "label": PROBE_LABEL, "prop": PROP, "inc": INC},
    "usecase": usecase,
    "repo_url": os.environ.get("PAGE_REPO_URL", ""),   # e.g. the anonymous mirror of the repository; empty: no link
}
data["closed"], data["curves"] = None, {}          # not shown on the page any more (kept in the paper)

TEMPLATE = r"""<!doctype html>
<html lang="en" data-theme="light">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title>Representation Steering · OpenVLA-OFT</title>
<style>
:root{color-scheme:light;
 --page:#f9f9f7;--surface:#fcfcfb;--ink:#0b0b0b;--ink2:#52514e;--muted:#898781;--grid:#e1e0d9;--axis:#c3c2b7;
 --ring:rgba(11,11,11,.10);--ours:#eb6834;--wo:#2a78d6;--std:#1baf7a;--oracle:#c3c2b7;--neutral:#898781;
 --warn:#fab219;--sel:rgba(11,11,11,.04);
 --o1:#2a78d6;--o2:#eb6834;--o3:#1baf7a;--o4:#eda100;--o5:#e87ba4;--a1:#86b6ef;--a2:#5598e7;--a3:#3987e5;--a4:#256abf;--a5:#0d366b}
@media (prefers-color-scheme:dark){:root:where(:not([data-theme="light"])){color-scheme:dark;
 --page:#0d0d0d;--surface:#1a1a19;--ink:#f0efec;--ink2:#c3c2b7;--muted:#898781;--grid:#2c2c2a;--axis:#383835;
 --ring:rgba(255,255,255,.10);--ours:#d95926;--wo:#3987e5;--std:#199e70;--oracle:#55544f;--neutral:#898781;--sel:rgba(255,255,255,.05);
 --o1:#3987e5;--o2:#d95926;--o3:#199e70;--o4:#c98500;--o5:#d55181;--a1:#184f95;--a2:#256abf;--a3:#3987e5;--a4:#6da7ec;--a5:#b7d3f6}}
:root[data-theme="dark"]{color-scheme:dark;
 --page:#0d0d0d;--surface:#1a1a19;--ink:#f0efec;--ink2:#c3c2b7;--muted:#898781;--grid:#2c2c2a;--axis:#383835;
 --ring:rgba(255,255,255,.10);--ours:#d95926;--wo:#3987e5;--std:#199e70;--oracle:#55544f;--neutral:#898781;--sel:rgba(255,255,255,.05);
 --o1:#3987e5;--o2:#d95926;--o3:#199e70;--o4:#c98500;--o5:#d55181;--a1:#184f95;--a2:#256abf;--a3:#3987e5;--a4:#6da7ec;--a5:#b7d3f6}
*{box-sizing:border-box}
html{scroll-behavior:smooth;scroll-padding-top:56px}
body{margin:0;background:var(--page);color:var(--ink);font:16px/1.6 system-ui,-apple-system,"Segoe UI",sans-serif}
a{color:inherit}
nav.top{position:sticky;top:0;z-index:10;background:color-mix(in srgb,var(--page) 92%,transparent);backdrop-filter:blur(6px);
 border-bottom:1px solid var(--grid)}
nav.top .in{max-width:1040px;margin:0 auto;padding:10px 16px;display:flex;gap:18px;align-items:center;overflow-x:auto;white-space:nowrap;font-size:14px}
nav.top a{text-decoration:none;color:var(--ink2)} nav.top a:hover{color:var(--ink)}
nav.top .sp{flex:1}
nav.top button{font:inherit;font-size:13px;background:none;border:1px solid var(--grid);border-radius:6px;color:var(--ink2);padding:3px 9px;cursor:pointer}
main{max-width:1040px;margin:0 auto;padding:8px 16px 96px}
section{padding-top:44px}
.k{font-size:12px;letter-spacing:.08em;text-transform:uppercase;color:var(--muted);margin:0 0 6px}
h1{font-size:clamp(28px,4.4vw,42px);line-height:1.15;margin:8px 0 12px;font-weight:650;letter-spacing:-.01em;max-width:860px}
h2{font-size:clamp(21px,2.6vw,27px);line-height:1.25;margin:0 0 8px;font-weight:650;letter-spacing:-.005em;max-width:860px}
h3{font-size:15px;margin:0 0 8px;font-weight:600}
p{margin:0 0 12px;max-width:760px} .lede{font-size:18px;color:var(--ink2);max-width:780px}
.note{font-size:13.5px;color:var(--muted);margin-top:8px}
.card{background:var(--surface);border:1px solid var(--ring);border-radius:12px;padding:18px}
.stack>*+*{margin-top:14px}
.grid2{display:grid;grid-template-columns:1fr 1fr;gap:16px}
.grid3{display:grid;grid-template-columns:repeat(3,1fr);gap:14px}
.grid4{display:grid;grid-template-columns:repeat(4,1fr);gap:12px}
.side{display:grid;grid-template-columns:minmax(0,1.55fr) minmax(0,1fr);gap:16px;align-items:start}
.cmpc{display:grid;grid-template-columns:repeat(3,1fr);gap:14px}
.cmpc .card h3{font-size:12px;letter-spacing:.07em;text-transform:uppercase;color:var(--muted);font-weight:600;margin-bottom:10px}
.cmpc dl{margin:0}.cmpc dt{font-size:12.5px;color:var(--muted);margin-top:8px}.cmpc dd{margin:2px 0 0;font-size:15px}
.cmpc .us{border-top:3px solid var(--ours)}
table.rt th{text-align:left;vertical-align:bottom}table.rt td{text-align:left;vertical-align:middle}
table.rt td.c,table.rt th.c{text-align:center}table.rt th span{display:block;font-size:12px;color:var(--muted);font-weight:400}
table.rt tr.ours td{background:var(--sel)} table.rt .nm{font-weight:600} table.rt .sy{color:var(--muted);font-size:13px;margin-left:4px}
.ic{width:26px;height:26px;vertical-align:middle}
@media (max-width:640px){table.rt thead{display:none}table.rt,table.rt tbody{display:block}
 table.rt tr{display:grid;grid-template-columns:auto auto 1fr;align-items:center;gap:4px 14px;padding:10px 6px;border-bottom:1px solid var(--grid)}
 table.rt td{border:none;padding:0}table.rt td:first-child{grid-column:1/-1}table.rt .sy{margin-left:6px}
 table.rt td[data-u]{display:flex;flex-direction:column;align-items:center;font-size:11.5px;color:var(--muted)}
 table.rt td[data-u]::before{content:attr(data-l);margin-bottom:2px}}
@media (max-width:820px){.grid2,.grid3,.side,.cmpc{grid-template-columns:1fr}.grid4{grid-template-columns:1fr 1fr}
 .read{grid-template-columns:1fr 1fr}.ph{grid-template-columns:1fr 1fr;aspect-ratio:1.6/1}.tile .v{font-size:27px}}
.tile .v{font-size:34px;font-weight:650;line-height:1.1;letter-spacing:-.01em}
.tile .l{font-size:14px;color:var(--ink2);margin-top:4px}
.ctrl{display:flex;flex-wrap:wrap;gap:8px 14px;align-items:center;font-size:14px;margin-bottom:12px}
.ctrl label{color:var(--muted)}
select,.seg button{font:inherit;font-size:14px;background:var(--surface);color:var(--ink);border:1px solid var(--grid);border-radius:7px;padding:5px 9px}
.seg{display:inline-flex;gap:0}.seg button{border-radius:0;margin-left:-1px;cursor:pointer;color:var(--ink2)}
.seg button:first-child{border-radius:7px 0 0 7px;margin-left:0}.seg button:last-child{border-radius:0 7px 7px 0}
.seg button.on{color:var(--ink);font-weight:600;background:var(--sel);border-color:var(--axis);position:relative}
svg{display:block;width:100%;height:auto;overflow:visible}
svg text{fill:var(--muted);font:12px system-ui,-apple-system,"Segoe UI",sans-serif}
svg text.ink{fill:var(--ink2)} svg text.lab{fill:var(--ink2);font-size:13px}
.legend{display:flex;flex-wrap:wrap;gap:6px 16px;font-size:13px;color:var(--ink2);margin:2px 0 8px}
.legend i{display:inline-block;vertical-align:middle;margin-right:6px}
.lk{width:18px;height:2px;border-radius:1px} .lk.wide{height:7px;border-radius:4px;opacity:.8}
.dk{width:10px;height:10px;border-radius:50%} .rk{width:10px;height:10px;border-radius:50%;border:2px solid var(--muted)}
.sk{width:10px;height:10px;border:2px solid var(--muted);border-radius:2px}
.dash{width:18px;height:0;border-top:2px dashed var(--ink2)}
table{border-collapse:collapse;width:100%;font-size:14px;font-variant-numeric:tabular-nums}
th,td{padding:6px 8px;border-bottom:1px solid var(--grid);text-align:right}
th{color:var(--muted);font-weight:500;font-size:12.5px} th:first-child,td:first-child{text-align:left}
tr.ours td{font-weight:600}
.sw{display:inline-block;width:9px;height:9px;border-radius:50%;margin-right:7px;vertical-align:middle}
.cmp td,.cmp th{vertical-align:top;text-align:left;font-variant-numeric:normal}
.cmp th{font-size:12px;letter-spacing:.06em;text-transform:uppercase}
.cmp td:first-child{color:var(--muted);width:110px;font-size:13px}
.cmp .us{background:var(--sel)}
.eq{font-family:ui-serif,Georgia,serif;font-size:17px;padding:10px 14px;border-left:3px solid var(--ours);background:var(--sel);border-radius:0 8px 8px 0;margin:12px 0}
.vbox{border-radius:10px;overflow:hidden}
.vbox video{width:100%;height:auto;display:block;background:#000}
.ph{aspect-ratio:4/1.15;display:grid;grid-template-columns:repeat(4,1fr);gap:2px;background:var(--grid);border-radius:10px;overflow:hidden}
.ph div{background:var(--surface);display:flex;align-items:center;justify-content:center;color:var(--muted);font-size:13px;text-align:center;padding:8px}
.read{display:grid;grid-template-columns:repeat(4,1fr);gap:2px;margin-top:8px;font-size:13.5px}
.read div{padding:4px 6px}.read b{display:block;font-weight:600;color:var(--ink)}
.read span{color:var(--ink2)}
.banner{background:color-mix(in srgb,var(--warn) 18%,var(--surface));border:1px solid color-mix(in srgb,var(--warn) 55%,transparent);
 border-radius:10px;padding:10px 14px;font-size:14px;margin:14px 0 0}
.scope li{margin:6px 0}
.tip{position:fixed;pointer-events:none;z-index:20;background:var(--surface);border:1px solid var(--ring);border-radius:8px;
 box-shadow:0 4px 18px rgba(0,0,0,.12);padding:8px 10px;font-size:13px;min-width:150px;display:none}
.tip .t{color:var(--muted);font-size:12px;margin-bottom:4px}
.tip .r{display:flex;align-items:center;gap:8px;justify-content:space-between}
.tip .r b{font-weight:650;font-variant-numeric:tabular-nums}
.tip .r i{display:inline-block;width:12px;height:2px;margin-right:6px;vertical-align:middle}
.hidden{display:none!important}
@media (max-width:820px){.read{grid-template-columns:1fr 1fr}}
button.lnk{font:inherit;font-size:13px;background:none;border:none;color:var(--ink2);text-decoration:underline;cursor:pointer;padding:0}

/* Editorial research edition */
:root{--page:#f7f7f2;--surface:#fff;--ink:#202b27;--ink2:#53605a;--muted:#68736c;--grid:#dedfd7;--axis:#bdc5bb;--ring:#dedfd7;--ours:#bd542e;--wo:#537b96;--std:#64836c;--oracle:#a9afa9;--sel:#f1f3eb}
:root[data-theme="dark"]{--page:#151c19;--surface:#1e2822;--ink:#edf0e7;--ink2:#c3cdbf;--muted:#a4b19f;--grid:#38453a;--axis:#667963;--ring:#38453a;--ours:#ed956a;--wo:#81afca;--std:#93b493;--sel:#2b392e}
html{scroll-padding-top:100px}body{font-family:Arial,Helvetica,sans-serif;-webkit-font-smoothing:antialiased;line-height:1.7}
nav.top{background:var(--page);backdrop-filter:none}nav.top .in{max-width:1240px;padding:22px 36px;gap:28px;font-size:12px}
nav.top .brand{font-size:16px;font-weight:700;letter-spacing:-.5px;margin-right:auto;color:var(--ink)}.brand span{font-weight:400;color:var(--muted)}
nav.top .sp{display:none}nav.top button{border-radius:50%;width:34px;height:34px;padding:0;font-size:17px}nav.top a.active{color:var(--ours)}
main{max-width:1240px;padding:0 36px 60px}section{padding-top:90px}section+section{margin-top:76px;border-top:1px solid var(--grid)}
#top{padding-top:68px!important}.k{font:11px/1.5 ui-monospace,monospace;letter-spacing:.14em;color:var(--ink2);margin-bottom:24px}
.hero-head{display:grid;grid-template-columns:1.4fr 1fr;gap:60px;align-items:end;margin-bottom:46px}
h1{font-family:Georgia,'Times New Roman',serif;font-size:clamp(46px,5.6vw,76px);font-weight:400;line-height:1.04;letter-spacing:-.055em;margin:0;max-width:710px}h1 em{font-weight:400;color:var(--ours)}
h2{font-family:Georgia,'Times New Roman',serif;font-size:clamp(30px,3.6vw,47px);font-weight:400;line-height:1.12;letter-spacing:-.035em;max-width:850px;margin-bottom:24px}
h3{font-size:18px;letter-spacing:-.025em;font-weight:600;margin-bottom:20px}.lede{font-size:17px;line-height:1.8;max-width:760px;margin-bottom:32px}.hero-copy p{font-size:16px;color:var(--ink2);margin-bottom:24px}
.hero-actions{display:flex;flex-wrap:wrap;gap:12px}.hero-actions a{padding:10px 18px;border:1px solid var(--ink);border-radius:3px;font-size:12px;text-decoration:none}.hero-actions a:first-child{background:var(--ink);color:var(--page)}
.hero-meta{display:flex;gap:25px;flex-wrap:wrap;border-top:1px solid var(--grid);padding:16px 0 22px;font:10px ui-monospace,monospace;letter-spacing:.08em;color:var(--muted)}
.card{border-radius:5px;padding:28px;box-shadow:none}.grid2{gap:22px}.grid4{gap:0;border-top:1px solid var(--grid);border-bottom:1px solid var(--grid);margin:34px 0}.tile.card{border:0;border-radius:0;background:transparent;padding:28px 24px;border-right:1px solid var(--grid)}.tile.card:last-child{border-right:0}.tile .v{font:40px/1.2 Georgia,serif;letter-spacing:-.04em}.tile .l{font-size:12px;margin-top:12px;line-height:1.7}
.demo-card{padding:0;overflow:hidden;border-color:var(--axis)}.demo-card .ctrl{padding:18px 24px;margin:0;background:var(--surface)}.demo-card .ctrl:before{content:'01 / BEHAVIOR IN ACTION';font:11px ui-monospace,monospace;letter-spacing:.08em;margin-right:auto}.demo-card .read,.demo-card .note{margin:18px 24px}.vbox{border-radius:0}.read{gap:16px}.read div{border-top:2px solid var(--grid);padding:12px 0;font-size:12px}.read div:last-child{border-color:var(--ours)}.read b{text-transform:capitalize;margin-bottom:6px}
.ph{border-radius:0;aspect-ratio:auto!important;min-height:280px;position:relative;padding:70px 24px 25px;gap:8px;background:var(--sel)}.ph:before{content:'VIDEO PREVIEW · SOURCE FOOTAGE NOT ATTACHED';position:absolute;top:26px;left:24px;font:11px ui-monospace,monospace;color:var(--muted);letter-spacing:.08em}.ph div{background:var(--surface);border:1px solid var(--grid);border-radius:3px;font-size:12px;min-height:65px}
select{padding:8px 30px 8px 12px;border-radius:3px;font-size:12px}.ctrl label{font-size:12px}.note{font-size:12px;line-height:1.8;max-width:900px}.legend{font-size:11px;gap:9px 18px;margin-bottom:22px}.banner{border-radius:3px;font-size:12px;margin:0 0 24px;padding:12px 16px;background:var(--sel);border-color:var(--axis)}
#top>.grid2{margin-top:24px!important}#top>.card:not(.demo-card):not(.flow-card){margin-top:24px!important}#upath{max-width:760px;margin:0 auto}.flow-card{margin-top:24px}.flow-card summary{font-size:14px;cursor:pointer}.flow-card svg{margin-top:24px}details summary{cursor:pointer;font-size:13px}details[open] summary{margin-bottom:18px}.scope{font-size:14px;color:var(--ink2)}.scope li{padding:7px 0;max-width:900px}
th,td{padding:15px 9px;font-size:12px}th{font-size:10px;text-transform:uppercase;letter-spacing:.07em}tr.ours td{color:var(--ours);background:var(--sel)}.eq{border-radius:0;background:var(--sel);padding:22px;margin-top:25px;font-size:20px}.result-summary{max-width:none;font-size:15px;color:var(--ink2);margin:28px 0}.result-summary b{color:var(--ink);font-weight:600}
footer{border-top:1px solid var(--grid);margin-top:80px;padding-top:24px;display:flex;justify-content:space-between;font:11px ui-monospace,monospace;color:var(--muted)}a:focus-visible,button:focus-visible,select:focus-visible,summary:focus-visible{outline:3px solid var(--ours);outline-offset:4px}.skip{position:absolute;left:20px;top:-70px}.skip:focus{top:15px;z-index:100;background:var(--surface);padding:10px}
@media(max-width:900px){.hero-head{grid-template-columns:1fr;gap:26px}.hero-copy{max-width:650px}nav.top .in{gap:18px}.grid2{grid-template-columns:1fr}.hero-meta{gap:15px}}
@media(max-width:600px){main{padding:0 20px 32px}nav.top .in{padding:15px 20px;gap:20px}nav.top .brand{font-size:14px}nav.top a[href="#scope"],nav.top a[href="#code"]{display:none}#top{padding-top:42px!important}h1{font-size:48px}h2{font-size:34px}section{padding-top:50px}section+section{margin-top:46px}.hero-head{margin-bottom:30px}.card{padding:20px}.demo-card{padding:0}.demo-card .ctrl{flex-wrap:wrap;padding:15px}.demo-card .ctrl:before{width:100%;margin-bottom:6px}.demo-card .read,.demo-card .note{margin:16px}.tile.card{padding:22px 12px}.tile .v{font-size:31px}.grid4 .tile:nth-child(2){border-right:0}.grid4 .tile:nth-child(-n+2){border-bottom:1px solid var(--grid)}.ph{grid-template-columns:repeat(2,1fr);padding:66px 15px 15px}.ph:before{font-size:9px;left:15px;right:15px}.eq{font-size:16px;overflow-x:auto}footer{gap:15px;flex-wrap:wrap}}
@media(prefers-reduced-motion:reduce){html{scroll-behavior:auto}*{transition:none!important}}


.demo-part{padding-bottom:8px}.alpha-part{border-top:1px solid var(--axis);background:var(--sel);padding-top:8px}.row-heading{padding:25px 24px 18px}.row-heading>span{font:10px ui-monospace,monospace;letter-spacing:.13em;color:var(--ours)}.row-heading h3{font-family:Georgia,serif;font-size:27px;font-weight:400;margin:9px 0 12px}.row-heading p{font-size:14px;color:var(--ink2);max-width:940px;margin:0}.demo-part .ph{min-height:160px;padding-top:60px}.demo-part .read{grid-template-columns:repeat(4,minmax(0,1fr))}.read .explain{display:block;margin:8px 0 12px;line-height:1.7}.read .outcome{display:block;font:11px ui-monospace,monospace;color:var(--ink);padding-top:9px;border-top:1px solid var(--grid)}.read .instruction{display:block;font-size:11px;font-style:italic;color:var(--ink2);margin:8px 0}.alpha-read b{text-transform:none}.alpha-read div:last-child{border-color:var(--grid)}.video-row{overflow:hidden;position:relative;aspect-ratio:4/1;background:#111}.video-row:has(video.hidden){display:none}.video-row video{display:block;width:100%;height:auto}.mcard{padding:28px 28px 8px}.mcard .legend{margin-bottom:4px}
.steps{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));border-top:1px solid var(--grid);margin-top:22px}
.step{padding:22px 22px 18px;border-right:1px solid var(--grid)}.step:first-child{padding-left:0}.step:last-child{border-right:0;padding-right:0}
.step .n,.scard .n{font:10px ui-monospace,monospace;letter-spacing:.13em;color:var(--ours)}
.step h4{font:400 21px/1.25 Georgia,'Times New Roman',serif;letter-spacing:-.02em;margin:8px 0 14px;color:var(--ink)}
.step .m{font-size:21px;margin:0 0 14px;min-height:56px;display:flex;align-items:center;overflow-x:auto}
math{font-family:'STIX Two Math','Cambria Math','Latin Modern Math',math;math-style:normal;color:var(--ink)}
.step p,.scard p{font-size:13px;line-height:1.75;color:var(--ink2);margin:0}
.codecard{display:grid;grid-template-columns:minmax(0,1.15fr) minmax(0,1fr);gap:32px}
#code .n{font:10px ui-monospace,monospace;letter-spacing:.13em;color:var(--ours);display:block;margin-bottom:12px}
#code code{font:12.5px ui-monospace,monospace;background:var(--sel);padding:1px 5px;border-radius:3px}
.tree{font:12.5px/1.95 ui-monospace,monospace;color:var(--muted);margin:0;white-space:pre;overflow-x:auto}
.tree b{color:var(--ink);font-weight:600}.tree i{font-style:normal;color:var(--ink2)}.tree .st{color:var(--ours)}
.qs pre{background:var(--sel);border:1px solid var(--grid);border-radius:4px;padding:14px 16px;font:12px/1.8 ui-monospace,monospace;
 color:var(--ink);overflow-x:auto;margin:0;white-space:pre}.qs pre i{font-style:normal;color:var(--muted)}
.dl{margin-top:14px;display:flex;gap:10px;flex-wrap:wrap}.dl a{font-size:12px;padding:9px 16px;border:1px solid var(--ink);border-radius:3px;text-decoration:none}
.dl a:first-child{background:var(--ink);color:var(--page)}
.lanes{display:grid}.lane{display:grid;grid-template-columns:130px minmax(0,1fr);gap:18px;padding:16px 0;border-top:1px solid var(--grid)}
.lane:first-child{border-top:0;padding-top:4px}.lane h4{font:400 19px/1.3 Georgia,'Times New Roman',serif;margin:8px 0 0;color:var(--ink)}
.chips{display:flex;flex-wrap:wrap;align-items:stretch;gap:8px}
.chip{border:1px solid var(--axis);border-radius:6px;padding:10px 12px;flex:1 1 150px;min-width:140px;background:var(--surface)}
.chip .id{font:10.5px ui-monospace,monospace;letter-spacing:.04em;color:var(--muted)}
.chip .nm{font-size:13.5px;font-weight:600;color:var(--ink);margin:4px 0 2px}.chip .out{font-size:11.5px;line-height:1.5;color:var(--ink2)}
.rt{font:9.5px ui-monospace,monospace;padding:1px 6px;border-radius:9px;margin-left:6px;vertical-align:1px}
.rt.gpu{background:color-mix(in srgb,var(--ours) 15%,transparent);color:var(--ours)}.rt.cpu{color:var(--ink2);border:1px solid var(--grid)}
.chips .ar{align-self:center;color:var(--muted);font-size:14px}
table.map td{font-size:13px;padding:11px 6px}table.map td:last-child{font:12px ui-monospace,monospace;color:var(--ink2);text-align:right;white-space:nowrap}
#code .scope li{font-size:13px;padding:4px 0}
@media(max-width:600px){.tree{font-size:10.5px}.qs pre{font-size:10.5px;padding:12px}}
@media(max-width:820px){.codecard{grid-template-columns:1fr;gap:24px}.lane{grid-template-columns:1fr;gap:8px}.chips .ar{display:none}}
.scard{margin-top:16px;display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:28px;padding:22px 28px}.scard p{margin-top:8px}
@media(max-width:820px){.steps,.scard{grid-template-columns:1fr}.step{border-right:0;border-bottom:1px solid var(--grid);padding:20px 0}.step:last-child{border-bottom:0}.scard{gap:18px}}
tr.sub td{color:var(--ink2)}.wctrl{display:flex;align-items:center;gap:12px;padding:0 24px 18px;font-size:12px;color:var(--muted)}.playback{display:flex;align-items:center;gap:12px;padding:12px 24px;background:var(--surface)}.playback button{font:12px Arial;padding:7px 10px;border:1px solid var(--axis);border-radius:3px;background:var(--surface);color:var(--ink);cursor:pointer}.playback input{min-width:50px;flex:1;accent-color:var(--ours)}
@media(max-width:600px){.demo-part .read,.demo-part .ph{grid-template-columns:repeat(2,minmax(0,1fr))!important}.row-heading{padding:22px 16px 16px}.row-heading h3{font-size:24px}.row-heading p{font-size:13px}.playback{padding:12px 16px;gap:8px}}
</style>
</head>
<body>
<a class="skip" href="#top">Skip to content</a>
<nav class="top"><div class="in">
 <a class="brand" href="#top">VLA<span> / Steering</span></a><a href="#demo">Demo</a><a href="#how">Method</a><a href="#code">Code</a>
 <span class="sp"></span><button id="theme" aria-label="Toggle color theme">◐</button>
</div></nav>
<main>

<!-- ================= 0 · use case (hero) ================= -->
<section id="top" style="padding-top:28px">
 <p class="k">Representation research / OpenVLA-OFT</p>
 <div class="hero-head"><h1>A new intent.<br>The same policy.<br><em>A different direction.</em></h1>
 <div class="hero-copy"><p>Redirect a robot by steering its internal representation. A probe reads what an action will do; the action head turns that insight into a direction.</p><div class="hero-actions"><a href="#demo">Explore the experiment ↗</a><a href="#how">How it works ↓</a></div></div></div>
 <div class="hero-meta"><span>ANONYMOUS SUPPLEMENTARY MATERIAL</span><span>OPENVLA-OFT × LIBERO-10</span><span>UNDER DOUBLE-BLIND REVIEW</span></div>
 <div id="pvbanner" class="banner hidden">⚠ <b>Preview</b>, placeholder data: the videos, counts and paths below are synthetic,
 only to show the layout.</div>
 <div class="card flow-card" id="situation" style="margin-bottom:24px">
  <div class="row-heading" style="padding:0 0 6px"><span>THE SITUATION</span><h3>Move only the yellow-and-white mug. Two ways to ask for it.</h3>
  <p>The policy learned to move the white mug first. Now we want only the yellow-and-white mug on the right plate, with the white mug left
  in place. We can (1) change the instruction, or (2) keep the original instruction and steer the policy's representation.</p></div>
  <svg id="ucflow" viewBox="0 0 960 300" role="img" aria-label="new intent; route 1: change the instruction, the policy still takes the white mug; route 2: steer the representation with the original instruction, the policy moves the yellow-and-white mug"></svg>
 </div>
 <div class="card demo-card" id="demo">
  <div class="ctrl"><label for="usel">Held-out start</label><select id="usel"></select></div>
  <div class="demo-part">
   <div class="row-heading"><span>A / INSTRUCTION VS. STEERING</span><h3>Same scene. Two ways to change the intent.</h3><p>The goal is to move only the yellow-and-white mug to the right plate, leaving the white mug in place. Compare the original instruction, two rewritten instructions, and steering with the original instruction.</p></div>
   <div class="video-row"><video id="uvid" muted loop playsinline preload="metadata" aria-label="Instruction versus steering comparison"></video></div>
   <div class="ph hidden" id="uph"><div>original instruction</div><div>new instruction (1)</div><div>new instruction (2)</div><div>steering (ours)</div></div>
   <div class="playback hidden" id="ucontrols"><button type="button" data-video="uvid">Play / pause</button><button type="button" data-restart="uvid">Replay</button><input type="range" min="0" max="100" step="0.1" value="0" data-seek="uvid" aria-label="Seek instruction comparison"></div>
   <div class="read" id="uread"></div>
   <p class="note" id="unote"></p>
  </div>
  <div class="demo-part alpha-part">
   <div class="row-heading"><span>B / WEAKER STEERING</span><h3>Too weak a push: the policy can't make up its mind.</h3><p>Same instruction and target, with α below the fixed strength. Rather than committing, the robot can switch between objects: it heads for one mug, turns to another, and sometimes knocks one over. Each example shows one failed run at each weaker strength, from different starts.</p></div>
   <div class="wctrl"><label for="wsel">Example</label><select id="wsel"></select></div>
   <div class="video-row"><video id="uavid" muted loop playsinline preload="metadata" aria-label="Steering strength comparison"></video></div>
   <div class="ph hidden" id="uaph"></div>
   <div class="playback hidden" id="uacontrols"><button type="button" data-video="uavid">Play / pause</button><button type="button" data-restart="uavid">Replay</button><input type="range" min="0" max="100" step="0.1" value="0" data-seek="uavid" aria-label="Seek steering strength comparison"></div>
   <div class="read alpha-read" id="uaread"></div>
   <p class="note" id="uanote"></p>
  </div>
 </div>
 <p class="result-summary">On the held-out starts, changing the instruction succeeds in <b id="hl1">–</b>. Steering with the original instruction succeeds in <b id="hl2">–</b>.</p>

 <div class="grid2" style="margin-top:14px">
  <div class="card"><h3>Success on held-out starts</h3><div id="utab"></div>
   <p class="note">Success: the yellow-and-white mug rests upright on the right plate, the white mug is never lifted and moves less
   than 3 cm, within 15 s. Fixed before the test run.</p></div>
  <div class="card"><h3>How strongly to push</h3><div class="legend" id="aleg"></div><svg id="abar" viewBox="0 0 460 300"></svg>
   <p class="note">Outcome by steering strength (α = 16 moves the head input by 8% of its norm per re-plan).
   Weak pushes leave the learned habit in place, intermediate ones leave the policy undecided; only the strongest one redirects it
   reliably.</p></div>
 </div>
 <details class="card" style="margin-top:14px"><summary><b>How this was set up, and its limits</b></summary><ul class="scope" style="padding-left:20px;margin:10px 0 0">
  <li>What we choose: the target quantity (distance of the end effector to a point above the yellow-and-white mug, at the
   height the demonstrations reach before grasping it), the strength α and the release rule (stop steering within 5 cm of that
   point, once the mug is lifted, or after 4.8 s). The direction itself comes from the probe and the model's own action head,
   recomputed at every re-plan; no simulator query, no new data, no training.</li>
  <li>Two runs. First: the height margin chosen on 12 development starts, several strengths tested on 13 other held-out starts.
   Confirmation: the strongest one (α = 56) fixed in advance, probes refit on the other half of the episodes, and 25 new held-out
   starts, each run once; the weaker strengths were run on the same starts afterwards. Everything on this page is from the
   confirmation run.</li>
  <li>The strengths used here are larger than the range in which the paper validates local steering (see the paper).</li>
  <li>After placing the yellow-and-white mug the policy stops: in its demonstrations, that scene is the end of the task. Moving the
   white mug next would need further steering.</li>
  <li>One model, one task. A policy that follows language more closely may respond to the new instruction.</li>
 </ul></details>
</section>

<!-- ================= 1 · method and scope ================= -->
<section id="how">
 <p class="k">1 · Method and scope</p>
 <h2>Read the outcome. Pull it back through the head. Push.</h2>
 <p class="lede">A probe reads, from the representation, what any candidate action chunk would do to a physical quantity ψ, here the
 distance of the end effector to a point above the yellow-and-white mug. Pulling that read-out back through the action head gives a
 direction in the representation; pushing along it steers the policy. No simulator query, no new data, no training.</p>
 <div class="card mcard">
  <div class="legend" id="chleg"></div>
  <svg id="chain" viewBox="0 0 960 270" role="img" aria-label="forward pass: observation x, representation z, action chunk u, outcome psi; a probe predicts psi from z and u; its read-out is pulled back through the action head to a direction z_psi, which is added to z"></svg>
  <div class="steps">
   <div class="step"><span class="n">01 · READ</span><h4>A probe predicts the outcome of any chunk</h4>
    <div class="m"><math><msub><mover accent="true"><mi>J</mi><mo>^</mo></mover><mrow><mi>ψ</mi><mo>,</mo><mi>x</mi></mrow></msub><mo stretchy="false">(</mo><mi>u</mi><mo stretchy="false">)</mo><mo>=</mo><mo stretchy="false">⟨</mo><mi>z</mi><mo stretchy="false">(</mo><mi>x</mi><mo stretchy="false">)</mo><mo>,</mo><mspace width="0.2em"></mspace><msub><mi>L</mi><mi>ψ</mi></msub><mspace width="0.1em"></mspace><mi>S</mi><mo stretchy="false">(</mo><mi>u</mi><mo stretchy="false">)</mo><mo stretchy="false">⟩</mo></math></div>
    <p>Bilinear in the representation z(x) and the signature S(u) of a candidate chunk u, so it predicts ψ after chunks the policy never
    executed.</p></div>
   <div class="step"><span class="n">02 · PULL BACK</span><h4>Through the action head</h4>
    <div class="m"><math><msub><mi>z</mi><mi>ψ</mi></msub><mo stretchy="false">(</mo><mi>x</mi><mo stretchy="false">)</mo><mo>=</mo><mi>D</mi><mi>φ</mi><msup><mrow><mo stretchy="false">(</mo><mi>z</mi><mo stretchy="false">)</mo></mrow><mo>⊤</mo></msup><mspace width="0.1em"></mspace><msub><mover accent="true"><mi>z</mi><mo>~</mo></mover><mi>ψ</mi></msub><mo stretchy="false">(</mo><mi>x</mi><mo stretchy="false">)</mo></math></div>
    <p>z̃<sub>ψ</sub>(x): the change of the chunk that raises ψ, read from the probe. Dφ: Jacobian of the action head, so only the
    small head is differentiated, never the language model or the simulator.</p></div>
   <div class="step"><span class="n">03 · PUSH</span><h4>Steer, then let go</h4>
    <div class="m"><math><mi>z</mi><mo>←</mo><mi>z</mi><mo>+</mo><mi>α</mi><mspace width="0.1em"></mspace><mi>ε</mi><mo stretchy="false">‖</mo><mi>z</mi><mo stretchy="false">‖</mo><mspace width="0.1em"></mspace><mfrac><msub><mi>z</mi><mi>ψ</mi></msub><mrow><mo stretchy="false">‖</mo><msub><mi>z</mi><mi>ψ</mi></msub><mo stretchy="false">‖</mo></mrow></mfrac></math></div>
    <p>Recomputed from the current representation at every re-plan (ε = 0.5%, so α = 16 moves z by 8% of its norm). Released near the
    target; the policy then acts on its own.</p></div>
  </div>
 </div>
 <div class="card scard">
  <div><span class="n">WHAT WE CHOOSE</span><p>The quantity ψ, the strength α and the release rule. The direction itself comes from the probe and the
   model's own action head.</p></div>
  <div><span class="n">WHAT THE PAPER VALIDATES</span><p>Small pushes bias the robot towards the chosen quantity. Changing which object it
   goes for needs the larger, released pushes of the use case, beyond that validated range.</p></div>
  <div><span class="n">TESTED ON</span><p>One model (OpenVLA-OFT), one LIBERO-10 task, the 32 leading principal directions of the
   action-head input.</p></div>
 </div>
</section>

<!-- ================= 2 · code ================= -->
<section id="code">
 <p class="k">2 · Code</p>
 <h2>Reproduce every number</h2>
 <p class="lede">Each step is one self-contained Colab cell. Results are written to one Drive folder, <code>aclrh/</code>, and every
 later step reads from there. GPU steps load the model or the simulator; CPU steps only analyse saved results.</p>

 <div class="card codecard">
  <div>
   <span class="n">REPOSITORY</span>
<pre class="tree"><b>vla-lrh/</b>
├── <b>openvla_oft/</b>  <span class="st">01–09</span>   <i>probing, steering, closed loop</i>
├── <b>probing/</b>      <span class="st">q1</span>      <i>Q1 probing table, both models</i>
├── <b>smolvla/</b>      <span class="st">s1–s4</span>   <i>stochastic policy</i>
├── <b>use_case/</b>     <span class="st">16–18</span>   <i>Figure 2, this use case</i>
├── <b>site/</b>         <span class="st">12, 19</span>  <i>this page</i>
├── <b>colab/</b>                <i>one cell per step</i>
├── <b>tools/</b>                <i>anonymity check</i>
└── README.md, PAPER_MAP.md   <i>run order, result → script</i></pre>
  </div>
  <div class="qs">
   <span class="n">QUICK START (COLAB)</span>
<pre><i># once per runtime: unzip code.zip in the working directory</i>
run = lambda p: exec(open(f"vla-lrh/{p}").read(),
                     {"__name__": "__main__"})

run("openvla_oft/02_collect_probe_data.py")  <i># GPU</i>
run("probing/q1_probe_extended.py")          <i># CPU</i></pre>
   <div class="dl" id="codelink"></div>
  </div>
 </div>

 <div class="card" style="margin-top:16px">
  <span class="n">PIPELINE</span>
  <div class="lanes">
   <div class="lane"><h4>OpenVLA-OFT</h4><div class="chips">
    <div class="chip"><span class="id">01 · 02</span><span class="rt gpu">GPU</span><div class="nm">Collect</div><div class="out">404 states × 32 candidate chunks</div></div><span class="ar">→</span>
    <div class="chip"><span class="id">03 · 05a</span><span class="rt cpu">CPU</span><div class="nm">Probe</div><div class="out">probing tables (OFT)</div></div><span class="ar">→</span>
    <div class="chip"><span class="id">04 · 05b · 05c</span><span class="rt gpu">GPU</span><div class="nm">Steer one chunk</div><div class="out">steering table, 140 held-out states</div></div><span class="ar">→</span>
    <div class="chip"><span class="id">06 → 07 · 08 · 09</span><span class="rt gpu">GPU</span><span class="rt cpu">CPU</span><div class="nm">Closed loop, figures</div><div class="out">response curves, closed-loop paths</div></div>
   </div></div>
   <div class="lane"><h4>SmolVLA</h4><div class="chips">
    <div class="chip"><span class="id">s1</span><span class="rt gpu">GPU</span><div class="nm">Collect</div><div class="out">16 policy samples + 16 perturbations per state</div></div><span class="ar">→</span>
    <div class="chip"><span class="id">q1</span><span class="rt cpu">CPU</span><div class="nm">Probe both models</div><div class="out">Q1 table (needs 02 too)</div></div><span class="ar">→</span>
    <div class="chip"><span class="id">s2</span><span class="rt gpu">GPU</span><div class="nm">Steer</div><div class="out">fresh samples shared across strengths</div></div><span class="ar">→</span>
    <div class="chip"><span class="id">s3 · s4</span><span class="rt cpu">CPU</span><div class="nm">Analyse</div><div class="out">steering tables, reversal diagnosis</div></div>
   </div></div>
   <div class="lane"><h4>Use case</h4><div class="chips">
    <div class="chip"><span class="id">16</span><span class="rt gpu">GPU</span><div class="nm">Instruction vs. steering</div><div class="out">α chosen on 12 starts, swept on 13</div></div><span class="ar">→</span>
    <div class="chip"><span class="id">18</span><span class="rt gpu">GPU</span><div class="nm">Confirm</div><div class="out">α fixed, new probes, 25 new starts</div></div><span class="ar">→</span>
    <div class="chip"><span class="id">19 = 17 + 12</span><span class="rt cpu">CPU</span><div class="nm">Figure 2 and this page</div><div class="out">fig_usecase, site</div></div>
   </div></div>
  </div>
  <p class="note" style="margin:14px 0 0">GPU: A100 (L4 is enough for 16 and 18). The first GPU cell of a runtime builds its environment
  (15–25 min); long runs checkpoint to Drive and resume when the cell is run again.</p>
 </div>

 <div class="grid2" style="margin-top:16px">
  <div class="card"><span class="n">WHERE EACH RESULT COMES FROM</span>
   <table class="map"><tbody>
    <tr><td>Q1 probing table, both models</td><td>q1</td></tr>
    <tr><td>OpenVLA-OFT steering table</td><td>04 · 05b · 05c</td></tr>
    <tr><td>Response curves</td><td>08</td></tr>
    <tr><td>Closed-loop figure</td><td>06 → 07 · 09</td></tr>
    <tr><td>SmolVLA steering tables</td><td>s2 → s3 · s4</td></tr>
    <tr class="ours"><td>Figure 2 and the use case above</td><td>16 · 18 → 17</td></tr>
   </tbody></table>
   <p class="note" style="margin:10px 0 0">Every table and figure, by its label in the paper: <code>PAPER_MAP.md</code>.</p></div>
  <div class="card"><span class="n">SETTINGS THE NUMBERS DEPEND ON</span>
   <ul class="scope" style="padding-left:18px;margin:10px 0 0">
    <li>OpenVLA-OFT fine-tuned on LIBERO-10, chunks of 8 actions; one LIBERO-10 task, all 50 layouts.</li>
    <li>z(x): the 32 leading principal directions of the action-head input, fitted on training episodes only.</li>
    <li>Held-out episodes everywhere: folds by episode (even / odd for steering), seed 0.</li>
    <li>One unit of α moves the head input by 0.5% of its norm; finite-difference step 0.25 (standardized units).</li>
    <li>Use-case success: the yellow-and-white mug upright on the right plate, the white mug never lifted and moved less than
     3 cm, within 15 s; fixed before the runs.</li>
   </ul></div>
 </div>
</section>
<footer><span>VLA / Representation Steering</span><span>Anonymous research supplementary · <a href="#top">Back to top ↑</a></span></footer>
</main>
<div class="tip" id="tip"></div>
<script id="data" type="application/json">__DATA__</script>
<script>
"use strict";

const D = JSON.parse(document.getElementById('data').textContent);
const css = n => getComputedStyle(document.documentElement).getPropertyValue(n).trim();
const NS = 'http://www.w3.org/2000/svg';
const DIR = {"sim-gradient":{n:"simulator gradient (oracle)",c:"--oracle"},"Dphi^T lambda_psi":{n:"probe via head (ours)",c:"--ours"},
             "gamma_psi":{n:"probe w/o head",c:"--wo"},"static":{n:"standard probe",c:"--std"}};
function el(tag,a,p){const e=document.createElementNS(NS,tag);for(const k in a)e.setAttribute(k,a[k]);if(p)p.appendChild(e);return e;}
function txt(p,x,y,s,a){const t=el('text',Object.assign({x,y},a||{}),p);t.textContent=s;return t;}
function clear(s){while(s.firstChild)s.removeChild(s.firstChild);}
const sc=(d0,d1,r0,r1)=>v=>r0+(v-d0)*(r1-r0)/((d1-d0)||1);
function ticks(a,b,n){const st0=(b-a)/n,p=Math.pow(10,Math.floor(Math.log10(st0))),st=[1,2,2.5,5,10].map(m=>m*p).find(x=>x>=st0);
 const o=[];for(let v=Math.ceil(a/st)*st;v<=b+1e-9;v+=st)o.push(+v.toFixed(6));return o;}
const fmt=(v,d=1)=>(v>0?'+':v<0?'−':'')+Math.abs(v).toFixed(d);
function qtl(a,p){const s=[...a].sort((x,y)=>x-y),i=(s.length-1)*p,l=Math.floor(i),h=Math.ceil(i);return s[l]+(s[h]-s[l])*(i-l);}
function path(xs,ys,x,y){return xs.map((v,i)=>(i?'L':'M')+x(v).toFixed(1)+' '+y(ys[i]).toFixed(1)).join('');}
function line(svg,xs,ys,x,y,col,w,o){return el('path',Object.assign({d:path(xs,ys,x,y),fill:'none',stroke:col,'stroke-width':w,
 'stroke-linejoin':'round','stroke-linecap':'round'},o||{}),svg);}
function hgrid(svg,y,dom,x0,x1,n,lab,fmtf){for(const t of ticks(dom[0],dom[1],n)){el('line',{x1:x0,x2:x1,y1:y(t),y2:y(t),stroke:css('--grid')},svg);
 txt(svg,x0-8,y(t)+4,fmtf?fmtf(t):String(t),{'text-anchor':'end'});}}
function cw(id){const w=document.getElementById(id).getBoundingClientRect().width;return Math.max(300,Math.round(w||640));}
const CH_W=7.1;  // conservative width of one character at 12-13 px (bold included)
function wrap(s,max){if(s.length*CH_W<=max)return [s];const w=s.split(' ');let best=[s],bd=1e9;
 for(let i=1;i<w.length;i++){const a=w.slice(0,i).join(' '),b=w.slice(i).join(' ');const d=Math.max(a.length,b.length);if(d<bd){bd=d;best=[a,b];}}
 if(Math.max(...best.map(l=>l.length))*CH_W<=max)return best;
 const L=[];let cur='';w.forEach(x=>{const t=cur?cur+' '+x:x;if(t.length*CH_W>max&&cur){L.push(cur);cur=x;}else cur=t;});if(cur)L.push(cur);return L;}
function wtext(p,x,y,s,max,a){const L=wrap(s,max);L.forEach((l,i)=>txt(p,x,y+(i-(L.length-1)/2)*15,l,a));return L.length;}
function sym(p,x,y,parts,a){const t=el('text',Object.assign({x,y},a||{}),p);let sh=0;
 parts.forEach(([s,k])=>{const ts=el('tspan',{},t);const want=k===1?4:k===2?-6:0;ts.setAttribute('dy',String(want-sh));sh=want;
  if(k)ts.setAttribute('font-size','75%');ts.textContent=s;});return t;}
const tip=document.getElementById('tip');
function showTip(ev,title,rows){clear(tip);const t=document.createElement('div');t.className='t';t.textContent=title;tip.appendChild(t);
 rows.forEach(r=>{const d=document.createElement('div');d.className='r';const l=document.createElement('span');const i=document.createElement('i');
  i.style.background=r.c;if(r.wide){i.style.height='6px';i.style.borderRadius='3px';}l.appendChild(i);l.appendChild(document.createTextNode(r.n));
  const b=document.createElement('b');b.textContent=r.v;d.appendChild(l);d.appendChild(b);tip.appendChild(d);});
 tip.style.display='block';const w=tip.offsetWidth,h=tip.offsetHeight;let X=ev.clientX+14,Y=ev.clientY+14;
 if(X+w>innerWidth-8)X=ev.clientX-w-14;if(Y+h>innerHeight-8)Y=ev.clientY-h-14;tip.style.left=X+'px';tip.style.top=Y+'px';}
function hideTip(){tip.style.display='none';}
function legend(id,items){const L=document.getElementById(id);clear(L);items.forEach(it=>{const s=document.createElement('span');const i=document.createElement('i');
 i.className=it.k;if(it.c)i.style.background=it.c;if(it.b)i.style.borderColor=it.b;if(it.dash){i.style.borderTopColor=it.dash;}
 s.appendChild(i);s.appendChild(document.createTextNode(it.n));L.appendChild(s);});}
function seg(id,cb){const S=document.getElementById(id);[...S.children].forEach(b=>b.onclick=()=>{[...S.children].forEach(c=>c.classList.toggle('on',c===b));cb(b);});}
if(D.preview)document.getElementById('pvbanner').classList.remove('hidden');

/* ---------- tiles ---------- */
const Q=D.qoi_order, ST=D.steer;
function tiles(){const T=document.getElementById('tiles');if(!T)return;clear(T);
 const mono=Math.round(Q.reduce((s,q)=>s+ST[q]["Dphi^T lambda_psi"][0]/100*D.n_states,0)), tot=Q.length*D.n_states;
 const cs=Q.map(q=>ST[q]["Dphi^T lambda_psi"][3]);const wrong=Q.filter(q=>ST[q]["static"][1]< -1).length;
 [[`${mono} / ${tot}`,'held-out states where our direction raises the quantity monotonically'],
  [`${Math.min(...cs).toFixed(2)}–${Math.max(...cs).toFixed(2)}`,"cosine with the simulator's own gradient"],
  [`${wrong} of ${Q.length}`,'quantities the standard probe pushes the wrong way'],
  ['0','simulator queries needed to find the direction']].forEach(([v,l])=>{const c=document.createElement('div');c.className='card tile';
  const a=document.createElement('div');a.className='v';a.textContent=v;const b=document.createElement('div');b.className='l';b.textContent=l;
  c.appendChild(a);c.appendChild(b);T.appendChild(c);});}
tiles();

/* ---------- 1 · chain diagram ---------- */
function box(svg,x,y,w,h,label,sub,o){const g=el('g',{},svg);el('rect',Object.assign({x,y,width:w,height:h,rx:10,fill:css('--surface'),stroke:css('--axis')},o||{}),g);
 txt(g,x+w/2,y+h/2+(sub?-3:5),label,{'text-anchor':'middle',class:'lab',style:'font-weight:600;fill:'+css('--ink')});
 if(sub)txt(g,x+w/2,y+h/2+15,sub,{'text-anchor':'middle'});return g;}
function arrow(svg,x1,y1,x2,y2,col,lab,w){el('line',{x1,y1,x2:x2-7,y2,stroke:col,'stroke-width':w||1.5},svg);
 el('path',{d:`M${x2-8} ${y2-5} L${x2} ${y2} L${x2-8} ${y2+5} Z`,fill:col},svg);if(lab)txt(svg,(x1+x2)/2,y1-8,lab,{'text-anchor':'middle'});}
function bracket(svg,x1,x2,y,col,lab,sub){el('path',{d:`M${x1} ${y-8} L${x1} ${y} L${x2} ${y} L${x2} ${y-8}`,fill:'none',stroke:col,'stroke-width':2.5,'stroke-linecap':'round'},svg);
 txt(svg,(x1+x2)/2,y+20,lab,{'text-anchor':'middle',class:'lab',style:'font-weight:600'});if(sub)txt(svg,(x1+x2)/2,y+37,sub,{'text-anchor':'middle'});}
function mt(p,x,y,segs,o){o=o||{};const fs=o.size||18;const t=el('text',{x,y,'text-anchor':o.anchor||'middle'},p);
 t.setAttribute('style',`font-family:Georgia,'Times New Roman',serif;font-size:${fs}px;fill:${o.fill||css('--ink')}`);let sh=0;
 segs.forEach(sg=>{const str=Array.isArray(sg)?sg[0]:sg,m=Array.isArray(sg)?sg[1]:'r';const ts=el('tspan',{},t);
  const want=/sub/.test(m)?0.3*fs:/sup/.test(m)?-0.42*fs:0;ts.setAttribute('dy',String(want-sh));sh=want;
  if(/sub|sup/.test(m))ts.setAttribute('font-size',String(Math.round(fs*0.66)));if(/i/.test(m))ts.setAttribute('font-style','italic');ts.textContent=str;});return t;}
function ahead(S,x,y,dx,dy,col){const l=Math.hypot(dx,dy)||1,ux=dx/l,uy=dy/l,px=-uy,py=ux;
 el('path',{d:`M${x} ${y} L${x-9*ux+4.5*px} ${y-9*uy+4.5*py} L${x-9*ux-4.5*px} ${y-9*uy-4.5*py} Z`,fill:col},S);}
function cnode(S,x,y,w,h,cap,math,sub,strong){const g=el('g',{},S);
 el('rect',{x,y,width:w,height:h,rx:8,fill:css('--surface'),stroke:strong?css('--ink2'):css('--axis'),'stroke-width':1.2},g);
 txt(g,x+14,y+19,cap,{style:`font:10px ui-monospace,monospace;letter-spacing:.12em;fill:${css('--muted')}`});
 mt(g,x+14,y+h/2+12,math,{anchor:'start',size:22});
 if(sub)txt(g,x+14,y+h-12,sub,{style:`font-size:11.5px;fill:${css('--ink2')}`});return g;}
function chain(){const S=document.getElementById('chain');if(!S)return;clear(S);const W=cw('chain');
 const ax=css('--axis'),o=css('--ours'),i2=css('--ink2'),mu=css('--muted');
 legend('chleg',[{k:'lk',c:ax,n:'forward pass of the policy'},{k:'dash',dash:i2,n:'probe'},{k:'lk',c:o,n:'steering direction (ours)'}]);
 const N=[['OBSERVATION',[['x','i']],'camera image + instruction'],['REPRESENTATION',[['z','i'],'(',['x','i'],')'],'action-head input'],
  ['ACTION CHUNK',[['u','i'],' = φ(',['z','i'],')'],'8 low-level actions'],['OUTCOME',[['ψ','i']],'e.g. distance to a target']];
 const F=['VLA backbone','action head φ','physics'];
 if(W<760){const bw=W-12,H0=78,gap=46;let y=6;N.forEach((d,i)=>{cnode(S,6,y,bw,H0,d[0],d[1],d[2],i===1);
   if(i<3){const x=40,y1=y+H0,y2=y+H0+gap;el('line',{x1:x,x2:x,y1,y2:y2-8,stroke:ax,'stroke-width':1.5},S);ahead(S,x,y2,0,1,ax);
    txt(S,x+14,(y1+y2)/2+4,F[i],{style:`font-size:12px;fill:${i2}`});}y+=H0+gap;});
  S.setAttribute('viewBox',`0 0 ${W} ${y-gap+8}`);return;}
 const H0=86,Y0=96,yl=42,bw=Math.min(210,(W-12-3*130)/4),gap=(W-12-4*bw)/3,X=i=>6+i*(bw+gap),cx=i=>X(i)+bw/2,ym=Y0+H0/2,pw=78,ph=28;
 const yb=Y0+H0+22,Hs=yb+76;S.setAttribute('viewBox',`0 0 ${W} ${Hs}`);
 N.forEach((d,i)=>cnode(S,X(i),Y0,bw,H0,d[0],d[1],d[2],i===1));
 const mid=i=>(X(i)+bw+X(i+1))/2;
 F.forEach((l,i)=>{el('line',{x1:X(i)+bw+4,x2:X(i+1)-10,y1:ym,y2:ym,stroke:ax,'stroke-width':1.6},S);ahead(S,X(i+1)-3,ym,1,0,ax);
  txt(S,mid(i),ym+22,l,{'text-anchor':'middle',style:`font-size:11.5px;fill:${i2}`});});
 // 01 probe: reads z and u, predicts psi
 const dsh={'stroke':i2,'stroke-width':1.3,'stroke-dasharray':'4 4',fill:'none'};
 el('path',Object.assign({d:`M${cx(1)} ${Y0+H0+3} L${cx(1)} ${yb} L${cx(3)} ${yb}`},dsh),S);
 el('line',Object.assign({x1:cx(2),x2:cx(2),y1:Y0+H0+3,y2:yb},dsh),S);
 el('line',Object.assign({x1:cx(3),x2:cx(3),y1:yb,y2:Y0+H0+12},dsh),S);ahead(S,cx(3),Y0+H0+3,0,-1,i2);
 const pc=(cx(1)+cx(3))/2;
 txt(S,pc,yb+26,'01 · READ   the probe predicts ψ from z and u, without the simulator',{'text-anchor':'middle',style:`font:10.5px ui-monospace,monospace;letter-spacing:.06em;fill:${mu}`});
 mt(S,pc,yb+56,[['Ĵ','i'],['ψ,x','subi'],'(',['u','i'],')  =  ⟨ ',['z','i'],', ',['L','i'],['ψ','subi'],' ',['S','i'],'(',['u','i'],') ⟩'],{size:19});
 // 02 pull back (top lane, right to left)
 const pill=(x,lab,filled)=>{el('rect',{x:x-pw/2,y:yl-ph/2,width:pw,height:ph,rx:ph/2,fill:filled?o:css('--surface'),stroke:o,'stroke-width':1.6},S);
  mt(S,x,yl+6,lab,{size:17,fill:filled?css('--surface'):o});};
 el('path',{d:`M${cx(3)} ${Y0-2} L${cx(3)} ${yl} L${cx(2)+pw/2+10} ${yl}`,fill:'none',stroke:o,'stroke-width':1.8},S);ahead(S,cx(2)+pw/2+2,yl,-1,0,o);
 el('line',{x1:cx(2)-pw/2,x2:cx(1)+pw/2+10,y1:yl,y2:yl,stroke:o,'stroke-width':1.8},S);ahead(S,cx(1)+pw/2+2,yl,-1,0,o);
 pill(cx(2),[['z̃','i'],['ψ','subi'],'(',['x','i'],')'],false);pill(cx(1),[['z','i'],['ψ','subi'],'(',['x','i'],')'],true);
 txt(S,(cx(2)+pw/2+cx(3))/2,yl-13,'02 · chunk change that raises ψ',{'text-anchor':'middle',style:`font:10.5px ui-monospace,monospace;letter-spacing:.06em;fill:${o}`});
 mt(S,(cx(1)+cx(2))/2,yl-9,[['D','i'],['φ','i'],'(',['z','i'],')',['⊤','sup']],{size:16,fill:o});
 // 03 push: added to the head input
 const m1=mid(1);el('path',{d:`M${cx(1)+pw/2-6} ${yl+ph/2} C ${cx(1)+pw/2} ${Y0-16}, ${m1} ${Y0-22}, ${m1} ${ym-14}`,fill:'none',stroke:o,'stroke-width':1.8},S);
 ahead(S,m1,ym-9,0,1,o);el('circle',{cx:m1,cy:ym,r:8,fill:css('--surface'),stroke:o,'stroke-width':1.8},S);
 el('path',{d:`M${m1-4} ${ym} H${m1+4} M${m1} ${ym-4} V${ym+4}`,stroke:o,'stroke-width':1.8},S);
 mt(S,m1+14,Y0-10,['03 · ',['z','i'],' + ',['α','i'],' ',['z','i'],['ψ','subi']],{size:14,anchor:'start',fill:o});}
/* ---------- 4 · overview dot plot ---------- */
let curQ=null;
function overview(){const S=document.getElementById('over');if(!S)return;clear(S);const W=cw('over'),narrow=W<640,m={l:narrow?132:270,r:18,t:8,b:40},rh=narrow?46:38,H=m.t+m.b+Q.length*rh;
 S.setAttribute('viewBox',`0 0 ${W} ${H}`);const all=Q.flatMap(q=>["sim-gradient","Dphi^T lambda_psi","gamma_psi","static"].map(d=>ST[q][d][1]));
 const x=sc(Math.min(-13,...all)-0.5,Math.max(14,...all)+0.5,m.l,W-m.r);
 legend('oleg',[{k:'sk',b:css('--muted'),n:DIR["sim-gradient"].n},{k:'dk',c:css('--ours'),n:DIR["Dphi^T lambda_psi"].n},
  {k:'dk',c:css('--wo'),n:DIR.gamma_psi.n},{k:'dk',c:css('--std'),n:DIR.static.n},{k:'lk',c:css('--muted'),n:'random (median)'}]);
 const tk=narrow?[-10,0,10]:ticks(-12,14,6);tk.forEach(t=>{el('line',{x1:x(t),x2:x(t),y1:m.t,y2:H-m.b,stroke:t===0?css('--axis'):css('--grid'),'stroke-width':t===0?1.5:1},S);
  txt(S,x(t),H-m.b+18,(t>0?'+':'')+t,{'text-anchor':'middle'});});
 txt(S,(m.l+W-m.r)/2,H-4,narrow?'effect (mm)':'effect (mm, positive = in the intended direction)',{'text-anchor':'middle'});
 Q.forEach((q,i)=>{const y=m.t+i*rh+rh/2,g=el('g',{style:'cursor:pointer'},S),s=ST[q];
  el('rect',{x:0,y:y-rh/2+2,width:W,height:rh-4,rx:6,fill:q===curQ?css('--sel'):'transparent'},g);
  wtext(g,m.l-14,y+4,D.qoi_label[q],m.l-18,{'text-anchor':'end',class:'lab',style:q===curQ?'font-weight:600;fill:'+css('--ink'):''});
  el('line',{x1:x(s.random[1]),x2:x(s.random[1]),y1:y-7,y2:y+7,stroke:css('--muted'),'stroke-width':2,'stroke-linecap':'round'},g);
  [["static",'--std',5],["gamma_psi",'--wo',5]].forEach(([d,c,r])=>el('circle',{cx:x(s[d][1]),cy:y,r,fill:css(c),stroke:css('--surface'),'stroke-width':2},g));
  el('rect',{x:x(s["sim-gradient"][1])-7,y:y-7,width:14,height:14,rx:2,fill:'none',stroke:css('--muted'),'stroke-width':2},g);
  el('circle',{cx:x(s["Dphi^T lambda_psi"][1]),cy:y,r:5.5,fill:css('--ours'),stroke:css('--surface'),'stroke-width':2},g);
  g.addEventListener('pointermove',ev=>showTip(ev,D.qoi_label[q],["sim-gradient","Dphi^T lambda_psi","gamma_psi","static"].map(d=>({n:DIR[d].n,v:fmt(s[d][1])+' mm',c:css(DIR[d].c)})).concat([{n:'random',v:fmt(s.random[1])+' mm',c:css('--muted')}])));
  g.addEventListener('pointerleave',hideTip);});}

/* ---------- 6 · use case ---------- */
const UC=D.usecase;
const OCOL=['--o1','--o2','--o3','--o4','--o5'];
function aCol(a){if(!UC)return css('--a3');const s=UC.sweep,i=s.indexOf(a),n=s.length;const k=['--a1','--a2','--a3','--a4','--a5'];
 return css(k[Math.round(i*(k.length-1)/Math.max(1,n-1))]);}
function uinit(){if(!UC){document.getElementById('uavid').classList.add('hidden');document.getElementById('uaph').classList.remove('hidden');document.getElementById('uaph').textContent='Steering-strength videos are not available.';document.getElementById('uvid').classList.add('hidden');document.getElementById('usel').disabled=true;['abar'].forEach(id=>txt(document.getElementById(id),cw(id)/2,140,'use-case data not available (run step 16)',{'text-anchor':'middle'}));
  document.getElementById('uph').classList.remove('hidden');return;}
 const S=document.getElementById('usel');const succ=e=>UC.rows[e].D_steer==='success';
 const eps=[...UC.eps].sort((a,b)=>(succ(b)-succ(a))||(a-b));
 eps.forEach(e=>{const o=document.createElement('option');o.value=e;o.textContent=`start ${e}`+(succ(e)?' · steering succeeds':'');S.appendChild(o);});
 S.onchange=ushow;ushow();utab();winit();}
function ushow(){const e=+document.getElementById('usel').value,V=document.getElementById('uvid'),P=document.getElementById('uph');
 if(UC.videos[e]){V.classList.remove('hidden');P.classList.add('hidden');V.src='videos/'+UC.videos[e];/* Playback starts only when the visitor requests it. */}
 else{V.classList.add('hidden');P.classList.remove('hidden');}
 const descriptions={A_original:"The learned sequence starts with the white mug.",B_lang_put:"Ask for only the yellow-and-white mug using ‘put’.",C_lang_move:"Try the same intent with a different verb: ‘move’.",D_steer:"Keep the original instruction. Steer toward the yellow-and-white mug, then release the policy to finish."};
 const R=document.getElementById('uread');clear(R);UC.cond.forEach(c=>{const d=document.createElement('div');const b=document.createElement('b');b.textContent=UC.label[c];d.appendChild(b);
 const desc=document.createElement('span');desc.className='explain';desc.textContent=descriptions[c];d.appendChild(desc);
 if(c==='B_lang_put'||c==='C_lang_move'){const ins=document.createElement('span');ins.className='instruction';ins.textContent='“'+UC.instr[c]+'”';d.appendChild(ins);}
 const sp=document.createElement('span');sp.className='outcome';sp.textContent='Outcome: '+(UC.rows[e][c]||'not available')+(c==='D_steer'?` (α = ${UC.chosen})`:'');d.appendChild(sp);R.appendChild(d);});
 document.getElementById('unote').textContent='Original instruction: “'+UC.instr.A_original+'”. Each caption describes the video column directly above it.';
 document.getElementById('ucontrols').classList.toggle('hidden',!UC.videos[e]);
 const sk=document.querySelector('[data-seek="uvid"]');if(sk)sk.value=0;
 upath(e);}
function winit(){const W=UC.weak,S=document.getElementById('wsel');clear(S);
 if(!W||!W.sets.length){const AP=document.getElementById('uaph');clear(AP);AP.textContent='Weaker-strength runs not available (no sweep runs found in step 16 or 18).';
  AP.classList.remove('hidden');document.getElementById('uavid').classList.add('hidden');S.disabled=true;return;}
 W.sets.forEach((s,i)=>{const o=document.createElement('option');o.value=i;o.textContent=`example ${i+1}`+(i===0?' · most indecisive':'');S.appendChild(o);});
 S.onchange=wshow;wshow();}
function wshow(){const W=UC.weak,s=W.sets[+document.getElementById('wsel').value]||W.sets[0];
 const AV=document.getElementById('uavid'),AP=document.getElementById('uaph'),AR=document.getElementById('uaread');AV.pause();clear(AP);clear(AR);
 const cols=innerWidth>600?`repeat(${s.cases.length}, minmax(0,1fr))`:'';
 s.cases.forEach(c=>{const title=`α = ${c.alpha} · start ${c.start}`;const ph=document.createElement('div');ph.textContent=title;AP.appendChild(ph);
  const col=document.createElement('div'),h=document.createElement('b');h.textContent=title;col.appendChild(h);
  const d=document.createElement('span');d.className='explain';d.textContent=c.story;col.appendChild(d);
  const o=document.createElement('span');o.className='outcome';o.textContent='Outcome: '+c.outcome;col.appendChild(o);AR.appendChild(col);});
 AR.style.gridTemplateColumns=cols;AP.style.gridTemplateColumns=cols;
 if(s.video){AV.classList.remove('hidden');AP.classList.add('hidden');AV.src='videos/'+s.video;}else{AV.classList.add('hidden');AP.classList.remove('hidden');}
 document.getElementById('uacontrols').classList.toggle('hidden',!s.video);const sk=document.querySelector('[data-seek="uavid"]');if(sk)sk.value=0;
 document.getElementById('uanote').textContent=(D.preview?'Preview, placeholder cases. ':'')+`Picked, not typical: among the ${W.n_fail} failed runs at α = ${W.alphas.join(', ')} (${W.n_eps} starts each${W.first_run?', first run':''}), these switch heading most often or knock a mug over. `+
  `${W.n_switch} of the ${W.n_fail} switch between mugs at least once and ${W.n_tip} knock a mug over. Headings are read from the end-effector path: the mug it closes in on fastest, held for at least 0.6 s.`;}
function utab(){const T=document.getElementById('utab');clear(T);const tb=document.createElement('table');const hr=document.createElement('tr');
 ['condition','instruction','success rate'].forEach(h=>{const th=document.createElement('th');th.textContent=h;hr.appendChild(th);});tb.appendChild(hr);
 const pct=(k,n)=>n?`${Math.round(100*k/n)}%`:'–';
 const row=(cells,cls,tip)=>{const tr=document.createElement('tr');if(cls)tr.className=cls;if(tip)tr.title=tip;cells.forEach(v=>{const td=document.createElement('td');td.textContent=v;tr.appendChild(td);});tb.appendChild(tr);};
 UC.cond.filter(c=>c!=='D_steer').forEach(c=>{const n=UC.eps.filter(e=>UC.rows[e][c]).length,k=UC.eps.filter(e=>UC.rows[e][c]==='success').length;
  row([UC.label[c],c==='A_original'?'original':'changed',pct(k,n)],'',`${k} of ${n}`);});
 const ST=UC.strength&&UC.strength.length?UC.strength:[{alpha:UC.chosen,counts:[UC.eps.filter(e=>UC.rows[e].D_steer==='success').length],n:UC.eps.length}];
 ST.forEach(s=>row([s.alpha===UC.chosen?`steering (ours), α = ${s.alpha}`:`steering, α = ${s.alpha}`,'original',pct(s.counts[0],s.n)],
  s.alpha===UC.chosen?'ours':'sub',`${s.counts[0]} of ${s.n}`));
 T.appendChild(tb);
 const fr=ST.filter(s=>s.first_run);if(fr.length){const p=document.createElement('p');p.className='note';p.style.marginTop='10px';
  p.textContent=`α = ${fr.map(s=>s.alpha).join(', ')}: first run, ${fr[0].n} held-out starts; all other rows: ${UC.eps.length} new held-out starts.`;T.appendChild(p);}}
function ucflow(){const S=document.getElementById('ucflow');clear(S);const W=cw('ucflow'),a=css('--axis'),o=css('--ours'),mu=css('--muted');
 const n=UC?UC.eps.length:13,k=c=>UC?UC.eps.filter(e=>UC.rows[e][c]==='success').length:null;
 const kl=Math.max(k('B_lang_put')||0,k('C_lang_move')||0),ks=k('D_steer');
 const R1=[['change the instruction','“put the yellow and white mug','on the right plate”'],['policy','acts on its own',''],
   ['white mug first',`success ${UC?kl:'–'} / ${n}`,'']];
 const R2=[['steer the representation','original instruction','ψ: end effector above the yellow mug'],['policy','takes over after release',''],
   ['yellow mug on its plate',`success ${UC?ks:'–'} / ${n}`,'']];
 const card=(x,y,w,h,L,col,strong)=>{const g=el('g',{},S);el('rect',{x,y,width:w,height:h,rx:10,fill:css('--surface'),stroke:col,'stroke-width':strong?2:1},g);
  const lines=L.filter(Boolean);const y0=y+h/2-(lines.length-1)*8+4;
  lines.forEach((t,i)=>txt(g,x+w/2,y0+i*16,t,{'text-anchor':'middle',class:i?'':'lab',style:i?'':'font-weight:600;fill:'+css('--ink')}));};
 if(W>=760){const iw=170,gap=34,cw_=(W-iw-gap*4-8)/3,X0=4,Xc=i=>X0+iw+gap+i*(cw_+gap),Y1=34,Y2=178,H=96;S.setAttribute('viewBox',`0 0 ${W} 290`);
  card(X0,110,iw,96,['new intent','“move only the','yellow-and-white mug”'],a,false);
  [[R1,Y1,mu,false],[R2,Y2,o,true]].forEach(([R,Y,col,st])=>{el('path',{d:`M${X0+iw} 158 C ${X0+iw+gap/2} 158, ${X0+iw+gap/2} ${Y+H/2}, ${Xc(0)-6} ${Y+H/2}`,fill:'none',stroke:col,'stroke-width':st?2.2:1.5},S);
   R.forEach((b,i)=>{card(Xc(i),Y,cw_,H,b,col,st);if(i<2)arrow(S,Xc(i)+cw_,Y+H/2,Xc(i+1),Y+H/2,col,null,st?2:1.5);});});
  txt(S,Xc(0),Y1-10,'option 1',{class:'ink'});txt(S,Xc(0),Y2-10,'option 2 (ours)',{style:'fill:'+o+';font-weight:600'});}
 else{const bw=W-12,H=70,gap=24;let y=6;
  card(6,y,bw,58,['new intent','“move only the yellow-and-white mug”'],a,false);y+=58+gap+12;
  [[R1,mu,false,'option 1'],[R2,o,true,'option 2 (ours)']].forEach(([R,col,st,lab])=>{txt(S,8,y-8,lab,st?{style:'fill:'+o+';font-weight:600'}:{class:'ink'});
   R.forEach((b,i)=>{card(6,y,bw,H,b,col,st);if(i<2){const x=6+bw/2;el('line',{x1:x,x2:x,y1:y+H,y2:y+H+gap-7,stroke:col,'stroke-width':1.5},S);
     el('path',{d:`M${x-5} ${y+H+gap-8} L${x} ${y+H+gap} L${x+5} ${y+H+gap-8} Z`,fill:col},S);}y+=H+gap;});y+=14;});
  S.setAttribute('viewBox',`0 0 ${W} ${y}`);}}
function abar(){if(!UC)return;const S=document.getElementById('abar');clear(S);const W=cw('abar'),H=300,m={l:46,r:10,t:10,b:44};S.setAttribute('viewBox',`0 0 ${W} ${H}`);
 legend('aleg',UC.outcomes.map((o,i)=>({k:'dk',c:css(OCOL[i]),n:o})));
 const A=UC.strength||[];if(!A.length)return;const bw=Math.min(56,(W-m.l-m.r)/A.length*0.6),x=i=>m.l+(i+0.5)*(W-m.l-m.r)/A.length,y=sc(0,100,H-m.b,m.t);
 for(let t=0;t<=100;t+=25){el('line',{x1:m.l,x2:W-m.r,y1:y(t),y2:y(t),stroke:css('--grid')},S);txt(S,m.l-8,y(t)+4,t+'%',{'text-anchor':'end'});}
 A.forEach((s,i)=>{const a=s.alpha,cnt=s.counts.map(c=>100*c/s.n);let acc=0;const g=el('g',{},S);
  cnt.forEach((c,j)=>{if(!c)return;el('rect',{x:x(i)-bw/2,y:y(acc+c),width:bw,height:Math.max(0,y(acc)-y(acc+c)-2),rx:3,fill:css(OCOL[j])},g);acc+=c;});
  txt(S,x(i),H-m.b+18,String(a)+(a===UC.chosen?' *':''),{'text-anchor':'middle',style:a===UC.chosen?'font-weight:600;fill:'+css('--ink'):''});
  el('rect',{x:x(i)-bw/2-6,y:m.t,width:bw+12,height:H-m.t-m.b,fill:'transparent'},g);
  g.addEventListener('pointermove',ev=>showTip(ev,`α = ${a}`+(a===UC.chosen?(UC.confirm?' (fixed in advance)':' (chosen on dev)'):''),
   UC.outcomes.map((o,j)=>({n:o,v:`${Math.round(cnt[j])}%  (${s.counts[j]} of ${s.n})`,c:css(OCOL[j])}))));
  g.addEventListener('pointerleave',hideTip);});
 txt(S,(m.l+W-m.r)/2,H-6,`steering strength α  (share of held-out starts; * ${UC.confirm?'fixed in advance':'chosen on development starts'})`,{'text-anchor':'middle'});}
function upath(e){const S=document.getElementById('upath');if(!S)return;clear(S);if(!UC)return;const ps=UC.paths[e]||{},ob=UC.objs[e]||{};
 const W=cw('upath'),H=Math.round(Math.min(400,W*0.62)),m={l:44,r:14,t:14,b:40};S.setAttribute('viewBox',`0 0 ${W} ${H}`);
 const keys=['none'].concat(UC.sweep.map(a=>String(a))).filter(k=>ps[k]);const T=p=>[-p[1],p[0]];
 legend('pthleg',[{k:'dash',dash:css('--neutral'),n:'original instruction, no steering'}].concat(UC.sweep.filter(a=>ps[String(a)]).map(a=>({k:'lk',c:aCol(a),n:`α = ${a}: ${UC.rows[e]['a'+a]||''}`}))));
 const pts=keys.flatMap(k=>ps[k].map(T)).concat(Object.values(ob).map(T));if(!pts.length)return;
 const xs=pts.map(p=>p[0]),ys=pts.map(p=>p[1]);const cx=(Math.min(...xs)+Math.max(...xs))/2,cy=(Math.min(...ys)+Math.max(...ys))/2;
 const half=Math.max(Math.max(...xs)-Math.min(...xs),(Math.max(...ys)-Math.min(...ys))*(W-m.l-m.r)/(H-m.t-m.b))/2+4,hy=half*(H-m.t-m.b)/(W-m.l-m.r);
 const x=sc(cx-half,cx+half,m.l,W-m.r),y=sc(cy-hy,cy+hy,H-m.b,m.t);hgrid(S,y,[cy-hy,cy+hy],m.l,W-m.r,5);
 ticks(cx-half,cx+half,6).forEach(t=>txt(S,x(t),H-m.b+18,String(t),{'text-anchor':'middle'}));txt(S,(m.l+W-m.r)/2,H-6,'cm (camera left ↔ right)',{'text-anchor':'middle'});
 const SH={"white mug":"white","yellow-and-white mug":"yellow","right plate":"plate","red mug":"red"};
 Object.entries(ob).forEach(([k,v])=>{const p=T(v);el('circle',{cx:x(p[0]),cy:y(p[1]),r:10,fill:'none',stroke:css('--ink2'),'stroke-width':1.8},S);
  txt(S,x(p[0])+(W<520?0:14),y(p[1])+(W<520?-15:4),W<520?(SH[k]||k):k,{class:'ink','text-anchor':W<520?'middle':'start'});});
 keys.forEach(k=>{const p=ps[k].map(T);const c=k==='none'?css('--neutral'):aCol(+k);line(S,p.map(q=>q[0]),p.map(q=>q[1]),x,y,c,k===String(UC.chosen)?3:2,{'stroke-dasharray':k==='none'?'6 5':''});
  const q=p[p.length-1];el('circle',{cx:x(q[0]),cy:y(q[1]),r:4.5,fill:c,stroke:css('--surface'),'stroke-width':2},S);});}

/* ---------- code link ---------- */
{const L=document.getElementById('codelink'),add=(href,t)=>{const a=document.createElement('a');a.href=href;a.textContent=t;L.appendChild(a);};
 if(location.protocol!=='file:')fetch('code.zip',{method:'HEAD'}).then(r=>{if(r.ok)L.prepend(Object.assign(document.createElement('a'),{href:'code.zip',textContent:'Download code.zip ↓'}));}).catch(()=>{});
 if(D.repo_url)add(D.repo_url,'Anonymous repository ↗');}

/* ---------- draw all + theme ---------- */
function heroNums(){if(!UC)return;const n=UC.eps.length,lang=['B_lang_put','C_lang_move'];
 const kl=lang.reduce((s,c)=>s+UC.eps.filter(e=>UC.rows[e][c]==='success').length,0);
 const ks=UC.eps.filter(e=>UC.rows[e].D_steer==='success').length;
 document.getElementById('hl1').textContent=`${kl} of ${lang.length*n} runs`;
 document.getElementById('hl2').textContent=UC.confirm?`${ks} of ${n} new held-out starts, with the strength fixed in advance`
  :`${ks} of ${n} held-out starts at the strength chosen on development starts`;}
function drawAll(){ucflow();chain();overview();tiles();
 if(UC){abar();upath(+document.getElementById('usel').value);}}
// Both rows show the original grid video, cropped without altering its pixels.
['uvid','uavid'].forEach(id=>{const video=document.getElementById(id);video.addEventListener('loadedmetadata',()=>{const rows=id==='uvid'&&UC&&UC.grid_rows?(UC.grid_rows[document.getElementById('usel').value]||1):1;
 video.parentElement.style.aspectRatio=`${video.videoWidth} / ${video.videoHeight/rows}`;});video.addEventListener('timeupdate',()=>{const seek=document.querySelector(`[data-seek="${id}"]`);seek.value=video.duration?100*video.currentTime/video.duration:0;});});
document.querySelectorAll('[data-video]').forEach(button=>button.onclick=()=>{const v=document.getElementById(button.dataset.video);if(v.paused)v.play().catch(()=>{});else v.pause();});
document.querySelectorAll('[data-restart]').forEach(button=>button.onclick=()=>{const v=document.getElementById(button.dataset.restart);v.currentTime=0;v.play().catch(()=>{});});
document.querySelectorAll('[data-seek]').forEach(input=>input.oninput=()=>{const v=document.getElementById(input.dataset.seek);if(Number.isFinite(v.duration))v.currentTime=v.duration*input.value/100;});
uinit();heroNums();drawAll();
document.getElementById('theme').onclick=()=>{const r=document.documentElement,dark=r.getAttribute('data-theme')==='dark';
 r.setAttribute('data-theme',dark?'light':'dark');drawAll();};
matchMedia('(prefers-color-scheme: dark)').addEventListener('change',drawAll);
let _rz=null,_lw=innerWidth;addEventListener('resize',()=>{if(Math.abs(innerWidth-_lw)<4)return;_lw=innerWidth;clearTimeout(_rz);_rz=setTimeout(drawAll,150);});
</script>
</body>
</html>
"""

# ---------------------------------------------------------------- write the site
def _finite(o):
    if isinstance(o, float):
        return o if np.isfinite(o) else None
    if isinstance(o, dict):
        return {k: _finite(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [_finite(v) for v in o]
    return o
safe = lambda o: json.dumps(_finite(o), separators=(",", ":"), allow_nan=False).replace("</", "<\\/")
os.makedirs(f"{OUT}/videos", exist_ok=True)
open(f"{OUT}/index.html", "w").write(TEMPLATE.replace("__DATA__", safe(data)))

if not PREVIEW and (closed or usecase):
    from shutil import which
    closed = closed or {"scenarios": []}
    used = set()                                   # closed-loop videos are no longer shown on the page
    for name in sorted(used):
        src, dst = f"{ROOT}/rebuttal/videos/{name}", f"{OUT}/videos/{name}"
        if not os.path.exists(src):
            missing.append(src); continue
        ok = which("ffmpeg") and subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", src, "-map_metadata", "-1",
                                                 "-c", "copy", dst]).returncode == 0
        if not ok:
            shutil.copy(src, dst); print("[warn] metadata not stripped:", name)
    if usecase:
        for e, name in usecase["videos"].items():
            src, dst = f"{UC_DIR}/test_ep{int(e):02d}_grid.mp4", f"{OUT}/videos/{name}"
            ok = which("ffmpeg") and subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", src, "-map_metadata", "-1",
                                                     "-c", "copy", dst]).returncode == 0
            if not ok:
                shutil.copy(src, dst); print("[warn] metadata not stripped:", name)
    code_dir = f"{ROOT}/code"
    if os.path.isdir(code_dir):
        shutil.make_archive(f"{OUT}/code", "zip", code_dir)

# ---------------------------------------------------------------- anonymity check
pat = [re.compile(re.escape(s), re.I) for s in FORBIDDEN if s] + \
      [re.compile(r"[\w.+-]+@[\w-]+\.[\w.]+"), re.compile(r"/content/"), re.compile(r"MyDrive")]
hits = []
for dp, _, fns in os.walk(OUT):
    for fn in fns:
        p = os.path.join(dp, fn)
        if fn.endswith(".zip"):
            import zipfile
            with zipfile.ZipFile(p) as z:
                for n in z.namelist():
                    b = z.read(n).decode("utf-8", "ignore")
                    hits += [(f"{fn}:{n}", r.pattern) for r in pat[:len(FORBIDDEN)] if r.search(b)]
            continue
        b = open(p, "rb").read().decode("utf-8", "ignore")
        use = pat if fn.endswith((".html", ".json", ".txt", ".md")) else pat[:len(FORBIDDEN)]
        hits += [(fn, r.pattern) for r in use if r.search(b)]
print("\nanonymity check:", "OK" if not hits else "")
for h in hits:
    print("  [!] found", h[1], "in", h[0])
if not FORBIDDEN:
    print("  (FORBIDDEN is empty: add names, affiliation and e-mail to also check for them)")
for m_ in missing:
    print("[missing]", m_)
if not PREVIEW:
    shutil.make_archive(OUT, "zip", OUT)
size = sum(os.path.getsize(os.path.join(dp, fn)) for dp, _, fns in os.walk(OUT) for fn in fns)
print(f"\nsite written to {OUT} ({size / 1e6:.1f} MB)" + ("" if PREVIEW else f" and {OUT}.zip"))

# ---------------------------------------------------------------- show it in Colab
if SERVE_IN_COLAB:
    try:
        from google.colab import output
        import http.server, functools, socketserver
        class _Q(http.server.SimpleHTTPRequestHandler):
            def log_message(self, *a): pass
        handler = functools.partial(_Q, directory=OUT)
        socketserver.TCPServer.allow_reuse_address = True
        try:
            srv = socketserver.TCPServer(("", 8765), handler)
            threading.Thread(target=srv.serve_forever, daemon=True).start()
        except OSError:
            pass                                   # already serving OUT from a previous run of this cell
        output.serve_kernel_port_as_window(8765)
        output.serve_kernel_port_as_iframe(8765, height="900")
    except Exception as ex:
        print("(preview inside the notebook not available:", type(ex).__name__, "- open index.html from the zip)")

