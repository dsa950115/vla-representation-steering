# ======================================================================
# Project page: add the step-18b baseline comparison to an EXISTING built site  (ONE Colab cell, CPU, seconds)
#   reads   aclrh/intent_change_confirm/baselines.json   (use_case/18b_intent_baselines.py)
#           SITE_ZIP: the built site (index.html, assets/results.js, ...), e.g. the anonymous release zip
#           aclrh/intent_change_confirm/compare_epXX.mp4 (18b, RECORD_BEST): 2 x 4 comparison videos, if present
#   writes  SITE_OUT: the same site with SITE_DATA.usecase.baselines filled in (the card "Against fixed steering
#           vectors" appears once this field exists), the baselines' outcomes at their best strength in usecase.rows,
#           and, when the comparison videos exist, videos/compare_epXX.mp4 + usecase.compare (the demo then plays the
#           2 x 4 comparison instead of the 1 x 4 one)
#   Ours is read from the site itself (SITE_DATA.usecase: held-out starts, D_steer outcomes, fixed alpha), so the
#   comparison uses exactly the starts the page shows.
# ======================================================================
import os, json, math, zipfile, shutil

try:
    from google.colab import drive
    if not os.path.isdir("/content/drive/MyDrive"):
        drive.mount("/content/drive")
except ImportError:
    pass
ROOT = os.environ.get("ACLRH_ROOT", "/content/drive/MyDrive/aclrh")
SITE_ZIP = os.environ.get("SITE_ZIP", f"{ROOT}/vla-steering-anon.zip")
SITE_OUT = os.environ.get("SITE_OUT", f"{ROOT}/vla-steering-anon_baselines.zip")
FB = f"{ROOT}/intent_change_confirm/baselines.json"
RES12 = f"{ROOT}/intent_change_confirm/results.json"        # step 18 (+ 18c): ours at its fixed and extra strengths

BASE_LABEL = {"CAA-QoI": "CAA, outcome contrast", "CAA-behavior": "CAA, behaviour contrast", "probe weight": "probe weight (ITI)"}
BASE_NEEDS = {"CAA-QoI": "ψ", "CAA-behavior": "labelled phases", "probe weight": "ψ"}


def outcome(r):
    """the page's outcome classes (as in use_case/18)"""
    if r["success"]:
        return "success"
    if r.get("tipped") or (r.get("white_move_cm", 0) >= 3.0 and r.get("first_lift") != "white"):
        return "knocked a mug"
    if r.get("first_lift") == "white":
        return "went for the white mug"
    if r.get("first_lift") == "yellow":
        return "grasped, not placed"
    return "no grasp"


def mcnemar(x, y):
    """exact two-sided McNemar test on paired successes: (only x, only y, p)"""
    b = sum(1 for p, q in zip(x, y) if p and not q); c = sum(1 for p, q in zip(x, y) if q and not p)
    n = b + c
    if n == 0:
        return b, c, 1.0
    return b, c, min(1.0, 2 * sum(math.comb(n, i) for i in range(min(b, c) + 1)) / 2 ** n)


assert os.path.exists(FB), f"{FB} not found: run use_case/18b_intent_baselines.py first"
assert os.path.exists(SITE_ZIP), f"{SITE_ZIP} not found: upload the built site zip there (or set SITE_ZIP)"
B = json.load(open(FB))

work = "/content/_site_patch" if os.path.isdir("/content") else "_site_patch"
shutil.rmtree(work, ignore_errors=True)
with zipfile.ZipFile(SITE_ZIP) as z:
    z.extractall(work)
res = next(os.path.join(d, f) for d, _, fs in os.walk(work) for f in fs if f == "results.js")
src = open(res, encoding="utf-8").read()
head, body = src.split("=", 1)
body = body.strip().rstrip(";")
D = json.loads(body)
UC = D["usecase"]
assert UC, "the site has no use-case data"
eps = [int(e) for e in UC["eps"]]
ours = [UC["rows"][str(e)].get("D_steer") == "success" for e in eps]

rows, best = {}, {}
for c in BASE_LABEL:
    alphas = sorted({float(k.split("|")[2]) for k in B if k.count("|") == 2 and k.split("|")[1] == c})
    pts = []
    for a in alphas:
        rs = [B.get(f"{e}|{c}|{a:.0f}") for e in eps]
        if all(r is not None for r in rs):
            succ = [bool(r["success"]) for r in rs]
            pts.append({"alpha": a, "k": sum(succ), "n": len(succ), "succ": succ})
    if not pts:
        print(f"[!] {c}: not complete on the page's {len(eps)} starts, left out")
        continue
    bp = max(pts, key=lambda d: (d["k"], -d["alpha"]))                 # ties: the smaller strength
    b_, c_, p_ = mcnemar(ours, bp["succ"])
    best[c] = {"alpha": bp["alpha"], "k": bp["k"], "n": bp["n"], "only_ours": b_, "only_base": c_, "p": round(p_, 4)}
    rows[c] = [{k: d[k] for k in ("alpha", "k", "n")} for d in pts]
    print(f"{c:13s} best {bp['k']:2d}/{bp['n']} at alpha {bp['alpha']:.0f} | only ours {b_}, only baseline {c_} | "
          f"exact McNemar p = {p_:.3f}")
assert rows, "no baseline complete on the page's starts"
UC["baselines"] = {"label": BASE_LABEL, "needs": BASE_NEEDS, "rows": rows, "best": best, "ours_alpha": UC["chosen"],
                   "ours_k": int(sum(ours)), "ours_n": len(ours)}
print(f"ours: {sum(ours)}/{len(ours)} at alpha {UC['chosen']:.0f} (fixed in advance)")
if os.path.exists(RES12):                                              # ours at every strength complete on these starts
    T12 = json.load(open(RES12)).get("test", {})
else:
    T12 = {}
if T12:
    al = sorted({float(k.split("sweep")[1]) for k in T12 if "|sweep" in k} | {float(UC["chosen"])})
    orow = []
    for a in al:
        rs = [T12.get(f"{e}|D_steer") if a == float(UC["chosen"]) else T12.get(f"{e}|sweep{a:.0f}") for e in eps]
        if all(r is not None for r in rs):
            orow.append({"alpha": a, "k": sum(bool(r["success"]) for r in rs), "n": len(rs)})
    UC["baselines"]["ours_rows"] = orow
    # success table and strength bars: ours at every strength, all on the same held-out starts (replaces the first run)
    st_rows = []
    for a in al:
        rs = [T12.get(f"{e}|D_steer") if a == float(UC["chosen"]) else T12.get(f"{e}|sweep{a:.0f}") for e in eps]
        if all(r is not None for r in rs):
            oc = [outcome(r) for r in rs]
            st_rows.append({"alpha": a, "counts": [oc.count(o) for o in UC["outcomes"]], "n": len(rs), "first_run": False})
    if st_rows:
        UC["strength"] = st_rows
        print("strength table:", ", ".join(f"alpha {d['alpha']:.0f} {d['counts'][0]}/{d['n']}" for d in st_rows))
    print("ours:", ", ".join(f"alpha {d['alpha']:.0f} {d['k']}/{d['n']}" for d in orow))
for c, d in best.items():                                              # outcome of each baseline at its best strength
    for e in eps:
        UC["rows"][str(e)][c] = outcome(B[f"{e}|{c}|{d['alpha']:.0f}"])

# comparison videos (2 x 4) from 18b, relabelled: the black band of every tile gets the page's method name
RELABEL = True
RELABEL_VERSION = 3          # bump to force relabelling after changing relabel()
_a = lambda c: f"α = {best[c]['alpha']:.0f}" if c in best else ""
TILE_LABELS = [[("original instruction", "no steering"), ("new instruction (1)", "no steering"),
                ("new instruction (2)", "no steering"), ("new instruction (3)", "no steering")],
               [("CAA, outcome contrast", _a("CAA-QoI")), ("CAA, behaviour contrast", _a("CAA-behavior")),
                ("probe weight (ITI)", _a("probe weight")), ("steering (ours)", f"α = {float(UC['chosen']):.0f}")]]
ORANGE = (235, 104, 52)


GREEN, RED, IDLE = (47, 158, 91), (217, 72, 59), (60, 60, 60)
BORDER = 5


def relabel(src, dst, oc):
    """paint over the burned-in header band of each tile (condition, instruction, time) and write the page's name;
    oc[r][c]: True (success) / False (failure) / None. Each tile gets a grey border while its run is going, which turns
    green or red once that run's clip has ended (the tile stops changing). Ours keeps an orange mark in its header."""
    import numpy as np, imageio
    from PIL import Image, ImageDraw, ImageFont
    import matplotlib
    fdir = os.path.join(matplotlib.get_data_path(), "fonts", "ttf")       # DejaVu ships with matplotlib (has α)
    try:
        font = ImageFont.truetype(os.path.join(fdir, "DejaVuSans-Bold.ttf"), 13)
        small = ImageFont.truetype(os.path.join(fdir, "DejaVuSans.ttf"), 11)
    except OSError:
        font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 13)
        small = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 11)
    rd = imageio.get_reader(src); fps = rd.get_meta_data().get("fps", 20)
    frames = [np.asarray(f)[..., :3] for f in rd]; rd.close()
    H, W = frames[0].shape[:2]; th, tw = H // 2, W // 4
    band = 3 + 16 * 2                 # use_case/18 burns in 3 lines at y = 3, 19, 35: repaint lines 1-2, keep the status line
    # when does each tile's clip end? (18b holds the last frame of shorter runs): last frame that still changes
    end = [[len(frames) - 1] * 4 for _ in range(2)]
    for r in range(2):
        for c in range(4):
            sub = lambda f: f[r * th + band + 8:(r + 1) * th - 8:4, c * tw + 8:(c + 1) * tw - 8:4].astype(np.int16)
            last = 0
            for t in range(1, len(frames)):
                if np.abs(sub(frames[t]) - sub(frames[t - 1])).mean() > 1.0:
                    last = t
            end[r][c] = last
    out = []
    for ti, f in enumerate(frames):
        im = Image.fromarray(np.array(f, copy=True)); d = ImageDraw.Draw(im)
        for r in range(2):
            for c in range(4):
                x0, y0 = c * tw, r * th
                d.rectangle([x0, y0, x0 + tw - 1, y0 + band - 1], fill=(0, 0, 0))
                t1, t2 = TILE_LABELS[r][c]
                d.text((x0 + 12, y0 + 5), t1, fill=(255, 255, 255), font=font)
                d.text((x0 + 12, y0 + 20), t2, fill=(200, 200, 200), font=small)
        a = np.asarray(im).copy()
        for r in range(2):
            for c in range(4):
                x0, y0 = c * tw, r * th
                col = IDLE if (ti < end[r][c] or oc[r][c] is None) else (GREEN if oc[r][c] else RED)
                a[y0:y0 + BORDER, x0:x0 + tw] = col; a[y0 + th - BORDER:y0 + th, x0:x0 + tw] = col
                a[y0:y0 + th, x0:x0 + BORDER] = col; a[y0:y0 + th, x0 + tw - BORDER:x0 + tw] = col
        a[th + BORDER:th + band - 2, 3 * tw + BORDER:3 * tw + BORDER + 4] = ORANGE   # ours: orange mark next to its name
        out.append(a)
    imageio.mimsave(dst, out, fps=fps, macro_block_size=1)
    return band

site_root = os.path.dirname(os.path.dirname(res))                     # .../assets/results.js -> site root
vdir = os.path.join(site_root, "videos"); os.makedirs(vdir, exist_ok=True)
cv = {}
for e in eps:
    src_v = f"{ROOT}/intent_change_confirm/compare_ep{e:02d}.mp4"
    if os.path.exists(src_v):
        dst_v = os.path.join(vdir, f"compare_ep{e:02d}.mp4")
        if RELABEL:
            # relabelled once, then cached on Drive next to the original; redone only if the labels or the source change
            keys = [["A_original", "B_lang_put", "C_lang_move", "E_lang_leave"], list(best)[:3] + ["D_steer"]]
            def _oc(k):
                o = UC["rows"][str(e)].get(k) if k != "E_lang_leave" else (outcome(T12[f"{e}|{k}"]) if f"{e}|{k}" in T12 else None)
                return None if o is None else (o == "success")
            oc = [[_oc(k) for k in row] for row in keys]
            sig = json.dumps([TILE_LABELS, oc, os.path.getsize(src_v), RELABEL_VERSION], ensure_ascii=False)
            cache, cache_sig = src_v[:-4] + "_site.mp4", src_v[:-4] + "_site.json"
            if os.path.exists(cache) and os.path.exists(cache_sig) and open(cache_sig, encoding="utf-8").read() == sig:
                shutil.copy(cache, dst_v)
            else:
                b_ = relabel(src_v, cache, oc)
                open(cache_sig, "w", encoding="utf-8").write(sig)
                shutil.copy(cache, dst_v)
                print(f"  relabelled compare_ep{e:02d}.mp4 (header band {b_} px), cached on Drive", flush=True)
        else:
            shutil.copy(src_v, dst_v)
        cv[str(e)] = f"compare_ep{e:02d}.mp4"
E_KEY, E_LABEL, E_INSTR = "E_lang_leave", "new instruction (3)", "leave the white mug where it is and put the yellow and white mug on the right plate"
has_e = os.path.exists(RES12) and all(f"{e}|{E_KEY}" in T12 for e in eps)
if has_e:
    for e in eps:
        UC["rows"][str(e)][E_KEY] = outcome(T12[f"{e}|{E_KEY}"])
    UC["label"][E_KEY], UC["instr"][E_KEY] = E_LABEL, E_INSTR
    UC["extra_instr"] = [E_KEY]
    print(f"new instruction (3): {sum(UC['rows'][str(e)][E_KEY] == 'success' for e in eps)}/{len(eps)} successes")
if cv:
    UC["compare"] = {"order": ["A_original", "B_lang_put", "C_lang_move", E_KEY if has_e else None] + list(best) + ["D_steer"],
                     "videos": cv, "alpha": {c: d["alpha"] for c, d in best.items()}}
    print(f"comparison videos: {len(cv)} of {len(eps)} starts" + ("" if len(cv) == len(eps) else
          " (the other starts keep the 1 x 4 video)"))
else:
    print("no compare_epXX.mp4 found (run 18b with RECORD_BEST = True): the demo keeps the 1 x 4 videos")

open(res, "w", encoding="utf-8").write(head.rstrip() + " = " + json.dumps(D, ensure_ascii=True, separators=(",", ":")) + ";\n")
if os.path.exists(SITE_OUT):
    os.remove(SITE_OUT)
with zipfile.ZipFile(SITE_OUT, "w", zipfile.ZIP_DEFLATED) as z:
    for d, _, fs in os.walk(work):
        for f in fs:
            p = os.path.join(d, f)
            z.write(p, os.path.relpath(p, work))
print(f"saved {SITE_OUT}")
