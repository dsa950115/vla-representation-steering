# ======================================================================
# OpenVLA-OFT — STEP 12: does the PROBE set the steering direction, or the head Jacobian?  (ONE Colab cell, GPU: A100, ~20 min)
#   Step 11 gave cos = 1.00 to the oracle for every probe. Every direction there is D phi^T (something), and so is the
#   oracle; if D phi is close to rank one, any coefficient vector lands on the same axis and the probe only sets the sign.
#   At 30 held-out states (2 folds) this measures:
#     - the singular values of D phi (signature space) and D phi_u (raw chunk space)
#     - cos to the oracle of: our direction, the direction of ANOTHER QoI's probe, random signature coefficients and
#       random chunk gradients pushed through the head, random directions in z (the control used so far),
#       and the oracle of another QoI
#   Output: aclrh/oft_dphi_diagnostic.npz, printed summary. Log: aclrh/oft_dphi_diagnostic_log.txt.
# ======================================================================
AUTO_SHUTDOWN = True
import os, subprocess, sys, textwrap, time

VENV = "/content/oftenv"
VPY = f"{VENV}/bin/python"
OFT = "/content/openvla-oft"
LIB = "/content/LIBERO"
MARK = f"{VENV}/.setup_done"


def sh(cmd, check=True):
    print(f"$ {cmd}", flush=True)
    r = subprocess.run(cmd, shell=True, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    tail = "\n".join(r.stdout.strip().splitlines()[-15:])
    if tail:
        print(tail, flush=True)
    if check and r.returncode != 0:
        raise RuntimeError(f"failed ({r.returncode}): {cmd}")
    return r.returncode


# ---------------------------------------------------------------- 0. Drive (checked before any model loading)
if not os.path.isdir("/content/drive/MyDrive"):
    from google.colab import drive
    drive.mount("/content/drive")
os.makedirs("/content/drive/MyDrive/aclrh", exist_ok=True)

# ---------------------------------------------------------------- 0b. GPU check
assert subprocess.run(["nvidia-smi"], stdout=subprocess.DEVNULL).returncode == 0, \
    "No GPU visible: switch the runtime to GPU (A100) and reconnect."

# ---------------------------------------------------------------- 1. setup (once)
if not os.path.exists(MARK):
    t0 = time.time()
    sh("pip install -q uv")
    sh("uv python install 3.10")
    sh(f"rm -rf {VENV}")                                # a half-built venv without the marker: start clean
    sh(f"uv venv {VENV} --python 3.10 --seed")
    UV = f"uv pip install --python {VPY}"
    sh(f"{UV} torch==2.2.0 torchvision==0.17.0 --index-url https://download.pytorch.org/whl/cu121")
    sh(f"{UV} numpy==1.26.4")
    if not os.path.exists(OFT):
        sh(f"git clone -q https://github.com/moojink/openvla-oft.git {OFT}")
    sh(f"{UV} -e {OFT}")                                   # pulls the transformers fork and pinned deps
    if not os.path.exists(LIB):
        sh(f"git clone -q https://github.com/Lifelong-Robot-Learning/LIBERO.git {LIB}")
    sh(f"{UV} -e {LIB}")
    sh(f"{UV} -r {OFT}/experiments/robot/libero/libero_requirements.txt")
    sh(f"{UV} numpy==1.26.4")                             # re-pin in case a dependency upgraded it
    # flash-attn: prebuilt wheel for torch 2.2 / py3.10; if it fails the verification falls back to sdpa
    rc = sh(f"{UV} https://github.com/Dao-AILab/flash-attention/releases/download/v2.5.5/"
            "flash_attn-2.5.5+cu122torch2.2cxx11abiFALSE-cp310-cp310-linux_x86_64.whl", check=False)
    print("flash-attn installed" if rc == 0 else "flash-attn NOT installed -> sdpa fallback")
    # LIBERO asks interactively for its data paths on first import: write the config up front
    os.makedirs(os.path.expanduser("~/.libero"), exist_ok=True)
    base = f"{LIB}/libero/libero"
    with open(os.path.expanduser("~/.libero/config.yaml"), "w") as f:
        f.write(textwrap.dedent(f"""\
            benchmark_root: {base}
            bddl_files: {base}/bddl_files
            init_states: {base}/init_files
            datasets: {LIB}/datasets
            assets: {base}/assets
            """))
    open(MARK, "w").write("ok")
    print(f"setup finished in {(time.time() - t0) / 60:.1f} min")
else:
    print("setup already done")

# ---------------------------------------------------------------- 1b. dependency fixes (idempotent)
# tensorflow_datasets is imported by openvla-oft at import time; a too-new tensorflow-metadata needs
# protobuf 5 (google.protobuf.runtime_version), which TF 2.15 cannot use -> pin the TF-2.15-era version
if sh(f"{VPY} -c \"import tensorflow_datasets\"", check=False) != 0:
    sh(f"uv pip install --python {VPY} tensorflow-metadata==1.14.0")
    sh(f"{VPY} -c \"import tensorflow_datasets, google.protobuf as p; print('tfds OK | protobuf', p.__version__)\"")

# robosuite 1.4 predates the MuJoCo >= 3.2 joint-type API (get_joint_qpos_addr assertion) -> pin 3.1.6
_mj = subprocess.run([VPY, "-c", "import mujoco; print(mujoco.__version__)"], text=True,
                     stdout=subprocess.PIPE, stderr=subprocess.DEVNULL).stdout.strip()
print("mujoco in venv:", _mj or "not installed")
if not _mj.startswith("3.1."):
    sh(f"uv pip install --python {VPY} mujoco==3.1.6")
os.makedirs(f"{LIB}/datasets", exist_ok=True)          # silences LIBERO's missing-datasets warning

sh(f"{VPY} -c \"import torch, transformers, numpy; print('torch', torch.__version__, 'cuda', "
   f"torch.cuda.is_available(), '| transformers', transformers.__version__, '| numpy', numpy.__version__)\"")

# ---------------------------------------------------------------- 2. verification script (runs in the venv)
SCRIPT = r'''
import os, sys, time, traceback
os.environ.setdefault("MUJOCO_GL", "egl")
os.environ.setdefault("PYOPENGL_PLATFORM", "egl")
os.environ["MPLBACKEND"] = "Agg"
sys.path.insert(0, "/content/openvla-oft")
sys.path.insert(0, "/content/LIBERO")          # LIBERO's setup.py is not exposed by uv editable installs
import numpy as np
import torch

CKPT = "moojink/openvla-7b-oft-finetuned-libero-10"
UNNORM = "libero_10_no_noops"
TASK_KEYWORDS = ("white mug", "left plate", "yellow and white mug", "right plate")
MAX_STEPS = 520
NUM_WAIT = 10

T0 = time.time()

def stamp(m):
    print(f"[{time.time() - T0:7.1f}s] {m}", flush=True)


def header(t):
    print("\n" + "=" * 90 + f"\n{t}\n" + "=" * 90, flush=True)

header("1. IMPORTS")
# wandb is only used for evaluation logging; the installed wandb needs a newer protobuf than
# TF 2.15 allows, so register a no-op stand-in instead of touching protobuf again
import types, importlib.machinery
_wb = types.ModuleType("wandb")
_wb.__spec__ = importlib.machinery.ModuleSpec("wandb", None)   # find_spec() (accelerate/transformers) needs a spec
_wb.__version__ = "0.0.0"
for _name in ("init", "log", "finish", "login", "config", "save", "watch"):
    setattr(_wb, _name, lambda *a, **k: None)
_wb.run = None
sys.modules["wandb"] = _wb
from experiments.robot.libero.run_libero_eval import GenerateConfig
import experiments.robot.libero.run_libero_eval as rle
import experiments.robot.openvla_utils as ou
import experiments.robot.libero.libero_utils as lu
import experiments.robot.robot_utils as ru
from libero.libero import benchmark
print("run_libero_eval exports:", [n for n in dir(rle) if not n.startswith("_")][:60])

try:
    import flash_attn  # noqa
    ATTN = "flash_attention_2"
except Exception:
    ATTN = "sdpa"
print("attention implementation:", ATTN)

header("2. LOAD OPENVLA-OFT (LIBERO-10)")
cfg = GenerateConfig(
    pretrained_checkpoint=CKPT, use_l1_regression=True, use_diffusion=False, use_film=False,
    num_images_in_input=2, use_proprio=True, load_in_8bit=False, load_in_4bit=False,
    center_crop=True, num_open_loop_steps=8, unnorm_key=UNNORM,
)
if hasattr(cfg, "task_suite_name"):
    cfg.task_suite_name = "libero_10"
if hasattr(cfg, "model_family"):
    cfg.model_family = "openvla"
t0 = time.time()
if ATTN != "flash_attention_2":
    # route the loader to sdpa if flash-attn is missing
    from transformers import AutoModelForVision2Seq
    _orig_fp = AutoModelForVision2Seq.from_pretrained
    def _fp(*a, **kw):
        kw["attn_implementation"] = "sdpa"
        return _orig_fp(*a, **kw)
    AutoModelForVision2Seq.from_pretrained = _fp
vla = ou.get_vla(cfg)
processor = ou.get_processor(cfg)
action_head = ou.get_action_head(cfg, llm_dim=vla.llm_dim)
proprio_projector = ou.get_proprio_projector(cfg, llm_dim=vla.llm_dim, proprio_dim=8)
print(f"loaded in {time.time() - t0:.0f}s | llm_dim {vla.llm_dim} | unnorm keys: {list(getattr(vla, 'norm_stats', {}).keys())[:8]}")

# ---- lambda hook: capture (and later intervene on) the input of the L1 action head ----
LAM = {"cap": None, "delta": None}
_orig_predict = action_head.predict_action
def _predict(actions_hidden_states, *a, **kw):
    LAM["cap"] = actions_hidden_states.detach().float().cpu()
    if LAM["delta"] is not None:
        actions_hidden_states = actions_hidden_states + LAM["delta"].to(actions_hidden_states.device,
                                                                          actions_hidden_states.dtype)
    return _orig_predict(actions_hidden_states, *a, **kw)
action_head.predict_action = _predict

def policy_chunk(obs, task_label):
    observation, _ = rle.prepare_observation(obs, ru.get_image_resize_size(cfg)) \
        if hasattr(rle, "prepare_observation") else (None, None)
    actions = ou.get_vla_action(cfg, vla, processor, observation, task_label, action_head, proprio_projector)
    return np.asarray(actions)


# constants used by the helpers shared with step 2 (perturb is not used for steering)
H = 8
N_KNOTS = 4
PERT_FRAC = 0.3
SEED = 0

header("3. TASK AND ENVIRONMENTS")
suite = benchmark.get_benchmark_dict()["libero_10"]()
tid = next(i for i in range(suite.n_tasks) if all(k in suite.get_task(i).language for k in TASK_KEYWORDS))
task = suite.get_task(tid)
init_states = suite.get_task_init_states(tid)
env, task_description = lu.get_libero_env(task, "openvla", resolution=256)
try:
    from libero.libero.envs import ControlEnv
except ImportError:
    from libero.libero.envs.env_wrapper import ControlEnv   # not re-exported in this LIBERO version
from libero.libero import get_libero_path
bddl = os.path.join(get_libero_path("bddl_files"), task.problem_folder, task.bddl_file)
cenv = ControlEnv(bddl_file_name=bddl, has_renderer=False, has_offscreen_renderer=False,
                  use_camera_obs=False, camera_heights=128, camera_widths=128)   # renderer-free twin
cenv.seed(0)
cenv.reset()
inner = env.env
print(f"task {tid}: {task_description} | init states {len(init_states)}")
print("objects:", list(inner.obj_body_id.keys()))

MUGS_PLATES = ["porcelain_mug_1", "white_yellow_mug_1", "plate_1", "plate_2"]
QOI_NAMES = ["ee_x", "ee_y", "ee_z"] + [f"{o}_{c}" for o in MUGS_PLATES for c in "xyz"]

def positions(e):
    s = e.env
    out = [np.array(s.sim.data.site_xpos[s.robots[0].eef_site_id])]
    out += [np.array(s.sim.data.body_xpos[s.obj_body_id[o]]) for o in MUGS_PLATES]
    return np.concatenate(out)

def grip_state(e):
    g = getattr(e.env.robots[0].gripper, "current_action", None)
    return None if g is None else np.array(g, dtype=np.float64).copy()

def restore(e, sim_state, grip):
    e.env.timestep, e.env.done = 0, False       # the twin env replays many chunks: never hit the horizon
    e.set_init_state(sim_state)
    if grip is not None and hasattr(e.env.robots[0].gripper, "current_action"):
        e.env.robots[0].gripper.current_action = grip.copy()

def run_chunk(e, sim_state, grip, actions):
    restore(e, sim_state, grip)
    for a in actions:
        e.step(np.asarray(a, dtype=np.float64).tolist())
    return positions(e)

# per-dimension scale for perturbations, from the checkpoint's action statistics (raw action space)
try:
    st_ = vla.norm_stats[UNNORM]["action"]
    half = (np.asarray(st_["q99"]) - np.asarray(st_["q01"])) / 2.0
except Exception as ex:
    print("[warn] norm stats unavailable, using 0.5:", repr(ex)); half = np.full(7, 0.5)
print("perturbation std per arm dim:", np.round(PERT_FRAC * half[:6], 4))
rng = np.random.default_rng(SEED)

def perturb(chunk, k):
    """k smooth perturbations of the raw policy chunk on the 6 arm dims; gripper unchanged"""
    tk = np.linspace(0, H - 1, N_KNOTS)
    out = np.repeat(chunk[None], k, 0).astype(np.float64)
    for i in range(k):
        knots = rng.normal(size=(N_KNOTS, 6)) * PERT_FRAC * half[:6]
        out[i, :, :6] += np.stack([np.interp(np.arange(H), tk, knots[:, j]) for j in range(6)], 1)
    return out

def executed(raw_chunk):
    return np.stack([np.asarray(rle.process_action(a.copy(), "openvla"), dtype=np.float64) for a in raw_chunk])



# ======================================================================
# STEP 11: STEERING ALONG LINEAR AND NONLINEAR PROBE DIRECTIONS
# ======================================================================
import pickle
import torch.nn as nn

def sig_levels(U):
    """time-augmented signature, dX = (dt, u dt): returns S1, S<=2."""
    U = np.asarray(U, dtype=np.float64)
    N, H, A = U.shape
    dt = 1.0 / H
    dx = np.concatenate([np.full((N, H, 1), dt), U * dt], axis=2)
    prev1 = np.cumsum(dx, axis=1) - dx
    inc2 = np.einsum("nti,ntj->ntij", prev1, dx) + 0.5 * np.einsum("nti,ntj->ntij", dx, dx)
    S1 = dx.sum(axis=1)
    S2 = inc2.sum(axis=1)
    return {"S1": S1, "S<=2": np.concatenate([S1, S2.reshape(N, -1)], axis=1)}


ROOT = "/content/drive/MyDrive/aclrh"
DATA = f"{ROOT}/oft_probe.npz"
OUT_ST = f"{ROOT}/oft_steering_mlp.npz"
PART = f"{ROOT}/oft_steering_mlp_partial.pkl"
MLP_CKPT = f"{ROOT}/oft_steer_mlp_fold{{}}.pt"

# 13 QoIs as in q1 (9 positions, then 4 distances); MLPs are trained jointly within each group
POS = ["EE x", "EE y", "EE z", "mug1 x", "mug1 y", "mug1 z", "mug2 x", "mug2 y", "mug2 z"]
TASK = ["-d(EE,mug1)", "-d(EE,mug2)", "-d(mug1,plate) xy", "-d(mug2,plate) xy"]
QOI_ALL = POS + TASK
GROUPS = {"pos": [QOI_ALL.index(q) for q in POS], "task": [QOI_ALL.index(q) for q in TASK]}
STEER = ["EE z", "mug1 z", "mug2 z", "-d(mug1,plate) xy", "-d(mug2,plate) xy", "-d(EE,mug1)", "-d(EE,mug2)"]
NEED_MOVE = {"mug1 z", "mug2 z", "-d(mug1,plate) xy", "-d(mug2,plate) xy"}   # MIN_FRAC rule of 04 / 05b

PCA_K = 32
N_PER_FOLD = 10               # steered states per QoI and fold (2 folds)
MOVE_MM, MIN_FRAC = 2e-3, 0.5
H_Z = 0.25                    # finite-difference step (standardized PCA units) for D phi and the simulator gradient
STEP_REL = 0.005              # ||delta lambda|| / ||lambda|| per unit tau, identical for all directions
TAUS = [-8.0, -4.0, -2.0, 0.0, 2.0, 4.0, 8.0]
N_RANDOM = 3
ALPHAS_R = np.logspace(-3, 4, 15)
READOUT_W = [32, 256]
UNSTR_W = [64, 256]
MLP_DEPTH, MLP_LR, MLP_WD, MLP_BATCH, MLP_EPOCHS, MLP_PATIENCE = 3, 1e-3, 1e-4, 512, 400, 25
DEV = torch.device("cuda" if torch.cuda.is_available() else "cpu")

def make_qoi(t1, t2):
    """15 raw positions ee(0:3) mug1(3:6) mug2(6:9) plate_1(9:12) plate_2(12:15) -> 13 QoIs (to increase)"""
    def f(P):
        P = np.asarray(P, dtype=np.float64)
        return np.concatenate([P[..., :9], np.stack([
            -np.linalg.norm(P[..., 0:3] - P[..., 3:6], axis=-1),
            -np.linalg.norm(P[..., 0:3] - P[..., 6:9], axis=-1),
            -np.linalg.norm(P[..., 3:5] - P[..., t1:t1 + 2], axis=-1),
            -np.linalg.norm(P[..., 6:8] - P[..., t2:t2 + 2], axis=-1)], axis=-1)], axis=-1)
    return f

def target_plates(Q0, EP, success_ep):
    last = [np.where(EP == e)[0][-1] for e in np.unique(EP) if success_ep[int(e)]]
    P = Q0[last]
    out = []
    for m in (3, 6):
        d1 = np.linalg.norm(P[:, m:m + 2] - P[:, 9:11], axis=1)
        d2 = np.linalg.norm(P[:, m:m + 2] - P[:, 12:14], axis=1)
        out.append(9 if np.mean(d1 < d2) >= 0.5 else 12)
        print(f"  mug at cols {m}:{m + 3} -> plate_{1 if out[-1] == 9 else 2}")
    return out

def ranks(v):
    v = np.asarray(v, float)
    r = np.empty(len(v)); r[np.argsort(v, kind="mergesort")] = np.arange(len(v), dtype=float)
    for val in np.unique(v):
        m = v == val
        r[m] = r[m].mean()
    return r

def spearman(x, y):
    y = np.asarray(y, float)
    if np.ptp(y) < 1e-12:
        return 0.0
    return float(np.corrcoef(ranks(x), ranks(y))[0, 1])

def ridge_fit(Xtr, Ytr, Xva, Yva):
    """primal ridge with standardized columns; penalty per target chosen on validation rows; refit on all"""
    def fit(X, Y, a_):
        mx, sx, my = X.mean(0), X.std(0) + 1e-12, Y.mean(0)
        Xs = (X - mx) / sx
        G = Xs.T @ Xs
        W = np.linalg.solve(G + a_ * len(X) * np.eye(G.shape[0]), Xs.T @ (Y - my))
        return W / sx[:, None], my - (mx / sx) @ W
    best = []
    for j in range(Ytr.shape[1]):
        errs = []
        for a_ in ALPHAS_R:
            W, b = fit(Xtr, Ytr[:, j:j + 1], a_)
            errs.append(np.mean((Xva @ W + b - Yva[:, j:j + 1]) ** 2))
        best.append(ALPHAS_R[int(np.argmin(errs))])
    X, Y = np.r_[Xtr, Xva], np.r_[Ytr, Yva]
    Ws, bs = zip(*[fit(X, Y[:, j:j + 1], best[j]) for j in range(Y.shape[1])])
    return np.concatenate(Ws, 1), np.concatenate(bs)

class MLP(nn.Module):
    def __init__(self, din, dout, hid):
        super().__init__()
        layers, d = [], din
        for _ in range(MLP_DEPTH):
            layers += [nn.Linear(d, hid), nn.GELU()]
            d = hid
        layers.append(nn.Linear(d, dout))
        self.net = nn.Sequential(*layers)
        nn.init.normal_(self.net[-1].weight, std=1e-3)
        nn.init.zeros_(self.net[-1].bias)

    def forward(self, x):
        return self.net(x)

T_ = lambda a: torch.as_tensor(np.asarray(a), dtype=torch.float32, device=DEV)

def mlp_forward(kind, net, q, A, B):
    """kind 'cf': g(A)^T [1, B] (MLP readout);  kind 'full': f([A, B]) (unstructured). Standardized targets."""
    if kind == "cf":
        Bp = torch.cat([torch.ones(len(B), 1, device=DEV), B], 1)
        return torch.einsum("nqp,np->nq", net(A).view(len(A), q, Bp.shape[1]), Bp)
    return net(torch.cat([A, B], 1))

def train_mlp(kind, A_tr, B_tr, Y_tr, A_va, B_va, Y_va, hid):
    """same recipe as probing/q1_capacity_sweep.py; returns state_dict, (ym, ys)"""
    torch.manual_seed(0)
    ym, ys = Y_tr.mean(0), Y_tr.std(0) + 1e-12
    q = Y_tr.shape[1]
    din = A_tr.shape[1] + (0 if kind == "cf" else B_tr.shape[1])
    net = MLP(din, q * (B_tr.shape[1] + 1) if kind == "cf" else q, hid).to(DEV)
    Atr, Btr, Ytr = T_(A_tr), T_(B_tr), T_((Y_tr - ym) / ys)
    Ava, Bva, Yva = T_(A_va), T_(B_va), T_((Y_va - ym) / ys)
    opt = torch.optim.AdamW(net.parameters(), lr=MLP_LR, weight_decay=MLP_WD)
    best, best_state, bad, n = float("inf"), None, 0, len(Atr)
    for ep in range(MLP_EPOCHS):
        net.train()
        perm = torch.randperm(n, device=DEV)
        for i in range(0, n, MLP_BATCH):
            b = perm[i:i + MLP_BATCH]
            loss = ((mlp_forward(kind, net, q, Atr[b], Btr[b]) - Ytr[b]) ** 2).mean()
            opt.zero_grad(); loss.backward(); opt.step()
        net.eval()
        with torch.no_grad():
            v = ((mlp_forward(kind, net, q, Ava, Bva) - Yva) ** 2).mean().item()
        if v < best - 1e-5:
            best, bad = v, 0
            best_state = {k: t.detach().clone().cpu() for k, t in net.state_dict().items()}
        else:
            bad += 1
            if bad >= MLP_PATIENCE:
                break
    return best_state, (ym, ys), ep + 1

def r2(y, p):
    return 1.0 - np.sum((y - p) ** 2, 0) / np.sum((y - y.mean(0)) ** 2, 0)

header("4. DATA, SIGNATURES, HEAD")
dd = np.load(DATA)
LAMS = dd["LAM"]                                              # float16 (NS, 229376)
EP, CS = dd["EP"], dd["C_STATE"]
UE, SIMS, GRIPS = dd["U_EXEC"], dd["SIM"], dd["GRIP"]
print("target plates:")
qoi = make_qoi(*target_plates(dd["Q0"], EP, dd["SUCCESS_EP"]))
Q0, QF = qoi(dd["Q0"]), qoi(dd["QF"])                         # (NS, 13), (NC, K, 13)
NS, (NC, K, H_, A_) = len(EP), UE.shape
S_all = sig_levels(UE.reshape(NC * K, H_, A_).astype(np.float64))["S<=2"]
s_mu, s_sd = S_all.mean(0), S_all.std(0)
keep = s_sd > 1e-8 * s_sd.max()
st = lambda UU: (sig_levels(np.asarray(UU, np.float64).reshape(-1, H_, A_))["S<=2"][:, keep] - s_mu[keep]) / s_sd[keep]
S_all = (S_all[:, keep] - s_mu[keep]) / s_sd[keep]
ps = S_all.shape[1]
RAW = UE.reshape(NC * K, H_ * A_).astype(np.float64)          # raw executed chunks (unstructured probe input)
r_mu, r_sd = RAW.mean(0), RAW.std(0)
keep_r = r_sd > 1e-8 * r_sd.max()
rst = lambda UU: (np.asarray(UU, np.float64).reshape(-1, H_ * A_)[:, keep_r] - r_mu[keep_r]) / r_sd[keep_r]
RAW = (RAW[:, keep_r] - r_mu[keep_r]) / r_sd[keep_r]
pr = RAW.shape[1]
print(f"signature features {ps} | raw action features {pr} | candidate states {NC} x {K} | device {DEV}")
hp = next(action_head.parameters())
LSHAPE = (56, 4096)

def head_chunks(lams):
    """lams: (n, 229376) float32 -> executed chunks (n, 8, 7), exactly as in the rollouts"""
    with torch.no_grad():
        na = _orig_predict(torch.from_numpy(lams.reshape((-1,) + LSHAPE)).to(hp.device, hp.dtype))
    na = na.float().cpu().numpy().reshape(-1, H_, A_)
    ua = np.asarray(vla._unnormalize_actions(na, UNNORM)).reshape(-1, H_, A_)
    return np.stack([executed(c) for c in ua])

chk = head_chunks(LAMS[CS[:8]].astype(np.float32))
print(f"head(stored lambda) vs stored executed policy chunk: max|diff| arm {np.abs(chk[:, :, :6] - UE[:8, 0, :, :6]).max():.2e}")


# ======================================================================
# STEP 12: IS THE DIRECTION SET BY THE PROBE, OR BY THE HEAD JACOBIAN?
# ======================================================================
N_DIAG = 15                   # held-out states per fold
N_XI = 32                     # random coefficient vectors in signature space per state
OUT_D = f"{ROOT}/oft_dphi_diagnostic.npz"
eps = np.unique(EP)
folds = [(set(eps[::2].tolist()), set(eps[1::2].tolist())), (set(eps[1::2].tolist()), set(eps[::2].tolist()))]
sidx = [QOI_ALL.index(q) for q in STEER]
rng = np.random.default_rng(0)
cosf = lambda a, b: float(a @ b / (np.linalg.norm(a) * np.linalg.norm(b) + 1e-300))
REC = []

for fi, (A_eps, B_eps) in enumerate(folds):
    header(f"5.{fi + 1} FOLD {fi + 1}")
    inA = np.array([e in A_eps for e in EP])
    X32 = LAMS[inA].astype(np.float32)
    mu = X32.mean(0); Xc = X32 - mu
    ev, V = np.linalg.eigh((Xc @ Xc.T).astype(np.float64)); ix = np.argsort(ev)[::-1][:PCA_K]
    comps = ((Xc.T.astype(np.float64) @ V[:, ix]) / np.sqrt(ev[ix])).astype(np.float32)
    del X32, Xc
    Zall = np.concatenate([(LAMS[i:i + 64].astype(np.float32) - mu) @ comps for i in range(0, NS, 64)])
    zm, zs = Zall[inA].mean(0), Zall[inA].std(0) + 1e-12
    Zall = (Zall - zm) / zs
    to_lam = lambda dz: (comps @ (zs * dz)).astype(np.float32)
    cA = np.where(inA[CS])[0]; cB = np.where(~inA[CS])[0]
    vaE = set(rng.choice(sorted(A_eps), size=max(1, len(A_eps) // 8), replace=False).tolist())
    isva = np.array([EP[CS[j]] in vaE for j in cA])
    rows_of = lambda js: np.concatenate([np.arange(j * K, (j + 1) * K) for j in js])
    tgt = lambda js: (QF[js] - Q0[CS[js]][:, None, :]).reshape(-1, Q0.shape[1])
    def design(js):
        Z = np.repeat(Zall[CS[js]], K, 0); S = S_all[rows_of(js)]
        return np.c_[Z, S, (Z[:, :, None] * S[:, None, :]).reshape(len(Z), -1)]
    Wc, _ = ridge_fit(design(cA[~isva]), tgt(cA[~isva])[:, sidx], design(cA[isva]), tgt(cA[isva])[:, sidx])
    b_inc = Wc[PCA_K:PCA_K + ps].T
    W_inc = Wc[PCA_K + ps:].T.reshape(len(sidx), PCA_K, ps)
    stamp("linear probe fitted")

    # held-out states where at least one steered QoI responds to the chunk (as in the steering selection)
    dq = QF[cB][:, :, sidx] - Q0[CS[cB]][:, None, sidx]
    ok = (dq.std(1) > MOVE_MM).any(1)
    sel = rng.choice(cB[ok], size=min(N_DIAG, ok.sum()), replace=False)
    for j in sel:
        g = CS[j]
        lam0 = LAMS[g].astype(np.float32); z0 = Zall[g]
        sim_state, grip = SIMS[g], GRIPS[g].astype(np.float64)
        E = np.eye(PCA_K) * H_Z
        up = head_chunks(np.stack([lam0 + to_lam(e) for e in E])); um = head_chunks(np.stack([lam0 - to_lam(e) for e in E]))
        Dphi = ((st(up) - st(um)) / (2 * H_Z)).T                                       # (ps, 32)
        Dphi_u = ((rst(up) - rst(um)) / (2 * H_Z)).T                                   # (pr, 32)
        Pp = np.array([qoi(run_chunk(cenv, sim_state, grip, c)) for c in up])          # (32, 13): all QoIs at once
        Pm = np.array([qoi(run_chunk(cenv, sim_state, grip, c)) for c in um])
        G = ((Pp - Pm) / (2 * H_Z))[:, sidx].T                                          # oracle per QoI (q, 32)
        moving = np.linalg.norm(G, axis=1) > 1e-6
        sv = np.linalg.svd(Dphi, compute_uv=False); su = np.linalg.svd(Dphi_u, compute_uv=False)
        C = np.stack([b_inc[q] + W_inc[q].T @ z0 for q in range(len(sidx))])           # probe coefficients (q, ps)
        ours = C @ Dphi                                                                 # Dphi^T c per QoI (q, 32)
        rec = dict(state=int(g), fold=fi, sv=sv, su=su, moving=moving,
                   pr=float(sv.sum() ** 2 / (sv ** 2).sum()), top1=float(sv[0] ** 2 / (sv ** 2).sum()),
                   pr_u=float(su.sum() ** 2 / (su ** 2).sum()), top1_u=float(su[0] ** 2 / (su ** 2).sum()),
                   ours=[], wrong=[], xi_S=[], xi_u=[], xi_z=[], oracle_x=[])
        for q in np.where(moving)[0]:
            rec["ours"].append(cosf(ours[q], G[q]))
            rec["wrong"] += [cosf(ours[p], G[q]) for p in range(len(sidx)) if p != q]           # another QoI's probe
            rec["xi_S"] += [cosf(rng.normal(size=ps) @ Dphi, G[q]) for _ in range(N_XI)]       # random coeffs, via the head
            rec["xi_u"] += [cosf(rng.normal(size=pr) @ Dphi_u, G[q]) for _ in range(N_XI)]     # random chunk grads, via the head
            rec["xi_z"] += [cosf(rng.normal(size=PCA_K), G[q]) for _ in range(N_XI)]           # random in z (current control)
            rec["oracle_x"] += [cosf(G[p], G[q]) for p in np.where(moving)[0] if p != q]       # oracles of other QoIs
        REC.append(rec)
        print(f"  state {g:5d} | Dphi: top-1 energy {rec['top1']:.2f}, eff. rank {rec['pr']:.1f} | "
              f"cos to oracle: ours {np.median(rec['ours']):+.2f}, other-QoI probe |{np.median(np.abs(rec['wrong'])):.2f}|, "
              f"random-via-head |{np.median(np.abs(rec['xi_S'])):.2f}|, random z |{np.median(np.abs(rec['xi_z'])):.2f}| | "
              f"|cos| between QoI oracles {np.median(np.abs(rec['oracle_x'])):.2f}", flush=True)

header("6. SUMMARY")
cat = lambda k: np.concatenate([np.atleast_1d(r[k]) for r in REC if len(np.atleast_1d(r[k]))])
print(f"{len(REC)} held-out states")
print(f"head Jacobian D phi (signature space):   top-1 energy median {np.median(cat('top1')):.2f}, "
      f"effective rank median {np.median(cat('pr')):.1f} of {PCA_K}")
print(f"head Jacobian D phi_u (raw chunk space): top-1 energy median {np.median(cat('top1_u')):.2f}, "
      f"effective rank median {np.median(cat('pr_u')):.1f}")
sv_mean = np.mean([r["sv"] / r["sv"][0] for r in REC], 0)
print("mean normalized singular values of D phi:", " ".join(f"{v:.2f}" for v in sv_mean[:10]), "...")
print("\ncosine to the oracle (per QoI and state)           median |cos|   share cos > 0.9")
for k, lab in (("ours", "ours: D phi^T c_psi(z0)"), ("wrong", "probe of ANOTHER QoI through the head"),
               ("xi_S", "random signature coefficients through the head"),
               ("xi_u", "random raw-chunk gradient through the head"), ("xi_z", "random direction in z (current control)"),
               ("oracle_x", "oracle of another QoI")):
    v = cat(k)
    print(f"  {lab:50s} {np.median(np.abs(v)):.2f}          {np.mean(v > 0.9):.0%}")
np.savez(OUT_D, **{f"{k}": cat(k) for k in ("ours", "wrong", "xi_S", "xi_u", "xi_z", "oracle_x", "top1", "pr", "top1_u", "pr_u")},
         sv_mean=sv_mean)
print("""
READING
=======
random-via-head |cos| near 1, D phi top-1 energy near 1
    -> the head maps almost every lambda displacement onto one chunk change; the probe only sets the sign.
       The steering result then says little about the probe's direction, and the paper must say so.
random-via-head low, other-QoI probe low, ours near 1
    -> the head leaves room (several directions), and the probe picks the right one for each QoI:
       the cos = 1.00 of every probe in step 11 is real agreement, not an artefact of the head.
QoI oracles mutually aligned
    -> the QoIs themselves move together at these states; the comparison between QoIs is then weak too.
""")
stamp(f"saved {OUT_D}")

'''

with open("/content/run_oft_dphi_diag.py", "w") as f:
    f.write(SCRIPT)
LOG = "/content/drive/MyDrive/aclrh/oft_dphi_diagnostic_log.txt"
print(f"\nrunning steering in the Python 3.10 venv ... (log: {LOG})\n", flush=True)
rc = -1
try:
    with open(LOG, "a") as logf:
        p = subprocess.Popen([VPY, "-u", "/content/run_oft_dphi_diag.py"], stdout=subprocess.PIPE,
                             stderr=subprocess.STDOUT, text=True, bufsize=1,
                             env={**os.environ, "MUJOCO_GL": "egl", "MPLBACKEND": "Agg", "TF_CPP_MIN_LOG_LEVEL": "2",
                                  "PYTHONPATH": f"{OFT}:{LIB}:" + os.environ.get("PYTHONPATH", "")})
        for line in p.stdout:
            print(line, end="")
            logf.write(line); logf.flush()
        rc = p.wait()
        msg = f"\nReturn code: {rc}\n" + ("COMPLETE" if rc == 0 else "Stopped; rerun the cell to resume.") + "\n"
        print(msg); logf.write(msg)
finally:
    if AUTO_SHUTDOWN:
        print("shutting the runtime down (AUTO_SHUTDOWN) ...", flush=True)
        try:
            from google.colab import drive as _d
            _d.flush_and_unmount()
        except Exception as ex:
            print("  (flush:", ex, ")")
        from google.colab import runtime
        runtime.unassign()
