# ======================================================================
# OpenVLA-OFT — STEP 11: REDIRECTION, FULL EPISODES, v4  (ONE Colab cell, GPU: A100 or L4)
#   v4: phase 2 — once the yellow-and-white mug is placed and the policy stalls, steer towards the white mug
#   v5: phase 2 starts right after the placement with a retreat (EE straight up, psi = EE z), then the white mug
#
#   steer towards the pre-grasp pose of the yellow-and-white mug seen in the demonstrations (EE above the mug),
#   release there, then let the policy act on its own until
#   the task succeeds or the episode ends (520 steps). Does it complete the task in the REVERSED order?
#   12 held-out episodes x alpha in {0, 32, 40}; ~4-6 min per episode (L4), resumable (summary.json)
#   outputs (Drive, aclrh/redirect_full/): epXX_alphaYY.mp4, epXX_grid.mp4, summary.json, printed table
# ======================================================================
import os, subprocess, sys, textwrap, time

VENV = "/content/oftenv"
VPY = f"{VENV}/bin/python"
OFT = "/content/openvla-oft"
LIB = "/content/LIBERO"
MARK = f"{VENV}/.setup_done"


def sh(cmd, check=True):
    print(f"$ {cmd}", flush=True)
    r = subprocess.run(cmd, shell=True, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    tail = "\n".join(r.stdout.strip().splitlines()[-15:])
    if tail:
        print(tail, flush=True)
    if check and r.returncode != 0:
        raise RuntimeError(f"failed ({r.returncode}): {cmd}")
    return r.returncode


# ---------------------------------------------------------------- 0. Drive (checked before any model loading)
if not os.path.isdir("/content/drive/MyDrive"):
    from google.colab import drive
    drive.mount("/content/drive")
os.makedirs("/content/drive/MyDrive/aclrh", exist_ok=True)

# ---------------------------------------------------------------- 0b. GPU check
assert subprocess.run(["nvidia-smi"], stdout=subprocess.DEVNULL).returncode == 0, \
    "No GPU visible: switch the runtime to GPU (A100) and reconnect."

# ---------------------------------------------------------------- 1. setup (once)
if not os.path.exists(MARK):
    t0 = time.time()
    sh("pip install -q uv")
    sh("uv python install 3.10")
    sh(f"rm -rf {VENV}")                                # a half-built venv without the marker: start clean
    sh(f"uv venv {VENV} --python 3.10 --seed")
    UV = f"uv pip install --python {VPY}"
    sh(f"{UV} torch==2.2.0 torchvision==0.17.0 --index-url https://download.pytorch.org/whl/cu121")
    sh(f"{UV} numpy==1.26.4")
    if not os.path.exists(OFT):
        sh(f"git clone -q https://github.com/moojink/openvla-oft.git {OFT}")
    sh(f"{UV} -e {OFT}")                                   # pulls the transformers fork and pinned deps
    if not os.path.exists(LIB):
        sh(f"git clone -q https://github.com/Lifelong-Robot-Learning/LIBERO.git {LIB}")
    sh(f"{UV} -e {LIB}")
    sh(f"{UV} -r {OFT}/experiments/robot/libero/libero_requirements.txt")
    sh(f"{UV} numpy==1.26.4")                             # re-pin in case a dependency upgraded it
    # flash-attn: prebuilt wheel for torch 2.2 / py3.10; if it fails the verification falls back to sdpa
    rc = sh(f"{UV} https://github.com/Dao-AILab/flash-attention/releases/download/v2.5.5/"
            "flash_attn-2.5.5+cu122torch2.2cxx11abiFALSE-cp310-cp310-linux_x86_64.whl", check=False)
    print("flash-attn installed" if rc == 0 else "flash-attn NOT installed -> sdpa fallback")
    # LIBERO asks interactively for its data paths on first import: write the config up front
    os.makedirs(os.path.expanduser("~/.libero"), exist_ok=True)
    base = f"{LIB}/libero/libero"
    with open(os.path.expanduser("~/.libero/config.yaml"), "w") as f:
        f.write(textwrap.dedent(f"""\
            benchmark_root: {base}
            bddl_files: {base}/bddl_files
            init_states: {base}/init_files
            datasets: {LIB}/datasets
            assets: {base}/assets
            """))
    open(MARK, "w").write("ok")
    print(f"setup finished in {(time.time() - t0) / 60:.1f} min")
else:
    print("setup already done")

# ---------------------------------------------------------------- 1b. dependency fixes (idempotent)
# tensorflow_datasets is imported by openvla-oft at import time; a too-new tensorflow-metadata needs
# protobuf 5 (google.protobuf.runtime_version), which TF 2.15 cannot use -> pin the TF-2.15-era version
if sh(f"{VPY} -c \"import tensorflow_datasets\"", check=False) != 0:
    sh(f"uv pip install --python {VPY} tensorflow-metadata==1.14.0")
    sh(f"{VPY} -c \"import tensorflow_datasets, google.protobuf as p; print('tfds OK | protobuf', p.__version__)\"")

# robosuite 1.4 predates the MuJoCo >= 3.2 joint-type API (get_joint_qpos_addr assertion) -> pin 3.1.6
_mj = subprocess.run([VPY, "-c", "import mujoco; print(mujoco.__version__)"], text=True,
                     stdout=subprocess.PIPE, stderr=subprocess.DEVNULL).stdout.strip()
print("mujoco in venv:", _mj or "not installed")
if not _mj.startswith("3.1."):
    sh(f"uv pip install --python {VPY} mujoco==3.1.6")
os.makedirs(f"{LIB}/datasets", exist_ok=True)          # silences LIBERO's missing-datasets warning

sh(f"{VPY} -c \"import torch, transformers, numpy; print('torch', torch.__version__, 'cuda', "
   f"torch.cuda.is_available(), '| transformers', transformers.__version__, '| numpy', numpy.__version__)\"")

# ---------------------------------------------------------------- 2. verification script (runs in the venv)
SCRIPT = r'''
import os, sys, time, traceback
os.environ.setdefault("MUJOCO_GL", "egl")
os.environ.setdefault("PYOPENGL_PLATFORM", "egl")
os.environ["MPLBACKEND"] = "Agg"
sys.path.insert(0, "/content/openvla-oft")
sys.path.insert(0, "/content/LIBERO")          # LIBERO's setup.py is not exposed by uv editable installs
import numpy as np
import torch

CKPT = "moojink/openvla-7b-oft-finetuned-libero-10"
UNNORM = "libero_10_no_noops"
TASK_KEYWORDS = ("white mug", "left plate", "yellow and white mug", "right plate")
MAX_STEPS = 520
NUM_WAIT = 10

T0 = time.time()

def stamp(m):
    print(f"[{time.time() - T0:7.1f}s] {m}", flush=True)


def header(t):
    print("\n" + "=" * 90 + f"\n{t}\n" + "=" * 90, flush=True)

header("1. IMPORTS")
# wandb is only used for evaluation logging; the installed wandb needs a newer protobuf than
# TF 2.15 allows, so register a no-op stand-in instead of touching protobuf again
import types, importlib.machinery
_wb = types.ModuleType("wandb")
_wb.__spec__ = importlib.machinery.ModuleSpec("wandb", None)   # find_spec() (accelerate/transformers) needs a spec
_wb.__version__ = "0.0.0"
for _name in ("init", "log", "finish", "login", "config", "save", "watch"):
    setattr(_wb, _name, lambda *a, **k: None)
_wb.run = None
sys.modules["wandb"] = _wb
from experiments.robot.libero.run_libero_eval import GenerateConfig
import experiments.robot.libero.run_libero_eval as rle
import experiments.robot.openvla_utils as ou
import experiments.robot.libero.libero_utils as lu
import experiments.robot.robot_utils as ru
from libero.libero import benchmark
print("run_libero_eval exports:", [n for n in dir(rle) if not n.startswith("_")][:60])

try:
    import flash_attn  # noqa
    ATTN = "flash_attention_2"
except Exception:
    ATTN = "sdpa"
print("attention implementation:", ATTN)

header("2. LOAD OPENVLA-OFT (LIBERO-10)")
cfg = GenerateConfig(
    pretrained_checkpoint=CKPT, use_l1_regression=True, use_diffusion=False, use_film=False,
    num_images_in_input=2, use_proprio=True, load_in_8bit=False, load_in_4bit=False,
    center_crop=True, num_open_loop_steps=8, unnorm_key=UNNORM,
)
if hasattr(cfg, "task_suite_name"):
    cfg.task_suite_name = "libero_10"
if hasattr(cfg, "model_family"):
    cfg.model_family = "openvla"
t0 = time.time()
if ATTN != "flash_attention_2":
    # route the loader to sdpa if flash-attn is missing
    from transformers import AutoModelForVision2Seq
    _orig_fp = AutoModelForVision2Seq.from_pretrained
    def _fp(*a, **kw):
        kw["attn_implementation"] = "sdpa"
        return _orig_fp(*a, **kw)
    AutoModelForVision2Seq.from_pretrained = _fp
vla = ou.get_vla(cfg)
processor = ou.get_processor(cfg)
action_head = ou.get_action_head(cfg, llm_dim=vla.llm_dim)
proprio_projector = ou.get_proprio_projector(cfg, llm_dim=vla.llm_dim, proprio_dim=8)
print(f"loaded in {time.time() - t0:.0f}s | llm_dim {vla.llm_dim} | unnorm keys: {list(getattr(vla, 'norm_stats', {}).keys())[:8]}")

# ---- lambda hook: capture (and later intervene on) the input of the L1 action head ----
LAM = {"cap": None, "delta": None}
_orig_predict = action_head.predict_action
def _predict(actions_hidden_states, *a, **kw):
    LAM["cap"] = actions_hidden_states.detach().float().cpu()
    if LAM["delta"] is not None:
        actions_hidden_states = actions_hidden_states + LAM["delta"].to(actions_hidden_states.device,
                                                                          actions_hidden_states.dtype)
    return _orig_predict(actions_hidden_states, *a, **kw)
action_head.predict_action = _predict

def policy_chunk(obs, task_label):
    observation, _ = rle.prepare_observation(obs, ru.get_image_resize_size(cfg)) \
        if hasattr(rle, "prepare_observation") else (None, None)
    actions = ou.get_vla_action(cfg, vla, processor, observation, task_label, action_head, proprio_projector)
    return np.asarray(actions)


# constants used by the helpers shared with step 2 (perturb is not used for steering)
H = 8
N_KNOTS = 4
PERT_FRAC = 0.3
SEED = 0

header("3. TASK AND ENVIRONMENTS")
suite = benchmark.get_benchmark_dict()["libero_10"]()
tid = next(i for i in range(suite.n_tasks) if all(k in suite.get_task(i).language for k in TASK_KEYWORDS))
task = suite.get_task(tid)
init_states = suite.get_task_init_states(tid)
env, task_description = lu.get_libero_env(task, "openvla", resolution=256)
try:
    from libero.libero.envs import ControlEnv
except ImportError:
    from libero.libero.envs.env_wrapper import ControlEnv   # not re-exported in this LIBERO version
from libero.libero import get_libero_path
bddl = os.path.join(get_libero_path("bddl_files"), task.problem_folder, task.bddl_file)
cenv = ControlEnv(bddl_file_name=bddl, has_renderer=False, has_offscreen_renderer=False,
                  use_camera_obs=False, camera_heights=128, camera_widths=128)   # renderer-free twin
cenv.seed(0)
cenv.reset()
inner = env.env
print(f"task {tid}: {task_description} | init states {len(init_states)}")
print("objects:", list(inner.obj_body_id.keys()))

MUGS_PLATES = ["porcelain_mug_1", "white_yellow_mug_1", "plate_1", "plate_2"]
QOI_NAMES = ["ee_x", "ee_y", "ee_z"] + [f"{o}_{c}" for o in MUGS_PLATES for c in "xyz"]

def positions(e):
    s = e.env
    out = [np.array(s.sim.data.site_xpos[s.robots[0].eef_site_id])]
    out += [np.array(s.sim.data.body_xpos[s.obj_body_id[o]]) for o in MUGS_PLATES]
    return np.concatenate(out)

def grip_state(e):
    g = getattr(e.env.robots[0].gripper, "current_action", None)
    return None if g is None else np.array(g, dtype=np.float64).copy()

def restore(e, sim_state, grip):
    e.env.timestep, e.env.done = 0, False       # the twin env replays many chunks: never hit the horizon
    e.set_init_state(sim_state)
    if grip is not None and hasattr(e.env.robots[0].gripper, "current_action"):
        e.env.robots[0].gripper.current_action = grip.copy()

def run_chunk(e, sim_state, grip, actions):
    restore(e, sim_state, grip)
    for a in actions:
        e.step(np.asarray(a, dtype=np.float64).tolist())
    return positions(e)

# per-dimension scale for perturbations, from the checkpoint's action statistics (raw action space)
try:
    st_ = vla.norm_stats[UNNORM]["action"]
    half = (np.asarray(st_["q99"]) - np.asarray(st_["q01"])) / 2.0
except Exception as ex:
    print("[warn] norm stats unavailable, using 0.5:", repr(ex)); half = np.full(7, 0.5)
print("perturbation std per arm dim:", np.round(PERT_FRAC * half[:6], 4))
rng = np.random.default_rng(SEED)

def perturb(chunk, k):
    """k smooth perturbations of the raw policy chunk on the 6 arm dims; gripper unchanged"""
    tk = np.linspace(0, H - 1, N_KNOTS)
    out = np.repeat(chunk[None], k, 0).astype(np.float64)
    for i in range(k):
        knots = rng.normal(size=(N_KNOTS, 6)) * PERT_FRAC * half[:6]
        out[i, :, :6] += np.stack([np.interp(np.arange(H), tk, knots[:, j]) for j in range(6)], 1)
    return out

def executed(raw_chunk):
    return np.stack([np.asarray(rle.process_action(a.copy(), "openvla"), dtype=np.float64) for a in raw_chunk])


# ======================================================================
# STEP 4: STEERING  lambda_alpha = lambda(x) + alpha d(x), chunk = head(lambda_alpha)  (deterministic)
# ======================================================================
def sig_levels(U):
    """time-augmented signature, dX = (dt, u dt): returns S1, S<=2, S<=3."""
    U = np.asarray(U, dtype=np.float64)
    N, H, A = U.shape
    dt = 1.0 / H
    dx = np.concatenate([np.full((N, H, 1), dt), U * dt], axis=2)
    prev1 = np.cumsum(dx, axis=1) - dx
    inc2 = np.einsum("nti,ntj->ntij", prev1, dx) + 0.5 * np.einsum("nti,ntj->ntij", dx, dx)
    prev2 = np.cumsum(inc2, axis=1) - inc2
    S1 = dx.sum(axis=1)
    S2 = inc2.sum(axis=1)
    S3 = (np.einsum("ntij,ntk->nijk", prev2, dx, optimize=True)
          + 0.5 * np.einsum("nti,ntj,ntk->nijk", prev1, dx, dx, optimize=True)
          + np.einsum("nti,ntj,ntk->nijk", dx, dx, dx, optimize=True) / 6.0)
    M2 = np.concatenate([S1, S2.reshape(N, -1)], axis=1)
    return {"S1": S1, "S<=2": M2, "S<=3": np.concatenate([M2, S3.reshape(N, -1)], axis=1)}


DATA = "/content/drive/MyDrive/aclrh/oft_probe.npz"
OUT_ST = None

# ---- task QoIs derived from the 15 stored positions: ee(0:3) mug1(3:6) mug2(6:9) plate_1(9:12) plate_2(12:15)
def target_plates(Q0, EP, success_ep):
    """plate each mug ends on in successful episodes (last snapshot), by horizontal distance"""
    last = [np.where(EP == e)[0][-1] for e in np.unique(EP) if success_ep[int(e)]]
    P = Q0[last]
    out = []
    for m in (3, 6):
        d1 = np.linalg.norm(P[:, m:m + 2] - P[:, 9:11], axis=1)
        d2 = np.linalg.norm(P[:, m:m + 2] - P[:, 12:14], axis=1)
        out.append(9 if np.mean(d1 < d2) >= 0.5 else 12)
        print(f"  mug at cols {m}:{m + 3}: nearer to plate_1 in {np.mean(d1 < d2):.0%} of successful end states "
              f"-> target plate_{1 if out[-1] == 9 else 2}")
    return out

def make_qoi(t1, t2):
    def qoi(P):
        """P (..., 15) -> (..., 3): psi to INCREASE (negative distances)"""
        return np.stack([-np.linalg.norm(P[..., 3:5] - P[..., t1:t1 + 2], axis=-1),
                         -np.linalg.norm(P[..., 6:8] - P[..., t2:t2 + 2], axis=-1),
                         -np.linalg.norm(P[..., 0:3] - P[..., 3:6], axis=-1),
                         -np.linalg.norm(P[..., 0:3] - P[..., 6:9], axis=-1)], axis=-1)
    return qoi

QOI_LIST = ["-d(mug1,plate) xy", "-d(mug2,plate) xy", "-d(EE,mug1)", "-d(EE,mug2)"]
PCA_K = 32
N_PER_FOLD = 10               # steered states per QoI and fold (2 folds)
MOVE_MM, MIN_FRAC = 2e-3, 0.5
H_Z = 0.25                    # finite-difference step (standardized PCA units) for D phi and the simulator gradient
STEP_REL = 0.005              # ||delta lambda|| / ||lambda|| per unit tau, identical for all directions
TAUS = [-8.0, -4.0, -2.0, 0.0, 2.0, 4.0, 8.0]
N_RANDOM = 3
ALPHAS_R = np.logspace(-3, 4, 15)

def ranks(v):
    v = np.asarray(v, float)
    r = np.empty(len(v)); r[np.argsort(v, kind="mergesort")] = np.arange(len(v), dtype=float)
    for val in np.unique(v):                     # average ranks for ties
        m = v == val
        r[m] = r[m].mean()
    return r

def spearman(x, y):
    y = np.asarray(y, float)
    if np.ptp(y) < 1e-12:                         # a flat response is not monotone
        return 0.0
    return float(np.corrcoef(ranks(x), ranks(y))[0, 1])

def ridge_fit(Xtr, Ytr, Xva, Yva):
    """primal ridge with standardized columns; penalty per target chosen on validation rows; refit on all"""
    def fit(X, Y, a_):
        mx, sx, my = X.mean(0), X.std(0) + 1e-12, Y.mean(0)
        Xs = (X - mx) / sx
        G = Xs.T @ Xs
        W = np.linalg.solve(G + a_ * len(X) * np.eye(G.shape[0]), Xs.T @ (Y - my))
        return W / sx[:, None], my - (mx / sx) @ W
    best = []
    for j in range(Ytr.shape[1]):
        errs = []
        for a_ in ALPHAS_R:
            W, b = fit(Xtr, Ytr[:, j:j + 1], a_)
            errs.append(np.mean((Xva @ W + b - Yva[:, j:j + 1]) ** 2))
        best.append(ALPHAS_R[int(np.argmin(errs))])
    X, Y = np.r_[Xtr, Xva], np.r_[Ytr, Yva]
    Ws, bs = zip(*[fit(X, Y[:, j:j + 1], best[j]) for j in range(Y.shape[1])])
    return np.concatenate(Ws, 1), np.concatenate(bs)          # coef (p, q), intercept (q,)

header("4. DATA, SIGNATURES, HEAD")
dd = np.load(DATA)
LAMS = dd["LAM"]                                              # float16 (NS, 229376)
EP, CS = dd["EP"], dd["C_STATE"]
UE, URAW, SIMS, GRIPS = dd["U_EXEC"], dd["U_RAW"], dd["SIM"], dd["GRIP"]
print("target plates:")
qoi = make_qoi(*target_plates(dd["Q0"], EP, dd["SUCCESS_EP"]))
Q0, QF = qoi(dd["Q0"]), qoi(dd["QF"])                         # psi(x) (NS, 3), psi(F_u x) (NC, K, 3)
QOIS = {name: i for i, name in enumerate(QOI_LIST)}
NS, (NC, K, H_, A_) = len(EP), UE.shape
S_all = sig_levels(UE.reshape(NC * K, H_, A_).astype(np.float64))["S<=2"]
s_mu, s_sd = S_all.mean(0), S_all.std(0)
keep = s_sd > 1e-8 * s_sd.max()
st = lambda UU: (sig_levels(np.asarray(UU, np.float64).reshape(-1, H_, A_))["S<=2"][:, keep] - s_mu[keep]) / s_sd[keep]
S_all = (S_all[:, keep] - s_mu[keep]) / s_sd[keep]
ps = S_all.shape[1]
hp = next(action_head.parameters())
LSHAPE = (56, 4096)

def head_chunks(lams):
    """lams: (n, 229376) float32 -> executed chunks (n, 8, 7), exactly as in the rollouts"""
    with torch.no_grad():
        na = _orig_predict(torch.from_numpy(lams.reshape((-1,) + LSHAPE)).to(hp.device, hp.dtype))
    na = na.float().cpu().numpy().reshape(-1, H_, A_)
    ua = np.asarray(vla._unnormalize_actions(na, UNNORM)).reshape(-1, H_, A_)
    return np.stack([executed(c) for c in ua])

# check: head(stored lambda) reproduces the stored policy chunk (candidate 0)
chk = head_chunks(LAMS[CS[:8]].astype(np.float32))
print(f"head(stored lambda) vs stored executed policy chunk: max|diff| arm {np.abs(chk[:, :, :6] - UE[:8, 0, :, :6]).max():.2e}")



# ---- shared with step 9 ----
import pickle, math
to_lam = lambda dz: (comps @ (zs * dz)).astype(np.float32)          # latent displacement -> head input
z_of = lambda lam: ((lam.astype(np.float32) - mu) @ comps - zm) / zs


def fit_fold(fi):
    """PCA and probes on one half of the episodes (fold 0: even, as in step 8); returns the held-out episodes"""
    global mu, comps, zm, zs, Zall, a_inc, b_inc, W_inc, a_sta, inA
    eps = np.unique(EP)
    A_eps = set((eps[::2] if fi == 0 else eps[1::2]).tolist())
    inA = np.array([e in A_eps for e in EP])
    X32 = LAMS[inA].astype(np.float32)
    mu = X32.mean(0); Xc = X32 - mu
    ev, V = np.linalg.eigh((Xc @ Xc.T).astype(np.float64)); ix = np.argsort(ev)[::-1][:PCA_K]
    comps = ((Xc.T.astype(np.float64) @ V[:, ix]) / np.sqrt(ev[ix])).astype(np.float32)
    del X32, Xc
    Zr = np.concatenate([(LAMS[i:i + 64].astype(np.float32) - mu) @ comps for i in range(0, NS, 64)])
    zm, zs = Zr[inA].mean(0), Zr[inA].std(0) + 1e-12
    Zall = (Zr - zm) / zs
    rng_ = np.random.default_rng(0)
    cA = np.where(inA[CS])[0]
    vaE = set(rng_.choice(sorted(A_eps), size=max(1, len(A_eps) // 8), replace=False).tolist())
    isva = np.array([EP[CS[j]] in vaE for j in cA])
    qidx = list(QOIS.values())
    def design(js):
        Z = np.repeat(Zall[CS[js]], K, 0); S = S_all[np.concatenate([np.arange(j * K, (j + 1) * K) for j in js])]
        return np.c_[Z, S, (Z[:, :, None] * S[:, None, :]).reshape(len(Z), -1)]
    def target(js):
        return (QF[js][:, :, qidx] - Q0[CS[js]][:, None, qidx]).reshape(-1, len(qidx))
    Wc, _ = ridge_fit(design(cA[~isva]), target(cA[~isva]), design(cA[isva]), target(cA[isva]))
    a_inc, b_inc = Wc[:PCA_K].T, Wc[PCA_K:PCA_K + ps].T
    W_inc = Wc[PCA_K + ps:].T.reshape(len(qidx), PCA_K, ps)
    sA = np.where(inA)[0]; sva = np.array([EP[i] in vaE for i in sA])
    Ws, _ = ridge_fit(Zall[sA[~sva]], Q0[sA[~sva]][:, qidx], Zall[sA[sva]], Q0[sA[sva]][:, qidx])
    a_sta = Ws.T
    stamp(f"fold {fi + 1}: PCA and probes fitted on {len(A_eps)} episodes")
    return sorted(set(eps.tolist()) - A_eps)


def directions(q, lam0):
    """probe-derived latent directions at the current state, scaled to STEP_REL * ||lambda||"""
    z0 = z_of(lam0[None])[0]
    u0 = head_chunks(lam0[None])[0]
    E = np.eye(PCA_K) * H_Z
    up = head_chunks(np.stack([lam0 + to_lam(e) for e in E])); um = head_chunks(np.stack([lam0 - to_lam(e) for e in E]))
    Dphi = ((st(up) - st(um)) / (2 * H_Z)).T                          # (|S|, 32)
    lam_psi = b_inc[q] + W_inc[q].T @ z0                              # probe coefficient at the current state
    d = {"Dphi^T lambda_psi": Dphi.T @ lam_psi,
         "gamma_psi": a_inc[q] + W_inc[q] @ st(u0)[0],
         "static": a_sta[q].copy()}
    n = float(np.linalg.norm(lam0))
    return {k: v / (np.linalg.norm(zs * v) + 1e-300) * STEP_REL * n for k, v in d.items()}


resize9 = ru.get_image_resize_size(cfg)


def reset_to(start):
    """start = ("init", episode) or ("snap", state index) -> first observation"""
    env.env.timestep, env.env.done = 0, False
    env.reset()
    kind, idx = start
    if kind == "init":
        obs = env.set_init_state(init_states[idx])
        for _ in range(NUM_WAIT):
            obs, _, _, _ = env.step(lu.get_libero_dummy_action("openvla"))
    else:
        obs = env.set_init_state(SIMS[idx])
        g_ = GRIPS[idx]
        if g_ is not None and hasattr(env.env.robots[0].gripper, "current_action"):
            env.env.robots[0].gripper.current_action = np.asarray(g_, np.float64).copy()
    return obs




# ======================================================================
# STEP 11: REDIRECTION, FULL EPISODES — does the policy complete the task in the REVERSED order?
#   unsteered: white mug -> left plate, then yellow-and-white mug -> right plate.
#   steered: from the start of the episode, at every re-plan move the latent along the probe direction of
#   psi = -d(EE, mug2), recomputed at the current state, until |EE - mug2| < RELEASE_M (or MAX_STEER_CHUNKS);
#   then alpha = 0 and the policy acts on its own until success or MAX_STEPS.
#   events: first lift (raised and upright), placement on the target plate, task success, tipped mugs.
# ======================================================================
from PIL import Image, ImageDraw, ImageFont
import subprocess, json
try:
    import imageio_ffmpeg  # noqa: F401
except ImportError:
    subprocess.run([sys.executable, "-m", "pip", "install", "-q", "imageio", "imageio-ffmpeg"], check=False)
import imageio
OUT11 = "/content/drive/MyDrive/aclrh/redirect_full_v5"
os.makedirs(OUT11, exist_ok=True)
SUMMARY11 = f"{OUT11}/summary.json"
PSI_MODE = "pregrasp"                    # "pregrasp": approach the pose the demonstrations reach before grasping mug2
                                         # "mug": psi = -d(EE, mug2) (v1/v2)
PREGRASP_UP = 0.05                       # target this much above the demonstrations' pre-grasp offset
RELEASE_PRE = 0.05                       # pregrasp mode: release once |EE - pre-grasp point| < 5 cm
PSI11 = "-d(EE,pregrasp2)" if PSI_MODE == "pregrasp" else "-d(EE,mug2)"
PHASE2 = True                            # second steering phase towards the white mug once the yellow one is placed
WAIT2 = 0.0                              # ... right after that placement (v4: 2 s; the policy re-grasped the yellow mug)
RETREAT = True                           # v5: first steer the EE straight up (psi = EE z), away from the placed mug,
RETREAT_DZ = 0.15                        #     until it is 15 cm higher ...
RETREAT_MAX = 6                          #     or for at most 6 re-plans, then steer towards the white mug
PSI11_2 = "-d(EE,pregrasp1)" if PSI_MODE == "pregrasp" else "-d(EE,mug1)"
ALPHAS11 = [0.0, 32.0, 40.0]            # alpha = 16 moves the head input by 8% of its norm per re-plan
N_START = 12                             # held-out episodes of fold 1 (up to 25), from the initial layout
MAX_STEPS11 = 520                        # LIBERO-10 episode limit
RELEASE_M = 0.11                         # stop steering once |EE - mug2 body| < 11 cm
MAX_STEER_CHUNKS = 12                    # give up steering after 12 re-plans (4.8 s)
LIFT_M = 0.03                            # lifted: 3 cm above the initial height and upright
PLACE_XY, PLACE_Z = 0.06, 0.03           # placed: within 6 cm of its target plate (xy), resting (z), upright
UPRIGHT, TIPPED = 0.866, 0.5             # cos(tilt): < 30 deg upright, > 60 deg tipped
SAVE_VIDEO = True
FPS = 20
MUG = {"white": "porcelain_mug_1", "yellow": "white_yellow_mug_1", "red": "red_coffee_mug_1"}
COL = {"white": 3, "yellow": 6}                                      # index of the body position in positions()
TP = target_plates(dd["Q0"], EP, dd["SUCCESS_EP"])                  # target plate column of mug1, mug2
PLATE = {"white": int(TP[0]), "yellow": int(TP[1])}
BID = {k: env.env.obj_body_id[v] for k, v in MUG.items() if v in env.env.obj_body_id}
try:
    FONT = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 12)
except Exception:
    FONT = ImageFont.load_default()


def cos_tilt(k):
    return float(env.env.sim.data.body_xmat[BID[k]].reshape(3, 3)[2, 2])


def body_pos(k):
    return np.array(env.env.sim.data.body_xpos[BID[k]])


def is_success():
    for f in (getattr(env, "check_success", None), getattr(env.env, "_check_success", None)):
        if f is not None:
            try:
                return bool(f())
            except Exception:
                pass
    return False


def overlay(img, lines):
    im = Image.fromarray(np.ascontiguousarray(img)).convert("RGB")
    d = ImageDraw.Draw(im)
    d.rectangle([0, 0, im.width, 16 * len(lines) + 6], fill=(0, 0, 0))
    for i, s_ in enumerate(lines):
        d.text((5, 3 + 16 * i), s_, fill=(255, 255, 255), font=FONT)
    return np.asarray(im)


def near(p_, k):
    c = COL[k]
    if PSI_MODE == "pregrasp":
        return np.linalg.norm(p_[0:3] - (p_[c:c + 3] + PREK[k])) < RELEASE_PRE
    return np.linalg.norm(p_[0:3] - p_[c:c + 3]) < RELEASE_M


PHASE_NAME = {0: "unsteered", 1: "steering to yellow", 2: "released", 5: "retreat (EE up)", 3: "steering to white",
              4: "released"}


def full_rollout(start, alpha):
    obs = reset_to(start)
    z0 = {k: body_pos(k)[2] for k in COL}
    q1, q2, qz = QOIS[PSI11], QOIS[PSI11_2], QOIS["EE z"]
    ev = {"lift": {}, "place": {}, "tipped": {}, "release": None, "retreat": None, "steer2": None, "release2": None,
          "success": None}
    z_ret = None
    frames, step, n_steer = [], 0, 0
    stable = {k: 0 for k in COL}
    stage = 1 if alpha > 0 else 0        # 0 unsteered | 1 steer to yellow | 2 released | 3 steer to white | 4 released
    while step < MAX_STEPS11 and ev["success"] is None:
        raw = np.asarray(ou.get_vla_action(cfg, vla, processor, rle.prepare_observation(obs, resize9)[0],
                                           task_description, action_head, proprio_projector), dtype=np.float64)
        lam0 = LAM["cap"][0].numpy().reshape(-1).astype(np.float32)
        p_, t_now = positions(env), round(step * 0.05, 2)
        if stage == 1 and (near(p_, "yellow") or "yellow" in ev["lift"] or n_steer >= MAX_STEER_CHUNKS):
            stage, ev["release"] = 2, t_now
        if (stage == 2 and PHASE2 and "yellow" in ev["place"] and "white" not in ev["lift"]
                and t_now - ev["place"]["yellow"] >= WAIT2):
            if RETREAT:
                stage, n_steer, ev["retreat"], z_ret = 5, 0, t_now, p_[2]
            else:
                stage, n_steer, ev["steer2"] = 3, 0, t_now
        if stage == 5 and (p_[2] >= z_ret + RETREAT_DZ or n_steer >= RETREAT_MAX):
            stage, n_steer, ev["steer2"] = 3, 0, t_now
        if stage == 3 and (near(p_, "white") or "white" in ev["lift"] or n_steer >= MAX_STEER_CHUNKS):
            stage, ev["release2"] = 4, t_now
        if stage in (1, 3, 5):
            v = directions({1: q1, 3: q2, 5: qz}[stage], lam0)["Dphi^T lambda_psi"]
            chunk = head_chunks((lam0 + to_lam(alpha * v))[None])[0]
            n_steer += 1
        else:
            chunk = executed(raw)
        for a in chunk:
            obs, _, done, _ = env.step(np.asarray(a).tolist())
            step += 1
            t = round(step * 0.05, 2)
            for k in COL:
                pk, ck = body_pos(k), cos_tilt(k)
                if k not in ev["lift"] and pk[2] > z0[k] + LIFT_M and ck > UPRIGHT:
                    ev["lift"][k] = t
                pl = env.env.sim.data.body_xpos[env.env.obj_body_id[["plate_1", "plate_2"][(PLATE[k] - 9) // 3]]]
                ok_ = (k in ev["lift"] and np.linalg.norm(pk[:2] - np.array(pl[:2])) < PLACE_XY
                       and pk[2] < z0[k] + PLACE_Z and ck > UPRIGHT)
                stable[k] = stable[k] + 1 if ok_ else 0                # resting there for 0.5 s, not just passing
                if k not in ev["place"] and stable[k] >= 10:
                    ev["place"][k] = round(t - 0.45, 2)
            for k in BID:
                if k not in ev["tipped"] and cos_tilt(k) < TIPPED:
                    ev["tipped"][k] = t
            if is_success():                      # (done can also mean the time limit)
                ev["success"] = t
            if SAVE_VIDEO:
                phase = PHASE_NAME[stage]
                order = " > ".join(k for k, _ in sorted(ev["place"].items(), key=lambda kv: kv[1])) or "-"
                frames.append(overlay(lu.get_libero_image(obs), [
                    f"alpha = {alpha:+.0f} | {phase} | t = {t:4.1f} s",
                    f"placed: {order}" + (" | SUCCESS" if ev["success"] else ""),
                    ("tipped: " + ", ".join(ev["tipped"])) if ev["tipped"] else ""]))
            if ev["success"] is not None or step >= MAX_STEPS11:
                break
    order = [k for k, _ in sorted(ev["place"].items(), key=lambda kv: kv[1])]
    lift_order = [k for k, _ in sorted(ev["lift"].items(), key=lambda kv: kv[1])]
    return dict(frames=frames, events=ev, place_order=order, lift_order=lift_order, steps=step,
                reversed=bool(ev["success"] is not None and order[:1] == ["yellow"]),
                yellow_first=bool(lift_order[:1] == ["yellow"]))


header("11. REDIRECTION, FULL EPISODES")

# ---- pre-grasp offsets of both mugs, from the demonstrations (successful rollouts in the data) ----
def pregrasp_offset(c, name):
    """EE - mug at the last snapshot before the mug (columns c:c+3) is lifted, EE horizontally above it (median)"""
    Qr = dd["Q0"]; offs = []
    for e in np.unique(EP):
        if not dd["SUCCESS_EP"][int(e)]:
            continue
        idx = np.where(EP == e)[0]
        z0_ = Qr[idx[0], c + 2]
        lifted = [i for i in idx if Qr[i, c + 2] > z0_ + LIFT_M]
        if not lifted:
            continue
        before = [i for i in idx if i < lifted[0] and np.linalg.norm(Qr[i, 0:2] - Qr[i, c:c + 2]) < 0.05]
        if before:
            offs.append(Qr[before[-1], 0:3] - Qr[before[-1], c:c + 3])
    off = np.median(np.array(offs), 0) if offs else np.array([0.0, 0.0, 0.08])
    print(f"pre-grasp offset EE - {name} from {len(offs)} successful episodes: {np.round(100 * off, 1)} cm", flush=True)
    return off + np.array([0.0, 0.0, PREGRASP_UP])

PREK = {"yellow": pregrasp_offset(6, "yellow-and-white mug"), "white": pregrasp_offset(3, "white mug")}
_qoi_base = qoi
def qoi(P):
    P = np.asarray(P, np.float64)
    pre2 = -np.linalg.norm(P[..., 0:3] - (P[..., 6:9] + PREK["yellow"]), axis=-1)
    pre1 = -np.linalg.norm(P[..., 0:3] - (P[..., 3:6] + PREK["white"]), axis=-1)
    return np.concatenate([_qoi_base(P), pre2[..., None], pre1[..., None], P[..., 2:3]], axis=-1)
QOI_LIST = QOI_LIST + ["-d(EE,pregrasp2)", "-d(EE,pregrasp1)", "EE z"]
QOIS = {name: i for i, name in enumerate(QOI_LIST)}
Q0, QF = qoi(dd["Q0"]), qoi(dd["QF"])                 # probes are refitted with the new QoIs in fit_fold
print(f"steering QoIs: {PSI11} then {PSI11_2} | pre-grasp points: yellow + {np.round(100 * PREK['yellow'], 1)} cm, "
      f"white + {np.round(100 * PREK['white'], 1)} cm | phase 2: {PHASE2}", flush=True)
held = fit_fold(0)
starts = [("init", int(e)) for e in held[:N_START]]
summary = json.load(open(SUMMARY11)) if os.path.exists(SUMMARY11) else []
done_eps = {s_["episode"] for s_ in summary}
print("held-out starts:", [s[1] for s in starts], "| alphas", ALPHAS11,
      "| already done:", sorted(done_eps), flush=True)
for start in starts:
    if start[1] in done_eps:
        continue
    t_ = time.time()
    runs = {a: full_rollout(start, a) for a in ALPHAS11}
    for a, r in runs.items():
        e_ = r["events"]
        summary.append(dict(episode=start[1], alpha=a, success=e_["success"], place_order=r["place_order"],
                            lift_order=r["lift_order"], reversed=r["reversed"], yellow_first=r["yellow_first"],
                            release=e_["release"], retreat=e_["retreat"], steer2=e_["steer2"], release2=e_["release2"], lift=e_["lift"], place=e_["place"], tipped=e_["tipped"],
                            seconds=round(r["steps"] * 0.05, 1)))
        print(f"  episode {start[1]:2d} | alpha {a:+4.0f} | first lifted {(r['lift_order'] or ['-'])[0]:6s} "
              f"| placed {' > '.join(r['place_order']) or '-':15s} | success "
              f"{('%.1f s' % e_['success']) if e_['success'] else '  no  ':7s} | released "
              f"{('%.1f s' % e_['release']) if e_['release'] else '  -  ':6s} | phase 2 "
              f"{('up %.1f, white %.1f-%s s' % (e_['retreat'] or -1, e_['steer2'], e_['release2'])) if e_['steer2'] else '  -  ':24s} | tipped {', '.join(e_['tipped']) or '-'}"
              + ("   <== REVERSED ORDER" if r["reversed"] else ""), flush=True)
        if SAVE_VIDEO:
            imageio.mimsave(f"{OUT11}/ep{start[1]:02d}_alpha{int(a):02d}.mp4", r["frames"], fps=FPS, macro_block_size=1)
    if SAVE_VIDEO:
        T = max(len(r["frames"]) for r in runs.values())
        grid = [np.concatenate([r["frames"][min(t, len(r["frames"]) - 1)] for r in runs.values()], axis=1)
                for t in range(T)]
        imageio.mimsave(f"{OUT11}/ep{start[1]:02d}_grid.mp4", grid, fps=FPS, macro_block_size=1)
    json.dump(summary, open(SUMMARY11, "w"), indent=1)                 # per-episode checkpoint
    stamp(f"episode {start[1]} done in {time.time() - t_:.0f} s")

header("SUMMARY (held-out episodes, full episodes up to 26 s)")
for a in ALPHAS11:
    S_ = [s_ for s_ in summary if s_["alpha"] == a]
    n = len(S_)
    f_ = lambda c: f"{sum(c(s_) for s_ in S_):2d}/{n}"
    print(f"  alpha {a:+4.0f} | task success {f_(lambda s_: s_['success'] is not None)} "
          f"| yellow lifted first {f_(lambda s_: s_['yellow_first'])} "
          f"| yellow placed first {f_(lambda s_: s_['place_order'][:1] == ['yellow'])} "
          f"| success in reversed order {f_(lambda s_: s_['reversed'])} "
          f"| any mug tipped {f_(lambda s_: bool(s_['tipped']))}")
rev = sorted({s_["episode"] for s_ in summary if s_["reversed"]})
print("episodes completed in the reversed order:", rev, "-> videos epXX_grid.mp4 in", OUT11)
stamp("done")
'''

with open("/content/run_oft_redirect_full.py", "w") as f:
    f.write(SCRIPT)
print("\nrunning in the Python 3.10 venv ...\n", flush=True)
p = subprocess.Popen([VPY, "-u", "/content/run_oft_redirect_full.py"], stdout=subprocess.PIPE,
                     stderr=subprocess.STDOUT, text=True,
                     env={**os.environ, "MUJOCO_GL": "egl",
                          "MPLBACKEND": "Agg",          # Colab sets a notebook-only backend
                          "TF_CPP_MIN_LOG_LEVEL": "2",  # silence TensorFlow start-up noise
                          "PYTHONPATH": f"{OFT}:{LIB}:" + os.environ.get("PYTHONPATH", "")})
for line in p.stdout:
    print(line, end="")
p.wait()
print(f"\nReturn code: {p.returncode}")
