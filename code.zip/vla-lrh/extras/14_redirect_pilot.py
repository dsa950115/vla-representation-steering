# ======================================================================
# OpenVLA-OFT — STEP 10: REDIRECTION PILOT v2  (ONE Colab cell, GPU: A100 or L4, ~30-40 min)
#   v2: release at 11 cm (v1 never released), lift = raised AND upright, tipped-over mugs reported
#
#   question: steering along the probe direction of psi = -d(EE, yellow-and-white mug), recomputed at every
#   re-plan until the EE is near that mug, and then letting the policy act on its own: does the policy then
#   pick up the yellow-and-white mug FIRST (the task order is white mug first)?
#   6 held-out episodes x alpha in {0, 16, 24, 32}, up to 30 chunks (12 s); videos with overlays
#   outputs (Drive, aclrh/redirect_pilot/): epXX_alphaYY.mp4, epXX_grid.mp4 (all alphas side by side),
#   epXX_positions.npz, summary.json, printed table
# ======================================================================
import os, subprocess, sys, textwrap, time

VENV = "/content/oftenv"
VPY = f"{VENV}/bin/python"
OFT = "/content/openvla-oft"
LIB = "/content/LIBERO"
MARK = f"{VENV}/.setup_done"


def sh(cmd, check=True):
    print(f"$ {cmd}", flush=True)
    r = subprocess.run(cmd, shell=True, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    tail = "\n".join(r.stdout.strip().splitlines()[-15:])
    if tail:
        print(tail, flush=True)
    if check and r.returncode != 0:
        raise RuntimeError(f"failed ({r.returncode}): {cmd}")
    return r.returncode


# ---------------------------------------------------------------- 0. Drive (checked before any model loading)
if not os.path.isdir("/content/drive/MyDrive"):
    from google.colab import drive
    drive.mount("/content/drive")
os.makedirs("/content/drive/MyDrive/aclrh", exist_ok=True)

# ---------------------------------------------------------------- 0b. GPU check
assert subprocess.run(["nvidia-smi"], stdout=subprocess.DEVNULL).returncode == 0, \
    "No GPU visible: switch the runtime to GPU (A100) and reconnect."

# ---------------------------------------------------------------- 1. setup (once)
if not os.path.exists(MARK):
    t0 = time.time()
    sh("pip install -q uv")
    sh("uv python install 3.10")
    sh(f"rm -rf {VENV}")                                # a half-built venv without the marker: start clean
    sh(f"uv venv {VENV} --python 3.10 --seed")
    UV = f"uv pip install --python {VPY}"
    sh(f"{UV} torch==2.2.0 torchvision==0.17.0 --index-url https://download.pytorch.org/whl/cu121")
    sh(f"{UV} numpy==1.26.4")
    if not os.path.exists(OFT):
        sh(f"git clone -q https://github.com/moojink/openvla-oft.git {OFT}")
    sh(f"{UV} -e {OFT}")                                   # pulls the transformers fork and pinned deps
    if not os.path.exists(LIB):
        sh(f"git clone -q https://github.com/Lifelong-Robot-Learning/LIBERO.git {LIB}")
    sh(f"{UV} -e {LIB}")
    sh(f"{UV} -r {OFT}/experiments/robot/libero/libero_requirements.txt")
    sh(f"{UV} numpy==1.26.4")                             # re-pin in case a dependency upgraded it
    # flash-attn: prebuilt wheel for torch 2.2 / py3.10; if it fails the verification falls back to sdpa
    rc = sh(f"{UV} https://github.com/Dao-AILab/flash-attention/releases/download/v2.5.5/"
            "flash_attn-2.5.5+cu122torch2.2cxx11abiFALSE-cp310-cp310-linux_x86_64.whl", check=False)
    print("flash-attn installed" if rc == 0 else "flash-attn NOT installed -> sdpa fallback")
    # LIBERO asks interactively for its data paths on first import: write the config up front
    os.makedirs(os.path.expanduser("~/.libero"), exist_ok=True)
    base = f"{LIB}/libero/libero"
    with open(os.path.expanduser("~/.libero/config.yaml"), "w") as f:
        f.write(textwrap.dedent(f"""\
            benchmark_root: {base}
            bddl_files: {base}/bddl_files
            init_states: {base}/init_files
            datasets: {LIB}/datasets
            assets: {base}/assets
            """))
    open(MARK, "w").write("ok")
    print(f"setup finished in {(time.time() - t0) / 60:.1f} min")
else:
    print("setup already done")

# ---------------------------------------------------------------- 1b. dependency fixes (idempotent)
# tensorflow_datasets is imported by openvla-oft at import time; a too-new tensorflow-metadata needs
# protobuf 5 (google.protobuf.runtime_version), which TF 2.15 cannot use -> pin the TF-2.15-era version
if sh(f"{VPY} -c \"import tensorflow_datasets\"", check=False) != 0:
    sh(f"uv pip install --python {VPY} tensorflow-metadata==1.14.0")
    sh(f"{VPY} -c \"import tensorflow_datasets, google.protobuf as p; print('tfds OK | protobuf', p.__version__)\"")

# robosuite 1.4 predates the MuJoCo >= 3.2 joint-type API (get_joint_qpos_addr assertion) -> pin 3.1.6
_mj = subprocess.run([VPY, "-c", "import mujoco; print(mujoco.__version__)"], text=True,
                     stdout=subprocess.PIPE, stderr=subprocess.DEVNULL).stdout.strip()
print("mujoco in venv:", _mj or "not installed")
if not _mj.startswith("3.1."):
    sh(f"uv pip install --python {VPY} mujoco==3.1.6")
os.makedirs(f"{LIB}/datasets", exist_ok=True)          # silences LIBERO's missing-datasets warning

sh(f"{VPY} -c \"import torch, transformers, numpy; print('torch', torch.__version__, 'cuda', "
   f"torch.cuda.is_available(), '| transformers', transformers.__version__, '| numpy', numpy.__version__)\"")

# ---------------------------------------------------------------- 2. verification script (runs in the venv)
SCRIPT = r'''
import os, sys, time, traceback
os.environ.setdefault("MUJOCO_GL", "egl")
os.environ.setdefault("PYOPENGL_PLATFORM", "egl")
os.environ["MPLBACKEND"] = "Agg"
sys.path.insert(0, "/content/openvla-oft")
sys.path.insert(0, "/content/LIBERO")          # LIBERO's setup.py is not exposed by uv editable installs
import numpy as np
import torch

CKPT = "moojink/openvla-7b-oft-finetuned-libero-10"
UNNORM = "libero_10_no_noops"
TASK_KEYWORDS = ("white mug", "left plate", "yellow and white mug", "right plate")
MAX_STEPS = 520
NUM_WAIT = 10

T0 = time.time()

def stamp(m):
    print(f"[{time.time() - T0:7.1f}s] {m}", flush=True)


def header(t):
    print("\n" + "=" * 90 + f"\n{t}\n" + "=" * 90, flush=True)

header("1. IMPORTS")
# wandb is only used for evaluation logging; the installed wandb needs a newer protobuf than
# TF 2.15 allows, so register a no-op stand-in instead of touching protobuf again
import types, importlib.machinery
_wb = types.ModuleType("wandb")
_wb.__spec__ = importlib.machinery.ModuleSpec("wandb", None)   # find_spec() (accelerate/transformers) needs a spec
_wb.__version__ = "0.0.0"
for _name in ("init", "log", "finish", "login", "config", "save", "watch"):
    setattr(_wb, _name, lambda *a, **k: None)
_wb.run = None
sys.modules["wandb"] = _wb
from experiments.robot.libero.run_libero_eval import GenerateConfig
import experiments.robot.libero.run_libero_eval as rle
import experiments.robot.openvla_utils as ou
import experiments.robot.libero.libero_utils as lu
import experiments.robot.robot_utils as ru
from libero.libero import benchmark
print("run_libero_eval exports:", [n for n in dir(rle) if not n.startswith("_")][:60])

try:
    import flash_attn  # noqa
    ATTN = "flash_attention_2"
except Exception:
    ATTN = "sdpa"
print("attention implementation:", ATTN)

header("2. LOAD OPENVLA-OFT (LIBERO-10)")
cfg = GenerateConfig(
    pretrained_checkpoint=CKPT, use_l1_regression=True, use_diffusion=False, use_film=False,
    num_images_in_input=2, use_proprio=True, load_in_8bit=False, load_in_4bit=False,
    center_crop=True, num_open_loop_steps=8, unnorm_key=UNNORM,
)
if hasattr(cfg, "task_suite_name"):
    cfg.task_suite_name = "libero_10"
if hasattr(cfg, "model_family"):
    cfg.model_family = "openvla"
t0 = time.time()
if ATTN != "flash_attention_2":
    # route the loader to sdpa if flash-attn is missing
    from transformers import AutoModelForVision2Seq
    _orig_fp = AutoModelForVision2Seq.from_pretrained
    def _fp(*a, **kw):
        kw["attn_implementation"] = "sdpa"
        return _orig_fp(*a, **kw)
    AutoModelForVision2Seq.from_pretrained = _fp
vla = ou.get_vla(cfg)
processor = ou.get_processor(cfg)
action_head = ou.get_action_head(cfg, llm_dim=vla.llm_dim)
proprio_projector = ou.get_proprio_projector(cfg, llm_dim=vla.llm_dim, proprio_dim=8)
print(f"loaded in {time.time() - t0:.0f}s | llm_dim {vla.llm_dim} | unnorm keys: {list(getattr(vla, 'norm_stats', {}).keys())[:8]}")

# ---- lambda hook: capture (and later intervene on) the input of the L1 action head ----
LAM = {"cap": None, "delta": None}
_orig_predict = action_head.predict_action
def _predict(actions_hidden_states, *a, **kw):
    LAM["cap"] = actions_hidden_states.detach().float().cpu()
    if LAM["delta"] is not None:
        actions_hidden_states = actions_hidden_states + LAM["delta"].to(actions_hidden_states.device,
                                                                          actions_hidden_states.dtype)
    return _orig_predict(actions_hidden_states, *a, **kw)
action_head.predict_action = _predict

def policy_chunk(obs, task_label):
    observation, _ = rle.prepare_observation(obs, ru.get_image_resize_size(cfg)) \
        if hasattr(rle, "prepare_observation") else (None, None)
    actions = ou.get_vla_action(cfg, vla, processor, observation, task_label, action_head, proprio_projector)
    return np.asarray(actions)


# constants used by the helpers shared with step 2 (perturb is not used for steering)
H = 8
N_KNOTS = 4
PERT_FRAC = 0.3
SEED = 0

header("3. TASK AND ENVIRONMENTS")
suite = benchmark.get_benchmark_dict()["libero_10"]()
tid = next(i for i in range(suite.n_tasks) if all(k in suite.get_task(i).language for k in TASK_KEYWORDS))
task = suite.get_task(tid)
init_states = suite.get_task_init_states(tid)
env, task_description = lu.get_libero_env(task, "openvla", resolution=256)
try:
    from libero.libero.envs import ControlEnv
except ImportError:
    from libero.libero.envs.env_wrapper import ControlEnv   # not re-exported in this LIBERO version
from libero.libero import get_libero_path
bddl = os.path.join(get_libero_path("bddl_files"), task.problem_folder, task.bddl_file)
cenv = ControlEnv(bddl_file_name=bddl, has_renderer=False, has_offscreen_renderer=False,
                  use_camera_obs=False, camera_heights=128, camera_widths=128)   # renderer-free twin
cenv.seed(0)
cenv.reset()
inner = env.env
print(f"task {tid}: {task_description} | init states {len(init_states)}")
print("objects:", list(inner.obj_body_id.keys()))

MUGS_PLATES = ["porcelain_mug_1", "white_yellow_mug_1", "plate_1", "plate_2"]
QOI_NAMES = ["ee_x", "ee_y", "ee_z"] + [f"{o}_{c}" for o in MUGS_PLATES for c in "xyz"]

def positions(e):
    s = e.env
    out = [np.array(s.sim.data.site_xpos[s.robots[0].eef_site_id])]
    out += [np.array(s.sim.data.body_xpos[s.obj_body_id[o]]) for o in MUGS_PLATES]
    return np.concatenate(out)

def grip_state(e):
    g = getattr(e.env.robots[0].gripper, "current_action", None)
    return None if g is None else np.array(g, dtype=np.float64).copy()

def restore(e, sim_state, grip):
    e.env.timestep, e.env.done = 0, False       # the twin env replays many chunks: never hit the horizon
    e.set_init_state(sim_state)
    if grip is not None and hasattr(e.env.robots[0].gripper, "current_action"):
        e.env.robots[0].gripper.current_action = grip.copy()

def run_chunk(e, sim_state, grip, actions):
    restore(e, sim_state, grip)
    for a in actions:
        e.step(np.asarray(a, dtype=np.float64).tolist())
    return positions(e)

# per-dimension scale for perturbations, from the checkpoint's action statistics (raw action space)
try:
    st_ = vla.norm_stats[UNNORM]["action"]
    half = (np.asarray(st_["q99"]) - np.asarray(st_["q01"])) / 2.0
except Exception as ex:
    print("[warn] norm stats unavailable, using 0.5:", repr(ex)); half = np.full(7, 0.5)
print("perturbation std per arm dim:", np.round(PERT_FRAC * half[:6], 4))
rng = np.random.default_rng(SEED)

def perturb(chunk, k):
    """k smooth perturbations of the raw policy chunk on the 6 arm dims; gripper unchanged"""
    tk = np.linspace(0, H - 1, N_KNOTS)
    out = np.repeat(chunk[None], k, 0).astype(np.float64)
    for i in range(k):
        knots = rng.normal(size=(N_KNOTS, 6)) * PERT_FRAC * half[:6]
        out[i, :, :6] += np.stack([np.interp(np.arange(H), tk, knots[:, j]) for j in range(6)], 1)
    return out

def executed(raw_chunk):
    return np.stack([np.asarray(rle.process_action(a.copy(), "openvla"), dtype=np.float64) for a in raw_chunk])


# ======================================================================
# STEP 4: STEERING  lambda_alpha = lambda(x) + alpha d(x), chunk = head(lambda_alpha)  (deterministic)
# ======================================================================
def sig_levels(U):
    """time-augmented signature, dX = (dt, u dt): returns S1, S<=2, S<=3."""
    U = np.asarray(U, dtype=np.float64)
    N, H, A = U.shape
    dt = 1.0 / H
    dx = np.concatenate([np.full((N, H, 1), dt), U * dt], axis=2)
    prev1 = np.cumsum(dx, axis=1) - dx
    inc2 = np.einsum("nti,ntj->ntij", prev1, dx) + 0.5 * np.einsum("nti,ntj->ntij", dx, dx)
    prev2 = np.cumsum(inc2, axis=1) - inc2
    S1 = dx.sum(axis=1)
    S2 = inc2.sum(axis=1)
    S3 = (np.einsum("ntij,ntk->nijk", prev2, dx, optimize=True)
          + 0.5 * np.einsum("nti,ntj,ntk->nijk", prev1, dx, dx, optimize=True)
          + np.einsum("nti,ntj,ntk->nijk", dx, dx, dx, optimize=True) / 6.0)
    M2 = np.concatenate([S1, S2.reshape(N, -1)], axis=1)
    return {"S1": S1, "S<=2": M2, "S<=3": np.concatenate([M2, S3.reshape(N, -1)], axis=1)}


DATA = "/content/drive/MyDrive/aclrh/oft_probe.npz"
OUT_ST = None

# ---- task QoIs derived from the 15 stored positions: ee(0:3) mug1(3:6) mug2(6:9) plate_1(9:12) plate_2(12:15)
def target_plates(Q0, EP, success_ep):
    """plate each mug ends on in successful episodes (last snapshot), by horizontal distance"""
    last = [np.where(EP == e)[0][-1] for e in np.unique(EP) if success_ep[int(e)]]
    P = Q0[last]
    out = []
    for m in (3, 6):
        d1 = np.linalg.norm(P[:, m:m + 2] - P[:, 9:11], axis=1)
        d2 = np.linalg.norm(P[:, m:m + 2] - P[:, 12:14], axis=1)
        out.append(9 if np.mean(d1 < d2) >= 0.5 else 12)
        print(f"  mug at cols {m}:{m + 3}: nearer to plate_1 in {np.mean(d1 < d2):.0%} of successful end states "
              f"-> target plate_{1 if out[-1] == 9 else 2}")
    return out

def make_qoi(t1, t2):
    def qoi(P):
        """P (..., 15) -> (..., 3): psi to INCREASE (negative distances)"""
        return np.stack([-np.linalg.norm(P[..., 3:5] - P[..., t1:t1 + 2], axis=-1),
                         -np.linalg.norm(P[..., 6:8] - P[..., t2:t2 + 2], axis=-1),
                         -np.linalg.norm(P[..., 0:3] - P[..., 3:6], axis=-1),
                         -np.linalg.norm(P[..., 0:3] - P[..., 6:9], axis=-1)], axis=-1)
    return qoi

QOI_LIST = ["-d(mug1,plate) xy", "-d(mug2,plate) xy", "-d(EE,mug1)", "-d(EE,mug2)"]
PCA_K = 32
N_PER_FOLD = 10               # steered states per QoI and fold (2 folds)
MOVE_MM, MIN_FRAC = 2e-3, 0.5
H_Z = 0.25                    # finite-difference step (standardized PCA units) for D phi and the simulator gradient
STEP_REL = 0.005              # ||delta lambda|| / ||lambda|| per unit tau, identical for all directions
TAUS = [-8.0, -4.0, -2.0, 0.0, 2.0, 4.0, 8.0]
N_RANDOM = 3
ALPHAS_R = np.logspace(-3, 4, 15)

def ranks(v):
    v = np.asarray(v, float)
    r = np.empty(len(v)); r[np.argsort(v, kind="mergesort")] = np.arange(len(v), dtype=float)
    for val in np.unique(v):                     # average ranks for ties
        m = v == val
        r[m] = r[m].mean()
    return r

def spearman(x, y):
    y = np.asarray(y, float)
    if np.ptp(y) < 1e-12:                         # a flat response is not monotone
        return 0.0
    return float(np.corrcoef(ranks(x), ranks(y))[0, 1])

def ridge_fit(Xtr, Ytr, Xva, Yva):
    """primal ridge with standardized columns; penalty per target chosen on validation rows; refit on all"""
    def fit(X, Y, a_):
        mx, sx, my = X.mean(0), X.std(0) + 1e-12, Y.mean(0)
        Xs = (X - mx) / sx
        G = Xs.T @ Xs
        W = np.linalg.solve(G + a_ * len(X) * np.eye(G.shape[0]), Xs.T @ (Y - my))
        return W / sx[:, None], my - (mx / sx) @ W
    best = []
    for j in range(Ytr.shape[1]):
        errs = []
        for a_ in ALPHAS_R:
            W, b = fit(Xtr, Ytr[:, j:j + 1], a_)
            errs.append(np.mean((Xva @ W + b - Yva[:, j:j + 1]) ** 2))
        best.append(ALPHAS_R[int(np.argmin(errs))])
    X, Y = np.r_[Xtr, Xva], np.r_[Ytr, Yva]
    Ws, bs = zip(*[fit(X, Y[:, j:j + 1], best[j]) for j in range(Y.shape[1])])
    return np.concatenate(Ws, 1), np.concatenate(bs)          # coef (p, q), intercept (q,)

header("4. DATA, SIGNATURES, HEAD")
dd = np.load(DATA)
LAMS = dd["LAM"]                                              # float16 (NS, 229376)
EP, CS = dd["EP"], dd["C_STATE"]
UE, URAW, SIMS, GRIPS = dd["U_EXEC"], dd["U_RAW"], dd["SIM"], dd["GRIP"]
print("target plates:")
qoi = make_qoi(*target_plates(dd["Q0"], EP, dd["SUCCESS_EP"]))
Q0, QF = qoi(dd["Q0"]), qoi(dd["QF"])                         # psi(x) (NS, 3), psi(F_u x) (NC, K, 3)
QOIS = {name: i for i, name in enumerate(QOI_LIST)}
NS, (NC, K, H_, A_) = len(EP), UE.shape
S_all = sig_levels(UE.reshape(NC * K, H_, A_).astype(np.float64))["S<=2"]
s_mu, s_sd = S_all.mean(0), S_all.std(0)
keep = s_sd > 1e-8 * s_sd.max()
st = lambda UU: (sig_levels(np.asarray(UU, np.float64).reshape(-1, H_, A_))["S<=2"][:, keep] - s_mu[keep]) / s_sd[keep]
S_all = (S_all[:, keep] - s_mu[keep]) / s_sd[keep]
ps = S_all.shape[1]
hp = next(action_head.parameters())
LSHAPE = (56, 4096)

def head_chunks(lams):
    """lams: (n, 229376) float32 -> executed chunks (n, 8, 7), exactly as in the rollouts"""
    with torch.no_grad():
        na = _orig_predict(torch.from_numpy(lams.reshape((-1,) + LSHAPE)).to(hp.device, hp.dtype))
    na = na.float().cpu().numpy().reshape(-1, H_, A_)
    ua = np.asarray(vla._unnormalize_actions(na, UNNORM)).reshape(-1, H_, A_)
    return np.stack([executed(c) for c in ua])

# check: head(stored lambda) reproduces the stored policy chunk (candidate 0)
chk = head_chunks(LAMS[CS[:8]].astype(np.float32))
print(f"head(stored lambda) vs stored executed policy chunk: max|diff| arm {np.abs(chk[:, :, :6] - UE[:8, 0, :, :6]).max():.2e}")



# ---- constants shared with step 9 ----
import pickle, math
to_lam = lambda dz: (comps @ (zs * dz)).astype(np.float32)          # latent displacement -> head input
z_of = lambda lam: ((lam.astype(np.float32) - mu) @ comps - zm) / zs


def fit_fold(fi):
    """PCA and probes on one half of the episodes (fold 0: even, as in step 8); returns the held-out episodes"""
    global mu, comps, zm, zs, Zall, a_inc, b_inc, W_inc, a_sta, inA
    eps = np.unique(EP)
    A_eps = set((eps[::2] if fi == 0 else eps[1::2]).tolist())
    inA = np.array([e in A_eps for e in EP])
    X32 = LAMS[inA].astype(np.float32)
    mu = X32.mean(0); Xc = X32 - mu
    ev, V = np.linalg.eigh((Xc @ Xc.T).astype(np.float64)); ix = np.argsort(ev)[::-1][:PCA_K]
    comps = ((Xc.T.astype(np.float64) @ V[:, ix]) / np.sqrt(ev[ix])).astype(np.float32)
    del X32, Xc
    Zr = np.concatenate([(LAMS[i:i + 64].astype(np.float32) - mu) @ comps for i in range(0, NS, 64)])
    zm, zs = Zr[inA].mean(0), Zr[inA].std(0) + 1e-12
    Zall = (Zr - zm) / zs
    rng_ = np.random.default_rng(0)
    cA = np.where(inA[CS])[0]
    vaE = set(rng_.choice(sorted(A_eps), size=max(1, len(A_eps) // 8), replace=False).tolist())
    isva = np.array([EP[CS[j]] in vaE for j in cA])
    qidx = list(QOIS.values())
    def design(js):
        Z = np.repeat(Zall[CS[js]], K, 0); S = S_all[np.concatenate([np.arange(j * K, (j + 1) * K) for j in js])]
        return np.c_[Z, S, (Z[:, :, None] * S[:, None, :]).reshape(len(Z), -1)]
    def target(js):
        return (QF[js][:, :, qidx] - Q0[CS[js]][:, None, qidx]).reshape(-1, len(qidx))
    Wc, _ = ridge_fit(design(cA[~isva]), target(cA[~isva]), design(cA[isva]), target(cA[isva]))
    a_inc, b_inc = Wc[:PCA_K].T, Wc[PCA_K:PCA_K + ps].T
    W_inc = Wc[PCA_K + ps:].T.reshape(len(qidx), PCA_K, ps)
    sA = np.where(inA)[0]; sva = np.array([EP[i] in vaE for i in sA])
    Ws, _ = ridge_fit(Zall[sA[~sva]], Q0[sA[~sva]][:, qidx], Zall[sA[sva]], Q0[sA[sva]][:, qidx])
    a_sta = Ws.T
    stamp(f"fold {fi + 1}: PCA and probes fitted on {len(A_eps)} episodes")
    return sorted(set(eps.tolist()) - A_eps)


def directions(q, lam0):
    """probe-derived latent directions at the current state, scaled to STEP_REL * ||lambda||"""
    z0 = z_of(lam0[None])[0]
    u0 = head_chunks(lam0[None])[0]
    E = np.eye(PCA_K) * H_Z
    up = head_chunks(np.stack([lam0 + to_lam(e) for e in E])); um = head_chunks(np.stack([lam0 - to_lam(e) for e in E]))
    Dphi = ((st(up) - st(um)) / (2 * H_Z)).T                          # (|S|, 32)
    lam_psi = b_inc[q] + W_inc[q].T @ z0                              # probe coefficient at the current state
    d = {"Dphi^T lambda_psi": Dphi.T @ lam_psi,
         "gamma_psi": a_inc[q] + W_inc[q] @ st(u0)[0],
         "static": a_sta[q].copy()}
    n = float(np.linalg.norm(lam0))
    return {k: v / (np.linalg.norm(zs * v) + 1e-300) * STEP_REL * n for k, v in d.items()}


resize9 = ru.get_image_resize_size(cfg)


def reset_to(start):
    """start = ("init", episode) or ("snap", state index) -> first observation"""
    env.env.timestep, env.env.done = 0, False
    env.reset()
    kind, idx = start
    if kind == "init":
        obs = env.set_init_state(init_states[idx])
        for _ in range(NUM_WAIT):
            obs, _, _, _ = env.step(lu.get_libero_dummy_action("openvla"))
    else:
        obs = env.set_init_state(SIMS[idx])
        g_ = GRIPS[idx]
        if g_ is not None and hasattr(env.env.robots[0].gripper, "current_action"):
            env.env.robots[0].gripper.current_action = np.asarray(g_, np.float64).copy()
    return obs




# ======================================================================
# STEP 10: REDIRECTION PILOT — can steering make the policy grasp the yellow-and-white mug FIRST?
#   unsteered, the policy picks up the white mug first (task order).
#   steered: at every re-plan, move the latent along the probe direction of psi = -d(EE, mug2)
#   (recomputed at the current state) until the EE is within RELEASE_M of mug2, then alpha = 0:
#   from there the policy acts on its own. Outcome: which mug is lifted (> LIFT_M) first.
# ======================================================================
from PIL import Image, ImageDraw, ImageFont
import subprocess, json
try:
    import imageio_ffmpeg  # noqa: F401
except ImportError:
    subprocess.run([sys.executable, "-m", "pip", "install", "-q", "imageio", "imageio-ffmpeg"], check=False)
import imageio
OUT10 = "/content/drive/MyDrive/aclrh/redirect_pilot_v2"
os.makedirs(OUT10, exist_ok=True)
PSI10 = "-d(EE,mug2)"
ALPHAS10 = [0.0, 24.0, 32.0, 40.0]      # 8% of ||lambda|| per 16 units; all above the validated range, but only in transit
N_START = 8                              # held-out episodes (fold 1), from the initial layout
N_CHUNKS10 = 30                          # 30 x 8 steps = 12 s
RELEASE_M = 0.11                         # stop steering once |EE - mug2 body| < 11 cm (v1: grasps happen at ~9 cm)
LIFT_M = 0.03                            # a mug is "lifted" once 3 cm above its initial height AND upright
UPRIGHT, TIPPED = 0.866, 0.5             # cos(tilt): upright < 30 deg, tipped over > 60 deg
BID = {m: env.env.obj_body_id[m] for m in ("porcelain_mug_1", "white_yellow_mug_1")}

def cos_tilt(m):
    return float(env.env.sim.data.body_xmat[BID[m]].reshape(3, 3)[2, 2])
AFTER_LIFT_CHUNKS = 4                    # keep recording a little after the first lift
FPS = 20
try:
    FONT = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 13)
except Exception:
    FONT = ImageFont.load_default()


def overlay(img, lines):
    im = Image.fromarray(np.ascontiguousarray(img)).convert("RGB")
    d = ImageDraw.Draw(im)
    d.rectangle([0, 0, im.width, 18 * len(lines) + 6], fill=(0, 0, 0))
    for i, s_ in enumerate(lines):
        d.text((6, 4 + 18 * i), s_, fill=(255, 255, 255), font=FONT)
    return np.asarray(im)


def redirect_rollout(start, alpha):
    obs = reset_to(start)
    P0 = positions(env)
    z1, z2 = P0[5], P0[8]
    q = QOIS[PSI10]
    P, frames, steering, first, t_first, t_release, n_after = [P0], [], alpha > 0, None, None, None, 0
    tipped = []
    step = 0
    for c in range(N_CHUNKS10):
        raw = np.asarray(ou.get_vla_action(cfg, vla, processor, rle.prepare_observation(obs, resize9)[0],
                                           task_description, action_head, proprio_projector), dtype=np.float64)
        lam0 = LAM["cap"][0].numpy().reshape(-1).astype(np.float32)
        if steering and np.linalg.norm(P[-1][0:3] - P[-1][6:9]) < RELEASE_M:
            steering, t_release = False, step * 0.05
        if steering:
            v = directions(q, lam0)["Dphi^T lambda_psi"]
            chunk = head_chunks((lam0 + to_lam(alpha * v))[None])[0]
        else:
            chunk = executed(raw)
        for a in chunk:
            obs, _, _, _ = env.step(np.asarray(a).tolist())
            p_ = positions(env); P.append(p_); step += 1
            c1, c2 = cos_tilt("porcelain_mug_1"), cos_tilt("white_yellow_mug_1")
            if c1 < TIPPED and "white" not in tipped:
                tipped.append("white")
            if c2 < TIPPED and "yellow-and-white" not in tipped:
                tipped.append("yellow-and-white")
            if first is None:
                if p_[5] > z1 + LIFT_M and c1 > UPRIGHT:
                    first, t_first = "white", step * 0.05
                elif p_[8] > z2 + LIFT_M and c2 > UPRIGHT:
                    first, t_first = "yellow-and-white", step * 0.05
            d2 = np.linalg.norm(p_[0:3] - p_[6:9])
            phase = ("steering" if steering else ("released" if alpha > 0 else "unsteered"))
            frames.append(overlay(lu.get_libero_image(obs),
                                  [f"alpha = {alpha:+.0f} | {phase} | t = {step * 0.05:4.1f} s",
                                   f"|EE - yellow mug| = {100 * d2:4.1f} cm | first lifted: {first or '-'}"
                                   + (f" | tipped: {', '.join(tipped)}" if tipped else "")]))
        if first is not None:
            n_after += 1
            if n_after > AFTER_LIFT_CHUNKS:
                break
    P = np.stack(P)
    return dict(P=P, frames=frames, first=first, t_first=t_first, t_release=t_release, tipped=tipped,
                min_d2=float(np.min(np.linalg.norm(P[:, 0:3] - P[:, 6:9], axis=1))),
                min_d1=float(np.min(np.linalg.norm(P[:, 0:3] - P[:, 3:6], axis=1))))


header("10. REDIRECTION PILOT")
held = fit_fold(0)
starts = [("init", int(e)) for e in held[:N_START]]
print("held-out starts:", [s[1] for s in starts], "| alphas", ALPHAS10, flush=True)
summary = []
for start in starts:
    t_ = time.time()
    runs = {a: redirect_rollout(start, a) for a in ALPHAS10}
    for a, r in runs.items():
        tag = f"ep{start[1]:02d}_alpha{int(a):02d}"
        imageio.mimsave(f"{OUT10}/{tag}.mp4", r["frames"], fps=FPS, macro_block_size=1)
        summary.append(dict(episode=start[1], alpha=a, first=r["first"], t_first=r["t_first"], t_release=r["t_release"],
                            tipped=r["tipped"],
                            min_d_yellow_cm=100 * r["min_d2"], min_d_white_cm=100 * r["min_d1"]))
        print(f"  episode {start[1]:2d} | alpha {a:+4.0f} | first lifted: {str(r['first']):17s} "
              f"at {('%.1f s' % r['t_first']) if r['t_first'] else '  -  '} | steering released at "
              f"{('%.1f s' % r['t_release']) if r['t_release'] else '  -  '} | min |EE-yellow| {100 * r['min_d2']:4.1f} cm "
              f"| min |EE-white| {100 * r['min_d1']:4.1f} cm | tipped: {', '.join(r['tipped']) or '-'}", flush=True)
    # side-by-side video of all alphas (shorter runs hold their last frame)
    T = max(len(r["frames"]) for r in runs.values())
    grid = [np.concatenate([r["frames"][min(t, len(r["frames"]) - 1)] for r in runs.values()], axis=1) for t in range(T)]
    imageio.mimsave(f"{OUT10}/ep{start[1]:02d}_grid.mp4", grid, fps=FPS, macro_block_size=1)
    np.savez_compressed(f"{OUT10}/ep{start[1]:02d}_positions.npz", **{f"alpha{int(a)}": r["P"] for a, r in runs.items()})
    stamp(f"episode {start[1]} done in {time.time() - t_:.0f} s -> {OUT10}/ep{start[1]:02d}_grid.mp4")

header("SUMMARY: which mug is lifted first?")
for a in ALPHAS10:
    S_ = [s_ for s_ in summary if s_["alpha"] == a]
    nY = sum(s_["first"] == "yellow-and-white" for s_ in S_); nW = sum(s_["first"] == "white" for s_ in S_)
    print(f"  alpha {a:+4.0f}: yellow-and-white first {nY}/{len(S_)} | white first {nW}/{len(S_)} | none {len(S_) - nY - nW} "
          f"| any mug tipped over {sum(bool(s_['tipped']) for s_ in S_)}/{len(S_)} "
          f"| median min |EE-yellow| {np.median([s_['min_d_yellow_cm'] for s_ in S_]):4.1f} cm")
json.dump(summary, open(f"{OUT10}/summary.json", "w"), indent=1)
stamp(f"saved videos and summary in {OUT10}")
'''

with open("/content/run_oft_redirect_pilot.py", "w") as f:
    f.write(SCRIPT)
print("\nrunning in the Python 3.10 venv ...\n", flush=True)
p = subprocess.Popen([VPY, "-u", "/content/run_oft_redirect_pilot.py"], stdout=subprocess.PIPE,
                     stderr=subprocess.STDOUT, text=True,
                     env={**os.environ, "MUJOCO_GL": "egl",
                          "MPLBACKEND": "Agg",          # Colab sets a notebook-only backend
                          "TF_CPP_MIN_LOG_LEVEL": "2",  # silence TensorFlow start-up noise
                          "PYTHONPATH": f"{OFT}:{LIB}:" + os.environ.get("PYTHONPATH", "")})
for line in p.stdout:
    print(line, end="")
p.wait()
print(f"\nReturn code: {p.returncode}")
