# ======================================================================
# OpenVLA-OFT — do the one-chunk steering curves show contact jumps like SmolVLA's?  (ONE Colab cell, CPU, seconds)
#   reads aclrh/oft_steering.npz, oft_steering_taskqoi.npz, oft_steering_ee_mug2.npz (steps 04, 05b, 05c)
#   For every steered state, QoI and direction, the response J(tau), tau in {-8,-4,-2,0,2,4,8}, of one chunk.
#   A curve counts as a JUMP when one interval carries most of its total variation (JUMP_SHARE) and its slope is
#   JUMP_RATIO times the median slope of the other intervals; it is NON-MONOTONE when Spearman(tau, J) < 0.8.
#   OpenVLA-OFT is deterministic, so a jump means: the chunk crosses a point where the simulated outcome changes
#   abruptly (as at SmolVLA's contact events). With 7 points this is a screen, not a proof: the flagged states
#   can be checked in the simulator.
# ======================================================================
import os
import numpy as np
from scipy.stats import spearmanr

try:
    from google.colab import drive
    if not os.path.isdir("/content/drive/MyDrive"):
        drive.mount("/content/drive")
except ImportError:
    pass
ROOT = os.environ.get("ACLRH_ROOT", "/content/drive/MyDrive/aclrh")
FILES = [f"{ROOT}/oft_steering.npz", f"{ROOT}/oft_steering_taskqoi.npz", f"{ROOT}/oft_steering_ee_mug2.npz"]
JUMP_SHARE, JUMP_RATIO = 0.6, 5.0
DIR_NAME = {"sim-gradient": "oracle", "Dphi^T lambda_psi": "ours", "gamma_psi": "gamma", "static": "static"}

rows = []
for f in FILES:
    if not os.path.exists(f):
        print("[missing]", f); continue
    R = np.load(f, allow_pickle=True)
    taus = np.array(R["taus"], float); dt = np.diff(taus)
    for k in R.files:
        if not k.endswith("|J"):
            continue
        qn, dn, _ = k.split("|")
        if dn not in DIR_NAME:
            continue
        st = R[f"{qn}|state"] if f"{qn}|state" in R.files else np.arange(len(R[k]))
        for s, J in zip(st, R[k]):
            J = 1e3 * np.asarray(J, float)                       # mm
            dJ = np.diff(J); tv = np.abs(dJ).sum() + 1e-12
            slope = np.abs(dJ / dt); i = int(np.argmax(np.abs(dJ)))
            others = np.delete(slope, i)
            share = abs(dJ[i]) / tv
            ratio = slope[i] / (np.median(others) + 1e-9)
            rho = spearmanr(taus, J).correlation if np.ptp(J) > 1e-9 else 1.0
            rows.append(dict(qoi=qn, dir=DIR_NAME[dn], state=int(s), J=J, share=share, ratio=ratio,
                             jump=bool(share >= JUMP_SHARE and ratio >= JUMP_RATIO and abs(dJ[i]) > 1.0),
                             at=(taus[i], taus[i + 1]), size=float(dJ[i]), rho=float(rho), tv=float(tv)))

qois = sorted({r["qoi"] for r in rows}, key=lambda q: [r["qoi"] for r in rows].index(q))
print(f"{len(rows)} curves ({len({(r['qoi'], r['state']) for r in rows})} (QoI, state) pairs)\n")
print(f"{'QoI':20s} | {'direction':7s} | jump | non-monotone | jump AND non-monotone")
for q in qois:
    for dn in DIR_NAME.values():
        R_ = [r for r in rows if r["qoi"] == q and r["dir"] == dn]
        if not R_:
            continue
        nj = sum(r["jump"] for r in R_); nm = sum(r["rho"] < 0.8 for r in R_)
        both = sum(r["jump"] and r["rho"] < 0.8 for r in R_)
        print(f"{q:20s} | {dn:7s} | {nj:2d}/{len(R_):2d} |    {nm:2d}/{len(R_):2d}    |   {both:2d}")

states_any = sorted({(r["qoi"], r["state"]) for r in rows if r["jump"]})
print(f"\n(QoI, state) pairs with a jump in at least one direction: {len(states_any)} of "
      f"{len({(r['qoi'], r['state']) for r in rows})}")
print("\nflagged curves (mm at tau = " + ", ".join(f"{t:+.0f}" for t in taus) + "):")
for r in sorted([r for r in rows if r["jump"] or r["rho"] < 0.8], key=lambda r: (r["qoi"], r["state"], r["dir"])):
    tag = ("JUMP " if r["jump"] else "     ") + ("NON-MONO" if r["rho"] < 0.8 else "        ")
    print(f"  {tag} {r['qoi']:18s} state {r['state']:5d} {r['dir']:6s} | " + " ".join(f"{v:+7.1f}" for v in r["J"])
          + f" | step {r['size']:+.1f} mm between tau {r['at'][0]:+.0f} and {r['at'][1]:+.0f}")

# the non-monotone curves of our direction: jump or smooth?
ours_nm = [r for r in rows if r["dir"] == "ours" and r["rho"] < 0.8]
print(f"\nour direction, non-monotone curves: {len(ours_nm)}; of these with a jump: {sum(r['jump'] for r in ours_nm)}")
print("""
READING
=======
few jumps, concentrated at a few states -> OpenVLA-OFT meets the same contact boundaries, only rarely within one
    short chunk and small pushes; those states are where it would fail like SmolVLA
our non-monotone curves are jumps -> the few OpenVLA-OFT failures have the same cause as SmolVLA's
no jumps at all -> no steered state sat at a boundary within the pushed range
""")
