# ======================================================================
# OpenVLA-OFT — STEP 8: closed-loop direction comparison (videos + summary for the rebuttal)  (ONE Colab cell, A100)
#
#   1. builds a separate Python 3.10 venv (/content/oftenv) with torch 2.2 (cu121),
#      openvla-oft (+ its transformers fork) and LIBERO
#   2. runs a verification script inside that venv:
#        - loads moojink/openvla-7b-oft-finetuned-libero-10
#        - closed-loop rollouts on the mug task (success check)
#        - captures lambda = action-token hidden states entering the L1 action head
#        - checks that the head applied to the captured lambda reproduces the action chunk
#
#   Nothing is written to Drive in this step. Re-running the cell skips finished installs.
# ======================================================================
import os, subprocess, sys, textwrap, time

VENV = "/content/oftenv"
VPY = f"{VENV}/bin/python"
OFT = "/content/openvla-oft"
LIB = "/content/LIBERO"
MARK = f"{VENV}/.setup_done"


def sh(cmd, check=True):
    print(f"$ {cmd}", flush=True)
    r = subprocess.run(cmd, shell=True, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    tail = "\n".join(r.stdout.strip().splitlines()[-15:])
    if tail:
        print(tail, flush=True)
    if check and r.returncode != 0:
        raise RuntimeError(f"failed ({r.returncode}): {cmd}")
    return r.returncode


# ---------------------------------------------------------------- 0. Drive (checked before any model loading)
if not os.path.isdir("/content/drive/MyDrive"):
    from google.colab import drive
    drive.mount("/content/drive")
os.makedirs("/content/drive/MyDrive/aclrh", exist_ok=True)

# ---------------------------------------------------------------- 0b. GPU check
assert subprocess.run(["nvidia-smi"], stdout=subprocess.DEVNULL).returncode == 0, \
    "No GPU visible: switch the runtime to GPU (A100) and reconnect."

# ---------------------------------------------------------------- 1. setup (once)
if not os.path.exists(MARK):
    t0 = time.time()
    sh("pip install -q uv")
    sh("uv python install 3.10")
    sh(f"rm -rf {VENV}")                                # a half-built venv without the marker: start clean
    sh(f"uv venv {VENV} --python 3.10 --seed")
    UV = f"uv pip install --python {VPY}"
    sh(f"{UV} torch==2.2.0 torchvision==0.17.0 --index-url https://download.pytorch.org/whl/cu121")
    sh(f"{UV} numpy==1.26.4")
    if not os.path.exists(OFT):
        sh(f"git clone -q https://github.com/moojink/openvla-oft.git {OFT}")
    sh(f"{UV} -e {OFT}")                                   # pulls the transformers fork and pinned deps
    if not os.path.exists(LIB):
        sh(f"git clone -q https://github.com/Lifelong-Robot-Learning/LIBERO.git {LIB}")
    sh(f"{UV} -e {LIB}")
    sh(f"{UV} -r {OFT}/experiments/robot/libero/libero_requirements.txt")
    sh(f"{UV} numpy==1.26.4")                             # re-pin in case a dependency upgraded it
    # flash-attn: prebuilt wheel for torch 2.2 / py3.10; if it fails the verification falls back to sdpa
    rc = sh(f"{UV} https://github.com/Dao-AILab/flash-attention/releases/download/v2.5.5/"
            "flash_attn-2.5.5+cu122torch2.2cxx11abiFALSE-cp310-cp310-linux_x86_64.whl", check=False)
    print("flash-attn installed" if rc == 0 else "flash-attn NOT installed -> sdpa fallback")
    # LIBERO asks interactively for its data paths on first import: write the config up front
    os.makedirs(os.path.expanduser("~/.libero"), exist_ok=True)
    base = f"{LIB}/libero/libero"
    with open(os.path.expanduser("~/.libero/config.yaml"), "w") as f:
        f.write(textwrap.dedent(f"""\
            benchmark_root: {base}
            bddl_files: {base}/bddl_files
            init_states: {base}/init_files
            datasets: {LIB}/datasets
            assets: {base}/assets
            """))
    open(MARK, "w").write("ok")
    print(f"setup finished in {(time.time() - t0) / 60:.1f} min")
else:
    print("setup already done")

# ---------------------------------------------------------------- 1b. dependency fixes (idempotent)
# tensorflow_datasets is imported by openvla-oft at import time; a too-new tensorflow-metadata needs
# protobuf 5 (google.protobuf.runtime_version), which TF 2.15 cannot use -> pin the TF-2.15-era version
if sh(f"{VPY} -c \"import tensorflow_datasets\"", check=False) != 0:
    sh(f"uv pip install --python {VPY} tensorflow-metadata==1.14.0")
    sh(f"{VPY} -c \"import tensorflow_datasets, google.protobuf as p; print('tfds OK | protobuf', p.__version__)\"")

# robosuite 1.4 predates the MuJoCo >= 3.2 joint-type API (get_joint_qpos_addr assertion) -> pin 3.1.6
_mj = subprocess.run([VPY, "-c", "import mujoco; print(mujoco.__version__)"], text=True,
                     stdout=subprocess.PIPE, stderr=subprocess.DEVNULL).stdout.strip()
print("mujoco in venv:", _mj or "not installed")
if not _mj.startswith("3.1."):
    sh(f"uv pip install --python {VPY} mujoco==3.1.6")
os.makedirs(f"{LIB}/datasets", exist_ok=True)          # silences LIBERO's missing-datasets warning

sh(f"{VPY} -c \"import torch, transformers, numpy; print('torch', torch.__version__, 'cuda', "
   f"torch.cuda.is_available(), '| transformers', transformers.__version__, '| numpy', numpy.__version__)\"")

# ---------------------------------------------------------------- 2. verification script (runs in the venv)
SCRIPT = r'''
import os, sys, time, traceback
os.environ.setdefault("MUJOCO_GL", "egl")
os.environ.setdefault("PYOPENGL_PLATFORM", "egl")
os.environ["MPLBACKEND"] = "Agg"
sys.path.insert(0, "/content/openvla-oft")
sys.path.insert(0, "/content/LIBERO")          # LIBERO's setup.py is not exposed by uv editable installs
import numpy as np
import torch

CKPT = "moojink/openvla-7b-oft-finetuned-libero-10"
UNNORM = "libero_10_no_noops"
TASK_KEYWORDS = ("white mug", "left plate", "yellow and white mug", "right plate")
MAX_STEPS = 520
NUM_WAIT = 10

T0 = time.time()

def stamp(m):
    print(f"[{time.time() - T0:7.1f}s] {m}", flush=True)


def header(t):
    print("\n" + "=" * 90 + f"\n{t}\n" + "=" * 90, flush=True)

header("1. IMPORTS")
# wandb is only used for evaluation logging; the installed wandb needs a newer protobuf than
# TF 2.15 allows, so register a no-op stand-in instead of touching protobuf again
import types, importlib.machinery
_wb = types.ModuleType("wandb")
_wb.__spec__ = importlib.machinery.ModuleSpec("wandb", None)   # find_spec() (accelerate/transformers) needs a spec
_wb.__version__ = "0.0.0"
for _name in ("init", "log", "finish", "login", "config", "save", "watch"):
    setattr(_wb, _name, lambda *a, **k: None)
_wb.run = None
sys.modules["wandb"] = _wb
from experiments.robot.libero.run_libero_eval import GenerateConfig
import experiments.robot.libero.run_libero_eval as rle
import experiments.robot.openvla_utils as ou
import experiments.robot.libero.libero_utils as lu
import experiments.robot.robot_utils as ru
from libero.libero import benchmark
print("run_libero_eval exports:", [n for n in dir(rle) if not n.startswith("_")][:60])

try:
    import flash_attn  # noqa
    ATTN = "flash_attention_2"
except Exception:
    ATTN = "sdpa"
print("attention implementation:", ATTN)

header("2. LOAD OPENVLA-OFT (LIBERO-10)")
cfg = GenerateConfig(
    pretrained_checkpoint=CKPT, use_l1_regression=True, use_diffusion=False, use_film=False,
    num_images_in_input=2, use_proprio=True, load_in_8bit=False, load_in_4bit=False,
    center_crop=True, num_open_loop_steps=8, unnorm_key=UNNORM,
)
if hasattr(cfg, "task_suite_name"):
    cfg.task_suite_name = "libero_10"
if hasattr(cfg, "model_family"):
    cfg.model_family = "openvla"
t0 = time.time()
if ATTN != "flash_attention_2":
    # route the loader to sdpa if flash-attn is missing
    from transformers import AutoModelForVision2Seq
    _orig_fp = AutoModelForVision2Seq.from_pretrained
    def _fp(*a, **kw):
        kw["attn_implementation"] = "sdpa"
        return _orig_fp(*a, **kw)
    AutoModelForVision2Seq.from_pretrained = _fp
vla = ou.get_vla(cfg)
processor = ou.get_processor(cfg)
action_head = ou.get_action_head(cfg, llm_dim=vla.llm_dim)
proprio_projector = ou.get_proprio_projector(cfg, llm_dim=vla.llm_dim, proprio_dim=8)
print(f"loaded in {time.time() - t0:.0f}s | llm_dim {vla.llm_dim} | unnorm keys: {list(getattr(vla, 'norm_stats', {}).keys())[:8]}")

# ---- lambda hook: capture (and later intervene on) the input of the L1 action head ----
LAM = {"cap": None, "delta": None}
_orig_predict = action_head.predict_action
def _predict(actions_hidden_states, *a, **kw):
    LAM["cap"] = actions_hidden_states.detach().float().cpu()
    if LAM["delta"] is not None:
        actions_hidden_states = actions_hidden_states + LAM["delta"].to(actions_hidden_states.device,
                                                                          actions_hidden_states.dtype)
    return _orig_predict(actions_hidden_states, *a, **kw)
action_head.predict_action = _predict

def policy_chunk(obs, task_label):
    observation, _ = rle.prepare_observation(obs, ru.get_image_resize_size(cfg)) \
        if hasattr(rle, "prepare_observation") else (None, None)
    actions = ou.get_vla_action(cfg, vla, processor, observation, task_label, action_head, proprio_projector)
    return np.asarray(actions)


# constants used by the helpers shared with step 2 (perturb is not used for steering)
H = 8
N_KNOTS = 4
PERT_FRAC = 0.3
SEED = 0

header("3. TASK AND ENVIRONMENTS")
suite = benchmark.get_benchmark_dict()["libero_10"]()
tid = next(i for i in range(suite.n_tasks) if all(k in suite.get_task(i).language for k in TASK_KEYWORDS))
task = suite.get_task(tid)
init_states = suite.get_task_init_states(tid)
env, task_description = lu.get_libero_env(task, "openvla", resolution=256)
try:
    from libero.libero.envs import ControlEnv
except ImportError:
    from libero.libero.envs.env_wrapper import ControlEnv   # not re-exported in this LIBERO version
from libero.libero import get_libero_path
bddl = os.path.join(get_libero_path("bddl_files"), task.problem_folder, task.bddl_file)
cenv = ControlEnv(bddl_file_name=bddl, has_renderer=False, has_offscreen_renderer=False,
                  use_camera_obs=False, camera_heights=128, camera_widths=128)   # renderer-free twin
cenv.seed(0)
cenv.reset()
inner = env.env
print(f"task {tid}: {task_description} | init states {len(init_states)}")
print("objects:", list(inner.obj_body_id.keys()))

MUGS_PLATES = ["porcelain_mug_1", "white_yellow_mug_1", "plate_1", "plate_2"]
QOI_NAMES = ["ee_x", "ee_y", "ee_z"] + [f"{o}_{c}" for o in MUGS_PLATES for c in "xyz"]

def positions(e):
    s = e.env
    out = [np.array(s.sim.data.site_xpos[s.robots[0].eef_site_id])]
    out += [np.array(s.sim.data.body_xpos[s.obj_body_id[o]]) for o in MUGS_PLATES]
    return np.concatenate(out)

def grip_state(e):
    g = getattr(e.env.robots[0].gripper, "current_action", None)
    return None if g is None else np.array(g, dtype=np.float64).copy()

def restore(e, sim_state, grip):
    e.env.timestep, e.env.done = 0, False       # the twin env replays many chunks: never hit the horizon
    e.set_init_state(sim_state)
    if grip is not None and hasattr(e.env.robots[0].gripper, "current_action"):
        e.env.robots[0].gripper.current_action = grip.copy()

def run_chunk(e, sim_state, grip, actions):
    restore(e, sim_state, grip)
    for a in actions:
        e.step(np.asarray(a, dtype=np.float64).tolist())
    return positions(e)

# per-dimension scale for perturbations, from the checkpoint's action statistics (raw action space)
try:
    st_ = vla.norm_stats[UNNORM]["action"]
    half = (np.asarray(st_["q99"]) - np.asarray(st_["q01"])) / 2.0
except Exception as ex:
    print("[warn] norm stats unavailable, using 0.5:", repr(ex)); half = np.full(7, 0.5)
print("perturbation std per arm dim:", np.round(PERT_FRAC * half[:6], 4))
rng = np.random.default_rng(SEED)

def perturb(chunk, k):
    """k smooth perturbations of the raw policy chunk on the 6 arm dims; gripper unchanged"""
    tk = np.linspace(0, H - 1, N_KNOTS)
    out = np.repeat(chunk[None], k, 0).astype(np.float64)
    for i in range(k):
        knots = rng.normal(size=(N_KNOTS, 6)) * PERT_FRAC * half[:6]
        out[i, :, :6] += np.stack([np.interp(np.arange(H), tk, knots[:, j]) for j in range(6)], 1)
    return out

def executed(raw_chunk):
    return np.stack([np.asarray(rle.process_action(a.copy(), "openvla"), dtype=np.float64) for a in raw_chunk])


# ======================================================================
# STEP 4: STEERING  lambda_alpha = lambda(x) + alpha d(x), chunk = head(lambda_alpha)  (deterministic)
# ======================================================================
def sig_levels(U):
    """time-augmented signature, dX = (dt, u dt): returns S1, S<=2, S<=3."""
    U = np.asarray(U, dtype=np.float64)
    N, H, A = U.shape
    dt = 1.0 / H
    dx = np.concatenate([np.full((N, H, 1), dt), U * dt], axis=2)
    prev1 = np.cumsum(dx, axis=1) - dx
    inc2 = np.einsum("nti,ntj->ntij", prev1, dx) + 0.5 * np.einsum("nti,ntj->ntij", dx, dx)
    prev2 = np.cumsum(inc2, axis=1) - inc2
    S1 = dx.sum(axis=1)
    S2 = inc2.sum(axis=1)
    S3 = (np.einsum("ntij,ntk->nijk", prev2, dx, optimize=True)
          + 0.5 * np.einsum("nti,ntj,ntk->nijk", prev1, dx, dx, optimize=True)
          + np.einsum("nti,ntj,ntk->nijk", dx, dx, dx, optimize=True) / 6.0)
    M2 = np.concatenate([S1, S2.reshape(N, -1)], axis=1)
    return {"S1": S1, "S<=2": M2, "S<=3": np.concatenate([M2, S3.reshape(N, -1)], axis=1)}


DATA = "/content/drive/MyDrive/aclrh/oft_probe.npz"
OUT_ST = None

# ---- task QoIs derived from the 15 stored positions: ee(0:3) mug1(3:6) mug2(6:9) plate_1(9:12) plate_2(12:15)
def target_plates(Q0, EP, success_ep):
    """plate each mug ends on in successful episodes (last snapshot), by horizontal distance"""
    last = [np.where(EP == e)[0][-1] for e in np.unique(EP) if success_ep[int(e)]]
    P = Q0[last]
    out = []
    for m in (3, 6):
        d1 = np.linalg.norm(P[:, m:m + 2] - P[:, 9:11], axis=1)
        d2 = np.linalg.norm(P[:, m:m + 2] - P[:, 12:14], axis=1)
        out.append(9 if np.mean(d1 < d2) >= 0.5 else 12)
        print(f"  mug at cols {m}:{m + 3}: nearer to plate_1 in {np.mean(d1 < d2):.0%} of successful end states "
              f"-> target plate_{1 if out[-1] == 9 else 2}")
    return out

def make_qoi(t1, t2):
    def qoi(P):
        """P (..., 15) -> (..., 3): psi to INCREASE (negative distances)"""
        return np.stack([-np.linalg.norm(P[..., 3:5] - P[..., t1:t1 + 2], axis=-1),
                         -np.linalg.norm(P[..., 6:8] - P[..., t2:t2 + 2], axis=-1),
                         -np.linalg.norm(P[..., 0:3] - P[..., 3:6], axis=-1),
                         -np.linalg.norm(P[..., 0:3] - P[..., 6:9], axis=-1)], axis=-1)
    return qoi

QOI_LIST = ["-d(mug1,plate) xy", "-d(mug2,plate) xy", "-d(EE,mug1)", "-d(EE,mug2)"]
PCA_K = 32
N_PER_FOLD = 10               # steered states per QoI and fold (2 folds)
MOVE_MM, MIN_FRAC = 2e-3, 0.5
H_Z = 0.25                    # finite-difference step (standardized PCA units) for D phi and the simulator gradient
STEP_REL = 0.005              # ||delta lambda|| / ||lambda|| per unit tau, identical for all directions
TAUS = [-8.0, -4.0, -2.0, 0.0, 2.0, 4.0, 8.0]
N_RANDOM = 3
ALPHAS_R = np.logspace(-3, 4, 15)

def ranks(v):
    v = np.asarray(v, float)
    r = np.empty(len(v)); r[np.argsort(v, kind="mergesort")] = np.arange(len(v), dtype=float)
    for val in np.unique(v):                     # average ranks for ties
        m = v == val
        r[m] = r[m].mean()
    return r

def spearman(x, y):
    y = np.asarray(y, float)
    if np.ptp(y) < 1e-12:                         # a flat response is not monotone
        return 0.0
    return float(np.corrcoef(ranks(x), ranks(y))[0, 1])

def ridge_fit(Xtr, Ytr, Xva, Yva):
    """primal ridge with standardized columns; penalty per target chosen on validation rows; refit on all"""
    def fit(X, Y, a_):
        mx, sx, my = X.mean(0), X.std(0) + 1e-12, Y.mean(0)
        Xs = (X - mx) / sx
        G = Xs.T @ Xs
        W = np.linalg.solve(G + a_ * len(X) * np.eye(G.shape[0]), Xs.T @ (Y - my))
        return W / sx[:, None], my - (mx / sx) @ W
    best = []
    for j in range(Ytr.shape[1]):
        errs = []
        for a_ in ALPHAS_R:
            W, b = fit(Xtr, Ytr[:, j:j + 1], a_)
            errs.append(np.mean((Xva @ W + b - Yva[:, j:j + 1]) ** 2))
        best.append(ALPHAS_R[int(np.argmin(errs))])
    X, Y = np.r_[Xtr, Xva], np.r_[Ytr, Yva]
    Ws, bs = zip(*[fit(X, Y[:, j:j + 1], best[j]) for j in range(Y.shape[1])])
    return np.concatenate(Ws, 1), np.concatenate(bs)          # coef (p, q), intercept (q,)

header("4. DATA, SIGNATURES, HEAD")
dd = np.load(DATA)
LAMS = dd["LAM"]                                              # float16 (NS, 229376)
EP, CS = dd["EP"], dd["C_STATE"]
UE, URAW, SIMS, GRIPS = dd["U_EXEC"], dd["U_RAW"], dd["SIM"], dd["GRIP"]
print("target plates:")
qoi = make_qoi(*target_plates(dd["Q0"], EP, dd["SUCCESS_EP"]))
Q0, QF = qoi(dd["Q0"]), qoi(dd["QF"])                         # psi(x) (NS, 3), psi(F_u x) (NC, K, 3)
QOIS = {name: i for i, name in enumerate(QOI_LIST)}
NS, (NC, K, H_, A_) = len(EP), UE.shape
S_all = sig_levels(UE.reshape(NC * K, H_, A_).astype(np.float64))["S<=2"]
s_mu, s_sd = S_all.mean(0), S_all.std(0)
keep = s_sd > 1e-8 * s_sd.max()
st = lambda UU: (sig_levels(np.asarray(UU, np.float64).reshape(-1, H_, A_))["S<=2"][:, keep] - s_mu[keep]) / s_sd[keep]
S_all = (S_all[:, keep] - s_mu[keep]) / s_sd[keep]
ps = S_all.shape[1]
hp = next(action_head.parameters())
LSHAPE = (56, 4096)

def head_chunks(lams):
    """lams: (n, 229376) float32 -> executed chunks (n, 8, 7), exactly as in the rollouts"""
    with torch.no_grad():
        na = _orig_predict(torch.from_numpy(lams.reshape((-1,) + LSHAPE)).to(hp.device, hp.dtype))
    na = na.float().cpu().numpy().reshape(-1, H_, A_)
    ua = np.asarray(vla._unnormalize_actions(na, UNNORM)).reshape(-1, H_, A_)
    return np.stack([executed(c) for c in ua])

# check: head(stored lambda) reproduces the stored policy chunk (candidate 0)
chk = head_chunks(LAMS[CS[:8]].astype(np.float32))
print(f"head(stored lambda) vs stored executed policy chunk: max|diff| arm {np.abs(chk[:, :, :6] - UE[:8, 0, :, :6]).max():.2e}")


# ======================================================================
# STEP 6: FIGURES  (A) one-chunk steering paths   (B) closed-loop steering towards a concept
# ======================================================================
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import imageio
FIG = "/content/drive/MyDrive/aclrh/figs"
os.makedirs(FIG, exist_ok=True)
RUN_A, RUN_SUMMARY, RUN_B = True, True, True   # one-chunk paths / summary curves / closed-loop figures
N_A = 3                               # states for panel A
A_QOI = "-d(EE,mug1)"
CL_EPISODES = 2                       # held-out episodes for panel B
CL_CONCEPTS = ["-d(EE,mug1)", "-d(EE,mug2)"]
CL_ALPHAS = [-16.0, -8.0, 0.0, 8.0, 16.0]
CL_CHUNKS = 6                         # 6 chunks = 48 control steps = 2.4 s

# ---------------- fold: fit on even episodes, show held-out odd episodes ----------------
eps = np.unique(EP)
A_eps, B_eps = set(eps[::2].tolist()), set(eps[1::2].tolist())
inA = np.array([e in A_eps for e in EP])
X32 = LAMS[inA].astype(np.float32)
mu = X32.mean(0); Xc = X32 - mu
ev, V = np.linalg.eigh((Xc @ Xc.T).astype(np.float64)); ix = np.argsort(ev)[::-1][:PCA_K]
comps = ((Xc.T.astype(np.float64) @ V[:, ix]) / np.sqrt(ev[ix])).astype(np.float32)
del X32, Xc
Zall = np.concatenate([(LAMS[i:i + 64].astype(np.float32) - mu) @ comps for i in range(0, NS, 64)])
zm, zs = Zall[inA].mean(0), Zall[inA].std(0) + 1e-12
Zall = (Zall - zm) / zs
to_lam = lambda dz: (comps @ (zs * dz)).astype(np.float32)          # latent displacement -> backbone
z_of = lambda lam: ((lam.astype(np.float32) - mu) @ comps - zm) / zs
rng = np.random.default_rng(0)
cA = np.where(inA[CS])[0]
vaE = set(rng.choice(sorted(A_eps), size=max(1, len(A_eps) // 8), replace=False).tolist())
isva = np.array([EP[CS[j]] in vaE for j in cA])
qidx = list(QOIS.values())
def design(js):
    Z = np.repeat(Zall[CS[js]], K, 0); S = S_all[np.concatenate([np.arange(j * K, (j + 1) * K) for j in js])]
    return np.c_[Z, S, (Z[:, :, None] * S[:, None, :]).reshape(len(Z), -1)]
def target(js):
    return (QF[js][:, :, qidx] - Q0[CS[js]][:, None, qidx]).reshape(-1, len(qidx))
Wc, bc = ridge_fit(design(cA[~isva]), target(cA[~isva]), design(cA[isva]), target(cA[isva]))
a_inc, b_inc = Wc[:PCA_K].T, Wc[PCA_K:PCA_K + ps].T
W_inc = Wc[PCA_K + ps:].T.reshape(len(qidx), PCA_K, ps)
sA = np.where(inA)[0]; sva = np.array([EP[i] in vaE for i in sA])
Ws, _ = ridge_fit(Zall[sA[~sva]], Q0[sA[~sva]][:, qidx], Zall[sA[sva]], Q0[sA[sva]][:, qidx])
a_sta = Ws.T
stamp("PCA and probes fitted on the even episodes")

def directions(q, lam0):
    """probe-derived latent directions at the current state, scaled to STEP_REL * ||lambda_bar||"""
    z0 = z_of(lam0[None])[0]
    u0 = head_chunks(lam0[None])[0]
    E = np.eye(PCA_K) * H_Z
    up = head_chunks(np.stack([lam0 + to_lam(e) for e in E])); um = head_chunks(np.stack([lam0 - to_lam(e) for e in E]))
    Dphi = ((st(up) - st(um)) / (2 * H_Z)).T                          # (|S|, 32)
    lam_psi = b_inc[q] + W_inc[q].T @ z0                              # lambda_psi(x), non-empty words
    d = {"Dphi^T lambda_psi": Dphi.T @ lam_psi,
         "gamma_psi": a_inc[q] + W_inc[q] @ st(u0)[0],
         "static": a_sta[q].copy()}
    n = float(np.linalg.norm(lam0))
    return {k: v / (np.linalg.norm(zs * v) + 1e-300) * STEP_REL * n for k, v in d.items()}

def ee(e):
    s_ = e.env; return np.array(s_.sim.data.site_xpos[s_.robots[0].eef_site_id])

def run_chunk_path(e, sim_state, grip, actions):
    restore(e, sim_state, grip)
    path = [ee(e)]
    for a in actions:
        e.step(np.asarray(a, dtype=np.float64).tolist()); path.append(ee(e))
    return np.array(path), positions(e)

# ---------------- camera projection (robosuite) + orientation check ----------------
from robosuite.utils.camera_utils import get_camera_transform_matrix, project_points_from_world_to_camera
IMG = 256
PROJ_MODE = "mirror_cols" # verified with A_projection_check.png (markers on EE and both mugs)
PROJ_MAPS = {"rot180": lambda r, c: (IMG - 1 - r, IMG - 1 - c),
             "mirror_cols": lambda r, c: (r, IMG - 1 - c),
             "none": lambda r, c: (r, c)}
def scene_and_projector(sim_state, grip, mode=None):
    env.env.timestep, env.env.done = 0, False
    obs = env.set_init_state(sim_state)
    img = lu.get_libero_image(obs)                                   # image as fed to the policy (rotated)
    Mcam = get_camera_transform_matrix(env.env.sim, "agentview", IMG, IMG)
    fmap = PROJ_MAPS[mode or PROJ_MODE]
    def proj(P):
        rc = project_points_from_world_to_camera(np.asarray(P, float).reshape(-1, 3), Mcam, IMG, IMG)
        r_, c_ = fmap(rc[:, 0], rc[:, 1])
        return np.stack([r_, c_], 1)
    return img, proj

def projection_check(sim_state, grip, P0):
    fig, axes = plt.subplots(1, len(PROJ_MAPS), figsize=(4 * len(PROJ_MAPS), 4))
    for ax, mode in zip(axes, PROJ_MAPS):
        img, proj = scene_and_projector(sim_state, grip, mode)
        ax.imshow(img); ax.set_axis_off(); ax.set_title(mode + (" (in use)" if mode == PROJ_MODE else ""))
        for pp, mk, col in [(P0[0:3], "x", "white"), (P0[3:6], "o", "lime"), (P0[6:9], "s", "yellow")]:
            uv = proj(pp); ax.plot(uv[:, 1], uv[:, 0], mk, mfc="none", mec=col, color=col, ms=14, mew=2)
    fig.suptitle("markers must sit on the EE (x), white mug (o), yellow-white mug (s)", fontsize=10)
    plt.tight_layout(); plt.savefig(f"{FIG}/A_projection_check.png", dpi=120); plt.close()

# ======================================================================
# (A) one-chunk steering paths
# ======================================================================

# ---------------- drawing and summary helpers (pure numpy / PIL / matplotlib; tested offline) ----------------
import json as _json
import numpy as _np
from PIL import Image as _Image, ImageDraw as _ImageDraw, ImageFont as _ImageFont

DIR_LABEL = {"Dphi^T lambda_psi": "probe via head  (lambda_psi)", "static": "static probe",
             "gamma_psi": "probe w/o head  (gamma_psi)"}
DIR_SHORT = {"Dphi^T lambda_psi": "probe via head", "static": "static probe", "gamma_psi": "probe w/o head"}


def _font(size):
    try:
        return _ImageFont.load_default(size=size)
    except TypeError:
        return _ImageFont.load_default()


def alpha_color(a, amax):
    if a == 0:
        return (235, 235, 235)
    t = min(1.0, abs(a) / amax)
    return (int(70 + 160 * t), 60, 60) if a > 0 else (60, int(110 + 40 * t), int(90 + 160 * t))


def draw_cell(frame, trail, ghost, target, color, label=None):
    """frame (H,W,3) uint8; trail/ghost (n,2) pixel (x,y) of EE so far; target (x,y) of the mug that defines psi"""
    im = _Image.fromarray(_np.ascontiguousarray(frame)).convert("RGB")
    d = _ImageDraw.Draw(im)
    if ghost is not None and len(ghost) > 1:
        d.line([tuple(p) for p in ghost], fill=(235, 235, 235), width=2)
    if trail is not None and len(trail) > 1:
        d.line([tuple(p) for p in trail], fill=color, width=3)
    if trail is not None and len(trail):
        x, y = trail[-1]; d.ellipse([x - 4, y - 4, x + 4, y + 4], fill=color, outline=(0, 0, 0))
    if target is not None:
        x, y = target; d.ellipse([x - 9, y - 9, x + 9, y + 9], outline=(255, 215, 0), width=3)
    if label:
        f = _font(13)
        d.rectangle([0, 0, 8 + 7 * len(label), 18], fill=(0, 0, 0))
        d.text((4, 2), label, fill=(255, 255, 255), font=f)
    return _np.asarray(im)


def grid_frame(cells, row_labels, col_labels, title, cell_px):
    """cells[r][c] (H,W,3) -> one frame with a title bar, column headers and row labels"""
    R, C = len(cells), len(cells[0])
    lw, th, ch = 150, 26, 22
    W, H = lw + C * cell_px, th + ch + R * cell_px
    im = _Image.new("RGB", (W, H), (255, 255, 255))
    d = _ImageDraw.Draw(im)
    d.text((8, 5), title, fill=(0, 0, 0), font=_font(15))
    for c, lab in enumerate(col_labels):
        d.text((lw + c * cell_px + 8, th + 3), lab, fill=(0, 0, 0), font=_font(14))
    for r in range(R):
        y0 = th + ch + r * cell_px
        for i, line in enumerate(row_labels[r].split("\n")):
            d.text((6, y0 + cell_px // 2 - 16 + 16 * i), line, fill=(0, 0, 0), font=_font(13))
        for c in range(C):
            im.paste(_Image.fromarray(cells[r][c]), (lw + c * cell_px, y0))
    return _np.asarray(im)


def write_video(path, frames, fps=10):
    import imageio
    try:
        imageio.mimsave(path, frames, fps=fps, codec="libx264", quality=8, macro_block_size=1)
        return path
    except Exception as ex:                                   # no ffmpeg: fall back to GIF
        alt = path.rsplit(".", 1)[0] + ".gif"
        imageio.mimsave(alt, frames, duration=1.0 / fps)
        print(f"  (mp4 failed: {ex}; wrote {alt})")
        return alt


def summary_figure(rows, out_png, scen_titles):
    """rows: list of dicts(scenario, psi, direction, effect_cm, other_cm) -> dot plot per scenario/psi"""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    keys = []
    for r in rows:
        k = (r["scenario"], r["psi"])
        if k not in keys:
            keys.append(k)
    dirs = list(DIR_SHORT)
    cols = {"Dphi^T lambda_psi": "#c0392b", "static": "#222222", "gamma_psi": "#2e6fb5"}
    fig, axes = plt.subplots(1, len(keys), figsize=(3.6 * len(keys), 3.4), squeeze=False)
    for ax, k in zip(axes[0], keys):
        for i, dn in enumerate(dirs):
            v = _np.array([r["effect_cm"] for r in rows if (r["scenario"], r["psi"]) == k and r["direction"] == dn])
            if not len(v):
                continue
            x = i + _np.linspace(-0.12, 0.12, len(v))
            ax.scatter(x, v, s=22, color=cols[dn], alpha=0.75, zorder=3)
            ax.plot([i - 0.25, i + 0.25], [_np.median(v)] * 2, color=cols[dn], lw=3, zorder=4)
        ax.axhline(0, color="0.6", lw=1)
        ax.set_xticks(range(len(dirs)))
        ax.set_xticklabels([DIR_SHORT[d] for d in dirs], rotation=15, fontsize=8)
        ax.set_title(scen_titles.get(k, f"{k[0]}: {k[1]}"), fontsize=9)
        ax.grid(axis="y", alpha=0.3)
    axes[0][0].set_ylabel("effect towards the goal (cm)\nsteered +16 vs -16, after 2.4 s")
    plt.tight_layout(); plt.savefig(out_png, dpi=170, bbox_inches="tight"); plt.close(fig)


def selectivity_figure(sel, out_png):
    """sel[(psi, measured)] = median change of the distance (cm, positive = closer) for the probe-via-head direction"""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    psis = ["-d(EE,mug1)", "-d(EE,mug2)"]
    M = _np.array([[sel.get((p, m), _np.nan) for m in psis] for p in psis])
    v = _np.nanmax(_np.abs(M)) if _np.isfinite(M).any() else 1.0
    fig, ax = plt.subplots(figsize=(3.8, 3.2))
    im = ax.imshow(M, cmap="RdBu_r", vmin=-v, vmax=v)
    for i in range(2):
        for j in range(2):
            ax.text(j, i, f"{M[i, j]:+.1f}", ha="center", va="center", fontsize=11,
                    color=("white" if _np.isfinite(M[i, j]) and abs(M[i, j]) > 0.6 * v else "black"))
    ax.set_xticks([0, 1]); ax.set_xticklabels(["closer to\nwhite mug", "closer to\nyellow-white mug"], fontsize=8)
    ax.set_yticks([0, 1]); ax.set_yticklabels(["steer: white mug", "steer: yellow-white mug"], fontsize=8)
    fig.colorbar(im, ax=ax, fraction=0.046, label="cm (median, +16 vs -16)")
    ax.set_title("selectivity of probe-via-head steering", fontsize=9)
    plt.tight_layout(); plt.savefig(out_png, dpi=170, bbox_inches="tight"); plt.close(fig)


def dump_json(path, obj):
    def conv(o):
        if isinstance(o, _np.ndarray):
            return _np.round(o.astype(float), 4).tolist()
        if isinstance(o, (_np.floating, _np.integer)):
            return o.item()
        raise TypeError(type(o))
    with open(path, "w") as f:
        _json.dump(obj, f, default=conv, separators=(",", ":"))


# ======================================================================
# STEP 8: CLOSED-LOOP DIRECTION COMPARISON (rebuttal videos + quantitative summary)
#   directions: probe via head (Dphi^T lambda_psi) | static probe | probe without head (gamma_psi)
#   recomputed at every re-plan from the current observation; alpha in {-16, 0, +16}
# ======================================================================
import subprocess, sys
try:
    import imageio_ffmpeg  # noqa: F401
except ImportError:
    subprocess.run([sys.executable, "-m", "pip", "install", "-q", "imageio-ffmpeg"], check=False)
OUT8 = "/content/drive/MyDrive/aclrh/rebuttal"
os.makedirs(f"{OUT8}/videos", exist_ok=True)
DIRS8 = ["Dphi^T lambda_psi", "static", "gamma_psi"]
ALPHAS8 = [-16.0, 0.0, 16.0]
AMAX = max(abs(a) for a in ALPHAS8)
CHUNKS8 = 6                              # 6 x 8 steps = 2.4 s
N_APPROACH = 6                           # held-out episodes, start of episode (scenario "approach")
N_CARRY = 6                              # held-out mid-episode states with the white mug in hand (scenario "carry")
N_VIDEO = 2                              # per scenario, the first N starts get videos
SCEN = {"approach": ["-d(EE,mug1)", "-d(EE,mug2)"], "carry": ["-d(mug1,plate) xy"]}
SCEN_TITLE = {("approach", "-d(EE,mug1)"): "approach the white mug",
              ("approach", "-d(EE,mug2)"): "approach the yellow-and-white mug",
              ("carry", "-d(mug1,plate) xy"): "carry the white mug to its plate"}
# which mug is the target of each psi (index into the 15 positions), and the metric to report (cm, + = goal)
TP8 = target_plates(dd["Q0"], EP, dd["SUCCESS_EP"])                  # position indices of each mug's target plate
TARGET = {"-d(EE,mug1)": 3, "-d(EE,mug2)": 6, "-d(mug1,plate) xy": int(TP8[0])}   # object marked as the goal
resize8 = ru.get_image_resize_size(cfg)
Mcam = None


def reset_to(start):
    """start = ("init", episode) or ("snap", state index) -> first observation"""
    env.env.timestep, env.env.done = 0, False
    env.reset()
    kind, idx = start
    if kind == "init":
        obs = env.set_init_state(init_states[idx])
        for _ in range(NUM_WAIT):
            obs, _, _, _ = env.step(lu.get_libero_dummy_action("openvla"))
    else:
        obs = env.set_init_state(SIMS[idx])
        g_ = GRIPS[idx]
        if g_ is not None and hasattr(env.env.robots[0].gripper, "current_action"):
            env.env.robots[0].gripper.current_action = np.asarray(g_, np.float64).copy()
    return obs


def rollout8(start, psi, dname, alpha, record):
    obs = reset_to(start)
    P, F = [positions(env)], ([lu.get_libero_image(obs)] if record else None)
    q = QOIS[psi]
    for _ in range(CHUNKS8):
        raw = np.asarray(ou.get_vla_action(cfg, vla, processor, rle.prepare_observation(obs, resize8)[0],
                                           task_description, action_head, proprio_projector), dtype=np.float64)
        lam0 = LAM["cap"][0].numpy().reshape(-1).astype(np.float32)
        if alpha == 0.0:
            chunk = executed(raw)
        else:
            v = directions(q, lam0)[dname]                               # recomputed at every re-plan
            chunk = head_chunks((lam0 + to_lam(alpha * v))[None])[0]
        for a in chunk:
            obs, _, _, _ = env.step(np.asarray(a).tolist())
            P.append(positions(env))
            if record:
                F.append(lu.get_libero_image(obs))
    return np.stack(P), (np.stack(F) if record else None)


def proj_xy(P3):
    rc = project_points_from_world_to_camera(np.asarray(P3, float).reshape(-1, 3), Mcam, IMG, IMG)
    r_, c_ = PROJ_MAPS[PROJ_MODE](rc[:, 0], rc[:, 1])
    return np.stack([c_, r_], 1)                                          # PIL (x, y)


def goal_metric(psi, P):
    """value of psi in cm along the rollout (larger = closer to the goal)"""
    return 100.0 * qoi(P)[:, QOIS[psi]]


# ---------------- choose the starts ----------------
held = sorted(B_eps)
starts = {"approach": [("init", int(e)) for e in held[:N_APPROACH]]}
qc = QOIS["-d(mug1,plate) xy"]
cB = np.where(~inA[CS])[0]
dq = QF[cB][:, :, qc] - Q0[CS[cB], qc][:, None]
frac = (np.abs(dq) > MOVE_MM).mean(1)
sd = dq.std(1)
order = [j for j in cB[np.argsort(-sd)] if frac[list(cB).index(j)] >= MIN_FRAC]
carry, seen = [], set()
for j in order:                                                           # one state per episode
    g_ = int(CS[j])
    if EP[g_] not in seen:
        carry.append(("snap", g_)); seen.add(EP[g_])
    if len(carry) == N_CARRY:
        break
starts["carry"] = carry
header("8. CLOSED-LOOP DIRECTION COMPARISON")
print("approach starts (held-out episodes):", [s[1] for s in starts["approach"]])
print("carry starts (held-out states, white mug in hand):", [s[1] for s in starts["carry"]])
n_roll = sum(len(v) * (1 + len(SCEN[k]) * len(DIRS8) * (len(ALPHAS8) - 1)) for k, v in starts.items())
print(f"{n_roll} closed-loop rollouts of {CHUNKS8} chunks", flush=True)

TRAJ8, rows, page = {}, [], {"scenarios": [], "alphas": ALPHAS8, "directions": DIRS8,
                            "dir_label": DIR_LABEL, "chunks": CHUNKS8, "dt": 0.05}
for scen, slist in starts.items():
    for si, start in enumerate(slist):
        rec = si < N_VIDEO
        base_P, base_F = rollout8(start, SCEN[scen][0], DIRS8[0], 0.0, rec)
        if Mcam is None:
            Mcam = get_camera_transform_matrix(env.env.sim, "agentview", IMG, IMG)
        for psi in SCEN[scen]:
            runs = {}
            for dn in DIRS8:
                for a in ALPHAS8:
                    runs[(dn, a)] = (base_P, base_F) if a == 0.0 else rollout8(start, psi, dn, a, rec)
            tgt = TARGET[psi]
            for dn in DIRS8:
                m = {a: goal_metric(psi, runs[(dn, a)][0]) for a in ALPHAS8}
                eff = m[ALPHAS8[-1]][-1] - m[ALPHAS8[0]][-1]
                other = None
                if scen == "approach":
                    opsi = "-d(EE,mug2)" if psi == "-d(EE,mug1)" else "-d(EE,mug1)"
                    om = {a: goal_metric(opsi, runs[(dn, a)][0]) for a in ALPHAS8}
                    other = om[ALPHAS8[-1]][-1] - om[ALPHAS8[0]][-1]
                ordered = bool(m[ALPHAS8[0]][-1] < m[0.0][-1] < m[ALPHAS8[-1]][-1])
                rows.append(dict(scenario=scen, start=int(start[1]), psi=psi, direction=dn,
                                 effect_cm=float(eff), other_cm=(None if other is None else float(other)),
                                 ordered=ordered))
                print(f"  {scen:8s} start {start[1]:4d} | {psi:18s} | {DIR_SHORT[dn]:15s} | psi after 2.4 s "
                      + " / ".join(f"{m[a][-1]:+.1f}" for a in ALPHAS8) + f" cm (alpha {ALPHAS8}) | effect {eff:+.1f} cm"
                      + ("" if other is None else f" | other mug {other:+.1f} cm"), flush=True)
            # page data (EE path in pixels and cm, psi over time)
            entry = {"scenario": scen, "title": SCEN_TITLE[(scen, psi)], "start": int(start[1]), "psi": psi,
                     "target_xy_px": proj_xy(base_P[0, tgt:tgt + 3])[0], "target_xy_cm": 100 * base_P[0, tgt:tgt + 2], "runs": []}
            for (dn, a), (P_, _) in runs.items():
                entry["runs"].append({"direction": dn, "alpha": a, "ee_px": proj_xy(P_[:, 0:3])[::2],
                                      "ee_xy_cm": 100 * P_[::2, 0:2], "psi_cm": goal_metric(psi, P_)[::2]})
            TRAJ8[(scen, start[1], psi)] = {k: v[0] for k, v in runs.items()}
            # videos
            if rec:
                tag = f"{scen}_{start[1]:04d}_{psi.replace('-d(', '').replace(')', '').replace(',', '_').replace(' xy', '')}"
                T = len(base_P)
                ghost = proj_xy(base_P[:, 0:3])
                frames_grid, frames_hero = [], []
                for t in range(T):
                    cells = []
                    for dn in DIRS8:
                        row_c = []
                        for a in ALPHAS8:
                            P_, F_ = runs[(dn, a)]
                            row_c.append(draw_cell(F_[t], proj_xy(P_[:t + 1, 0:3]), ghost[:t + 1] if a != 0 else None,
                                                   proj_xy(P_[t, tgt:tgt + 3])[0], alpha_color(a, AMAX)))
                        cells.append(row_c)
                    title = f"{SCEN_TITLE[(scen, psi)]}   |   psi = {psi}   |   held-out start {start[1]}   |   t = {t * 0.05:.2f} s"
                    frames_grid.append(grid_frame(cells, [DIR_LABEL[d].replace("  (", "\n(") for d in DIRS8],
                                                  [f"alpha = {a:+.0f}" for a in ALPHAS8], title, IMG))
                    hero = [[cells[0][1]] + [cells[i][-1] for i in range(len(DIRS8))]]   # unsteered | three directions at +AMAX
                    frames_hero.append(grid_frame(hero, [""], ["unsteered"] + [f"{DIR_SHORT[d]}, alpha = +{AMAX:.0f}" for d in DIRS8],
                                                  f"{SCEN_TITLE[(scen, psi)]}   |   t = {t * 0.05:.2f} s", IMG))
                vg = write_video(f"{OUT8}/videos/{tag}_grid.mp4", frames_grid, fps=10)
                vh = write_video(f"{OUT8}/videos/{tag}_hero.mp4", frames_hero, fps=10)
                entry["video_grid"], entry["video_hero"] = os.path.basename(vg), os.path.basename(vh)
                from PIL import Image as _I
                _I.fromarray(frames_grid[-1]).save(f"{OUT8}/videos/{tag}_grid_last.png")
                _I.fromarray(frames_hero[-1]).save(f"{OUT8}/videos/{tag}_hero_last.png")
                stamp(f"videos: {vg}, {vh}")
            page["scenarios"].append(entry)

# ---------------- summaries ----------------
header("SUMMARY (closed loop, 2.4 s, effect = psi(+16) - psi(-16) in cm; + = towards the goal)")
summ = {}
for (scen, psi) in SCEN_TITLE:
    for dn in DIRS8:
        r_ = [r for r in rows if r["scenario"] == scen and r["psi"] == psi and r["direction"] == dn]
        if not r_:
            continue
        e_ = np.array([r["effect_cm"] for r in r_]); o_ = np.mean([r["ordered"] for r in r_])
        oth = [r["other_cm"] for r in r_ if r["other_cm"] is not None]
        summ[(scen, psi, dn)] = dict(median=float(np.median(e_)), positive=float(np.mean(e_ > 0)), ordered=float(o_),
                                     other=(float(np.median(oth)) if oth else None), n=len(e_))
        print(f"{SCEN_TITLE[(scen, psi)]:36s} | {DIR_SHORT[dn]:15s} | effect median {np.median(e_):+5.1f} cm "
              f"| towards goal {np.mean(e_ > 0):4.0%} | ordered -16<0<+16 {o_:4.0%} | n {len(e_)}"
              + (f" | other mug median {np.median(oth):+.1f} cm" if oth else ""))
summary_figure(rows, f"{OUT8}/closed_loop_summary.png", {k: v for k, v in SCEN_TITLE.items()})
sel = {}
for psi in SCEN["approach"]:
    r_ = [r for r in rows if r["scenario"] == "approach" and r["psi"] == psi and r["direction"] == DIRS8[0]]
    sel[(psi, psi)] = float(np.median([r["effect_cm"] for r in r_]))
    opsi = "-d(EE,mug2)" if psi == "-d(EE,mug1)" else "-d(EE,mug1)"
    sel[(psi, opsi)] = float(np.median([r["other_cm"] for r in r_]))
selectivity_figure(sel, f"{OUT8}/closed_loop_selectivity.png")
page["summary"] = [dict(scenario=k[0], psi=k[1], direction=k[2], **v) for k, v in summ.items()]
page["rows"] = rows
dump_json(f"{OUT8}/page_data.json", page)
np.savez_compressed(f"{OUT8}/closed_loop_directions.npz",
                    **{f"{s}|{st_}|{p}|{d}|{a:+.0f}": P_ for (s, st_, p), runs in TRAJ8.items() for (d, a), P_ in runs.items()})
stamp(f"saved figures, page_data.json and trajectories in {OUT8}")
'''

with open("/content/run_oft_steer_videos.py", "w") as f:
    f.write(SCRIPT)
print("\nrunning figures in the Python 3.10 venv ...\n", flush=True)
p = subprocess.Popen([VPY, "-u", "/content/run_oft_steer_videos.py"], stdout=subprocess.PIPE,
                     stderr=subprocess.STDOUT, text=True,
                     env={**os.environ, "MUJOCO_GL": "egl",
                          "MPLBACKEND": "Agg",          # Colab sets a notebook-only backend
                          "TF_CPP_MIN_LOG_LEVEL": "2",  # silence TensorFlow start-up noise
                          "PYTHONPATH": f"{OFT}:{LIB}:" + os.environ.get("PYTHONPATH", "")})
for line in p.stdout:
    print(line, end="")
p.wait()
print(f"\nReturn code: {p.returncode}")
